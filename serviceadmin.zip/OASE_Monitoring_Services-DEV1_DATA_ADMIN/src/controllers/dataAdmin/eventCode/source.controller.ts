import { Response } from "express";
import { HTTP_NO_CONTENT } from "../../../constants/httpResponseCodes.constant";
import * as db from "../../../repositories/dataAdmin/eventCode/source.repository";
import { IGetAllRequest, IRequestQueryParams, TDbResponse, TRequestParams } from "../../../types/dataAdmin/dataAdmin.types";
import addPayloadToRequestHeader from "../../../utils/addPayloadToRequestHeader.util";
import { getInternalServerError, jsonSuccess } from "../../../utils/jsonMessage.util";
import { replaceNullOrEmptyStringArray } from "../../../utils/object/replaceNullOrEmptyStringArray.util";
import printToConsole from "../../../utils/printToConsole.util";

const message = {
   "english": `Successfully Retrieved Event Code Source`,
   "indonesia": `Berhasil Mengambil Event Code Source`,
}
const errorMessage = "Internal Server Error!";
const errorTag = "getEventCodeSource";

export async function getEventCodeSources(req: IGetAllRequest, res: Response) {
   addPayloadToRequestHeader(req);

   let dbRes: TDbResponse = [[], []];
   //const queryData: IRequestQueryParams = matchedData(req, { locations: ["query"] });
   const page = req?.query?.page;
   const limit = req?.query?.limit;
   const sortBy = req?.query?.sortBy;
   const orderBy = req?.query?.orderBy;
   const search = req?.query?.search;
   const advancedSearch = req?.query?.advancedSearch;
   const advancedSearchPeriode = req?.query?.advancedSearchPeriode;

   if (search) {
      const params = {
         search: JSON.parse(search)
      }

      dbRes = await db.getEventCodeSources(page!, limit!, sortBy!, orderBy!, params);
   }
   else if (advancedSearch || advancedSearchPeriode) {
      const params = {
         advancedSearch: advancedSearch ? JSON.parse(advancedSearch) : null,
         advancedSearchPeriode: advancedSearchPeriode ? JSON.parse(advancedSearchPeriode) : null
      }

      dbRes = await db.getEventCodeSources(page!, limit!, sortBy!, orderBy!, params);
   }
   else {
      dbRes = await db.getEventCodeSources(page!, limit!, sortBy!, orderBy!);
   }

   const [data, [total]] = dbRes;

   replaceNullOrEmptyStringArray(data);

   const payload = {
      ...total,
      data: data
   }

   res.send(jsonSuccess(message, payload));
}

export async function getEventCodeSourceList(req: IGetAllRequest, res: Response) {
   const dbRes: TDbResponse = await db.getEventCodeSourceList();

   const [data] = dbRes;

   const payload = {
      ...data
   }

   res.send(jsonSuccess(message, payload));
}

export async function getEventCodeSource(req: IGetAllRequest, res: Response) {
   addPayloadToRequestHeader(req);

   //const paramsData: TRequestParams = matchedData(req, { locations: ["params"] });

   const [data] = await db.getEventCodeSource(req?.params?.id!);

   res.send(jsonSuccess(message, data));
}

export async function postEventCodeSource(req: IGetAllRequest, res: Response) {
   addPayloadToRequestHeader(req);

   const name = req.kauth.grant?.access_token.content.preferred_username;

   const message = {
      "english": `Successfully Insert An Event Code Source`,
      "indonesia": `Berhasil Memasukkan Sebuah Event Code Source`,
   }

   await db.postEventCodeSource(req?.body, name);

   res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function putEventCodeSource(req: IGetAllRequest, res: Response) {
   addPayloadToRequestHeader(req);

   const name = req.kauth.grant?.access_token.content.preferred_username;
   //const bodyData = matchedData(req, { locations: ["body"] });
   // const paramsData = matchedData(req, { locations: ["params"] });
   const message = {
      "english": `Successfully Updated An Event Code Source`,
      "indonesia": `Berhasil Mengubah Sebuah Event Code Source`,
   }

   await db.putEventCodeSource(req?.body, req?.params?.id, name);

   res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function deleteEventCodeSource(req: IGetAllRequest, res: Response) {
   addPayloadToRequestHeader(req);
   const name = req.kauth.grant?.access_token.content.preferred_username;
   // const paramsData = matchedData(req, { locations: ["params"] });

   const message = {
      "english": `Successfully Delete An Event Code Source`,
      "indonesia": `Berhasil Menghapus Sebuah Event Code Source`,
   }

   await db.deleteEventCodeSource(req?.params?.id, name);

   res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export { };

