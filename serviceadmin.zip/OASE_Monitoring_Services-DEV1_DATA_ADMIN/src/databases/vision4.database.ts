import * as databaseConfig from "../configs/database.config";
import { VISION4_QUERY_ERRORS } from "../constants/database.constant";
import env from "../env/server.env";
import { DatabaseError } from "../errors/server.error";

const sql = require("mssql");

const environment = `[${env.NODE_ENV?.toUpperCase()}]`;

let pool: any;

const VISION4_CONNECTION_STATUS = {
	CONNECTING: `${environment}: Connecting to VISION4...`,
	CONNECTED: `\r${environment}: Connected to VISION4    \n`,
	CONNECTION_FAILED: `\r${environment}: Failed to connect to VISION4\n`,
};

export const connect = async () => {
	process.stdout.write(VISION4_CONNECTION_STATUS.CONNECTING);
	try {
		pool = await sql.connect(databaseConfig.vision4);
		await execMssql("select 1");
		process.stdout.write(VISION4_CONNECTION_STATUS.CONNECTED);
	} catch (error) {
		process.stdout.write(VISION4_CONNECTION_STATUS.CONNECTION_FAILED);
		throw new DatabaseError(
			"Unable to connect to VISION4",
			"DATABASE_VISION4_CONNECTION_TIMEOUT"
		);
	}
};

export const execMssql = async (query: string) => {
	try {
		let res = await pool.request().query(query);
		return res.recordset;
	} catch (err) {
		//@ts-ignore
		if (VISION4_QUERY_ERRORS.hasOwnProperty(err.code)) {
			//@ts-ignore
			const { message, code } = VISION4_QUERY_ERRORS[err.code];
			throw new DatabaseError(message, code);
		}

		throw new DatabaseError("Database error", "DATABASE_VISION4_GENERAL_ERROR");
	}
};

export { };

