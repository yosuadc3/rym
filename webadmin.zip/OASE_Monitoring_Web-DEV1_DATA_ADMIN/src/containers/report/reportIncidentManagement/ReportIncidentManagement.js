import FilterListIcon from "@mui/icons-material/FilterList";
import { Box, Button, Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import BaseBreadcrumbs from "../../../components/breadcrumb/BaseBreadcrumbs";
import ButtonExportV2 from "../../../components/buttons/ButtonExportV2";
import EmptyCard from "../../../components/cards/EmptyCard";
import SkeletonText from "../../../components/skeleton/SkeletonText";
import StyledTableV2 from "../../../components/table/StyledTableV2";
import useFetch from "../../../hooks/useFetch";
import { toParams } from "../../../utilities/Axios";
import { MSSQLTimeFormat } from "../../../utilities/TimeConverter";
import FilterBox from "./components/FilterBox";
import {
	DATE_OBJ,
	FILTER_OBJ,
	REPORT_FILTER_COLUMNS,
	REPORT_HEADER,
	REPORT_INCIDENT_BREADCRUMBS,
	styles,
} from "./constants/ReportIncidentManagement";

const ReportInfo = ({ query, isRefetch, setHasRows, setDisabledSearch }) => {
	const endpoint = `info?${query}`;
	const [isFirstRender, setIsFirstRender] = useState(true);
	const { data, isLoading, fetch } = useFetch(endpoint, "incident");

	useEffect(() => {
		if (isFirstRender) {
			setIsFirstRender((_) => false);
			return;
		}
		fetch(endpoint, "incident");
	}, [isRefetch]);

	useEffect(() => {
		if (data && data.data) {
			setDisabledSearch(prev => false);
			setHasRows(data?.data?.total !== 0)
		}
	}, [data])

	if (isLoading) {
		return (
			<div style={{ marginLeft: "12px" }}>
				<Typography sx={styles.reportTitle}>
					<SkeletonText height={30} width={300} />
				</Typography>
				<Typography sx={styles.reportDescription}>
					<SkeletonText height={20} width={400} />
				</Typography>
			</div>
		);
	}

	const showTotal = data?.data?.showTotal;
	const total = data?.data?.total || 0;

	return (
		<div style={{ marginLeft: "12px" }}>
			{total !== 0 ? (
				<>
					<Typography sx={styles.reportTitle}>
						Report Incident Management
					</Typography>
					<Typography sx={styles.reportDescription}>
						Data yang ditampilkan {showTotal} dari {total} record, untuk melihat
						lebih lengkap dapat klik 'Download File'
					</Typography>
				</>
			) : null}
		</div>
	);
};

export default function ReportIncident() {
	const [hasSearch, setHasSearch] = useState(false);
	const [searchQuery, setSearchQuery] = useState("");
	const [isFirstRender, setIsFirstRender] = useState(true);
	const [trigger, setTrigger] = useState(false);
	const [hasRows, setHasRows] = useState(false);
	const [disabledSearch, setDisabledSearch] = useState(false);

	const [filter, setFilter] = useState([FILTER_OBJ]);
	const [date, setDate] = useState(DATE_OBJ);

	const [isOpen, setIsOpen] = useState(true);

	useEffect(() => {
		if (isFirstRender) {
			setIsFirstRender((_) => false);
			return;
		}
		setTrigger((_) => true);
	}, [hasSearch]);

	const handleHasSearch = () => {
		setHasSearch((prev) => !prev);
		setIsOpen((prev) => !prev);
	};

	const handleTogglePopup = () => {
		setIsOpen((prev) => !prev);
	};

	const getFilter = () => {
		setDisabledSearch(prev => true);
		const filterQueries = filter.reduce((newObj, curr) => {
			const values = curr.values.join(",");
			newObj[curr.category] = values;
			return newObj;
		}, {});

		const query = {
			startDate: MSSQLTimeFormat(date.start),
			endDate: MSSQLTimeFormat(date.end),
			...filterQueries,
		};

		const params = "&" + toParams(query);
		setSearchQuery(() => params);
	};

	return (
		<Box>
			<BaseBreadcrumbs breadcrumbs={REPORT_INCIDENT_BREADCRUMBS} />
			<Grid>
				<Grid item container xs={4}>
					<div style={styles.filterBtnDiv}>
						<Button
							startIcon={<FilterListIcon sx={styles.filterIcon} />}
							sx={styles.filterBtn}
							onClick={handleTogglePopup}
						>
							Filter
						</Button>
						{(hasSearch || trigger) && (
							<ReportInfo query={searchQuery} isRefetch={hasSearch} setHasRows={setHasRows} setDisabledSearch={setDisabledSearch} />
						)}
					</div>
				</Grid>
			</Grid>
			<Grid container spacing={2}>
				{isOpen && (
					<Grid item xs={3}>
						<FilterBox
							categories={REPORT_FILTER_COLUMNS}
							freeSolo
							getter={getFilter}
							handleHasSearch={handleHasSearch}
							date={date}
							setDate={setDate}
							filter={filter}
							setFilter={setFilter}
							disabled={disabledSearch}
						/>
					</Grid>
				)}
				{(hasSearch || trigger) && (
					<Grid item xs={isOpen ? 9 : 12}>
						<EmptyCard sx={styles.tableDiv(isOpen)}>
							<StyledTableV2
								headers={REPORT_HEADER}
								defaultSortBy="id"
								link="report-preview"
								route="incident"
								useReportTheme
								searchQuery={searchQuery}
								refetchDependencies={[hasSearch]}
							/>
						</EmptyCard>
						{hasRows && (
							<div style={styles.downloadDiv}>
								<ButtonExportV2
									link="report"
									route="incident"
									query={searchQuery}
									timestamp={true}
									filename="Report Incident Management"
									trigger={[hasSearch]}
									disabled={disabledSearch}
									extension="xlsx"
								/>
							</div>
						)
						}
					</Grid>
				)}
			</Grid>
		</Box>
	);
}
