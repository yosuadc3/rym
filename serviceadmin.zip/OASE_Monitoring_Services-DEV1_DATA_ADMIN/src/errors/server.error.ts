import * as httpCodes from "../constants/httpResponseCodes.constant";
import env from "../env/server.env";
import { jsonFailed } from "../utils/jsonMessage.util";
import GlobalError from "./global.error";

abstract class ServerError extends GlobalError {
   errorCode: number;
   errorType: string;

   constructor(
      message: string,
      errorCode: number,
      errorType: string,
      private property: string
   ) {
      super(message);
      this.errorCode = errorCode;
      this.errorType = errorType;

      Object.setPrototypeOf(this, ServerError.prototype);
   }

   serializeErrors(): ReturnType<typeof jsonFailed> {
      if (env.NODE_ENV === "production") {
         return jsonFailed(this.errorCode, this.errorType, this.errorType, "XX");
      }
      return jsonFailed(this.errorCode, this.property, this.message, "XX");
   }
}

export class DatabaseError extends ServerError {
   constructor(message: string, property: string) {
      super(
         message,
         httpCodes.HTTP_INTERNAL_SERVER_ERROR,
         "DATABASE_ERROR",
         property
      );
      Object.setPrototypeOf(this, DatabaseError.prototype);
   }
}

export class InternalServerError extends ServerError {
   constructor(message: string, property: string) {
      super(
         message,
         httpCodes.HTTP_INTERNAL_SERVER_ERROR,
         "INTERNAL_SERVER_ERROR",
         property
      );
      Object.setPrototypeOf(this, InternalServerError.prototype);
   }
}

export class ServiceUnavailable extends ServerError {
   constructor(message: string, property: string) {
      super(
         message,
         httpCodes.HTTP_SERVICE_UNAVAILABLE,
         "SERVICE_UNAVAILABLE",
         property
      );
      Object.setPrototypeOf(this, ServiceUnavailable.prototype);
   }
}

export class APIError extends ServerError {
   constructor(message: string, property: string) {
      super(
         message,
         httpCodes.HTTP_INTERNAL_SERVER_ERROR,
         "API_ERROR",
         property
      );
      Object.setPrototypeOf(this, APIError.prototype);
   }
}

export class BadGatewayError extends ServerError {
   constructor(message: string, property: string) {
      super(message, httpCodes.HTTP_BAD_GATEWAY, "GATEWAY_ERROR", property);
      Object.setPrototypeOf(this, BadGatewayError.prototype);
   }
}

export class GatewayTimeoutError extends ServerError {
   constructor(message: string, property: string) {
      super(message, httpCodes.HTTP_GATEWAY_TIMEOUT, "GATEWAY_TIMEOUT", property);
      Object.setPrototypeOf(this, GatewayTimeoutError.prototype);
   }
}
