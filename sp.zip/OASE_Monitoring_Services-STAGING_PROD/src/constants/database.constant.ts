exports.DB_MONITORING = process.env.DB_SCHEMA_OASEMON
