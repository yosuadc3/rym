import { axiosGet } from "../utilities/Fetch";

export function getLostComm() {
	return async (dispatch) => {
		try {
			const res = await axiosGet("lost-comm");
			dispatch({
				type: "GET_LOST_COMM",
				payload: {
					data: res?.data,
					message: res?.error_message?.english,
				},
			});
		} catch (error) {
			throw error;
		}
	};
}

export function getLostCommReport() {
	return async (dispatch) => {
		try {
			const dispatchAction = {
				type: "GET_LOST_COMM_REPORT",
				loading: {
					report: true
				}
			}
			dispatch(dispatchAction);
			const res = await axiosGet("lost-comm/report");
			dispatch({
				...dispatchAction,
				payload: {
					data: res?.data,
					message: res?.error_message?.english,
				},
				loading: {
					report: false
				}
			});
		} catch (error) {
			throw error;
		}
	};
}
