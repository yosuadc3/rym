import React from "react";
import { Box } from "@mui/material";
import { useEffect, useState } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from "recharts";
import TimeRange from "../dateTimePicker/DateTimePicker";

function Chart(props) {
    const n_data = 100;
    const [data, setData] = useState(initialData(n_data));

    const updateInterval = 10000;

    useEffect(() => {
        const interval = setInterval(() => {
            setData(initialData(n_data));
        }, updateInterval);

        return () => clearInterval(interval);
    });

    return (
        <Box sx={{ borderRadius: "8px", boxShadow: "6" }}>
            <Box paddingTop={1} paddingRight={1.5}>
                <TimeRange />
            </Box>
            <ResponsiveContainer aspect={3.4}>
                <AreaChart data={data} margin={{ top: 10, right: 40, left: 0, bottom: 0 }}>
                    <XAxis dataKey="time" />
                    <YAxis domain={[0, 10]} />
                    <Tooltip />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Area type="monotone" dataKey="lost" stroke="#156db8" fill="#156db8" dot={true} fillOpacity={0.3} isAnimationActive={true} />
                </AreaChart>
            </ResponsiveContainer>
        </Box>
    );
}

//Dummy data
function initialData(n) {
    let data = [];

    const randomNum = () => {
        return Math.floor(Math.random() * 10);
    };

    for (let i = 0; i < n; i++) {
        data.push({
            time: "03:00",
            lost: randomNum()
        });
    }
    return data;
}

export default Chart;