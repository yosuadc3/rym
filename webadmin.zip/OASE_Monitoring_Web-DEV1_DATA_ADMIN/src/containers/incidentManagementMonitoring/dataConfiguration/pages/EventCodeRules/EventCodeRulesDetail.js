import { Typography,Grid } from "@mui/material";
import CustomBreadcrumbs from "../../../../../components/breadcrumb/CustomBreadcrumbs";
import React from "react";
import {useParams} from "react-router-dom"
import {useGetEventCodeRulesByIdQuery} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeRules/api/eventCodeRules'
import { useState, useEffect } from "react";

export default function EventCodeRulesDetail(){
    const {id} = useParams()
    const { data: ruleData, isLoading: ruleIsLoading} = useGetEventCodeRulesByIdQuery(id);
    const [data, setData] = useState({});

    const BREADCRUMBS = [
        {
            item: "Home",
            link: "/",
            current: false
        },
        {
            item: "Incident Management & Monitoring",
            link: null,
            current: false
        },
        {
            item: "Data Configuration",
            link: null,
            current: false
        },
        {
            item: "Event Code Rules",
            link: "/data-configuration/event-code-rules/",
            current: false
        },
        {
            item: data.rule,
            link: null,
            current: true
        },
    ];

    useEffect(() => {
        if (!ruleIsLoading) {
            const { data} = ruleData;
            setData(data);
        }
    }, [ruleData, ruleIsLoading]);

    return(
        <>
         <Grid container alignItems={"center"} height={50} marginBottom={2}>
                <Grid item xs={12}>
                    <CustomBreadcrumbs breadcrumbs={BREADCRUMBS} />
                </Grid>
            </Grid>
            <Typography variant="h4">ID: {data.id}</Typography>
            <Typography variant="h4">Rule: {data.rule}</Typography>
            <Typography variant="h4">Ticket Action: {data.ticket_action}</Typography>
            <Typography variant="h4">Email Action: {data.email_action}</Typography>
            <Typography variant="h4">Fault Category: {data.fault_category}</Typography>
        </>
        
    );
}