//Incident Router
import * as incident from "../../controllers/incident/incident.controller";
// import * as incidentV1 from "../../controllers/incident/incident.v1.controller";
import { protect } from "../../middlewares/keycloakHandler.middleware";
let router = require("express").Router();

// VALIDATION
import validation from "../../middlewares/validator.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
import * as validationRules from "../../validators/incident/incidentManagement.validator";
import * as validationRulesDetail from "../../validators/incident/incidentManagementDetail.validator";
import * as validationRulesReport from "../../validators/incident/incidentManagementReport.validator";

/** Incident Management */
router.get(
	"/v2/category",
	protect(["LIST_INCIDENT_MANAGEMENT"]),
	validation(validationRules.getIncidentCategory),
	errorWrapper(incident.getIncidentCategory)
);
router.get(
	"/v1/tickets",
	protect(["LIST_INCIDENT_MANAGEMENT"]),
	validation(validationRules.getIncidentID),
	errorWrapper(incident.getIncidentID)
);

/** Incident Management Detail */
router.get(
	"/v1/incident",
	protect(["GET_INCIDENT_DETAIL"]),
	validation(validationRulesDetail.getIncidentCurrent),
	errorWrapper(incident.getIncidentCurrent)
);
router.get(
	"/v1/terminal",
	protect(["GET_INCIDENT_DETAIL"]),
	validation(validationRulesDetail.getTerminalDetails),
	errorWrapper(incident.getTerminalDetails)
);
router.get(
	"/v1/status",
	protect(["GET_INCIDENT_DETAIL"]),
	validation(validationRulesDetail.getTerminalCurrentStatus),
	errorWrapper(incident.getTerminalCurrentStatus)
);
router.get(
	"/v1/history",
	protect(["GET_INCIDENT_DETAIL"]),
	validation(validationRulesDetail.getIncidentHistory),
	errorWrapper(incident.getIncidentHistory)
);
router.get(
	"/v1/comment",
	protect(["LIST_INCIDENT_MANAGEMENT"]),
	validation(validationRulesDetail.getIncidentComments),
	errorWrapper(incident.getIncidentComments)
);
router.post(
	"/v1/comment",
	protect(["LIST_INCIDENT_MANAGEMENT"]),
	validation(validationRulesDetail.postIncidentComment),
	errorWrapper(incident.postIncidentComment)
);

/** Report */
router.get(
	"/v1/report",
	protect(["LIST_INCIDENT_MANAGEMENT"]),
	validation(validationRulesReport.getIncidentReport),
	errorWrapper(incident.getIncidentReport)
);
router.get(
	"/v1/report-preview",
	protect(["LIST_INCIDENT_MANAGEMENT"]),
	validation(validationRulesReport.getIncidentReport),
	errorWrapper(incident.getIncidentReportPreview)
);
router.get(
	"/v1/info",
	protect(["LIST_INCIDENT_MANAGEMENT"]),
	validation(validationRulesReport.getIncidentReport),
	errorWrapper(incident.getIncidentReportInfo)
);

export default router;
export { };

