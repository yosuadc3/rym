const constant = require("../constants/dsa.constant");
const dbExec = require("../databases/gasper.database").exec;

export const get = () => {
  // const query =
  //     `SELECT ID, SUBSTR(DESCRIPTION,1,4) AS PENGELOLA FROM GASPER_OBJECT GO JOIN INSTITUTION I ON GO.INSTITUTION_LINK = I.LINK
  //     WHERE OBJECT_KEY IN (SELECT DISTINCT OBJECT_KEY FROM OPEN_TICKET WHERE STATUS_CODE_KEY in (` + constant.DSA_OFF_STATUS_CODE_KEY + `) AND TICKET_KEY IS NOT NULL)
  //     ORDER BY DESCRIPTION ASC`;

  const query = `SELECT LISTAGG(ID, ',') WITHIN GROUP(ORDER BY ID) AS ID, COUNT(ID) AS JUMLAH, SUBSTR(DESCRIPTION,1,4) AS PENGELOLA FROM GASPER_OBJECT GO
    JOIN INSTITUTION I ON GO.INSTITUTION_LINK = I.LINK
    WHERE OBJECT_KEY IN (SELECT DISTINCT OBJECT_KEY FROM OPEN_TICKET WHERE STATUS_CODE_KEY in (${constant.DSA_OFF_STATUS_CODE_KEY}) AND TICKET_KEY IS NOT NULL) 
    GROUP BY DESCRIPTION
    ORDER BY DESCRIPTION ASC`;

  return dbExec(query);
}

export const getReport = () => {
  const query = `SELECT ID, TICKET_KEY, ADDRESS as LOCATION, I.DESCRIPTION AS PENGELOLA,s.DESCRIPTION AS STATUS_CODE_DESCRIPTION, 
        to_CHAR(Start_time,'mm/dd/yyyy') as TICKET_START_DATE, 
        to_CHAR(Start_time,'HH24:MI:SS') as TICKET_START_TIME, 
        to_CHAR(end_time, 'mm/dd/yyyy') as TICKET_END_DATE,
        to_CHAR(end_time, 'HH24:MI:SS') as TICKET_END_TIME,
        to_CHAR((end_time-start_time)+(end_time-start_time)*60+(end_time-start_time)*24*60,99999999) as DURATION_IN_MINUTES,
        go.notes AS ADDRESS
        FROM gasper_object go join ticket t on go.object_key = t.object_key 
        join status_code s on s.LINK = t.status_code_key 
        join INSTITUTION I on I.LINK = go.INSTITUTION_LINK
        where STATUS_CODE_KEY IN (${constant.DSA_OFF_STATUS_CODE_KEY}) and
        t.Start_time >= TRUNC(SYSDATE)`;

  return dbExec(query);
}

export const getTotal = () => {
  const query = `SELECT COUNT(ID) AS JUMLAH FROM GASPER_OBJECT
    WHERE OBJECT_KEY IN (SELECT DISTINCT OBJECT_KEY FROM OPEN_TICKET WHERE STATUS_CODE_KEY in (${constant.DSA_OFF_STATUS_CODE_KEY}) AND TICKET_KEY IS NOT NULL)`;

  return dbExec(query);
}

export { };
