import * as controller from "../../../controllers/dataAdmin/eventCode/source.controller";
import validation from "../../../middlewares/validator.middleware";
import errorWrapper from "../../../utils/errorWrapper.util";
import * as validationRules from "../../../validators/dataAdmin/eventCode/source.validator";
const router = require("express").Router();
const keycloak = require("../../../middlewares/keycloakHandler.middleware").get();

router.get("/", validationRules.getEventCodeSources, validation(validationRules.getEventCodeSources), errorWrapper(controller.getEventCodeSources));
router.post("/", validationRules.postEventCodeSource, validation(validationRules.postEventCodeSource), errorWrapper(controller.postEventCodeSource));
router.get("/list", errorWrapper(controller.getEventCodeSourceList));
router.get("/:id", validationRules.getEventCodeSource, validation(validationRules.getEventCodeSource), errorWrapper(controller.getEventCodeSource));
router.put("/:id", validationRules.putEventCodeSource, validation(validationRules.putEventCodeSource), errorWrapper(controller.putEventCodeSource));
router.delete("/:id", validationRules.deleteEventCodeSource, validation(validationRules.deleteEventCodeSource), errorWrapper(controller.deleteEventCodeSource));

export default router;