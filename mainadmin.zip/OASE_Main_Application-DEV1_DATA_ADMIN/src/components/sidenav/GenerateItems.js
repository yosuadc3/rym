import React from 'react';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import Link from '@mui/material/Link';
// import { Link } from 'react-router-dom';
import { hasRoles } from '../../token/roles';

const styles = {
    text: {
        color: "white",
        height: "auto",
    },
}

function GenerateItems(props) {
    const items = props.items;
    const level = props.level;

    return items.map(value => {
        if (value.roles) {
            if (hasRoles(value.roles)) {
                return listItemsComponent(value.key, value.link, value.text, level);
            }
        }
        else {
            return listItemsComponent(value.key, value.link, value.text, level);
        }
    });
}

function listItemsComponent(key, link, text, level) {
    return (
        <ListItemButton key={key} component={Link} href={`/#${link}`}>
            <ListItemText inset primary={<Typography marginLeft={level + 1} sx={styles.text}>{text}</Typography>} />
        </ListItemButton>
    );
}

export default GenerateItems;