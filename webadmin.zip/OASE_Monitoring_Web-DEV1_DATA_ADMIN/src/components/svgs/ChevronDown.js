import { SvgIcon } from "@mui/material";
import React from "react";

export default function ChevronDown(props) {
	return (
		<SvgIcon {...props}>
			<svg
				// width="21"
				height="24px"
				viewBox="0 0 24 12"
				// fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M0.430837 0.962087C0.796954 0.595971 1.39055 0.595971 1.75666 0.962087L10.1562 9.36168L18.5558 0.962088C18.9219 0.595972 19.5155 0.595972 19.8817 0.962089C20.2478 1.32821 20.2478 1.9218 19.8817 2.28791L10.8192 11.3504C10.453 11.7165 9.85945 11.7165 9.49333 11.3504L0.430837 2.28791C0.0647208 1.9218 0.0647208 1.3282 0.430837 0.962087Z"
					fill="#0D5CAB"
				/>
			</svg>
		</SvgIcon>
	);
}
