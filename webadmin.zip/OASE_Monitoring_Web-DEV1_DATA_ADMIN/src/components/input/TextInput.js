import React from "react";
import { TextField } from "@mui/material";

function TextInput({ autoFocus, error, helperText, onChange, variant, value, sx, ...other }) {
    return (
        <TextField
            {...other}
            type={"text"}
            autoFocus={autoFocus}
            error={error}
            helperText={helperText}
            onChange={onChange}
            variant={variant}
            value={value}
            sx={sx}
        />
    )
}

export default TextInput;