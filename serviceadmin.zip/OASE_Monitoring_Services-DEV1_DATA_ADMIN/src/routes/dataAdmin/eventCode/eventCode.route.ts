import group from "./group.route";
import index from "./index.route";
import rule from "./rule.route";
import source from "./source.route";
import action from "../ticketAction.route"
const router = require("express").Router();

router.use("/source", source);
router.use("/group", group);
router.use("/rule", rule);
router.use("/action", action);
router.use("/", index);

export default router;