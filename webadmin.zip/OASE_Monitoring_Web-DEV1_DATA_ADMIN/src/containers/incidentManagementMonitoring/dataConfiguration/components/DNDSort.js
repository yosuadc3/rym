import React, { useState,useEffect } from 'react';
import { Grid,} from '@mui/material';
import Order from '../../../../components/svgs/Order';
import { useDrag, useDrop } from 'react-dnd';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import { useRef } from 'react';
import { useNavigate } from "react-router-dom";
import RuleAction from './action/RuleAction';
export default function DNDSort({
    data,
    moveRow=()=>{},
    changeIndex = ()=>{},
    headers,
}){
    const ref = useRef(null);
    const navigate = useNavigate();
    const handleCellClick = (id) =>{
        navigate('/data-configuration/event-code-rules/'+id);
    }
    const [, drop] = useDrop({
        accept: 'ROW',
        hover(item, monitor) {
            if (!ref.current) {
                return;
            }
            const dragIndex = item.index;
            const dragData =  item.data;
            const hoverIndex =   data.priority-1;
            if (dragIndex === hoverIndex) {
                return;
            }
            
            const hoverBoundingRect = ref.current?.getBoundingClientRect();
            const hoverMiddleY =
                (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
            const clientOffset = monitor.getClientOffset();
            const hoverClientY = clientOffset.y - hoverBoundingRect.top;
            if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
                return;
            }
            if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
                return;
            }
            moveRow(dragData,dragIndex,hoverIndex,item.sourceIndex);
            item.index = hoverIndex;
        },
        drop(item) {
            if(item.sourceIndex != item.index){
                const data = {
                    "id": item.data.id,
                    "start_priority": item.sourceIndex+1,
                    "end_priority": item.index+1
                }
                changeIndex(data);
            }
          },
    });
     const [{ isDragging },handle,drag] = useDrag({
        type: 'ROW',
        item: () => {
            return { data: data , index: data.priority-1, sourceIndex:  data.priority-1 };
        },
        collect: (monitor) => ({
        isDragging: monitor.isDragging(),
        }),
    });

    useEffect(()=>{
        if(ref.current){
            if(isDragging){
                ref.current.style.opacity = 0;
            }else{
                ref.current.style.opacity = 1;   
            }
        }
    },[isDragging]);
    
    drag(drop(ref));
    return(
        <TableRow component={"div"}
        onClick={()=> handleCellClick(data.id)}
        ref= {ref}
        >
            {headers.map(header=>{
                if(header.field === "-"){
                    return ( <TableCell key={header.field} component={"div"} align="center">  
                    <Grid container justifyContent={"center"} gap={2}>
                       {header.component(data)}
                        <Grid item ref = {handle} >
                            <Order
                                onMouseDown={(e) => {e.stopPropagation();}}
                                sx={{ display:"block",color: "#8D8D8D",marginTop: "-2px",marginLeft:"-5px"}}
                            />
                        </Grid>
                    </Grid>
                </TableCell>);
                }else if(header.field === "color"){
                    return (<TableCell key={header.field} component={"div"} align="center">  
                    {header.component(data[header.field])}
                </TableCell>);
                }else{
                return <TableCell key={header.field} component="div" align={header.align}>{data[header.field]}</TableCell>
                }
            })}   
        </TableRow>
    );
}