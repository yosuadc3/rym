import * as lostComm from "../../controllers/lostComm/lostComm.controller";
import { protect } from "../../middlewares/keycloakHandler.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
let router = require("express").Router();

router.get("/", protect(["GET_LOST_COMM"]), errorWrapper(lostComm.getLostComm));
router.get(
	"/report",
	protect(["GET_LOST_COMM_REPORT"]),
	errorWrapper(lostComm.getLostCommReport)
);

export default router;
export { };

