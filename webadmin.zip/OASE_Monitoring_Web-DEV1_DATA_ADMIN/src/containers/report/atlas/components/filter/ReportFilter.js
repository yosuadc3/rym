import DeleteIcon from '@mui/icons-material/Delete';
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from 'react-redux';
import AutocompleteFreeSolo from "../../../../../components/autocomplete/AutocompleteFreeSolo";
import ButtonCommon from "../../../../../components/buttons/ButtonCommon";
import EmptyCard from "../../../../../components/cards/EmptyCard";
import DateRangePicker from "../../../../../components/dateTimePicker/DateRangePicker";
import BasicSelect from "../../../../../components/select/BasicSelect";
import { useGetReportFiltersQuery, useGetReportTypeQuery } from '../../../../../redux/features/report/atlas/api/reportAtlas';
import { hasRoles } from "../../../../../token/roles";
import { dateAdd, dateSubtract } from "../../../../../utilities/DateManipulator";
import { customFormat } from "../../../../../utilities/TimeConverter";
import { setType as setTypeReducer, setFilter as setFilterReducer, setPeriode as setPeriodeReducer } from "../../../../../redux/features/report/atlas/reportAtlas";

const styles = {
    label: {
        color: "#65748B",
        fontWeight: "bold",
    },
    btnSearch: {
        fontSize: "16px",
        fontWeight: "bold"
    },
    btnResetFilter: {
        fontSize: "14px",
        fontWeight: "bold",
        px: 0,
        py: 0,
        "&:hover": {
            backgroundColor: "transparent"
        }
    },
    btnAddSearchCategory: {
        fontSize: "0.7vw",
        fontWeight: "bold",
        px: 0,
        py: 0,
        "&:hover": {
            backgroundColor: "transparent"
        },
        textDecoration: "underline"
    },
    btnDeleteSelect: {
        color: "#8D8D8D",
        px: 0,
        py: 0,
        "&:hover": {
            backgroundColor: "transparent"
        },
        minWidth: 0
    }
};

function checkReportsRole(types) {
    const result = [];

    types.forEach((item) => {
        if (hasRoles([item.role_name])) {
            result.push(item);
        }
    });

    return result;
}

function FilterCategoryComponent({ id, categories, options, handleSelectCategory, handleSelectValues, handleDelete, selectedCategory, selectedValues, disabled }) {
    return (
        <Grid key={id} container marginBottom={1}>
            <Grid item xs={id === 0 ? 6 : 5.5}>
                <BasicSelect items={categories} onChange={(event) => handleSelectCategory(event, id)} value={selectedCategory} disabled={disabled} />
            </Grid>
            <Grid item xs={id === 0 ? 6 : 5.5} paddingLeft={1}>
                <AutocompleteFreeSolo onChange={(event, values) => handleSelectValues(values, id)} value={selectedValues} options={options} disabled={disabled} />
            </Grid>
            {
                id === 0 ? <></> : <Grid item alignSelf={"center"} textAlign={"center"} xs={1}>
                    <ButtonCommon
                        handleClick={() => handleDelete(id)}
                        label={<DeleteIcon />}
                        variant={"text"}
                        sx={styles.btnDeleteSelect}
                        disabled={disabled}
                    />
                </Grid>
            }
        </Grid>
    )
}

function ReportFilter({ }) {
    const filterObjTemplate = {
        category: "",
        values: []
    }
    const dateObjTemplate = {
        start: null,
        end: null
    };
    const dispatch = useDispatch();
    const type = useSelector((state) => state.reportAtlas.type);
    const [skipUseQuery, setSkipUseQuery] = useState(true);
    const [categories, setCategories] = useState([]);
    const [values, setValues] = useState([]);
    const [filter, setFilter] = useState([filterObjTemplate]);
    const [date, setDate] = useState(dateObjTemplate);
    const [dateError, setDateError] = useState(dateObjTemplate);
    const [filterDisabled, setFilterDisabled] = useState(true);
    const [searchDisabled, setSearchDisabled] = useState(true);
    const [FilterCategoryComponents, setFilterCategoryComponents] = useState([]);
    const { data: reportTypeData } = useGetReportTypeQuery();
    const { data: filterData, isLoading: filterIsLoading } = useGetReportFiltersQuery(type, { skip: skipUseQuery });

    useEffect(() => {
        if (!filterIsLoading && !skipUseQuery) {
            const { categories } = filterData;

            setCategories(categories);
            // setValues(values);
        }
    }, [filterData, filterIsLoading, skipUseQuery]);

    useEffect(() => {
        setSearchDisabled(date.start === null || date.end === null || dateError.start !== null || dateError.end !== null);
    }, [date, dateError]);

    const handleDateError = (error, target) => {
        setDateError((prev) => ({ ...prev, [target]: error }));
    }

    const handleSelectType = (event) => {
        const { value } = event.target;

        if (value === "") {
            setSkipUseQuery(true);
        }
        else {
            dispatch(setTypeReducer(value));
            setSkipUseQuery(false);
        }

        if (value !== []) {
            setFilterDisabled(false);
        }
    };

    const handleSelectCategory = (event, index) => {
        const { value } = event.target;
        const selected = {
            ...filterObjTemplate,
            category: value
        };

        setFilter((prev) => Object.assign([...prev], { [index]: selected }));
    };

    const handleSelectValues = (values, index) => {
        const selected = {
            ...filter[index],
            values: values
        };

        setFilter((prev) => Object.assign([...prev], { [index]: selected }));
    }

    const handleDelete = (index) => {
        const temp = [...filter];
        temp.splice(index, 1);
        setFilter(temp);
    };

    const handleAddSearchCategory = () => {
        if (filter.length < categories.length) {
            setFilter((prev) => ([...prev, filterObjTemplate]));
        }
    };

    const handleButtonSearch = () => {
        const periode = {};
        const filterObj = {};

        periode["startDate"] = customFormat(date.start);
        periode["endDate"] = customFormat(date.end);

        filter.forEach(item => {
            if (item.category !== "") {
                filterObj[item.category] = item.values;
            }
        });

        dispatch(setPeriodeReducer(periode));
        dispatch(setFilterReducer(filterObj));
    };

    const handleResetFilter = () => {
        setSkipUseQuery(true);
        setDate(dateObjTemplate);
        setFilter([filterObjTemplate]);
        setFilterDisabled(true);
        dispatch(setTypeReducer(""));
        dispatch(setFilterReducer(null));
    };

    useEffect(() => {
        const selectedCategories = filter.map(item => item.category);
        const components = filter.map((item, index) => {
            const toBeRemoved = selectedCategories.filter(category => category !== item.category);
            const categoryList = categories.filter(x => !toBeRemoved.includes(x.id));
            const selectedCategory = item?.category;
            const selectedValues = item?.values

            return (
                FilterCategoryComponent({
                    id: index,
                    categories: categoryList,
                    // options: values[selectedCategory],
                    handleSelectCategory: handleSelectCategory,
                    handleSelectValues: handleSelectValues,
                    handleDelete: handleDelete,
                    selectedCategory: selectedCategory,
                    selectedValues: selectedValues,
                    disabled: filterDisabled
                })
            )
        });

        setFilterCategoryComponents(components);
    }, [filter, filterDisabled, categories, values]);

    return (
        <EmptyCard sx={{ padding: 2 }}>
            <Grid container direction={"column"} textAlign={"left"} spacing={3}>
                <Grid item>
                    <Grid container direction={"column"} spacing={1}>
                        <Grid item>
                            <Typography sx={styles.label}>Jenis Report</Typography>
                        </Grid>
                        <Grid item>
                            <BasicSelect items={checkReportsRole(reportTypeData || [])} onChange={handleSelectType} value={type} />
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item>
                    <Grid container direction={"column"} spacing={1}>
                        <Grid item>
                            <Typography sx={styles.label}>Periode</Typography>
                        </Grid>
                        <Grid item>
                            <DateRangePicker
                                date={date}
                                handleDateError={handleDateError}
                                setDate={setDate}
                                disabled={filterDisabled}
                                minDate={date.end ? dateSubtract(29, "days", date.end) : null}
                                maxDate={dateAdd(29, "days", date.start)}
                            />
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item>
                    <Grid container direction={"column"} spacing={1}>
                        <Grid item>
                            <Typography sx={styles.label}>Kategori (optional)</Typography>
                        </Grid>
                        <Grid item>
                            {FilterCategoryComponents}
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item marginTop={-3}>
                    <ButtonCommon label={"Tambah kategori pencarian"} handleClick={handleAddSearchCategory} variant={"text"} sx={styles.btnAddSearchCategory} disabled={filterDisabled} />
                </Grid>
                <Grid item>
                    <Grid container justifyContent={"right"} spacing={2}>
                        <Grid item alignSelf={"center"}>
                            <ButtonCommon label={"Reset Filter"} handleClick={handleResetFilter} variant={"text"} sx={styles.btnResetFilter} />
                        </Grid>
                        <Grid item>
                            <ButtonCommon label={"Search"} disabled={searchDisabled} handleClick={handleButtonSearch} sx={styles.btnSearch} />
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </EmptyCard>
    );
}

export default ReportFilter;