import axios, { AxiosError } from "axios";
import { Response } from "express";
import "express-async-errors";
import { NextFunction } from "express-serve-static-core";
import expressSession from "express-session";
import KeycloakConnect, { Keycloak } from "keycloak-connect";
import MemoryStore from "memorystore";
import config from "../configs/keycloak.config";
import env from "../env/server.env";
import { ForbiddenError, UnauthorizedError } from "../errors/client.error";
import { BadGatewayError } from "../errors/server.error";
import { ICustomKeycloakProtectRequest, TRoles } from "../types/keycloak.type";

const environment = `[${env.NODE_ENV?.toUpperCase()}]`;

const MemoryStoreConstructor = MemoryStore(expressSession)
let keycloak: Keycloak;

const KEYCLOAK_CONNECTION_STATUS = {
  CONNECTING: `${environment}: Initializing Keycloak...`,
  CONNECTED: `\r${environment}: Initialized keycloak    \n`,
  CONNECTION_FAILED: `\r${environment}: Keycloak has not been initialized\n`,
};

export const init = () => {
  process.stdout.write(`${environment}: Initializing Keycloak...`);
  if (keycloak) {
    return keycloak;
  } else {
    keycloak = new KeycloakConnect(
      {
        store: new MemoryStoreConstructor({ checkPeriod: 86400000 }),
      },
      config
    );

    process.stdout.write(`\r${environment}: Initialized Keycloak    \n`);

    return keycloak;
  }
};

export const get = () => {
  if (!keycloak) {
    process.stdout.write(KEYCLOAK_CONNECTION_STATUS.CONNECTION_FAILED);
  } else {
    return keycloak;
  }
};

export const protect = (allowedRoles: string[]) => {
  return async (
    req: ICustomKeycloakProtectRequest,
    _res: Response,
    next: NextFunction
  ) => {
    const accessToken = req.kauth?.grant?.access_token;

    if (!accessToken) {
      throw new UnauthorizedError("Unauthorized", "KEYCLOAK_UNAUTHORIZED")
    }
    else {
      const currentUnixTime = Math.floor(Date.now() / 1000);
      const tokenExpireTime = accessToken.content.exp;
      const userID = accessToken.content.sub;
      const token = accessToken.token;

      if (tokenExpireTime && tokenExpireTime < currentUnixTime) {
        throw new UnauthorizedError("Token expired", "KEYCLOAK_TOKEN_EXPIRED")
      }

      const getRolesUrl = `${env.KEYCLOAK_URL}/admin/realms/${env.KEYCLOAK_REALM}/users/${userID}/role-mappings/realm/composite`;
      const options = {
        headers: {
          Authorization: "Bearer " + token,
        },
      };

      try {
        const { data } = await axios.get<TRoles[]>(getRolesUrl, options);
        const roles = data.map((role) => `realm:${role.name}`);
        const hasRole = allowedRoles.some((allowedRole) => roles.includes(`realm:${allowedRole}`));

        if (!hasRole) {
          throw new ForbiddenError("Role not found", "KEYCLOAK_ROLE_NOT_FOUND");
        }

        next();
      } catch (err: any | unknown | AxiosError) {
        const axError = err satisfies AxiosError;
        throw new BadGatewayError(axError.response.data.error, "KEYCLOAK_GATEWAY_ERROR");
      }
    }
  };
};

export { };

