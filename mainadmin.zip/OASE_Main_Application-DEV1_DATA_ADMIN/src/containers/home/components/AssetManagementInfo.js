import React from 'react';
import { Box, Typography, Grid, Link } from '@mui/material';
import right from '../../../assets/icons/Right.png';
import { hasRoles } from '../../../token/roles';
import { Link as LinkRouter} from 'react-router-dom';

const useStyles = {
    boxRoot: {
        width: '100%',
        borderRadius: '8px',
        padding: '5%',
    },
    gridRoot: {
        marginBottom: '30px'
    },
    title: {
        fontSize: '1.5vw',
        fontWeight: 700,
        color: '#156db8',
    },
    countText: {
        fontSize: '2vw',
        fontWeight: 700,
        color: '#156db8',
    },
    subText: {
        fontSize: '1vw',
        fontWeight: 700,
    },
    main: {
        marginTop: 48,
        textAlign: 'center',
        marginBottom: 48
    },
    makeCenter: {
        display: 'flex',
        justifyContent: 'center'
    },
    linkDashboardAsset: {
        display: 'flex',
        justifyContent: 'flex-end',
        textDecoration : 'none',

    },
    next: {
        color: '#65748B',
        fontSize: '1vw',
        marginRight:1,
        '&:hover':{
            textDecoration : 'underline',
        }
    },
};

function AssetManagementInfo({ data }) {
    let dataAssetHome = data || {};
    return (
        <Box sx={useStyles.boxRoot} boxShadow={6} >
            <Typography sx={useStyles.title}>Asset Management</Typography>
            <div style={useStyles.main}>
                <Grid container sx={useStyles.gridRoot}>
                    <Grid item xs={hasRoles(['DASHBOARD']) ? 4 : 6}>
                        <Typography sx={useStyles.countText}>{dataAssetHome.outstandingTask || 0}<br /></Typography>
                        <Typography sx={useStyles.subText}>Outstanding Task</Typography>
                    </Grid>
                    {hasRoles(['DASHBOARD']) &&
                        <Grid item xs={4}>
                            <Typography sx={useStyles.countText}>{dataAssetHome.onlineMachine || 0}<br /></Typography>
                            <Typography sx={useStyles.subText}>Mesin Online</Typography>
                        </Grid>
                    }
                    <Grid item xs={hasRoles(['DASHBOARD']) ? 4 : 6}>
                        <Typography sx={useStyles.countText}>{dataAssetHome.inStockMachine || 0}<br /></Typography>
                        {/* <Typography sx={useStyles.countText}>{dataAssetHome.inStockMachine}<br/></Typography> */}
                        <Typography sx={useStyles.subText}>Mesin In Stock</Typography>
                    </Grid>
                </Grid>
            </div>
            {hasRoles(['DASHBOARD']) &&
                <Link color="inherit" to="/asset/asset/dashboard" sx={useStyles.linkDashboardAsset} component={LinkRouter}>
                    <Typography sx={useStyles.next}>Selengkapnya</Typography>
                    <img src={right} alt="Logo" component={Link} to="/asset/asset/dashboard" />
                </Link>
            }
        </Box>
    )
}

export default AssetManagementInfo