const getVPNUrl = () => {
    /* eslint-disable */
    const url = window.location.pathname;
    let vpnId = url.match(/(\/cvpn\/([^\/]*))/gi);
    if (vpnId != null) {
        return vpnId[0];
    }
    return '';
}

const hasVPNURrl = (url) => {
    /* eslint-disable */
    let vpnId = url.match(/(\/cvpn\/([^\/]*))/gi);
    if (vpnId != null) {
        return true
    }
    return false;
}

// https://monitor.securegw.bca.co,id/cvpn/randomvpn/route
// https://10.20.200.3:2443/cvpn/randomvpn/route
// 0     1 2               3     4         5

// const vpnRedirect = (url) => {
//     if(hasVPNURrl(window.location.href) /*&& !hasVPNURrl(url)*/){
    // let arrayUrl = window.location.href.split("/")
    // arrayUrl[5] = url.charAt(0) === '/' ? url.substring(1) : url
    // arrayUrl = arrayUrl.slice(0,6).join("/");
    // return arrayUrl
//     }else{
//         console.log(6, url)
//         return url;
//     }
// }
const vpnRedirect = (url) => {
    if(hasVPNURrl(window.location.href) /*&& !hasVPNURrl(url)*/){
        let arrayUrl = window.location.href.split("/")
        arrayUrl[5] = `#/${url.charAt(0) === '/' ? url.substring(1) : url}`
        arrayUrl = arrayUrl.slice(0,6).join("/");
        return arrayUrl
    }else{
        return '/#'+url;
    }
}

// cannot be used on blob data, always return not found
const vpnDownload = (url) => {
    if(hasVPNURrl(window.location.href) /*&& !hasVPNURrl(url)*/){
        let arrayUrl = url.split("/")
        arrayUrl[2] += getVPNUrl()
        arrayUrl = arrayUrl.slice(0,6).join("/");
        return arrayUrl
    }else{
        return url;
    }
}

const vpnImageUrl = () => {
    if(hasVPNURrl(window.location.href)){
        return window.location.href.split("/").slice(0,5).join("/")+'/'
    }else{
        return process.env.REACT_APP_IMAGE_PATH
    }
}

module.exports ={
    getVPNUrl,
    hasVPNURrl,
    vpnRedirect,
    vpnDownload,
    vpnImageUrl
}