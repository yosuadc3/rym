import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import CustomBreadcrumbs from "../../../components/breadcrumb/CustomBreadcrumbs";
import ButtonExport from "../../../components/buttons/ButtonExport";
import { SPV_MODE_DETAIL_INTERVAL } from "../../../constants/UpdateInterval";
import { useGetSpvModeDetailQuery, useGetSpvModeReportQuery } from "../../../redux/features/dashboard/spvMode/api/spvMode";
import { hasRoles } from "../../../token/roles";
import CardList from "../components/cards/CardList";

const breadcrumbs = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "SPV Mode",
        link: "/dashboard/spv-mode",
        current: false
    },
    {
        item: "SPV Mode Detail",
        link: null,
        current: true
    },
];

function SPVModeDetail() {
    const [cardData, setCardData] = useState([]);
    const { data: spvModeDetailData, isLoading } = useGetSpvModeDetailQuery(null, { pollingInterval: SPV_MODE_DETAIL_INTERVAL, refetchOnReconnect: true });

    useEffect(() => {
        if (!isLoading) {
            setCardData(spvModeDetailData);
        }
    }, [spvModeDetailData, isLoading]);

    const exportUseQuery = (_, options) => useGetSpvModeReportQuery(null, options);

    return (
        <>
            <Grid container alignItems={"center"} height={60}>
                <Grid item xs>
                    <CustomBreadcrumbs breadcrumbs={breadcrumbs} />
                </Grid>
                <Grid item xs textAlign={"end"}>
                    {
                        hasRoles(["GET_SPV_MODE_REPORT"]) && <ButtonExport useQuery={exportUseQuery} timestamp={true} fileName={"SpvMode"} />
                    }
                </Grid>
            </Grid>
            <Grid container spacing={2}>
                {
                    cardData.map((value, index) => {
                        const data = {
                            title: value?.PENGELOLA || "-",
                            content: value?.WSID || []
                        }

                        return (
                            <Grid key={index} item xs={2.4}>
                                <CardList data={data} />
                            </Grid>
                        );
                    })
                }
            </Grid>
        </>
    );
}

export default SPVModeDetail;