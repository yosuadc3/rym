import { Box, Grid, Link } from "@mui/material";
import React, { useState } from "react";
const styles = {
    container: {
        position: "relative",
        width: "100%",
        height: "100%",
    },
    link: {
        display: "block",
        width: "100%",
        height: "100%",
        color: "black",
        border: "none",
        textDecoration: "none",
        paddingX: 1,
        paddingY: 2,
        "&:hover": { color: "black", textDecoration: "none" },
        "&:visited": { color: "black", textDecoration: "none", border: "none" },

    },
    linkChild: {
        width: "100%",
        height: "100%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        color: "black",
        "&:visited": { color: "black", textDecoration: "none", border: "none" },
    }
}
export default function LinkBoxTerminal({ children, data, value }) {

    const [route, setRoute] = useState('-/' + data?.row._id)

    const handleClick = (e) => {
        if (e.button === 2) {
            setRoute(data?.row._id);
        }
    }

    return (
        <Grid sx={styles.container} onMouseDown={handleClick}>
            <Link href={"#/monitoring/incident-management/" + route} sx={styles.link}>
                <Box sx={styles.linkChild}>
                    {data.row[value]}
                </Box>
            </Link>
            {children}
        </Grid>

    );
}