import { SvgIcon } from "@mui/material";
import React from "react";

export default function ArrowDown2(props) {
  return (
    <SvgIcon {...props}>
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4.34467 7.96967C4.63756 7.67678 5.11244 7.67678 5.40533 7.96967L12.125 14.6893L18.8447 7.96967C19.1376 7.67678 19.6124 7.67678 19.9053 7.96967C20.1982 8.26256 20.1982 8.73744 19.9053 9.03033L12.6553 16.2803C12.3624 16.5732 11.8876 16.5732 11.5947 16.2803L4.34467 9.03033C4.05178 8.73744 4.05178 8.26256 4.34467 7.96967Z" fill="#0D5CAB"/>
      </svg>
    </SvgIcon>
  );
}
