//Lost Comm Controller
import { Response } from "express";
import {
	IGetDetailSPVModeRequest,
	IGetSPVModeByFLMRequest,
	IGetSPVModeReportRequest,
	IGetSPVModeRequest,
} from "../../types/spvMode/spvMode.type";
import * as dateTime from "../../utils/dateTime.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import printToConsole from "../../utils/printToConsole.util";
const spvModeRepo = require("../../repositories/spvMode.repository");

export const getSPVMode = async (req: IGetSPVModeRequest, res: Response) => {
	try {
		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const data = await spvModeRepo.get();
		let counterSPVMode = 0;

		data.rows.map((item: any) => {
			counterSPVMode = counterSPVMode + item.JUMLAH;
		});

		const response = {
			total: counterSPVMode,
			lastUpdate: dateTime.getCurrent(),
			data: data.rows,
		};
		const message = {
			english: `Successfully Retrieved SPV Mode Data`,
			indonesia: `Berhasil Mengambil Data SPV Mode`,
		};
		res.send(jsonMessage.jsonSuccess(message, response));
	} catch (err) {
		jsonMessage.getInternalServerError(
			err,
			res,
			"Some error occurred while retrieved SPV Mode"
		);
		printToConsole("SPV-get", err);
	}
};

export const getSPVModeByFLM = async (req: any, res: Response) => {
	try {
		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const data = await spvModeRepo.getByFLM(req.param.id);
		const message = {
			english: `Successfully Retrieved SPV Mode Data`,
			indonesia: `Berhasil Mengambil Data SPV Mode`,
		};

		res.send(jsonMessage.jsonSuccess(message, data.rows));
	} catch (err) {
		jsonMessage.getInternalServerError(
			err,
			res,
			"Some error occurred while retrieved SPV Mode"
		);
		printToConsole("SPV-getByFLM", err);
	}
};

export const getDetailSPVMode = async (
	req: IGetDetailSPVModeRequest,
	res: Response
) => {
	try {
		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const data = await spvModeRepo.getDetail();
		let total = 0;
		// let temp = "";
		// let responseArray = [];
		// let responseSPVMode = {};

		// data.rows.map(item => {
		//     if (item.PENGELOLA === temp) {
		//         // Using Last Object
		//         responseSPVMode.WSID.push(item.ID);
		//         responseSPVMode.JUMLAH = responseSPVMode.WSID.length;
		//     } else {
		//         // Create New Object
		//         responseSPVMode = {};
		//         responseSPVMode.PENGELOLA = item.PENGELOLA;
		//         responseSPVMode.WSID = [];
		//         responseSPVMode.WSID.push(item.ID);
		//         responseSPVMode.JUMLAH = responseSPVMode.WSID.length;
		//         responseArray.push(responseSPVMode);
		//     }
		//     temp = item.PENGELOLA;
		//     total++;
		// });

		const responseArray = data.rows.map((value: any) => {
			total += value.JUMLAH;

			return {
				PENGELOLA: value.PENGELOLA,
				WSID: value.ID.split(","),
				JUMLAH: value.JUMLAH,
			};
		});

		const response = {
			total: total,
			data: responseArray,
		};
		const message = {
			english: `Successfully Retrieved SPV Mode Detail`,
			indonesia: `Berhasil Mengambil Detail SPV Mode`,
		};

		res.send(jsonMessage.jsonSuccess(message, response));
	} catch (err) {
		jsonMessage.getInternalServerError(
			err,
			res,
			"Some error occurred while retrieved SPV Mode"
		);
		printToConsole("SPV-getDetail", err);
	}
};

export const getSPVModeReport = async (
	req: IGetSPVModeReportRequest,
	res: Response
) => {
	try {
		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const data = await spvModeRepo.getReport();
		const message = {
			english: `Successfully Retrieved SPV Mode Report`,
			indonesia: `Berhasil Mengambil Report SPV Mode`,
		};

		res.send(jsonMessage.jsonSuccess(message, data.rows));
	} catch (err) {
		jsonMessage.getInternalServerError(
			err,
			res,
			"Some error occurred while retrieved SPV Mode"
		);
		printToConsole("SPV-getReport", err);
	}
};

export { };

