
import { INCIDENT } from "../../constants/dbQuery.constant";
import { query as dbQuery } from "../../databases/oase.database";
import { TQueryParams, TSearchParams } from "../../types/dataAdmin/dataAdmin.types";
import { handleAdvancedSearchParams, handleSearchParams } from "../../utils/dbQueryHelper.util";

export function getIncidents(page: number, limit: number, sortBy: string, orderBy: string, searchParams?: TSearchParams) {
   let searchData: TQueryParams = {
      query: "",
      params: []
   }

   if (searchParams?.search) {
      searchData = handleSearchParams(searchParams.search);
   }

   if (searchParams?.advancedSearch || searchParams?.advancedSearchPeriode) {
      searchData = handleAdvancedSearchParams(searchParams.advancedSearchPeriode!, searchParams.advancedSearch, "created_time");
   }

   const offset = page * limit;

   const queryData = `select * from ${INCIDENT} ${searchData.query}
        order by \`${sortBy}\` ${orderBy} limit ${limit} offset ${offset}`;

   const queryTotal = `select count(id) as total from ${INCIDENT} ${searchData.query} `;

   const result = dbQuery(queryData, searchData.params);
   const total = dbQuery(queryTotal, searchData.params);

   return Promise.all([result, total]);
}