import { Response } from "express";
import { matchedData, validationResult } from "express-validator";
import { HTTP_NO_CONTENT } from "../../../constants/httpResponseCodes.constant";
import * as db from "../../../repositories/dataAdmin/eventCode/rule.repository";
import { IGetAllRequest, IRequestQueryParams, TDbResponse, TRequestParams } from "../../../types/dataAdmin/dataAdmin.types";
import addPayloadToRequestHeader from "../../../utils/addPayloadToRequestHeader.util";
import { getInternalServerError, jsonSuccess } from "../../../utils/jsonMessage.util";
import { replaceNullOrEmptyStringArray } from "../../../utils/object/replaceNullOrEmptyStringArray.util";
import printToConsole from "../../../utils/printToConsole.util";

const message = {
    "english": `Successfully Retrieved Event Code Rule`,
    "indonesia": `Berhasil Mengambil Event Code Rule`,
}
const errorMessage = "Internal Server Error!";
const errorTag = "getEventCodeRule";

export async function getEventCodeRules(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    let dbRes: TDbResponse = [[], []];
    //const queryData: IRequestQueryParams = matchedData(req, { locations: ["query"] });
    const page = req?.query?.page;
    const limit = req?.query?.limit;
    const sortBy = req?.query?.sortBy;
    const orderBy = req?.query?.orderBy;
    const offset = req?.query?.offset;
    const search = req?.query?.search;
    const advancedSearch = req?.query?.advancedSearch;
    const advancedSearchPeriode = req?.query?.advancedSearchPeriode;

    if (search) {
        const params = {
            search: JSON.parse(search)
        }

        dbRes = await db.getEventCodeRules(page!, limit!, sortBy!, orderBy!, offset, params);
    }
    else if (advancedSearch || advancedSearchPeriode) {
        const params = {
            advancedSearch: advancedSearch ? JSON.parse(advancedSearch) : null,
            advancedSearchPeriode: advancedSearchPeriode ? JSON.parse(advancedSearchPeriode) : null
        }

        dbRes = await db.getEventCodeRules(page!, limit!, sortBy!, orderBy!, offset, params);
    }
    else {
        dbRes = await db.getEventCodeRules(page!, limit!, sortBy!, orderBy!, offset);
    }

    const [data, [total]] = dbRes;

    replaceNullOrEmptyStringArray(data);

    const payload = {
        ...total,
        data: data
    }

    res.send(jsonSuccess(message, payload));
}

export async function cunGetEventCodeRules(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    let dbRes: TDbResponse = [[], []];
    //const queryData: IRequestQueryParams = matchedData(req, { locations: ["query"] });
    const page = req?.query?.page;
    const limit = req?.query?.limit;
    const sortBy = req?.query?.sortBy;
    const orderBy = req?.query?.orderBy;
    const offset = req?.query?.offset;
    const search = req?.query?.search;
    const advancedSearch = req?.query?.advancedSearch;
    const advancedSearchPeriode = req?.query?.advancedSearchPeriode;

    if (search) {
        const params = {
            search: JSON.parse(search)
        }

        dbRes = await db.cunGetEventCodeRules(page!, limit!, sortBy!, orderBy!, offset, params);
    }
    else if (advancedSearch || advancedSearchPeriode) {
        const params = {
            advancedSearch: advancedSearch ? JSON.parse(advancedSearch) : null,
            advancedSearchPeriode: advancedSearchPeriode ? JSON.parse(advancedSearchPeriode) : null
        }

        dbRes = await db.cunGetEventCodeRules(page!, limit!, sortBy!, orderBy!, offset, params);
    }
    else {
        dbRes = await db.cunGetEventCodeRules(page!, limit!, sortBy!, orderBy!, offset);
    }

    const [data, [total]] = dbRes;

    replaceNullOrEmptyStringArray(data);

    const payload = {
        ...total,
        data: data
    }

    res.send(jsonSuccess(message, payload));
}

export async function getEventCodeRule(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    //const paramsData: TRequestParams = matchedData(req, { locations: ["params"] });

    const [data] = await db.getEventCodeRule(req?.params?.id!);

    res.send(jsonSuccess(message, data));
}


export async function getEventCodeRuleList(req: IGetAllRequest, res: Response) {
    const dbRes: TDbResponse = await db.getEventCodeRuleList();

    const [data] = dbRes;

    const payload = {
        ...data
    }

    res.send(jsonSuccess(message, payload));
}

export async function postEventCodeRule(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;

    const message = {
        "english": `Successfully Insert An Event Code Rule`,
        "indonesia": `Berhasil Memasukkan Sebuah Event Code Rule`,
    }

    await db.postEventCodeRule(req?.body, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

// export async function injectEventCodeRule(req: IGetAllRequest, res: Response) {
//     addPayloadToRequestHeader(req);

//     const name = req.kauth.grant?.access_token.content.preferred_username;

//     const message = {
//         "english": `Successfully Insert An Event Code Rule`,
//         "indonesia": `Berhasil Memasukkan Sebuah Event Code Rule`,
//     }

//     for (let index = 0; index < 999; index++) {
//         const dummy = {
//             rule: 'INJECT CUN' + (index + 1),
//             action_id: '2',
//             email_action_id: '1',
//             fault_category_id: '5b46ac4f-efa2-11ed-b96e-566ff8c600ea',
//             reopen_limit: '3'
//         };
//         await db.injectEventCodeRule(dummy, name);
//     }

//     res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
// }

export async function changeOrdersEventCodeRule(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    const bodyData = matchedData(req, { locations: ["body"] });

    const message = {
        "english": `Successfully Updated The Priority of The Event Code Rule`,
        "indonesia": `Berhasil Mengubah Prioritas Event Code Rule`,
    }

    await db.changeOrdersEventCodeRule(req?.body, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function cunChangeOrdersEventCodeRule(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    const bodyData = matchedData(req, { locations: ["body"] });

    const message = {
        "english": `Successfully Updated The Priority of The Event Code Rule`,
        "indonesia": `Berhasil Mengubah Prioritas Event Code Rule`,
    }

    await db.cunChangeOrdersEventCodeRule(req?.body, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function putEventCodeRule(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    // const bodyData = matchedData(req, { locations: ["body"] });
    // const paramsData = matchedData(req, { locations: ["params"] });

    const message = {
        "english": `Successfully Updated An Event Code Rule`,
        "indonesia": `Berhasil Mengubah Sebuah Event Code Rule`,
    }

    await db.putEventCodeRule(req?.body, req?.params?.id, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function deleteEventCodeRule(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);
    const name = req.kauth.grant?.access_token.content.preferred_username;
    //const paramsData = matchedData(req, { locations: ["params"] });

    const message = {
        "english": `Successfully Delete An Event Code Rule`,
        "indonesia": `Berhasil Menghapus Sebuah Event Code Rule`,
    }

    await db.deleteEventCodeRule(req?.params?.id, req?.body?.priority, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export { };

