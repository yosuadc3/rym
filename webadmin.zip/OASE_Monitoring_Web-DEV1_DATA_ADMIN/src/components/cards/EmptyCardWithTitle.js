import { Typography } from "@mui/material";
import React from "react";
import EmptyCard from "./EmptyCard";

function EmptyCardWithTitle({ children, sx, title, title_sx }) {
    return (
        <EmptyCard sx={sx}>
            <Typography sx={{
                fontSize: "1.5rem",
                fontWeight: "bold",
                color: "#0F549F",
                marginBottom: 1,
                textAlign: "left",
                ...title_sx
            }}>
                {title}
            </Typography>
            {children}
        </EmptyCard>
    )
}

export default EmptyCardWithTitle;