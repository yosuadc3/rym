import { Box, Grid, Stack } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import BaseBreadcrumbs from "../../../../../components/breadcrumb/BaseBreadcrumbs";
import StyledSearchV2 from "../../../../../components/search/StyledSearchV2";
import StyledTableV2 from "../../../../../components/table/StyledTableV2";
import { CENTER_COLUMNS } from "../../../../../utilities/MaterialUI";

export const INCIDENTS_BREADCRUMBS = [
   {
      item: "Home",
      link: "/",
      current: false
   },
   {
      item: "Incident Management & Monitoring",
      link: null,
      current: false
   },
   {
      item: "Incidents",
      link: null,
      current: true
   },
];

export const INCIDENTS_SEARCH = [
   { value: "all", label: "All" },
   { value: "id", label: "Incident ID" },
   { value: "wsid", label: "WSID" },
   { value: "event_code", label: "Event Code" },
   { value: "rule", label: "rule" },
   { value: "group", label: "Group" },
   { value: "start_time", label: "Start Time" },
   { value: "end_time", label: "End Time" },
];

export const INCIDENTS_COLUMN = [
   {
      headerName: "Incident ID",
      field: "id",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "WSID",
      field: "wsid",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "Event Code",
      field: "event_code",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "Rule",
      field: "rule",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "Group",
      field: "group",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "Reopen",
      field: "reopens",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "Reopen Limit",
      field: "reopen_limit",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "Start Time",
      field: "start_time",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "End Time",
      field: "end_time",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "Duration",
      field: "duration",
      ...CENTER_COLUMNS,
   },
   {
      headerName: "Closed By",
      field: "closed_by",
      ...CENTER_COLUMNS,
   },
]

export default () => {
   const dispatch = useDispatch();
   const [searchQuery, setSearchQuery] = useState("");

   const handleSearchQuery = (query) => {
      setSearchQuery((_) => query);
   };

   return (
      <Box>
         <BaseBreadcrumbs breadcrumbs={INCIDENTS_BREADCRUMBS} />
         <Grid container marginTop={2}>
            <Grid item container xs={12}>
               <StyledTableV2
                  headers={INCIDENTS_COLUMN}
                  defaultSortBy="id"
                  defaultOrderBy="desc"
                  link="incidents"
                  route="data-admin"
                  searchQuery={searchQuery}
                  useStripesWhiteGray
                  enableInterval
               />
            </Grid>
         </Grid>
      </Box>
   );
};