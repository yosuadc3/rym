import { EVENT_CODE } from "../../../constants/dbQuery.constant";
import { query as dbQuery } from "../../../databases/oase.database";
import { TQueryParams, TSearchParams } from "../../../types/dataAdmin/dataAdmin.types";
import { handleAdvancedSearchParams, handleSearchParams } from "../../../utils/dbQueryHelper.util";
import { getObjectValues } from "../../../utils/object/convertToArray.util";

export function getEventCodeSources(page: number, limit: number, sortBy: string, orderBy: string, searchParams?: TSearchParams) {
   let searchData: TQueryParams = {
      query: "",
      params: []
   }

   if (searchParams?.search) {
      searchData = handleSearchParams(searchParams.search);
   }

   if (searchParams?.advancedSearch || searchParams?.advancedSearchPeriode) {
      searchData = handleAdvancedSearchParams(searchParams.advancedSearchPeriode!, searchParams.advancedSearch, "created_time");
   }

   const offset = page * limit;

   const queryData = `select id, \`source\`, description
        from ${EVENT_CODE.VIEW_SOURCE} ${searchData.query}
        order by \`${sortBy}\` ${orderBy} limit ${limit} offset ${offset}`;

   const queryTotal = `select count(id) as total from ${EVENT_CODE.VIEW_SOURCE} ${searchData.query} `;

   const result = dbQuery(queryData, searchData.params);
   const total = dbQuery(queryTotal, searchData.params);

   return Promise.all([result, total]);
}

export function getEventCodeSource(id: number | undefined) {
   const baseQuery = `select id, \`source\`, description,
   (select count(id) as total from ${EVENT_CODE.VIEW} 
   where catalog_id = "${id}" ) As 'total', modified_time
   from ${EVENT_CODE.VIEW_SOURCE} where id = "${id}"`;

   return dbQuery(baseQuery, [id]);
}

export function postEventCodeSource(data: { [k: string]: unknown }, createdBy: string | undefined) {
   const baseQuery = `INSERT INTO ${EVENT_CODE.TABLE_SOURCE} (\`source\`, description, is_delete, created_by) VALUES (?, ?, 0, ?)`;

   return dbQuery(baseQuery, [...getObjectValues(data), createdBy]);
}

export function putEventCodeSource(body: { [k: string]: unknown }, id: number | undefined, modifiedBy: string | undefined) {
   const baseQuery = `UPDATE ${EVENT_CODE.TABLE_SOURCE} t SET t.source = ?, t.description = ?, t.modified_by = ? where t._id = ?`;

   return dbQuery(baseQuery, [...getObjectValues(body), modifiedBy, id]);
}

export function deleteEventCodeSource(id: number | undefined, modifiedBy: string | undefined) {
   const baseQuery = `UPDATE ${EVENT_CODE.TABLE_SOURCE} t SET t.is_delete = 1, t.modified_by = ? WHERE _id = ?`;

   return dbQuery(baseQuery, [modifiedBy, id]);
}

export function getEventCodeSourceList() {
   const baseQuery = `select json_arrayagg(json_object('id', id, 'value', source)) as list from ${EVENT_CODE.VIEW_SOURCE}`;

   return dbQuery(baseQuery);
}

export { };

