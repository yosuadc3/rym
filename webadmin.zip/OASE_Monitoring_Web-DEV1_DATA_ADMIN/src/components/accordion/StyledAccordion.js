import {
	Accordion,
	AccordionDetails,
	AccordionSummary,
	Typography,
} from "@mui/material";
import React from "react";
import ChevronDown from "../svgs/ChevronDown";

const styles = {
	hr: {
		border: "1px solid #F1F1F7",
		width: "100%",
		marginTop: ".8rem",
		marginLeft: "1rem",
		marginRight: "1rem",
	},
	accordion: {
		borderBottom: "none",
		borderTop: "none",
	},
	accordionIcon: {
		color: "#0D5CAB",
	},
	accordionTitle: {
		fontSize: 20,
		fontWeight: "bold",
		color: "#0D5CAB",
		whiteSpace: "nowrap",
	},
};

export default function StyledAccordion({
	title,
	children,
	defaultExpanded = false,
	isSkeleton,
}) {
	return (
		<Accordion
			elevation={0}
			defaultExpanded={isSkeleton ? false : defaultExpanded}
			disableGutters={true}
			square={true}
			sx={styles.accordion}
		>
			<AccordionSummary
				sx={{ padding: 0 }}
				expandIcon={<ChevronDown sx={styles.accordionIcon} />}
			>
				<Typography sx={styles.accordionTitle}>{title}</Typography>
				<hr style={styles.hr} />
			</AccordionSummary>
			<AccordionDetails sx={{ padding: 0, marginBottom: 2 }}>
				{children}
			</AccordionDetails>
		</Accordion>
	);
}
