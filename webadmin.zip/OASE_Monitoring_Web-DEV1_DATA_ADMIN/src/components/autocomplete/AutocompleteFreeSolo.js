import { TextField } from "@mui/material";
import React, { useState } from "react";
import AutocompleteBase from "./AutocompleteBase";

export default function AutocompleteFreeSolo({
  onChange = (event, values) => { },
  value = [],
  useSmallSize = false,
  disabled = false,
  options = [],
}) {
  const [inputValue, setInputValue] = useState("");

  const handleInputKeyDown = (event) => {
    const { key } = event;

    if (key === ";") {
      event.preventDefault();
      event.stopPropagation();

      const { value: newValue } = event.target;
      const valueExist = value.includes(newValue);

      if (newValue && newValue !== "" && !valueExist) {
        onChange(event, [...value, newValue]);
        setInputValue("");
      }
    }

    if (key === "Enter") {
      event.preventDefault();
      event.stopPropagation();
    }
  }

  const handleInputOnChange = (event) => {
    const { value } = event.target;
    setInputValue(value);
  }

  return (
    <AutocompleteBase
      freeSolo={true}
      disabled={disabled}
      inputValue={inputValue}
      value={value}
      renderInput={(params) => {
        params.inputProps.onKeyDown = handleInputKeyDown;
        params.inputProps.onChange = handleInputOnChange;

        return (
          <TextField
            {...params}
            sx={{
              backgroundColor: disabled ? "#C4C4C4" : "#FFFFFF"
            }}
          />
        );
      }}
      onChange={onChange}
      options={options}
      size={useSmallSize ? "small" : "medium"}
    />
  );
}
