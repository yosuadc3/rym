import { Dialog, DialogTitle,Grid } from "@mui/material";
import React from "react";
import Close from "../svgs/Close";

export default function FormDialogV2({
	isOpen,
	handleToggle,
	title,
	children,
	width = "50%",
	sx
}) {
	return (
		<Dialog
			open={isOpen}
			onClose={handleToggle}
			PaperProps={{
				sx: {
					maxWidth: width ? width : "50%",
					height: "full",
					backgroundColor:"#0D5CAB",
					paddingTop: "10px",
					...sx,
				},
			}}
		>
			<Grid sx={{backgroundColor:"#ffffff",paddingX:"20px"}}>
				<DialogTitle
					sx={{
						display: "flex",
						alignItems: "center",
						justifyContent: "space-between",
						fontSize: 20,
						fontWeight: 700,
						color: "#014C8B",
					}}
				>
					{title}
					<Close
						aria-label="close"
						onClick={handleToggle}
						sx={{ ml: "auto", cursor: "pointer", fontSize: 16 }}
					/>
				</DialogTitle>
				{children}
			</Grid>
		</Dialog>
	);
}
