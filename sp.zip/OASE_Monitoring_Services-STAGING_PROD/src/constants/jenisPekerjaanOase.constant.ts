export const PATCH_MANAGEMENT = 16
export const IMAGE_MANAGEMENT = 17