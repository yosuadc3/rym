import * as welcomeApp from "../controllers/welcomeApp.controller";
let router = require("express").Router();

router.get("/", welcomeApp.getWelcomeApp);

export default router;
export {};
