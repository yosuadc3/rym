import { createApi } from "@reduxjs/toolkit/query/react";
import { BASE_URL_API_MONITORING } from "../../../../../constants/Api";
import axiosBaseQuery from "../../../../utils/axiosBaseQuery";

const path = "/report/atlas";

export const reportAtlasApi = createApi({
    reducerPath: "reportAtlasApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getReport: builder.query({
            query: (params = { periode: {}, filter: {}, type: "" }) => ({
                url: path, method: "get", params: params
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total: data.total
                }
            }
        }),
        getReportDownload: builder.query({
            query: (params = { periode: {}, filter: {}, type: "" }) => ({
                url: `${path}/download`, method: "get", params: params
            }),
            transformResponse: (res) => (res.data)
        }),
        getReportFilters: builder.query({
            query: (type) => ({ url: `${path}/filter`, method: "get", params: { type: type } }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    categories: data.categories,
                    values: data.values
                }
            }
        }),
        getReportType: builder.query({
            query: () => ({ url: `${path}/type`, method: "get" }),
            transformResponse: (res) => (res.data)
        }),
    })
});

export const {
    useGetReportQuery,
    useGetReportDownloadQuery,
    useGetReportFiltersQuery,
    useGetReportTypeQuery
} = reportAtlasApi;