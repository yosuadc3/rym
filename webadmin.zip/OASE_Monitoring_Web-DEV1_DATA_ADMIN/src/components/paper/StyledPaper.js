import Paper from "@mui/material/Paper";
import React from "react";

export default function StyledPaper({
  usePadding = true,
  useTopBorder = true,
  customBoxShadow,
  children,
}) {
  const STYLE = {
    border: useTopBorder ? `.5rem solid #0D5CAB` : "",
    borderBottom: "none",
    borderLeft: "none",
    borderRight: "none",
    borderRadius: 2,
    boxShadow: customBoxShadow ? customBoxShadow : "0px 4px 4px rgba(0, 0, 0, 0.25)",
    padding: usePadding ? "1rem 2rem" : "",
    display: "flex",
    flexDirection: "column",
    justifyContent: "left",
    alignItems: "start"
  };
  return (
    <Paper elevation={2} sx={STYLE}>
      {children}
    </Paper>
  );
}
