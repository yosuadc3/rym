import * as controller from "../../controllers/serviceAvailability/serviceAvailability.controller";
const keycloak = require("../../middlewares/keycloakHandler.middleware").get();
let router = require("express").Router();

router.get(
	"/",
	keycloak.protect("realm:GET_SERVICE_AVAILABILITY"),
	controller.getStatus
);
router.get(
	"/dsa-stats",
	keycloak.protect("realm:GET_SERVICE_AVAILABILITY"),
	controller.getDsaStats
);
router.get(
	"/summary",
	keycloak.protect("realm:GET_SERVICE_AVAILABILITY"),
	controller.getSummary
);
router.get(
	"/report",
	keycloak.protect("realm:GET_SERVICE_AVAILABILITY_REPORT"),
	controller.getReport
);
router.get(
	"/search-items",
	keycloak.protect("realm:GET_SERVICE_AVAILABILITY"),
	controller.getSearchItems
);

export default router;
export { };

