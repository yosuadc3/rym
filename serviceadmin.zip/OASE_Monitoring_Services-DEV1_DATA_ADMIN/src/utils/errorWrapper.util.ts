import { NextFunction, Response } from "express";
import "express-async-errors";
import GlobalError from "../errors/global.error";
import { APIError } from "../errors/server.error";
import { IRequestAPI } from "../types/global.type";
import { ICustomKeycloakProtectRequest } from "../types/keycloak.type";

export default (controller: (req: IRequestAPI | ICustomKeycloakProtectRequest, res: Response, next: NextFunction) => {}) => async (req: IRequestAPI, res: Response, next: NextFunction) => {
   try {
      await controller(req, res, next);
   } catch (error) {
      if (error instanceof GlobalError) {
         throw error;
      }

      throw new APIError("API encountered an error", "API_ERROR");
   }
}