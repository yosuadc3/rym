import React from "react";
import { Grid, Typography } from "@mui/material";

const style = {
    textLabel: {
        textAlign: "left",
        fontWeight: "bold",
        fontSize: "16px",
        lineHeight: "19.5px",
        color: "#65748B"
    },
    textValue: {
        fontWeight: "bold",
        lineHeight: "19.5px",
        fontSize: "16px",
        color: "black"
    },
    containerItem: {
        marginTop: "6%"
    }
}

function ProfileInternal(props) {
    const { userData } = props;

    return (
        <Grid container textAlign="left">
            <Grid container sx={style.containerItem}>
                <Grid item xs={3}>
                    <Typography variant="h6" component="h2" sx={style.textLabel}>Udomain</Typography>
                </Grid>
                <Grid item xs={9}>
                    <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.username || "-"}</Typography>
                </Grid>
            </Grid>
            <Grid container sx={style.containerItem}>
                <Grid item xs={3}>
                    <Typography variant="h6" component="h2" sx={style.textLabel}>Email</Typography>
                </Grid>
                <Grid item xs={9}>
                    <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.email || "-"}</Typography>
                </Grid>
            </Grid>
            <Grid container sx={style.containerItem}>
                <Grid item xs={3}>
                    <Typography variant="h6" component="h2" sx={style.textLabel}>KP / Kanwil</Typography>
                </Grid>
                <Grid item xs={9}>
                    <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.LDAP_ENTRY_DN?.[0].substring(userData?.attributes?.LDAP_ENTRY_DN[0].search("OU=") + 3, userData?.attributes?.LDAP_ENTRY_DN[0].indexOf(",", userData?.attributes?.LDAP_ENTRY_DN[0].search("OU=") + 3)).replace(/([a-z])([A-Z])/g, "$1 $2") || "-"}</Typography>
                </Grid>
            </Grid>
            <Grid container sx={style.containerItem}>
                <Grid item xs={3}>
                    <Typography variant="h6" component="h2" sx={style.textLabel}>Divisi</Typography>
                </Grid>
                <Grid item xs={9}>
                    <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.department?.[0] || "-"}</Typography>
                </Grid>
            </Grid>
            <Grid container sx={style.containerItem}>
                <Grid item xs={3}>
                    <Typography variant="h6" component="h2" sx={style.textLabel}>Biro</Typography>
                </Grid>
                <Grid item xs={9}>
                    <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.division?.[0] || "-"}</Typography>
                </Grid>
            </Grid>
            <Grid container sx={style.containerItem}>
                <Grid item xs={3}>
                    <Typography variant="h6" component="h2" sx={style.textLabel}>Jabatan</Typography>
                </Grid>
                <Grid item xs={9}>
                    <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.description?.[0] || "-"}</Typography>
                </Grid>
            </Grid>
        </Grid>
    );
}

export default ProfileInternal;