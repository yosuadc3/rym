import React, { useEffect, useState } from "react";
import TextField from '@mui/material/TextField';
import AdapterDateFns from '@mui/x-date-pickers/AdapterDateFns';
import LocalizationProvider from '@mui/x-date-pickers/LocalizationProvider';
import StaticDatePicker from '@mui/x-date-pickers/StaticDatePicker';
import { Box } from '@mui/material';


function MonthYearPicker(props) {
    const { setMonth } = props;
    const [value, setValue] = useState(null);

    useEffect(() => {
        setMonth(value);
    }, [value, setMonth])

    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Box height="73%">
                <StaticDatePicker
                    views={["year", "month"]}
                    maxDate={new Date()}
                    displayStaticWrapperAs="desktop"
                    openTo="month"
                    value={value}
                    onChange={(newValue) => {
                        setValue(newValue);
                    }}
                    renderInput={(params) => <TextField {...params} />}
                />
            </Box>
        </LocalizationProvider>
    );
}


export default MonthYearPicker;