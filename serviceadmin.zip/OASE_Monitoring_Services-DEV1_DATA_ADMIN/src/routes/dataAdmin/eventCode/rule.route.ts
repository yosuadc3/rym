import { query } from "express-validator";
import * as controller from "../../../controllers/dataAdmin/eventCode/rule.controller";
import validation from "../../../middlewares/validator.middleware";
import errorWrapper from "../../../utils/errorWrapper.util";
import * as validationRules from "../../../validators/dataAdmin/eventCode/rule.validator";
const router = require("express").Router();
const keycloak = require("../../../middlewares/keycloakHandler.middleware").get();

router.get("/", validationRules.getEventCodeRules, validation(validationRules.getEventCodeRules), errorWrapper(controller.getEventCodeRules));
router.post("/", validationRules.postEventCodeRule, validation(validationRules.postEventCodeRule), errorWrapper(controller.postEventCodeRule));
router.get("/cun", validationRules.getEventCodeRules, validation(validationRules.getEventCodeRules), errorWrapper(controller.cunGetEventCodeRules));
router.put("/cun/change-orders", validationRules.changeOrdersEventCodeRule, validation(validationRules.changeOrdersEventCodeRule), errorWrapper(controller.cunChangeOrdersEventCodeRule));
router.get("/list", errorWrapper(controller.getEventCodeRuleList));
router.get("/:id", validationRules.getEventCodeRule, validation(validationRules.getEventCodeRule), errorWrapper(controller.getEventCodeRule));
router.put("/change-orders", validationRules.changeOrdersEventCodeRule, validation(validationRules.changeOrdersEventCodeRule), errorWrapper(controller.changeOrdersEventCodeRule));
router.put("/:id", validationRules.putEventCodeRule, validation(validationRules.putEventCodeRule), errorWrapper(controller.putEventCodeRule));
router.delete("/:id", validationRules.deleteEventCodeRule, validation(validationRules.deleteEventCodeRule), errorWrapper(controller.deleteEventCodeRule));

export default router;