import { Grid, Stack, TextField, Typography } from "@mui/material";
import React from "react";

const FormInput = ({ label, isDisabled = false, handleOnChange }) => {
	return (
		<TextField value={label} disabled={isDisabled} onChange={handleOnChange} />
	);
};

export default function BaseFormGrid({
	useContainer = false,
	xs,
	title,
	description,
	isDisabled = false,
	useForm = false,
	handleOnChange,
}) {
	return (
		<Grid item container={useContainer} xs={xs}>
			<Stack justifyContent="start" alignItems="start">
				<Typography sx={{ fontWeight: "bold", color: "#65748B" }}>
					{title}
				</Typography>
				<Typography sx={{ textAlign: "left", fontWeight: 600 }}>
					{useForm ? (
						<FormInput
							label={description}
							isDisabled={isDisabled}
							handleOnChange={handleOnChange}
						/>
					) : (
						description
					)}
				</Typography>
			</Stack>
		</Grid>
	);
}
