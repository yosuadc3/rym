import { NextFunction, Response } from "express";
import { validationResult } from "express-validator";
import { IRequestAPI } from "../types/global.type";
import { getInternalServerError } from "../utils/jsonMessage.util";

type TError = {
   [key: string]: { [key: string]: string }[]
}

export default function (req: IRequestAPI, res: Response, next: NextFunction) {
   const result = validationResult(req);

   if (!result.isEmpty()) {
      const error = {
         response: {
            status: 400
         }
      }
      const extractedResult: TError = {}

      result.array().forEach((value) => {
         const { msg, param, location } = value;

         if (location) {
            const tempArray = extractedResult[location.toString()] || [];
            const errorObj = { [param]: msg }

            extractedResult[location] = [...tempArray, errorObj];
         }
      });

      return getInternalServerError(error, res, extractedResult);
   }

   next();
}