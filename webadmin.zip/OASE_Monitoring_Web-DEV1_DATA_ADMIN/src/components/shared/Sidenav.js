import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import MuiDrawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import HomeIcon from '@mui/icons-material/Home';
import DashboardIcon from '@mui/icons-material/Dashboard';
// import AnalyticsIcon from '@mui/icons-material/Analytics';
// import FolderIcon from '@mui/icons-material/Folder';
import OASELogo from '../../assets/image/OASE Logo White.png';
import { CardMedia, ClickAwayListener } from '@mui/material';
import ItemButton from '../sidenav/ItemButton';
import SubItem from '../sidenav/SubItem';
import GenerateItems from '../sidenav/GenerateItems';


const drawerWidth = 400;

const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: 'hidden',
    overflowY: 'initial',
    backgroundColor: '#156db8',
});

const closedMixin = (theme) => ({
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    overflowY: 'hidden',
    width: `calc(${theme.spacing(7)} + 1px)`,
    [theme.breakpoints.up('sm')]: {
        width: `calc(${theme.spacing(9)} + 1px)`,
    },
    backgroundColor: '#156db8',
});

const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: theme.spacing(4.0, 0),
    backgroundColor: '#156db8',
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        width: drawerWidth,
        flexShrink: 0,
        whiteSpace: 'nowrap',
        boxSizing: 'border-box',
        ...(open && {
            ...openedMixin(theme),
            '& .MuiDrawer-paper': openedMixin(theme),
        }),
        ...(!open && {
            ...closedMixin(theme),
            '& .MuiDrawer-paper': closedMixin(theme),
        }),
    }),
);


//Monitoring Items
const monitoringDashboard = {
    key: "Monitoring Dashboard",
    text: "Monitoring Dashboard",
    items: [
        {
            key: "SPV Mode",
            text: "SPV Mode",
            link: "/dashboard/spv-mode"
        },
        {
            key: "Lost Communication",
            text: "Lost Comm",
            link: "/dashboard/lost-comm"
        },
        {
            key: "DSA",
            text: "DSA",
            link: "/dashboard/dsa"
        },
        {
            key: "Test Page",
            text: "Test Page",
            link: "/dashboard/test-page"
        }
    ]
};

// const monitoringKibana = {
//     key: "Kibana",
//     text: "Kibana",
//     items: [
//         {
//             key: "SPC Overview",
//             text: "SPC Overview",
//             link: "/kibana/spc-overview"
//         },
//         {
//             key: "DPD Overview",
//             text: "DPD Overview",
//             link: "/kibana/dpd-overview"
//         }
//     ]
// };

// const monitoringReport = {
//     key: "Monitoring Report",
//     text: "Report",
//     items: [
//         {
//             key: "SPV Report",
//             text: "SPV Report",
//             link: "/report/spv-report"
//         },
//         {
//             key: "Lost Communication Report",
//             text: "Lost Comm Report",
//             link: "/report/lost-comm-report"
//         }
//     ]
// };


function Sidenav() {
    const [openDrawer, setOpenDrawer] = useState(false);

    const [openMenu, setOpenMenu] = useState(null);

    const handleDrawerOpen = () => {
        setOpenDrawer(true);
    };
    const handleDrawerClose = () => {
        setOpenDrawer(false);
    };

    //OPEN-CLOSE LOGIC FOR MENU & SUBMENU
    const handleClikMenu = (menu) => {
        if (menu === openMenu) {
            setOpenMenu(null);
        }

        setOpenMenu(menu);
    };

    return (
        <>
            <CssBaseline />
            <ClickAwayListener onClickAway={handleDrawerClose}>
                <Drawer variant="permanent" open={openDrawer}>
                    <DrawerHeader>
                        {!openDrawer ?
                            <IconButton onClick={handleDrawerOpen} size="large" edge="start" aria-label="menu" sx={{ ml: 0, color: "white" }}><HomeIcon /></IconButton>
                            :
                            <CardMedia onClick={handleDrawerClose} component="img" sx={{ width: "60%" }} image={OASELogo} alt="OASE" />
                        }
                    </DrawerHeader>
                    <Divider />
                    <List>
                        <>
                            <ItemButton text={monitoringDashboard.text} icon={<DashboardIcon />} onClickFunction={() => handleClikMenu(monitoringDashboard.key)} state={openMenu === monitoringDashboard.key} />
                            <SubItem level={1} state={(openMenu === monitoringDashboard.key) && openDrawer}>
                                <GenerateItems items={monitoringDashboard.items} level={1} />
                            </SubItem>
                        </>
                        <>
                            <ItemButton text={monitoringKibana.text} icon={<AnalyticsIcon />} onClickFunction={() => handleClikMenu(monitoringKibana.key)} state={openMenu === monitoringKibana.key} />
                            <SubItem level={1} state={(openMenu === monitoringKibana.key) && openDrawer}>
                                <GenerateItems items={monitoringKibana.items} level={1} />
                            </SubItem>
                        </>
                        <>
                            <ItemButton text={monitoringReport.text} icon={<FolderIcon />} onClickFunction={() => handleClikMenu(monitoringReport.key)} state={openMenu === monitoringReport.key} />
                            <SubItem level={1} state={(openMenu === monitoringReport.key) && openDrawer}>
                                <GenerateItems items={monitoringReport.items} level={1} />
                            </SubItem>
                        </>
                    </List>
                </Drawer>
            </ClickAwayListener>
        </>
    );
}


export default Sidenav;