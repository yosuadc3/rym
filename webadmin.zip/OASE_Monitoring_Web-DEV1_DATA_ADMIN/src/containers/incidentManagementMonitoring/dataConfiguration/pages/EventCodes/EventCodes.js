import React from "react";
import StyledSearch from "../../../../../components/search/StyledSearch";
import {useCallback,useState,useEffect} from 'react';
import { Grid, Button } from "@mui/material";
import StyledTable from "../../../../../components/table/StyledTable";
import {useGetEventCodesQuery} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodes/api/eventCodes'
import { customFormat } from "../../../../../utilities/TimeConverter";
import { TABLE_ADDONS_SEARCH_ITEMS, SEARCH_ITEMS} from "../../../../../constants/IncidentManagement/EventCodes";
import FormPopUp from "./FormPopUp";
import { handleInsertCodes, handleRemoveCodes, handleUpdateCodes, setData } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodes/eventCodes";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";


const tableColumnsCommonProps = {
    headerAlign: "center",
    align: "center",
    flex: 0.7
};

const styles = {
    table: {
        "& .MuiDataGrid-iconButtonContainer": {
            marginLeft: "0px !important"
        }
    }
}

function mapSearchItems() {
    return [
        ...TABLE_ADDONS_SEARCH_ITEMS,
        ...SEARCH_ITEMS
    ];
}


function EventCodes({id}) {
    const [currRowsPerPage, setCurrRowsPerPage] = useState(5);
    const [page, setPage] = useState(0);
    const [total, setTotal] = useState(0);
    const [firstRender, setFirstRender] = useState(true);
    const [tableData, setTableData] = useState([]);
    const [sortBy, setSortBy] = useState("id");
    const [orderBy, setOrderBy] = useState("desc");
    const [isResetSearch, setIsResetSearch] = useState(false);
    const [searchFlag, setSearchFlag] = useState(false);
    const [advancedSearchFlag, setAdvancedSearchFlag] = useState(false);
    const [searchValue, setSearchValue] = useState(null);
    const [advancedSearchValue, setAdvancedSearchValue] = useState(null);
    const [advancedSearchPeriode, setAdvancedSearchPeriode] = useState({ startDate: null, endDate: null });
    const [isUpdate, setIsUpdate]= useState(false);
    const [updateData, setUpdateData] = useState({id:"",event_code:"",description:"",group:"",rule:""});
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const handleCellClick = (id) =>{
        navigate('/data-configuration/event-codes/'+id);
    }

    const [queryParams, setQueryParams] = useState({
        catalog_id: id,
        page: 0,
        limit: 10,
        sortBy: "id",
        orderBy: "desc",
        search: null,
        advancedSearch: null,
        advancedSearchPeriode: null
    });
    const { data: eventCodesData, isLoading: eventCodesIsLoading, refetch:eventCodesRefetch  } = useGetEventCodesQuery(queryParams,{ refetchOnMountOrArgChange: isUpdate? true:60 });

    
const tableColumns = [
    {
        ...tableColumnsCommonProps,
        field: "event_code",
        headerName: "Event Code",
        flex: 2,
    },
    {
        field: "description",
        headerName: "Description",
        headerAlign: 'left',
        align: 'left',
        flex: 4,
    },
    {
        field: "group",
        headerName: "Group",
        headerAlign: 'left',
        align: 'left',
        flex: 3,
    },
    {
        field: "rule",
        headerName: "Rule",
        headerAlign: 'left',
        align: 'left',
        flex: 3,
    },
    {
        field: "message",
        headerName: "Message",
        headerAlign: 'left',
        align: 'left',
        flex: 3,
    },
    {
        field: "knowledge_base",
        headerName: "Knowledge Base",
        headerAlign: 'left',
        align: 'left',
        flex: 4,
        renderCell: (data)=>{return (<>{data.row.knowledge_base.length>30?data.row.knowledge_base.substring(0,30)+"..":data.row.knowledge_base}</>)}
    },
    {
        ...tableColumnsCommonProps,
        field: "-",
        headerName: "Action",
       // renderCell: (data) =>  Action(data.row,handleOpenUpdateClick,handleOpenRemoveClick,setUpdateData),
        flex: 2,
        sortable: false 
    },
];
    useEffect(() => {
        if (!eventCodesIsLoading) {
            const { data, total} = eventCodesData;
            setTableData(data);
            setTotal(total);
        }
    }, [eventCodesData, eventCodesIsLoading]);

    useEffect(() => {
        if (firstRender) {
            setFirstRender(false);
        }else{
            setIsUpdate(true);
            eventCodesRefetch();
        }
    }, [useSelector((state) => state.eventCodes.refresh)]);

    useEffect(()=>{
        dispatch(setData(updateData));
    },[updateData]);

    useEffect(() => {
        const commonParams = {
            catalog_id: id,
            page: page,
            limit: currRowsPerPage,
            sortBy: sortBy,
            orderBy: orderBy
        }

        if (searchFlag) {
            setQueryParams({
                ...commonParams,
                search: searchValue
            });
        }
        else if (advancedSearchFlag) {
            setQueryParams({
                ...commonParams,
                advancedSearch: advancedSearchValue,
                advancedSearchPeriode: advancedSearchPeriode
            });
        }
        else {
            setQueryParams(commonParams);
        }
    }, [page, currRowsPerPage, sortBy, orderBy, searchValue, advancedSearchValue, advancedSearchPeriode]);


    const handleSortModelChange = useCallback((sortModel) => {
        if (sortModel.length) {
            setSortBy(() => sortModel[0]?.field);
            setOrderBy(() => sortModel[0]?.sort);
        } else {
            setSortBy(() => "id");
            setOrderBy(() => "desc");
        }
    }, []);
    

    
    const handleSearchClick = (searchInput) => {
        const { text, column } = searchInput;
        const data = {};

        if (column === "all") {
            SEARCH_ITEMS.forEach((item) => {
                data[item.value] = text;
            });
        }
        else {
            data[column] = text;
        }

        setSearchValue(data);
        setSearchFlag(true);
        setAdvancedSearchFlag(false);
    }

    const handleAdvancedSearchSubmit = (data) => {
        const { selectedDates, advancedData } = data;
        const temp = {};

        if (advancedData[0]?.category !== null) {
            advancedData.forEach((item) => {
                temp[item.category] = item.chips;
            });

            setAdvancedSearchValue(temp);
        }

        setAdvancedSearchPeriode({
            startDate: customFormat(selectedDates.startDate),
            endDate: customFormat(selectedDates.endDate)
        });
        setAdvancedSearchFlag(true);
        setSearchFlag(false);
    }

    const handleOpenInsertClick = () => {
        dispatch(handleInsertCodes());
    }

    const handleOpenUpdateClick = () => {
        dispatch(handleUpdateCodes());
    }

    const handleOpenRemoveClick = () => {
        dispatch(handleRemoveCodes());
    }

    return (
        <>
            <Grid container direction={"row"} alignItems={"center"}>
                <Grid item xs={8} marginRight={"auto"}>
                    <StyledSearch
                        useAdvancedSearch
                        selectMenuItems={mapSearchItems()}
                        handleSearchClick={handleSearchClick}
                        handleAdvancedSearchSubmit={handleAdvancedSearchSubmit}
                        isResetSearch={isResetSearch}
                        setIsResetSearch={setIsResetSearch}
                    />
                </Grid>
                <Grid item marginRight={1}>
                    <Button 
                        variant="outlined"
                        disableElevation 
                        sx={{color:"#0D5CAB",fontWeight:"bold", fontSize:"16px",textTransform:"capitalize", padding:"10px",paddingX:"35px", borderRadius:"6px"}}
                        onClick={handleOpenInsertClick}
                        >
                        Tambah
                    </Button>
                </Grid>
            </Grid>
            <Grid container alignItems={"center"} marginTop={4}>
                <Grid item sx={styles.table} xs={12}>
                    <StyledTable
                        headers={tableColumns}
                        page={page}
                        rows={tableData}
                        pageSize={currRowsPerPage}
                        loading={eventCodesIsLoading}
                        rowCount={total}
                        setPage={(e) => setPage(e)}
                        useStripesWhiteGray
                        setPageSizeChange={(e) => setCurrRowsPerPage(e)}
                        onSortModelChange={handleSortModelChange}
                        //disableRowClick
                    />
                </Grid>
            </Grid>
            <FormPopUp id={id}/>
        </>
    );
}


export default EventCodes;