import { Box, Divider, Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import AutocompleteBase from "../../../../../components/autocomplete/AutocompleteBase";
import EmptyCard from "../../../../../components/cards/EmptyCard";
import BasicSelect from "../../../../../components/select/BasicSelect";
import SkeletonCircular from "../../../../../components/skeleton/SkeletonCircular";
import SkeletonText from "../../../../../components/skeleton/SkeletonText";
import { SUMMARY_ADDON_FILTER_ITEMS, SUMMARY_FILTER_TYPE } from "../../../../../constants/ServiceAvailability";
import { SERVICE_AVAILABILITY_INTERVAL } from "../../../../../constants/UpdateInterval";
import { useGetSummaryQuery } from "../../../../../redux/features/dashboard/serviceAvailability/api/serviceAvailability";
import { updateTimestamp } from "../../../../../redux/features/dashboard/serviceAvailability/serviceAvailability";
import { useGetReportFiltersQuery } from "../../../../../redux/features/report/atlas/api/reportAtlas";
import { numberWithCommas } from "../../../../../utilities/NumberFormatting";
import PieChart from "../chart/PieChart";

const styles = {
    title: {
        fontSize: "1.5rem",
        fontWeight: "bold",
        color: "#0F549F",
        marginBottom: 1,
        textAlign: "left",
    },
    textBasedOn: {
        fontSize: "14px",
        fontWeight: "bold",
        color: "#FFFFF",
        textAlign: "right"
    }
}

function addItemsToCategories(data) {
    return [
        ...SUMMARY_ADDON_FILTER_ITEMS,
        ...data
    ];
}

export default function Summary({ }) {
    const dispatch = useDispatch();
    const refresh = useSelector((state) => state.serviceAvailability.refresh);
    const [queryParams, setQueryParams] = useState({ category: null, value: null });
    const [selectedCategory, setSelectedCategory] = useState("all");
    const [selectedValue, setSelectedValue] = useState(null);
    const [pieData, setPieData] = useState([]);
    const [totalTerminal, setTotalTerminal] = useState(0);
    const [categories, setCategories] = useState([]);
    const [values, setValues] = useState({});
    const { data: summaryData, isLoading: summaryIsLoading, refetch: refetchSummary } = useGetSummaryQuery(queryParams, { pollingInterval: SERVICE_AVAILABILITY_INTERVAL, refetchOnReconnect: true });
    const { data: filterData, isLoading: filterIsLoading, refetch: refetchFilter } = useGetReportFiltersQuery(SUMMARY_FILTER_TYPE);

    useEffect(() => {
        if (!summaryIsLoading) {
            const { data, total_terminal, last_update } = summaryData;
            setPieData(data);
            setTotalTerminal(total_terminal);
            dispatch(updateTimestamp(last_update));
        }
    }, [summaryData, summaryIsLoading]);

    useEffect(() => {
        if (!filterIsLoading) {
            const { categories, values } = filterData;
            setCategories(categories);
            setValues(values);
        }
    }, [filterData, filterIsLoading]);

    useEffect(() => {
        let category = null;
        let value = null;

        if (selectedCategory !== "all") {
            category = selectedCategory;
            value = selectedValue;
        }
        else {
            setQueryParams({
                category: null,
                value: null
            });
        }

        if (selectedValue !== null) {
            setQueryParams({
                category: category,
                value: value
            });
        }
    }, [selectedCategory, selectedValue]);

    useEffect(() => {
        refetchSummary();
        // refetchFilter();
    }, [refresh]);

    const handleSelectCategory = (event) => {
        const { value } = event.target;

        setSelectedCategory(value);
        setSelectedValue(null);
    }

    const handleSelectValues = (_, values) => {
        setSelectedValue(values);
    }

    return (
        <EmptyCard sx={{ padding: 3 }} >
            <Grid container direction={"column"}>
                <Grid item>
                    <Grid container>
                        <Grid item xs={5} alignSelf={"center"}>
                            <Typography sx={styles.title}>Availability Summary</Typography>
                        </Grid>
                        <Grid item xs={7}>
                            <Grid container direction={"row"} spacing={1}>
                                <Grid item xs={3} alignSelf={"center"}>
                                    <Typography sx={styles.textBasedOn}>Based on</Typography>
                                </Grid>
                                <Grid item xs={9}>
                                    <Grid container textAlign={"left"}>
                                        <Grid item xs={5} paddingRight={0.5}>
                                            <BasicSelect items={addItemsToCategories(categories)} onChange={handleSelectCategory} value={selectedCategory} />
                                        </Grid>
                                        <Grid item xs={7} paddingLeft={0.5}>
                                            <AutocompleteBase onChange={handleSelectValues} options={values[selectedCategory] || []} value={selectedValue} multiple={false} />
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item>
                    <Box height={300} position={"relative"} >
                        <Box sx={{ paddingLeft: "60%", paddingTop: "2%", position: "absolute", width: "100%" }}>
                            <Typography sx={{ fontSize: 18, textAlign: "left", color: "#65748B" }}>Total WSID</Typography>
                            <Divider sx={{ width: "70%" }} />
                            {
                                !summaryIsLoading ? (
                                    <Typography sx={{ fontSize: 26, fontWeight: "bold", marginTop: 1, textAlign: "left" }}>{numberWithCommas(totalTerminal)} WSID</Typography>
                                ) : (
                                    <SkeletonText height={52} width={"70%"} />
                                )
                            }
                        </Box>
                        {
                            !summaryIsLoading ? (
                                <PieChart
                                    data={pieData}
                                    total={totalTerminal}
                                    margin={{ top: 32, bottom: 30, left: -300, right: 0 }}
                                    colors={d => d.data.color}
                                    arcLinkLabelsDiagonalLength={20}
                                    arcLinkLabelsStraightLength={10}
                                    arcLinkLabelsSkipAngle={1}
                                    legendsProps={{ translateX: -305, translateY: -22 }}
                                />
                            ) : (
                                <SkeletonCircular
                                    height={230}
                                    width={230}
                                    sx={{ marginLeft: 17 }}
                                />
                            )
                        }
                    </Box>
                </Grid>
            </Grid>
        </EmptyCard>
    );
}