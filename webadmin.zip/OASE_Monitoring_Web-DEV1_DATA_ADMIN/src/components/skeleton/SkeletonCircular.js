import React from "react";
import Skeleton from "@mui/material/Skeleton";

export default function SkeletonCircular({ width = 50, height = 50, sx }) {
    return (<Skeleton variant="circular" animation="wave" width={width} height={height} sx={sx} />);
}