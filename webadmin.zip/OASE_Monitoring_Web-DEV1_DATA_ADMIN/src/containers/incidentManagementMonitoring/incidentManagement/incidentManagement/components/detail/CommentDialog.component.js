import { Box, DialogActions, DialogContent, Grid, Stack } from "@mui/material";
import React from "react";
import { useDispatch, useSelector } from "react-redux";

import StyledDivider from "../../../../../../components/divider/StyledDivider";
import FormButton from "../../../../../../components/form/FormButton";
import FormDialog from "../../../../../../components/form/FormDialog";

import { setIsOpenDialogViewComments } from "../../../../../../redux/features/incident-management-monitoring/incident-management/imm";
import CustomGrid from "../../../../../../utilities/CustomGrid";
import Comments from "./Comments.component";

export default function CommentDialog({
  isOpenDialog,
}) {
  const { incident_number, start_time, end_time, action_code, action_code_description, status_code, status_code_description } = useSelector(state => state.incidentManagement);

  const currentIncident = {
    "Start Time": start_time,
    "End Time": end_time,
    "Action Code": action_code,
    "Action Code Description": action_code_description,
    "Status Code": status_code,
    "Status Code Description": status_code_description
  }

  const dispatch = useDispatch();

  const handleToggleDialog = () => {
    dispatch(setIsOpenDialogViewComments(
      {
        data: {
          isOpenDialogViewComments: false
        }
      }
    ))
  };

  return (
    <>
      <FormDialog
        title="Detail Incident"
        isOpen={isOpenDialog}
        width="55%"
        handleToggle={handleToggleDialog}
      >
        <DialogContent>
          <Grid container spacing={4}>
            <Grid item xs={12}>
              <Grid sx={{ marginBottom: 4 }}>
                <CustomGrid
                  title="Incident Number"
                  description={incident_number}
                  xs={12}
                />
              </Grid>
              <Grid container spacing={4}>
                {Object.keys(currentIncident).map((item, i) => (
                  <CustomGrid
                    key={i}
                    title={item}
                    description={currentIncident[item]}
                    xs={6}
                    useContainer
                  />
                ))}
              </Grid>
            </Grid>
            <Grid item xs={12} marginTop={-3}>
              <StyledDivider />
            </Grid>
            <Comments />
          </Grid>
        </DialogContent>
        <DialogActions>
          <Stack
            direction="column"
            width="100%"
            justifyContent="center"
            alignItems="center"
            paddingX={2}
            paddingBottom={2}
          >
            <Box width="15%">
              <FormButton
                primary
                isOutlined
                onClick={handleToggleDialog}
                label="Back"
              />
            </Box>
          </Stack>
        </DialogActions>
      </FormDialog>
    </>
  );
}
