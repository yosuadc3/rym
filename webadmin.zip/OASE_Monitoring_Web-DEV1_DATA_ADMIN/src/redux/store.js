import { configureStore } from "@reduxjs/toolkit";
import { setupListeners } from "@reduxjs/toolkit/query/react";
import { dsaApi } from "./features/dashboard/dsa/api/dsa";
import { lostcommApi } from "./features/dashboard/lostcomm/api/lostcomm";
import { serviceAvailabilityApi } from "./features/dashboard/serviceAvailability/api/serviceAvailability";
import serviceAvailabilitySlice from "./features/dashboard/serviceAvailability/serviceAvailability";
import { spvModeApi } from "./features/dashboard/spvMode/api/spvMode";

import { eventCodesApi } from "./features/incidentManagementMonitoring/dataConfiguration/eventCodes/api/eventCodes";
import eventCodesSlice from "./features/incidentManagementMonitoring/dataConfiguration/eventCodes/eventCodes";

import { eventCodeGroupApi } from "./features/incidentManagementMonitoring/dataConfiguration/eventCodeGroup/api/eventCodeGroup";
import eventCodeGroupSlice from "./features/incidentManagementMonitoring/dataConfiguration/eventCodeGroup/eventCodeGroup";

import { eventCodeRulesApi } from "./features/incidentManagementMonitoring/dataConfiguration/eventCodeRules/api/eventCodeRules";
import eventCodeRulesSlice from "./features/incidentManagementMonitoring/dataConfiguration/eventCodeRules/eventCodeRules";

import { eventCodeSourceApi } from "./features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/api/eventCodeSource";
import eventCodeSourceSlice from "./features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/eventCodeSource";

import { faultCategoryApi } from "./features/incidentManagementMonitoring/dataConfiguration/faultCategory/api/faultCategory";
import faultCategorySlice from "./features/incidentManagementMonitoring/dataConfiguration/faultCategory/faultCategory";

import { reportDataConfigurationApi } from "./features/report/dataConfiguration/api/dataConfiguration";
import reportDataConfigurationSlice from "./features/report/dataConfiguration/dataConfiguration";

import { immApi } from "./features/incident-management-monitoring/incident-management/api/imm";
import incidentManagementSlice from "./features/incident-management-monitoring/incident-management/imm";
import { ticketActionApi } from "./features/incidentManagementMonitoring/dataConfiguration/ticketAction/api/ticketAction";
import { reportAtlasApi } from "./features/report/atlas/api/reportAtlas";
import reportAtlasSlice from "./features/report/atlas/reportAtlas";

import colorPickerSlice from "./features/incidentManagementMonitoring/colorPicker/colorPicker";

export const store = configureStore({
    reducer: {
        [dsaApi.reducerPath]: dsaApi.reducer,
        [lostcommApi.reducerPath]: lostcommApi.reducer,
        [spvModeApi.reducerPath]: spvModeApi.reducer,
        [serviceAvailabilityApi.reducerPath]: serviceAvailabilityApi.reducer,
        [reportAtlasApi.reducerPath]: reportAtlasApi.reducer,
        [eventCodesApi.reducerPath]: eventCodesApi.reducer,
        [eventCodeGroupApi.reducerPath]: eventCodeGroupApi.reducer,
        [eventCodeRulesApi.reducerPath]: eventCodeRulesApi.reducer,
        [eventCodeSourceApi.reducerPath]: eventCodeSourceApi.reducer,
        [reportDataConfigurationApi.reducerPath]: reportDataConfigurationApi.reducer,
        [faultCategoryApi.reducerPath]: faultCategoryApi.reducer,
        [ticketActionApi.reducerPath]: ticketActionApi.reducer,
        [serviceAvailabilitySlice.name]: serviceAvailabilitySlice.reducer,
        [immApi.reducerPath]: immApi.reducer,
        [incidentManagementSlice.name]: incidentManagementSlice.reducer,
        [serviceAvailabilitySlice.name]: serviceAvailabilitySlice.reducer,
        [reportAtlasSlice.name]: reportAtlasSlice.reducer,
        [reportDataConfigurationSlice.name]: reportDataConfigurationSlice.reducer,
        [eventCodesSlice.name]: eventCodesSlice.reducer,
        [eventCodeGroupSlice.name]: eventCodeGroupSlice.reducer,
        [eventCodeSourceSlice.name]: eventCodeSourceSlice.reducer,
        [eventCodeRulesSlice.name]: eventCodeRulesSlice.reducer,
        [faultCategorySlice.name]: faultCategorySlice.reducer,
        [colorPickerSlice.name]: colorPickerSlice.reducer,
    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            serializableCheck: false,
        })
            .concat(dsaApi.middleware)
            .concat(lostcommApi.middleware)
            .concat(spvModeApi.middleware)
            .concat(serviceAvailabilityApi.middleware)
            .concat(reportAtlasApi.middleware)
            .concat(eventCodesApi.middleware)
            .concat(eventCodeGroupApi.middleware)
            .concat(faultCategoryApi.middleware)
            .concat(ticketActionApi.middleware)
            .concat(eventCodeRulesApi.middleware)
            .concat(eventCodeSourceApi.middleware)
            .concat(immApi.middleware)
            .concat(reportDataConfigurationApi.middleware)
});

setupListeners(store.dispatch);