const oracledb = require("oracledb");
const path = require("path");
const schedule = require("node-schedule");
const databaseConfig = require("../configs/database.config");
import * as dateTime from "../utils/dateTime.util";
import printToConsole from "../utils/printToConsole.util";

const environment = `[${process.env.NODE_ENV?.toUpperCase()}]`;
const convertUnix = dateTime.convertUnix;

let pool: any;

function initOracleClient() {
	try {
		oracledb.initOracleClient({ configDir: path.resolve("oracle-config") });
	} catch (err) {
		printToConsole("initOracleClient", err);
		process.exit(1);
	}
}

function init(): Promise<void> {
	process.stdout.write(`${environment}: Connecting to GASPER...`);
	return new Promise(async (resolve, reject) => {
		try {
			// await initOracleClient();
			oracledb.initOracleClient({ configDir: path.resolve("oracle-config") });
			pool = await oracledb.createPool(databaseConfig.gasper);

			process.stdout.write(`\r${environment}: Connected to GASPER    \n`);

			poolStatisticLogging();
			resolve();
		} catch (error) {
			process.stdout.write(`\r${environment}: Failed to connect to GASPER\n`);
			printToConsole("createPool", error);
			reject();
		}
	});
}

async function exec(query: string, binds = {}) {
	return execHelper(pool, query, binds);
}

async function close() {
	try {
		await schedule.gracefulShutdown();

		await pool.close();
	} catch (error) {
		printToConsole("closePool", error);
	}
}

async function execHelper(pool: any, query: string, binds: any) {
	let connection;

	try {
		connection = await pool.getConnection();

		const options = {
			outFormat: oracledb.OUT_FORMAT_OBJECT,
			autoCommit: true,
		};
		const result = await connection.execute(query, binds, options);

		return result;
	} finally {
		// catch (error) {
		//     printToConsole("execQuery", error);
		// }
		if (connection) {
			try {
				await connection.close();
			} catch (error) {
				printToConsole("closeConnection", error);
			}
		}
	}
}

function poolStatisticLogging() {
	// console.log(`UV_THREADPOOL_SIZE: ${pool.getStatistics().threadPoolSize}`);

	/*	const poolStatisticLogging = schedule.scheduleJob(
			"0 0 * * *",
			async function () {
				const poolStatistics = pool.getStatistics();
	
				// pool.logStatistics();
				const statistics = `
			  Pool Statistics:
			  - gathered date: ${convertUnix(poolStatistics.gatheredDate)}
			  - up time (miliseconds): ${poolStatistics.upTime}
			  - connection requests: ${poolStatistics.connectionRequests}
			  - requests failed: ${poolStatistics.failedRequests}
			  - requests rejected: ${poolStatistics.rejectedRequests}
			  - requests timeout: ${poolStatistics.requestTimeouts}
			  - average time in queue: ${poolStatistics.averageTimeInQueue}
			  - connection in use: ${poolStatistics.connectionsInUse}
			  - connection open: ${poolStatistics.connectionsOpen}`;
	
				console.log(statistics);
			}
		);
		*/
}

module.exports = {
	init,
	exec,
	close,
};

export { };

