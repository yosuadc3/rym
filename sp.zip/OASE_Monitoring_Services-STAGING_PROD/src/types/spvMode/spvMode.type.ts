import { Request } from "express";
import { IId, IUser } from "../global.type";

export interface IGetSPVModeRequest
	extends IUser,
	Request<any, any, any, any, any> { }

export interface IGetSPVModeByFLMRequest
	extends IUser,
	Request<any, any, any, any, any> { }
export interface IGetDetailSPVModeRequest
	extends IUser,
	Request<any, any, any, any, any> { }
export interface IGetSPVModeReportRequest
	extends IUser,
	Request<any, any, any, any, any> { }
