import { Grid } from "@mui/material";
import React from "react";
import CustomBreadcrumbs from "../../../../../components/breadcrumb/CustomBreadcrumbs";
import { INCIDENT_MANAGEMENT_BREADCRUMBS } from "../constants/IncidentManagement";

const Breadcrumbs = () => {
  return (
    <Grid item xs={7}>
      <CustomBreadcrumbs breadcrumbs={INCIDENT_MANAGEMENT_BREADCRUMBS} />
    </Grid>
  );
};

export default Breadcrumbs;
