import moment from "moment";

export function dateSubtract(amount = 0, unit = "days", date, format = "YYYY-MM-DD") {
    const _date = date || moment();

    return moment(_date).subtract(amount, unit).format(format);
}

export function dateAdd(amount = 0, unit = "days", date, format = "YYYY-MM-DD") {
    const _date = date || moment();

    return moment(_date).add(amount, unit).format(format);
}