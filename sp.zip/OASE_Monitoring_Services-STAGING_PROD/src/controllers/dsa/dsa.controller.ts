import { Response } from "express";
import {
	IGetDSAReportRequest,
	IGetDSARequest,
} from "../../types/dsa/dsa.type";

//DSA Controller
import * as jsonMessage from "../../utils/jsonMessage.util";
import printToConsole from "../../utils/printToConsole.util";
const dsaRepo = require("../../repositories/dsa.repository");

export const getDSA = async (req: IGetDSARequest, res: Response) => {
	try {
		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const data = await dsaRepo.get();
		let total = 0;
		// let temp = "";
		// let responseArray = [];
		// let responseDSA = {};

		// data.rows.map(item => {
		//     if (item.PENGELOLA === temp) {
		//         // Using Last Object
		//         responseDSA.WSID.push(item.ID);
		//         responseDSA.JUMLAH = responseDSA.WSID.length;
		//     } else {
		//         // Create New Object
		//         responseDSA = {};
		//         responseDSA.PENGELOLA = item.PENGELOLA;
		//         responseDSA.WSID = [];
		//         responseDSA.WSID.push(item.ID);
		//         responseDSA.JUMLAH = responseDSA.WSID.length;
		//         responseArray.push(responseDSA);
		//     }
		//     temp = item.PENGELOLA;
		//     total++;
		// })

		const responseArray = data.rows.map((value: any) => {
			total += value.JUMLAH;

			return {
				PENGELOLA: value.PENGELOLA,
				WSID: value.ID.split(","),
				JUMLAH: value.JUMLAH,
			};
		});

		const response = {
			total: total,
			data: responseArray,
		};
		const message = {
			english: `Successfully Retrieved DSA Data`,
			indonesia: `Berhasil Mengambil Data DSA`,
		};

		res.send(jsonMessage.jsonSuccess(message, response));
	} catch (err) {
		jsonMessage.getInternalServerError(
			err,
			res,
			"Some error occurred while retrieved DSA Data"
		);
		printToConsole("DSA-get", err);
	}
};

export const getDSAReport = async (
	req: IGetDSAReportRequest,
	res: Response
) => {
	try {
		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const data = await dsaRepo.getReport();
		const message = {
			english: `Successfully Retrieved DSA Report`,
			indonesia: `Berhasil Mengambil Report DSA`,
		};

		res.send(jsonMessage.jsonSuccess(message, data.rows));
	} catch (err) {
		jsonMessage.getInternalServerError(
			err,
			res,
			"Some error occurred while retrieved DSA Data"
		);
		printToConsole("DSA-getReport", err);
	}
};

export { };

