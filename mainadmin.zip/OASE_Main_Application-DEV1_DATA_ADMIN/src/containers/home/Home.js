/* eslint-disable no-unused-vars */
import React, { useEffect, lazy, Suspense } from "react";
import { Grid } from "@mui/material";
import { hasRoles } from "../../token/roles";
import { axiosGet } from "../../utilities/AxiosHelper";

const API_URI = process.env.REACT_APP_API_OASE;

const AssetManagementInfo = lazy(() => import('./components/AssetManagementInfo'));
const ATMLocation = lazy(() => import('./components/ATMLocation'));
const ProgressTask = lazy(() => import('./components/ProgressTask'));

async function getDataDashboard() {
  const temp = {
    dataDashboard: {},
  };
  try {
    const res = await axiosGet(API_URI, "/dashboard");
    if (res.data !== undefined) {
      temp.dataDashboard = res.data;
    } else {
      temp.message = res.error_code + " - " + res.error_message.code;
    }
  } catch (error) {
    if (error.response !== undefined) {
      temp.message = error.response.status + " - " + error.response.statusText;
    } else {
      temp.message = "Something wrong!";
    }
  }
  return temp;
}

async function getDataProgressTaskDashboard() {
  const temp = {
    dataProgressTask: {},
  };
  try {
    const res = await axiosGet(API_URI, "/dashboard/asset/progress-task");
    if (res.data !== undefined) {
      temp.dataProgressTask = res.data;
    } else {
      temp.message = res.error_code + " - " + res.error_message.code;
    }
  } catch (error) {
    if (error.response !== undefined) {
      temp.message = error.response.status + " - " + error.response.statusText;
    } else {
      temp.message = "Something wrong!";
    }
  }
  return temp;
}

function Home() {
  const [dataDashboard, setDataDashboard] = React.useState({});
  const [dataProgressTask, setDataProgressTask] = React.useState({})
  const is_bca = localStorage.getItem('is_bca')

  useEffect(() => {
    if (hasRoles(['DASHBOARD', 'DASHBOARD_ADMIN_WH'])) {
      async function fetchDataDashboard() {
        const temp = await getDataDashboard();
        setDataDashboard(temp.dataDashboard)
      }
      async function fetchDataProgressTaskDashboard() {
        const temp = await getDataProgressTaskDashboard();
        setDataProgressTask(temp.dataProgressTask)
      }
      fetchDataDashboard();
      fetchDataProgressTaskDashboard();
    }
  }, []);

  return (
    <>
      <Grid container spacing={3}>
        {hasRoles(['DASHBOARD', 'DASHBOARD_ADMIN_WH']) &&
          <Suspense fallback={<div>Sedang memuat...</div>}>
            <Grid item xs={4}>
              <AssetManagementInfo data={dataDashboard.dashboardStatus} />
            </Grid>
          </Suspense>
        }
        {hasRoles(['DASHBOARD_MAP']) &&
          <Suspense fallback={<div>Sedang memuat...</div>}>
            <Grid item xs={8}>
              <ATMLocation />
            </Grid>
          </Suspense>
        }
        {hasRoles(['DASHBOARD_ADMIN_WH']) &&
          <Suspense fallback={<div>Sedang memuat...</div>}>
            <Grid item xs={5}>
              <ProgressTask dataProgressTask={dataProgressTask} />
            </Grid>
          </Suspense>
        }
      </Grid>
    </>
  );
}

export default Home
