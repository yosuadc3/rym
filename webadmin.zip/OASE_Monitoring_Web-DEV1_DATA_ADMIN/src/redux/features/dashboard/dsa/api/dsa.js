import { createApi } from "@reduxjs/toolkit/query/react";
import { BASE_URL_API_MONITORING } from "../../../../../constants/Api";
import axiosBaseQuery from "../../../../utils/axiosBaseQuery";

const path = "/dsa";

export const dsaApi = createApi({
    reducerPath: "dsaApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getDsa: builder.query({
            query: () => ({ url: path, method: "get" }),
            transformResponse: (res) => (res.data.data)
        }),
        getDsaReport: builder.query({
            query: () => ({ url: `${path}/report`, method: "get" }),
            transformResponse: (res) => (res.data)
        }),
    })
});

export const { useGetDsaQuery, useGetDsaReportQuery } = dsaApi;
