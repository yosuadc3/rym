import { Response } from "express";
import { matchedData } from "express-validator";
import { HTTP_NO_CONTENT } from "../../../constants/httpResponseCodes.constant";
import * as db from "../../../repositories/dataAdmin/eventCode/index.repository";
import { IGetAllRequest, IRequestQueryParams, TDbResponse, TRequestBodyInsertEventCode, TRequestBodyUpdateEventCode, TRequestParams } from "../../../types/dataAdmin/dataAdmin.types";
import addPayloadToRequestHeader from "../../../utils/addPayloadToRequestHeader.util";
import { getInternalServerError, jsonSuccess } from "../../../utils/jsonMessage.util";
import { replaceNullOrEmptyStringArray } from "../../../utils/object/replaceNullOrEmptyStringArray.util";
import printToConsole from "../../../utils/printToConsole.util";

const message = {
    "english": `Successfully Retrieved Event Code`,
    "indonesia": `Berhasil Mengambil Event Code`,
}
const errorMessage = "Internal Server Error!";
const errorTag = "getEventCode";

export async function getEventCodes(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    let dbRes: TDbResponse = [[], []];
    // const queryData: IRequestQueryParams = matchedData(req, { locations: ["query"] });
    const catalog_id = req?.query?.catalog_id;
    const page = req?.query?.page;
    const limit = req?.query?.limit;
    const sortBy = req?.query?.sortBy;
    const orderBy = req?.query?.orderBy;
    const search = req?.query?.search;
    const advancedSearch = req?.query?.advancedSearch;
    const advancedSearchPeriode = req?.query?.advancedSearchPeriode;

    if (search) {
        const params = {
            search: JSON.parse(search)
        }

        dbRes = await db.getEventCodes(catalog_id!, page!, limit!, sortBy!, orderBy!, params);
    }
    else if (advancedSearch || advancedSearchPeriode) {
        const params = {
            advancedSearch: advancedSearch ? JSON.parse(advancedSearch) : null,
            advancedSearchPeriode: advancedSearchPeriode ? JSON.parse(advancedSearchPeriode) : null
        }

        dbRes = await db.getEventCodes(catalog_id!, page!, limit!, sortBy!, orderBy!, params);
    }
    else {
        dbRes = await db.getEventCodes(catalog_id!, page!, limit!, sortBy!, orderBy!);
    }

    const [data, [total]] = dbRes;

    replaceNullOrEmptyStringArray(data);

    const payload = {
        ...total,
        data: data
    }

    res.send(jsonSuccess(message, payload));
}

export async function getEventCode(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    // const paramsData: TRequestParams = matchedData(req, { locations: ["params"] });

    const [data] = await db.getEventCode(req?.params?.id!);

    res.send(jsonSuccess(message, data));
}

export async function putEventCode(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    //const paramsData: TRequestParams = matchedData(req, { locations: ["params"] });
    //const bodyData: TRequestBodyUpdateEventCode = matchedData(req, { locations: ["body"] });

    if (Object.keys(req?.body).length > 0) {
        const updateData = {
            ...req?.body,
            modified_by: name
        }

        await db.putEventCode(req?.params?.id!, updateData, name);

        const message = {
            "english": `Successfully Update Event Code`,
            "indonesia": `Berhasil Memperbaharui Event Code`,
        }

        res.send(jsonSuccess(message));
    }
}

export async function postEventCode(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    //const bodyData = matchedData(req, { locations: ["body"], includeOptionals: true });
    const message = {
        "english": `Successfully Insert Event Code`,
        "indonesia": `Berhasil Memasukkan Event Code`,
    }
    await db.postEventCode(req?.body, name);
    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function deleteEventCode(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;

    const paramsData = matchedData(req, { locations: ["params"] });

    const message = {
        "english": `Successfully Delete An Event Code`,
        "indonesia": `Berhasil Menghapus Sebuah Event Code`,
    }

    await db.deleteEventCode(req?.params?.id, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export { };

