import { CENTER_COLUMNS } from "../../../../utilities/MaterialUI";

export const REPORT_TYPE_MENU_DATA_CONFIGURATION = "Report Data Configuration";
export const REPORT_TYPE_MENU_LOG_PERUBAHAN = "Report Log Perubahan";

export const filterBoxStyles = {
  label: {
    color: "#65748B",
    fontSize: "14px",
    fontWeight: 600,
  },
  btnSearch: {
    width: 120,
    backgroundColor: "#0D5CAB",
    height: 48,
    color: "white",
    borderRadius: 1,
    fontSize: 16,
    fontFamily: "Montserrat",
    textTransform: "inherit",
    marginLeft: 2,
    "&:hover": {
      backgroundColor: "#125fa1",
    },
    "&:active": {
      backgroundColor: "#0D5CAB",
    },
  },
  btnResetFilter: {
    textTransform: "inherit",
    backgroundColor: "transparent",
    border: "transparent",
    fontSize: "14px",
    color: "#156DB8",
    fontFamily: "Montserrat",
    fontWeight: 600,
    px: 1,
    "&:hover": {
      backgroundColor: "transparent",
    },
    "&:active": {
      backgroundColor: "transparent",
    },
  },
  btnAddSearchCategory: {
    marginTop: "10px",
    border: "transparent",
    backgroundColor: "transparent",
    fontSize: "12px",
    color: "#156DB8",
    textDecoration: "underline",
    fontWeight: 600,
    cursor: "pointer",
  },
  btnDeleteSelect: {
    px: 0,
    py: 0,
    "&:hover": {
      backgroundColor: "transparent",
    },
    minWidth: 0,
  },
};

export const styles = {
  reportTitle: {
    fontSize: 20,
    fontFamily: "Montserrat",
    fontWeight: 600,
    color: "#333333",
    textAlign: "left",
  },
  reportDescription: {
    fontSize: 12,
    textAlign: "left",
    fontFamily: "Montserrat",
    fontWeight: 500,
    color: "#333333",
    whiteSpace: "nowrap",
  },
  filterBtnDiv: {
    display: "flex",
    justifyContent: "center",
    alignContent: "center",
  },
  filterBtn: {
    fontFamily: "Montserrat",
    fontWeight: 700,
    textTransform: "inherit",
    width: 127,
    height: 48,
    fontSize: 18,
    backgroundColor: "#FFFF",
    color: "#0D5CAB",
    borderRadius: 1,
    boxSizing: "border-box",
    border: "1px solid #0D5CAB",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingX: 3,
  },
  filterIcon: {
    transform: "scale(1.2)",
  },
  popupBox: {
    marginTop: 2,
    width: 406,
    height: 557,
    borderRadius: 2,
    background: "white",
    padding: 4,
    overflowX: "auto",
  },
  label: {
    color: "#65748B",
    fontWeight: 600,
    fontFamily: "Montserrat",
    fontSize: 14,
    textAlign: "left",
  },
  periode: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 10,
    marginTop: 10,
    height: 5,
  },
  seperator: {
    width: "10%",
    margin: "0 16px",
    alignItems: "center",
    height: 0,
    marginTop: 24,
  },
  tableDiv: (isOpenFilterBox) => ({
    width: "100%",
    marginLeft: isOpenFilterBox ? "16px" : "0px",
    marginTop: "16px",
    display: "flex",
    flexDirection: "column",
  }),
  tableBox: {
    height: 611,
    width: "100%",
    backgroundColor: "white",
    overflowX: "auto",
    padding: 2,
  },
  downloadDiv: {
    marginLeft: "auto",
    marginTop: "12px",
    marginBottom: "12px",
    float: "right",
  },
  downloadBtn: {
    marginRight: "auto",
    width: 120,
    backgroundColor: "#0D5CAB",
    height: 48,
    color: "white",
    borderRadius: 1,
    fontSize: 16,
    fontFamily: "Montserrat",
    textTransform: "inherit",
    marginLeft: 2,
    "&:hover": {
      backgroundColor: "#125fa1",
    },
    "&:active": {
      backgroundColor: "#0D5CAB",
    },
  },
};

export const REPORT_DATA_CONFIGURATION_BREADCRUMBS = [
  {
    item: "Home",
    link: "/",
    current: false,
  },
  {
    item: "Report Data Configuration",
    link: null,
    current: true,
  },
];

export const REPORT_CATEGORY_DATA_CONFIGURATION = [
  { id: "1", label: "Event Code Rules" },
  { id: "2", label: "Event Code Catalog" },
  { id: "3", label: "Event Code Group" },
  { id: "4", label: "Fault Category" },
];

export const REPORT_CATEGORY_LOG_PERUBAHAN = [
  { id: "1", value: "Event Code Rules" },
  { id: "2", value: "Event Code Catalog" },
  { id: "3", value: "Event Code Group" },
  { id: "4", value: "Fault Category" },
];

export const REPORT_HEADER_LOG_PERUBAHAN = [
  {
    headerName: "Date",
    field: "time",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Time",
    field: "time",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Last Updated By",
    field: "last_updated_by",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Activity",
    field: "activity",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Before",
    field: "before",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "After",
    field: "after",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Keterangan / Alasan",
    field: "reason",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
]

export const REPORT_HEADER_DATA_CONFIGURATION = [
  {
    headerName: "Event Code",
    field: "event_code",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Description",
    field: "description",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Group",
    field: "group",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Rule",
    field: "rule",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Catalog",
    field: "catalog",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Message",
    field: "message",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Fault Category",
    field: "fault_category",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
];

export const FILTER_OBJ = {
  category: "",
  values: [],
};

export const DATE_OBJ = {
  start: null,
  end: null,
};