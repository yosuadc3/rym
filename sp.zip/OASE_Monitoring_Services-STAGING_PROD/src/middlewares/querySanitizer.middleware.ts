import { NextFunction, Request, Response } from "express";
import xss from "xss";

type QueryParams = { [key: string]: string };

export default (req: Request, res: Response, next: NextFunction) => {
   const queries = req.query as QueryParams;

   const params = Object.keys(req.query);

   params.forEach((key: keyof QueryParams) => {
      const value = xss(queries[key]);
      const escapedStr = value.replace(/'/g, "''"); // replace single apostrophe with 2 single apostrophes
      req.query[key] = escapedStr;
   })

   next();
};

