import React, { useEffect, useState } from "react";
import { HashRouter, Navigate, Route, Routes, BrowserRouter } from "react-router-dom";
import Home from "../containers/home/Home";
import LoginAndChangePassword from "../containers/login/LoginAndChangePassword";
// import NotFound from "../components/error/NotFound";
import { renewToken, tokenExist } from "../token/action";
import {getVPNUrl, hasVPNURrl} from '../utilities/Vpn';

async function checkTokenActive(setTokenActive) {
    renewToken()
        .then(() => {
            setTokenActive(true);
        })
        .catch(() => {
            localStorage.clear();   
            setTokenActive(false);
        });
}

function AppRouter() {
    const [tokenActive, setTokenActive] = useState(tokenExist());
    const url = window.location.href
    const myArray = url.split("/");
    let path = myArray[3];
    const urlVpn = getVPNUrl();
    
    useEffect(() => {
        checkTokenActive(setTokenActive);
    }, []);

    if (tokenActive) {
        return (
            <HashRouter>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="*" element={<></>} />
                </Routes>
            </HashRouter>
        );
    }

    return (
        <HashRouter>
            <Routes>
                <Route path="/" element={<LoginAndChangePassword />} />
                <Route path="*" element={<Navigate to="/" />} />
            </Routes>
        </HashRouter>
    );
}

export default AppRouter;