import { Request, Response } from "express";

export const getWelcomeApp = async (req: Request, res: Response) => {
	res.send("Welcome to OASE Monitoring API Services");
};

export { };

