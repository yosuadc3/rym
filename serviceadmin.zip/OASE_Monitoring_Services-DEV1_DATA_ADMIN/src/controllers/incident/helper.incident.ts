import { NumberOrUndefined, StringOrUndefined } from "../../types/global.type";
import * as timeFormatter from "../../utils/dateTime.util";

export const paginate = (arr: TData[], page: number, limit: number) => {
	const offset = page * limit;
	return arr.slice(offset, offset + limit);
}

interface TTicketField {
	[key: string]: string
}

//@ts-ignore
export const handleProcessIncidentCurrent = (ticketIdData: any[]) => {
	const currTicketId = ticketIdData[0];

	const allFieldTicketId = Object.keys(currTicketId);
	const newTicketId = allFieldTicketId.reduce((newObj: TTicketField, item) => {
		newObj[item] = currTicketId[item] === null ? "-" : currTicketId[item];
		return newObj;
	}, {});

	newTicketId["Start Time"] = timeFormatter.UTCTimeFormat(
		newTicketId["Start Time"]
	);

	newTicketId["End Time"] = timeFormatter.UTCTimeFormat(
		newTicketId["End Time"]
	);

	const wsid = currTicketId["WSID"];
	const _wsid = currTicketId._wsid;
	const incidentNumber = currTicketId["Incident Number"];

	delete newTicketId["WSID"];
	delete newTicketId._wsid;

	return {
		wsid,
		_wsid,
		incidentNumber,
		currentDetails: newTicketId,
	};
}

interface TDataDict {
	[key: string]: string
}

export const handleProcessTerminalDetails = (data: any) => {
	const temp = data[0];
	let allField = Object.keys(temp);

	const dataDict: TDataDict = {};
	allField.forEach((item) => {
		dataDict[item] = temp[item] === null ? "-" : temp[item];
	});

	return {
		terminalDetails: dataDict,
	};
}

interface TAdvancedSearchOptions {
	[key: string]: boolean
}

interface TData {
	[key: string]: (string | number)
}

export const handleAdvancedSearch = (
	data: TData[],
	all: any | undefined,
	ticket_id: StringOrUndefined,
	wsid: StringOrUndefined,
	lok: StringOrUndefined,
	lokasi: StringOrUndefined,
	tipe_mesin: StringOrUndefined,
	vendor_mesin: StringOrUndefined,
	status_code: StringOrUndefined,
	start_time: StringOrUndefined,
	end_time: StringOrUndefined,
	duration: NumberOrUndefined,
	status_code_description: StringOrUndefined,
	last_comment: StringOrUndefined
) => {
	const COLUMNS = {
		ALL: "all",
		TICKET_ID: "id",
		WSID: "wsid",
		LOK: "lok",
		LOKASI: "lokasi",
		TIPE_MESIN: "tipe_mesin",
		VENDOR_MESIN: "vendor_mesin",
		STATUS_CODE: "status_code",
		START_TIME: "start_time",
		END_TIME: "end_time",
		DURATION: "duration",
		STATUS_CODE_DESCRIPTION: "status_code_description",
		LAST_COMMENT: "last_comment",
	};
	let store: TData[] = [];

	if (all) {
		data.forEach((item: any) => {
			let flag = false;
			Object.keys(item).forEach((key) => {
				if (
					String(item[key]).toLowerCase().includes(String(all).toLowerCase()) &&
					key !== "category" && key !== "_id" && key !== "_wsid"
				) {
					flag = true;
				}
			});
			if (flag) {
				store.push(item);
			}
		});
	} else {
		function isExist(val: StringOrUndefined | NumberOrUndefined) {
			return val ? true : false;
		}

		const advancedSearchOptions: TAdvancedSearchOptions = {
			id: isExist(ticket_id),
			wsid: isExist(wsid),
			lok: isExist(lok),
			lokasi: isExist(lokasi),
			tipe_mesin: isExist(tipe_mesin),
			vendor_mesin: isExist(vendor_mesin),
			status_code: isExist(status_code),
			start_time: isExist(start_time),
			end_time: isExist(end_time),
			duration: isExist(duration),
			status_code_description: isExist(status_code_description),
			last_comment: isExist(last_comment),
		};

		if (!all) {
			Object.keys(advancedSearchOptions).forEach((key) => {
				if (!advancedSearchOptions[key]) {
					delete advancedSearchOptions[key];
				}
			});
		}

		data.forEach((ticket) => {
			function clause(column: StringOrUndefined, columnStr: string) {
				let flag = false;

				if (column) {
					let reqQueryArr = column.split(",");

					reqQueryArr.forEach((query) => {
						if (
							String(ticket[columnStr])
								.toLowerCase()
								.includes(String(query).toLowerCase())
						) {
							flag = true;
						}
					});
				}
				return flag;
			}

			let flagWSID = clause(wsid, COLUMNS.WSID);
			let flagLok = clause(lok, COLUMNS.LOK);
			let flagTicketId = clause(ticket_id, COLUMNS.TICKET_ID);
			let flagLokasi = clause(lokasi, COLUMNS.LOKASI);
			let flagTipeMesin = clause(tipe_mesin, COLUMNS.TIPE_MESIN);
			let flagVendorMesin = clause(vendor_mesin, COLUMNS.VENDOR_MESIN);
			let flagStatusCode = clause(status_code, COLUMNS.STATUS_CODE);
			let flagStartTime = clause(start_time, COLUMNS.START_TIME);
			let flagEndTime = clause(end_time, COLUMNS.END_TIME);
			let flagDuration = clause(String(duration), COLUMNS.DURATION);
			let flagStatusCodeDescription = clause(
				status_code_description,
				COLUMNS.STATUS_CODE_DESCRIPTION
			);
			let flagLastComment = clause(last_comment, COLUMNS.LAST_COMMENT);

			let flag = true;

			function checker(objKey: boolean, flagger: boolean) {
				if (!flag || (objKey && objKey !== flagger)) {
					return false;
				}
				return true;
			}
			flag = checker(advancedSearchOptions[COLUMNS.WSID], flagWSID);
			flag = checker(advancedSearchOptions[COLUMNS.LOK], flagLok);
			flag = checker(advancedSearchOptions[COLUMNS.TICKET_ID], flagTicketId);
			flag = checker(advancedSearchOptions[COLUMNS.LOKASI], flagLokasi);
			flag = checker(advancedSearchOptions[COLUMNS.TIPE_MESIN], flagTipeMesin);
			flag = checker(advancedSearchOptions[COLUMNS.VENDOR_MESIN], flagVendorMesin);
			flag = checker(
				advancedSearchOptions[COLUMNS.STATUS_CODE],
				flagStatusCode
			);
			flag = checker(advancedSearchOptions[COLUMNS.START_TIME], flagStartTime);
			flag = checker(advancedSearchOptions[COLUMNS.END_TIME], flagEndTime);
			flag = checker(
				advancedSearchOptions[COLUMNS.STATUS_CODE_DESCRIPTION],
				flagStatusCodeDescription
			);
			flag = checker(advancedSearchOptions[COLUMNS.DURATION], flagDuration);
			flag = checker(
				advancedSearchOptions[COLUMNS.LAST_COMMENT],
				flagLastComment
			);

			if (flag) {
				store.push(ticket);
			}
		});
	}
	return store;
}


export const handleHistoryAdvancedSearch = (
	data: TData[],
	all: any | undefined,
	ticket_id: StringOrUndefined,
	start_time: StringOrUndefined,
	end_time: StringOrUndefined,
	action_code: StringOrUndefined,
	action_code_description: StringOrUndefined,
	status_code: StringOrUndefined,
	status_code_description: StringOrUndefined,
	last_comment: StringOrUndefined
) => {
	const COLUMNS = {
		ALL: "all",
		TICKET_ID: "id",
		START_TIME: "start_time",
		END_TIME: "end_time",
		ACTION_CODE: "action_code",
		ACTION_CODE_DESCRIPTION: "action_code_description",
		STATUS_CODE: "status_code",
		STATUS_CODE_DESCRIPTION: "status_code_description",
		LAST_COMMENT: "last_comment",
	};
	let store: TData[] = [];

	if (all) {
		data.forEach((item: any) => {
			let flag = false;
			Object.keys(item).forEach((key) => {
				if (
					String(item[key]).toLowerCase().includes(String(all).toLowerCase()) &&
					key !== "category" && key !== "_id" && key !== "_wsid"
				) {
					flag = true;
				}
			});
			if (flag) {
				store.push(item);
			}
		});
	} else {
		function isExist(val: StringOrUndefined | NumberOrUndefined) {
			return val ? true : false;
		}

		const advancedSearchOptions: TAdvancedSearchOptions = {
			id: isExist(ticket_id),
			start_time: isExist(start_time),
			end_time: isExist(end_time),
			action_code: isExist(action_code),
			action_code_description: isExist(action_code_description),
			status_code: isExist(status_code),
			status_code_description: isExist(status_code_description),
			last_comment: isExist(last_comment),
		};

		if (!all) {
			Object.keys(advancedSearchOptions).forEach((key) => {
				if (!advancedSearchOptions[key]) {
					delete advancedSearchOptions[key];
				}
			});
		}

		data.forEach((ticket: any) => {
			function clause(column: StringOrUndefined, columnStr: string) {
				let flag = false;

				if (column) {
					let reqQueryArr = column.split(",");

					reqQueryArr.forEach((query) => {
						if (
							String(ticket[columnStr])
								.toLowerCase()
								.includes(String(query).toLowerCase())
						) {
							flag = true;
						}
					});
				}
				return flag;
			}

			let flagTicketId = clause(ticket_id, COLUMNS.TICKET_ID);
			let flagStartTime = clause(start_time, COLUMNS.START_TIME);
			let flagEndTime = clause(end_time, COLUMNS.END_TIME);
			let flagActionCode = clause(action_code, COLUMNS.ACTION_CODE);
			let flagActionCodeDescription = clause(
				action_code_description,
				COLUMNS.ACTION_CODE_DESCRIPTION
			);
			let flagStatusCode = clause(status_code, COLUMNS.STATUS_CODE);
			let flagStatusCodeDescription = clause(
				status_code_description,
				COLUMNS.STATUS_CODE_DESCRIPTION
			);
			let flagLastComment = clause(last_comment, COLUMNS.LAST_COMMENT);

			let flag = true;

			function checker(objKey: boolean, flagger: boolean) {
				if (!flag || (objKey && objKey !== flagger)) {
					return false;
				}
				return true;
			}
			flag = checker(advancedSearchOptions[COLUMNS.TICKET_ID], flagTicketId);
			flag = checker(advancedSearchOptions[COLUMNS.START_TIME], flagStartTime);
			flag = checker(advancedSearchOptions[COLUMNS.END_TIME], flagEndTime);
			flag = checker(
				advancedSearchOptions[COLUMNS.ACTION_CODE],
				flagActionCode
			);
			flag = checker(
				advancedSearchOptions[COLUMNS.ACTION_CODE_DESCRIPTION],
				flagActionCodeDescription
			);
			flag = checker(
				advancedSearchOptions[COLUMNS.STATUS_CODE],
				flagStatusCode
			);
			flag = checker(
				advancedSearchOptions[COLUMNS.STATUS_CODE_DESCRIPTION],
				flagStatusCodeDescription
			);
			flag = checker(
				advancedSearchOptions[COLUMNS.LAST_COMMENT],
				flagLastComment
			);

			if (flag) {
				store.push(ticket);
			}
		});
	}
	return store;
}
