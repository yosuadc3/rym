import React,{useState,useEffect} from "react";
import FormDialogV2 from "../../../../../components/form/FormDialogV2";
import FormInput from "../../components/FormInput";
import FormLabel from "../../../../../components/form/FormLabel";
import { Grid, Button, DialogContent, DialogActions,Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { handleInsertCodes, handleRefresh, handleRemoveCodes, handleUpdateCodes, setData} from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodes/eventCodes";
import { handleRefresh as refreshEventCodeCatalog} from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/eventCodeSource";
import {useDeleteEventCodesMutation,usePostEventCodesMutation,usePutEventCodesMutation} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodes/api/eventCodes'
import { useGetEventCodeRulesListQuery } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeRules/api/eventCodeRules";
import { useGetEventCodeGroupListQuery } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeGroup/api/eventCodeGroup";
import FormSelect from "../../components/FormSelect"
import ConfirmDialog from "../../components/ConfirmDialog";
import { STYLES, MENUPROPS  } from "../../../../../constants/IncidentManagement/Styles";

export default function FormPopUp({id}){
    const [inputCode, setInputCode ] = useState("");
    const [inputDesc, setInputDesc ] = useState("");
    const [inputGroup, setInputGroup ] = useState("");
    const [inputRule, setInputRule ] = useState("");
    const [inputKnowledge, setInputKnowledge ] = useState("");
    const [groupData, setGroupData] = useState([{}]);
    const [ruleData, setRuleData] = useState([{}]);
    const [openInsert2, setOpenInsert2 ] = useState(false);
    const [openUpdate2, setOpenUpdate2 ] = useState(false);
    const [isChange, setIsChange] = useState(false);

    const [insertIntoApi,{isLoading:insertLoading,isSuccess: insertSuccess}] = usePostEventCodesMutation();
    const [updateApi,{isLoading:updateLoading,isSuccess: updateSuccess}] = usePutEventCodesMutation();
    const [deleteApi, {isSuccess:deleteSuccess}] = useDeleteEventCodesMutation();
    const { data: group, isLoading: groupIsLoading} = useGetEventCodeGroupListQuery();
    const { data: rule, isLoading: ruleIsLoading} = useGetEventCodeRulesListQuery();

    const data = useSelector((state) => state.eventCodes.data);
    const dispatch = useDispatch();
    const insert = () =>{
        if(inputCode !="" &&  inputRule !== ""){
            let insertData = {
                event_code: inputCode,
                description: inputDesc,
                group_id: inputGroup,
                rule_id: inputRule,
                catalog_id: id,
            }
            if(inputGroup == ""){
                insertData = {
                    event_code: inputCode,
                    description: inputDesc,
                    group_id: null,
                    rule_id: inputRule,
                    catalog_id: id,
                }
            }
            insertIntoApi(insertData);
        }
    }

    const update = () =>{
        if(data.id != ""   && inputCode !="" && inputRule !== ""){
            let data_update = {
                event_code: inputCode,
                description: inputDesc,
                group_id: inputGroup,
                rule_id: inputRule,
                catalog_id: id,
            }
            if(inputGroup == ""){
                data_update = {
                    event_code: inputCode,
                    description: inputDesc,
                    group_id: null,
                    rule_id: inputRule,
                    catalog_id: id,
                }
            }
            updateApi({ id: data.id, data: data_update });
        }
    }

    const remove = () =>{
        if(data.id != ""){
            deleteApi(data.id);
            dispatch(handleRefresh());
        }
    }

    const handleCloseInsertClick = () => {
        dispatch(handleInsertCodes());
        setIsChange(false);
    }
    const handleOpenInsert2Click = () => {
        dispatch(handleInsertCodes());
        setOpenInsert2(true);
    }

    const handleCloseInsert2Click = () => {
        setIsChange(false);
        setOpenInsert2(false);
    }

    const handleCloseUpdateClick = () => {
        dispatch(handleUpdateCodes());
        setIsChange(false);
    }

    const handleOpenUpdate2Click = () => {
        dispatch(handleUpdateCodes());
        setOpenUpdate2(true);
    }

    const handleCloseUpdate2Click = () => {
        setIsChange(false);
        setOpenUpdate2(false);
    }

    
    const handleCloseRemoveClick = () => {
        dispatch(handleRemoveCodes());
    }

    useEffect(() => {  
        if(insertSuccess){
            dispatch(handleRefresh());
            dispatch(refreshEventCodeCatalog());
            handleCloseInsert2Click();
        }  
    }, [insertSuccess]);

    useEffect(() => {  
        if(updateSuccess){
            dispatch(handleRefresh());
            dispatch(refreshEventCodeCatalog());
            handleCloseUpdate2Click();
         }  
    }, [updateSuccess]);

    useEffect(() => {  
        if(deleteSuccess){
            dispatch(handleRemoveCodes());
            dispatch(handleRefresh());
            dispatch(refreshEventCodeCatalog());
         }  
    }, [deleteSuccess]);

    useEffect(() => {
        if (!groupIsLoading) {
            const {data} = group;
            const tempData = [...data.list??[{}],{id: null, value: 'NULL'}];
            setGroupData(tempData);
        }
    }, [group, groupIsLoading]);

    useEffect(() => {
        if (!ruleIsLoading) {
            const {data} = rule;
            setRuleData(data.list??[{}]);
        }
    }, [rule, ruleIsLoading]);
   
    useEffect(() => {
        if(!isChange){
            setInputCode(data.event_code);
            setInputDesc(data.description);
            setInputKnowledge(data.knowledge_base);
            if(data.group !== ""&& groupData){
                const group = groupData.find(g=>g.value === data.group);
                setInputGroup(group?group.id:"");
            }
            if(data.rule !== "" && ruleData){
                const rule = ruleData.find(r=>r.value === data.rule);
                setInputRule(rule?rule.id:"");
            }
        }
    }, [data,useSelector((state) => state.eventCodes.updateOpen)]);

    useEffect(()=>{
        if(!isChange){
            setInputCode("");
            setInputDesc("");
            setInputGroup("");
            setInputRule("");
            setInputKnowledge("");
        }
    },[useSelector((state) => state.eventCodes.insertOpen)]);

    return(
        <>
        <FormDialogV2
                isOpen={useSelector((state) => state.eventCodes.insertOpen)}
                handleToggle={handleCloseInsertClick}
                title = {"Tambah Event Code"}
            >
                <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={2}>
                            <FormInput
                            changed={inputCode != ""}
                            label={"Event Code"}
                            autoFocus
                            onChange={(e) => {setInputCode(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormInput
                            changed={inputDesc != ""}
                            label={"Description"}
                            useMultiline
                            onChange={(e) => {setInputDesc(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Group"} items={groupData??[{}]} onChange={(e)=>{setInputGroup(e.target.value);setIsChange(true);}}  value={inputGroup} MenuProps={MENUPROPS}/>
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Rule"} items={ruleData??[{}]} onChange={(e)=>{setInputRule(e.target.value);setIsChange(true);}}  value={inputRule} MenuProps={MENUPROPS}/>
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormLabel label="Message"/>
                            <Typography marginLeft={1}>-</Typography>
                        </Grid>
                        <Grid item>
                            <FormInput
                            changed={inputKnowledge !=""}
                            label={"Knowledge Base (Opsional)"}
                            useMultiline
                            minRow={7}
                            maxRow={7}
                            onChange={(e)=>{setInputKnowledge(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                    </Grid>
                </DialogContent>

                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={3}gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseInsertClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenInsert2Click}
                            disabled = {inputCode== "" ||inputRule==""}
                            >
                            Simpan
                        </Button>
                       
                    </Grid>
                </DialogActions>

            </FormDialogV2>    

            <FormDialogV2
                isOpen={useSelector((state) => state.eventCodes.updateOpen)}
                handleToggle={handleCloseUpdateClick}
                title = {"Detail Event Code"}
            >
                <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={2}>
                            <FormInput
                            changed={inputCode != ""}
                            label={"Event Code"}
                            autoFocus
                            value={data.event_code}
                            onChange={(e) => {setInputCode(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormInput
                            changed={inputDesc != ""}
                            label={"Description"}
                            useMultiline
                            value={data.description}
                            onChange={(e) => {setInputDesc(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Group"} items={groupData??[{}]} onChange={(e)=>{setInputGroup(e.target.value);setIsChange(true);}}  value={inputGroup} MenuProps={MENUPROPS}/>
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Rule"} items={ruleData??[{}]} onChange={(e)=>{setInputRule(e.target.value);setIsChange(true);}}  value={inputRule} MenuProps={MENUPROPS}/>
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormLabel label="Message"/>
                            <Typography marginLeft={1}>{data.message}</Typography>
                        </Grid>
                        <Grid item>
                            <FormInput
                            changed={inputKnowledge !=""}
                            label={"Knowledge Base (Opsional)"}
                            useMultiline
                            minRow={7}
                            maxRow={7}
                            value={inputKnowledge}
                            onChange={(e)=>{setInputKnowledge(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={3}gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseUpdateClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenUpdate2Click}
                            disabled = {inputCode== "" ||inputRule==""||!isChange}
                            >
                            Simpan
                        </Button>
                       
                    </Grid>
                </DialogActions>

            </FormDialogV2>   

            <ConfirmDialog
                isOpen={useSelector((state) => state.eventCodes.removeOpen)}
                handleClose={handleCloseRemoveClick}
                title={`Yakin akan menghapus Event Code ${data.event_code}?`}
                handleSave={remove}
                paddingX= "10px"
                paddingTop = "40px"
            />
             <ConfirmDialog
                isOpen={openInsert2}
                handleClose={handleCloseInsert2Click}
                title={`Yakin akan menambah Event Code ${inputCode}?`}
                handleSave={insert}
                paddingX= "10px"
                paddingTop = "40px"
            />
            <ConfirmDialog
                isOpen={openUpdate2}
                handleClose = {handleCloseUpdate2Click}
                title = {"Yakin akan menyimpan perubahan Event Code?"}
                handleSave = {update}
            />

         </>
    );
}