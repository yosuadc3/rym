import { Response } from "express";
import * as db from "../../repositories/report/atlas.repository";
import { IRequestAPI } from "../../types/global.type";
import {
	IGetReportDownloadRequest,
	IGetReportFilterRequest,
	IGetReportRequest,
} from "../../types/report/atlas.type";
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import * as dateTimeUtils from "../../utils/dateTime.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import replaceNullOrEmptyString from "../../utils/object/replaceNullOrEmptyString.util";
import printToConsole from "../../utils/printToConsole.util";

const message = {
	english: `Successfully Retrieved Report Atlas`,
	indonesia: `Berhasil Mengambil Report Atlas`,
};
const errorMessage = "Error occured while retrieving Report Atlas";
const errorTag = "Get Report Atlas";

type TDropdownItem = { field: string; label: string };
type TObject<T> = { [k: string]: T };
type TPeriode = {
	startDate: string;
	endDate: string;
};
type TFilter = {
	[k: string]: string[];
};
type TReportMapperItem = {
	duration: number;
	start_problem: string;
	end_problem: string;
};

async function reportTypeMapping(
	periode: TPeriode,
	filter: TFilter,
	type: string
) {
	let data: Promise<[any, any]> | [] = [];

	if (type === "Report DSA") {
		data = db.getReportDsa(periode, filter);
	}

	return data;
}

async function reportDownloadTypeMapping(
	periode: TPeriode,
	filter: TFilter,
	type: string
) {
	let data: Promise<[any, any]> | [] = [];

	if (type === "Report DSA") {
		data = db.getReportDsaDownload(periode, filter);
	}

	return data;
}

async function reportFilterMapping(field: string, type: string) {
	let data: Promise<[any, any]> | [] = [];

	if (type === "Report DSA") {
		data = db.getReportFilterDsa(field);
	}

	return data;
}

function reportDataMapper(data: TReportMapperItem[] = [], durationToMinutes = false) {
	const result = data.map((item) => {
		const startProblemTimestamp = dateTimeUtils.UTCTimeFormat(item.start_problem);
		const endProblemTimestamp = dateTimeUtils.UTCTimeFormat(item.end_problem);
		let problemDuration;

		if (durationToMinutes) {
			problemDuration = Math.floor(item.duration / 60);
		}
		else {
			problemDuration = dateTimeUtils.secondsToReadableFormat(item.duration, true);
		}

		replaceNullOrEmptyString(item);

		return {
			...item,
			duration: problemDuration,
			start_problem: startProblemTimestamp,
			end_problem: endProblemTimestamp,
		};
	});

	return result;
}

export const getReport = async (req: IGetReportRequest, res: Response) => {
	addPayloadToRequestHeader(req);

	const type = req.query?.type;
	const periode = req.query?.periode;
	const filter = req.query?.filter;
	const parsedPeriode = JSON.parse(periode);
	let parsedFilter = null;

	if (!type) {
		throw new Error("Report type undefined");
	}

	if (filter) {
		parsedFilter = JSON.parse(filter);
	}

	const [data, [total]] = await reportTypeMapping(
		parsedPeriode,
		parsedFilter,
		type
	);
	const finalData = reportDataMapper(data);

	const payload = {
		...total,
		data: finalData,
	};

	res.send(jsonMessage.jsonSuccess(message, payload));
};

export const getReportDownload = async (
	req: IGetReportDownloadRequest,
	res: Response
) => {
	addPayloadToRequestHeader(req);

	const type = req.query?.type;
	const periode = req.query?.periode;
	const filter = req.query?.filter;
	const parsedPeriode = JSON.parse(periode);
	let parsedFilter = null;

	if (!type) {
		throw new Error("Report type undefined");
	}

	if (filter) {
		parsedFilter = JSON.parse(filter);
	}

	const data = await reportDownloadTypeMapping(
		parsedPeriode,
		parsedFilter,
		type
	);
	const finalData = reportDataMapper(data, false);

	res.send(jsonMessage.jsonSuccess(message, finalData));
};

export const getReportFilter = async (
	req: IGetReportFilterRequest,
	res: Response
) => {
	addPayloadToRequestHeader(req);

	const type = req.query?.type;

	if (!type) {
		throw new Error("Report type undefined");
	}

	const dropdowns = await db.getReportFilterDropdowns(type);
	const values: TObject<string> = {};
	const categories = await Promise.all(
		dropdowns.map(async (item: TDropdownItem) => {
			const [temp] = await reportFilterMapping(item.field, type);
			values[item.field] = temp.flat(1);

			return {
				id: item.field,
				label: item.label,
			};
		})
	);

	const finalData = {
		categories: categories,
		values: values,
	};

	res.send(jsonMessage.jsonSuccess(message, finalData));
};

export const getReportType = async (req: IRequestAPI, res: Response) => {
	addPayloadToRequestHeader(req);

	const data = await db.getReportType();

	res.send(jsonMessage.jsonSuccess(message, data));
};
