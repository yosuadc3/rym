import { Response } from "express";
import { HTTP_OK } from "../../constants/httpResponseCodes.constant";
import * as db from "../../repositories/serviceAvailability.repository";
import {
	IGetDSAStatsRequest,
	IGetReportRequest,
	IGetSearchItems,
	IGetStatusRequest,
	IGetSummaryRequest,
	TMappingItems,
	TStatusDataMapperItem,
} from "../../types/serviceAvailability/serviceAvailability.type";
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import * as dateTimeUtils from "../../utils/dateTime.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import replaceNullOrEmptyString from "../../utils/object/replaceNullOrEmptyString.util";

const message = {
	english: `Successfully Retrieved Service Availability Data`,
	indonesia: `Berhasil Mengambil Data Service Availability`,
};

function statusDataMapper(data: TStatusDataMapperItem = [], durationToMinutes = false) {
	const result = data.map((item) => {
		const last_received = dateTimeUtils.UTCTimeFormat(item.last_received);
		let duration;

		if (durationToMinutes) {
			duration = Math.floor(item.duration / 60);
		}
		else {
			duration = dateTimeUtils.secondsToReadableFormat(item.duration, true);
		}

		replaceNullOrEmptyString(item);

		return {
			...item,
			duration,
			last_received,
		};
	});

	return result;
}

export const getStatus = async (req: IGetStatusRequest, res: Response) => {
	addPayloadToRequestHeader(req);

	let dbRes = [];
	const limit = parseInt(req.query?.limit.toString());
	const page = parseInt(req.query?.page.toString()) * limit;
	const sortBy = req.query?.sortBy;
	const orderBy = req.query?.orderBy;
	const search = req.query?.search;
	const advancedSearch = req.query?.advancedSearch;
	const advancedSearchPeriode = req.query?.advancedSearchPeriode;

	if (search) {
		const parsedSearch = JSON.parse(search);

		dbRes = await db.getStatus(page, limit, sortBy, orderBy, parsedSearch);
	} else if (advancedSearch) {
		const parsedAdvancedSearch = JSON.parse(advancedSearch);
		const parsedAdvancedSearchPeriode = JSON.parse(advancedSearchPeriode);
		dbRes = await db.getStatus(
			page,
			limit,
			sortBy,
			orderBy,
			null,
			parsedAdvancedSearch,
			parsedAdvancedSearchPeriode
		);
	} else if (advancedSearchPeriode) {
		const parsedAdvancedSearchPeriode = JSON.parse(advancedSearchPeriode);
		dbRes = await db.getStatus(
			page,
			limit,
			sortBy,
			orderBy,
			null,
			null,
			parsedAdvancedSearchPeriode
		);
	} else {
		dbRes = await db.getStatus(page, limit, sortBy, orderBy);
	}

	const [data, [total]] = dbRes;

	const finalData = statusDataMapper(data);

	const payload = {
		last_update: dateTimeUtils.getCurrent(),
		...total,
		data: finalData,
	};

	res.send(jsonMessage.jsonSuccess(message, payload));
};

export const getReport = async (req: IGetReportRequest, res: Response) => {
	addPayloadToRequestHeader(req);

	let dbRes = [];
	const sortBy = req.query?.sortBy;
	const orderBy = req.query?.orderBy;
	const search = req.query?.search;
	const advancedSearch = req.query?.advancedSearch;
	const advancedSearchPeriode = req.query?.advancedSearchPeriode;

	if (search) {
		const parsedSearch = JSON.parse(search);

		dbRes = await db.getReport(sortBy, orderBy, parsedSearch);
	} else if (advancedSearch) {
		const parsedAdvancedSearch = JSON.parse(advancedSearch);
		const parsedAdvancedSearchPeriode = JSON.parse(advancedSearchPeriode);
		dbRes = await db.getReport(
			sortBy,
			orderBy,
			null,
			parsedAdvancedSearch,
			parsedAdvancedSearchPeriode
		);
	} else if (advancedSearchPeriode) {
		const parsedAdvancedSearchPeriode = JSON.parse(advancedSearchPeriode);
		dbRes = await db.getReport(
			sortBy,
			orderBy,
			null,
			null,
			parsedAdvancedSearchPeriode
		);
	} else {
		dbRes = await db.getReport(sortBy, orderBy);
	}

	const finalData = statusDataMapper(dbRes, false);

	res.send(jsonMessage.jsonSuccess(message, finalData));
};

export const getDsaStats = async (req: IGetDSAStatsRequest, res: Response) => {
	addPayloadToRequestHeader(req);

	const data = await db.getDsaStats();
	const flattenedData = data.flat(1);
	const [{ online }, { offline }] = flattenedData;

	const [{ total }] = await db.getTotalTerminal();

	const payload = {
		last_update: dateTimeUtils.getCurrent(),
		total_terminal: total,
		data: [
			{
				type: "Online",
				total: online,
			},
			{
				type: "Offline",
				total: offline,
			},
			{
				type: "Not Installed",
				total: total - (online + offline),
			},
		],
	};

	res.send(jsonMessage.jsonSuccess(message, payload));
};

export const getSummary = async (req: IGetSummaryRequest, res: Response) => {
	addPayloadToRequestHeader(req);

	const category = req.query?.category;
	const value = req.query?.value;
	let filter = null;
	let total = 0;

	if (category && value) {
		filter = {
			category: category,
			value: value,
		};
	}

	const summaryData = await db.getSummaryCount(filter);
	const data = summaryData.map((item: TMappingItems) => {
		total += item.count;

		return {
			id: item.summary,
			label: item.summary,
			value: item.count,
			color: item.color
		}
	});

	const payload = {
		last_update: dateTimeUtils.getCurrent(),
		total_terminal: total,
		data: data,
	};

	res.send(jsonMessage.jsonSuccess(message, payload));
};

export const getSearchItems = async (req: IGetSearchItems, res: Response) => {
	addPayloadToRequestHeader(req);

	const data = await db.getSearchItems();

	res.status(HTTP_OK).send(jsonMessage.jsonSuccess(message, data));
};

export { };

