import { Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import AutocompleteMultipleValues from "../../../../components/autocomplete/AutocompleteMultipleValues";
import ButtonCommon from "../../../../components/buttons/ButtonCommon";
import EmptyCard from "../../../../components/cards/EmptyCard";
import DateRangePicker from "../../../../components/dateTimePicker/DateRangePicker";
import { setLogPerubahanQueryEndPeriod, setLogPerubahanQueryStartPeriod, setLogPerubahanQueryTypes, setReportType } from "../../../../redux/features/report/dataConfiguration/dataConfiguration";
import { dateAdd, dateSubtract } from "../../../../utilities/DateManipulator";
import { customFormat } from "../../../../utilities/TimeConverter";
import {
   DATE_OBJ,
   FILTER_OBJ,
   REPORT_CATEGORY_LOG_PERUBAHAN,
   REPORT_TYPE_MENU_DATA_CONFIGURATION,
   filterBoxStyles
} from "../constants/ReportDataConfiguration";
import DataConfigurationMenu from "./DataConfigurationMenu";
import ReportType from "./ReportType";

const LogPerubahanMenu = () => {
   const dispatch = useDispatch();
   const [date, setDate] = useState(DATE_OBJ);
   const [hasErrorDate, sethasErrorDate] = useState(DATE_OBJ);

   const { logPerubahanQuery } = useSelector((state) => state.reportDataConfigurationSlice);
   const { period, types } = logPerubahanQuery;

   useEffect(() => {
      const { start, end } = date;
      dispatch(setLogPerubahanQueryStartPeriod(start));
      dispatch(setLogPerubahanQueryEndPeriod(end));
   }, [date, setDate])

   const handleDateError = (error, target) => {
      sethasErrorDate((prev) => ({ ...prev, [target]: error }));
   };

   const handleOnChange = (_, newValue, reason) => {
      if (reason === "selectOption" || reason === "removeOption") {
         dispatch(setLogPerubahanQueryTypes(newValue));
         return;
      }

      if (reason === "clear") {
         dispatch(setLogPerubahanQueryTypes([]));
      }
   };

   return (
      <Grid container direction="column" textAlign="left" spacing={3} paddingLeft={3} marginTop={.25}>
         <Grid item>
            <Grid container direction="column" spacing={1}>
               <Grid item>
                  <Typography sx={filterBoxStyles.label}>Periode</Typography>
               </Grid>
               <Grid item>
                  <DateRangePicker
                     date={period}
                     setDate={setDate}
                     handleDateError={handleDateError}
                     minDate={date.end ? dateSubtract(29, "days", date.end) : null}
                     maxDate={dateAdd(29, "days", date.start)}
                  />
               </Grid>
            </Grid>
         </Grid>
         <Grid item>
            <Grid container direction="column" spacing={1}>
               <Grid item>
                  <Typography sx={filterBoxStyles.label}>
                     Kategori (opsional)
                  </Typography>
               </Grid>
               <Grid item>
                  <AutocompleteMultipleValues
                     options={REPORT_CATEGORY_LOG_PERUBAHAN}
                     onChange={handleOnChange}
                     value={types}
                  />
               </Grid>
            </Grid>
         </Grid>
      </Grid>
   )
}


export default function ReportFilter({
   categories,
   values,
   freeSolo,
   handleHasSearch,
   getter,
   filter,
   disabled,
   setFilter,
}) {
   const dispatch = useDispatch();
   const { reportType } = useSelector((state) => state.reportDataConfigurationSlice);

   const handleButtonSearch = () => {
      getter();
      handleHasSearch();
   };

   const handleResetFilter = () => {
      dispatch(setReportType(""));
      setFilter((_) => [FILTER_OBJ]);
   };

   return (
      <EmptyCard sx={{ padding: 2, marginTop: 2 }}>
         <Grid container direction="column" textAlign="left" spacing={3}>
            <Grid item>
               <Grid container direction="column" spacing={1}>
                  <Grid item>
                     <Typography sx={filterBoxStyles.label}>Jenis Report</Typography>
                  </Grid>
                  <Grid item>
                     <ReportType />
                  </Grid>
               </Grid>
            </Grid>
            {reportType ? (reportType === REPORT_TYPE_MENU_DATA_CONFIGURATION ?
               (
                  <DataConfigurationMenu
                     filter={filter}
                     values={values}
                     disabled={disabled}
                     categories={categories}
                     setFilter={setFilter}
                  />
               ) : <LogPerubahanMenu />
            ) : null}
            <Grid item>
               <Grid container justifyContent="right">
                  <Grid item alignSelf="center">
                     <ButtonCommon
                        label="Reset Filter"
                        disabled={disabled}
                        handleClick={handleResetFilter}
                        variant="text"
                        sx={filterBoxStyles.btnResetFilter}
                     />
                  </Grid>
                  <Grid item>
                     <ButtonCommon
                        label="Search"
                        disabled={disabled || !reportType}
                        handleClick={handleButtonSearch}
                        sx={filterBoxStyles.btnSearch}
                     />
                  </Grid>
               </Grid>
            </Grid>
         </Grid>
      </EmptyCard>
   );
}
