import log from "./simplifiedLog.util";

export default () => {
   log('\n/\\ /|(`[~  |\\/|  ,_.|-    .,_' +
      '    (` _     . _ _  _\n' +
      '\\//-|_)[_  |  |()||||_()|`|||(|  _)' +
      '(/_|`\\/|(_(/__\\\n' +
      '                             _|\n');
}