const { merge } = require("webpack-merge");
const Dotenv = require("dotenv-webpack");
const path = require("path");
const commonConfig = require("./webpack.common");

const PORT = 3001;
const DOMAIN = "localhost";

module.exports = (env) => {
	const devConfig = {

		mode: "development",

		output: {
			publicPath: `auto`,
		},

		devtool: "source-map",

		devServer: {
			port: PORT,
			headers: {
				"Access-Control-Allow-Origin": "*",
			},
			historyApiFallback: true,
		},

		plugins: [
			new Dotenv({
				path: path.resolve(".env.dev"),
			}),
		],
	};

	return merge(commonConfig, devConfig);
};
