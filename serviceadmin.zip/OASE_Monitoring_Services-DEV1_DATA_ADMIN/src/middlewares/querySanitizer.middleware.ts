import { NextFunction, Request, Response } from "express";
import xss from "xss";
import { IRequestAPI } from "../types/global.type";

type QueryParams = { [key: string]: string };

export default (req: IRequestAPI, _res: Response, next: NextFunction) => {
   const queries = req.query as QueryParams;

   const params = Object.keys(req.query);

   params.forEach((key: keyof QueryParams) => {
      const value = xss(queries[key]);
      const escapedStr = value.replace(/'/g, "''"); // replace single apostrophe with 2 single apostrophes
      req.query[key] = escapedStr;
   })

   next();
};

