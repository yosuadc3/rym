import { body, param, query } from "express-validator";

export const getIncidentReport = [
    query("all").optional().isString(),
    query("ticket_id").optional().isString(),
    query("wsid").optional().isString(),
    query("lok").optional().isString(),
    query("lokasi").optional().isString(),
    query("tipe_mesin").optional().isString(),
    query("vendor_mesin").optional().isString(),
    query("status_code").optional().isString(),
    query("start_time").optional().isString(),
    query("end_time").optional().isString(),
    query("duration").optional().isNumeric(),
    query("status_code_description").optional().isString(),
    query("last_comment").optional().isString(),
    query("startDate").isString(),
    query("endDate").isString()
];