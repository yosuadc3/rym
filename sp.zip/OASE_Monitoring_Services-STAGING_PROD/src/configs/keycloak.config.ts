module.exports = {
  clientId: process.env.KEYCLOAK_CLIENTID,
  bearerOnly: process.env.KEYCLOAK_BEARER_ONLY,
  serverUrl: process.env.KEYCLOAK_URL,
  realm: process.env.KEYCLOAK_REALM,
  credentials: {
    secret: process.env.KEYCLOAK_SECRET,
  },
};
