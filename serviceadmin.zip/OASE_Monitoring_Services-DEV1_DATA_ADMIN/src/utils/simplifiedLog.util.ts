export default (...args: any[]) => {
   // eslint-disable-next-line
   console.log(...args);
}