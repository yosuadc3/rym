import mysql from "mysql2";
import * as dbConfig from "../configs/database.config";
import { OASE_QUERY_ERRORS } from "../constants/database.constant";
import env from "../env/server.env";
import { DatabaseError } from "../errors/server.error";

const oasemon = dbConfig.oasemon;

const environment = `[${env.NODE_ENV?.toUpperCase()}]`;

let pool: mysql.Pool;
let poolPromise: any;

const OASE_CONNECTION_STATUS = {
	CONNECTING: `${environment}: Connecting to OASE...`,
	CONNECTED: `\r${environment}: Connected to OASE     \n`,
	CONNECTION_FAILED: `\r${environment}: Failed to connect to OASE\n`,
};

export const connect = async () => {
	process.stdout.write(OASE_CONNECTION_STATUS.CONNECTING);
	try {
		pool = mysql.createPool(oasemon);
		poolPromise = pool.promise();

		// Test OASE connection
		await exec("select 1");

		process.stdout.write(OASE_CONNECTION_STATUS.CONNECTED);
	} catch (err) {
		process.stdout.write(OASE_CONNECTION_STATUS.CONNECTION_FAILED);

		throw new DatabaseError(
			"Unable to connect to OASE",
			"DATABASE_OASE_CONNECTION_TIMEOUT"
		);
	}
};

export const disconnect = (): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			pool.end();
			resolve();
		} catch (err) {
			throw new DatabaseError("Unable to close connection", "DATABASE_OASE_CLOSE_CONNECTION_ERROR")
		}
	});
};

export const exec = async (query: string, binds: (string | number)[] = []) => {
	const sql = poolPromise.format(query, binds);

	try {
		// console.log(sql.replace(/\s+/g, " ").trim());
		const [rows, _] = await poolPromise.execute(sql);
		return rows;
	} catch (err) {
		//@ts-ignore
		if (OASE_QUERY_ERRORS.hasOwnProperty(err.code)) {
			//@ts-ignore
			const { message, code } = OASE_QUERY_ERRORS[err.code];
			throw new DatabaseError(message, code);
		}

		throw new DatabaseError("Database error", "DATABASE_OASE_GENERAL_ERROR");
	}
};

export const query = async (
	query: string,
	binds: any[] = [],
	rowsAsArray = false
) => {
	const sql = poolPromise.format(query, binds);
	try {
		const [rows, _] = await poolPromise.query({
			sql,
			rowsAsArray,
		});

		return rows;
	} catch (err) {
		//@ts-ignore
		if (OASE_QUERY_ERRORS.hasOwnProperty(err.code)) {
			//@ts-ignore
			const { message, code } = OASE_QUERY_ERRORS[err.code];
			throw new DatabaseError(message, code);
		}

		throw new DatabaseError("Database error", "DATABASE_OASE_GENERAL_ERROR");
	}
};

export { pool, poolPromise };

