import { getDecodedToken } from "./action";

function getRoles() {
    const roles = getDecodedToken()?.realm_access?.roles || [];

    return roles;
}

function hasRoles(requiredRoles) {
    const roles = getRoles();

    if (requiredRoles) {
        return requiredRoles.some(requiredRole => roles.includes(requiredRole));
    }

    return false;
}

export { getRoles, hasRoles }