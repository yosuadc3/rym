import replaceNullOrEmptyString from "./replaceNullOrEmptyString.util";

export const replaceNullOrEmptyStringArray = (data: Array<object>) => {
   data.forEach((item: any) => {
      replaceNullOrEmptyString(item);
   })
}