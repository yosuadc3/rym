import { PoolOptions } from "mysql2/typings/mysql";

export const gasper = {
	user: process.env.DB_USER,
	password: process.env.DB_PASSWORD,
	connectString: `${process.env.DB_HOST}:${process.env.DB_PORT}/${process.env.DB_SERVICE_NAME}?expire_time=1`,
	poolMin: 10,
	poolMax: 10,
	poolIncrement: 0,
	enableStatistics: true,
};

export const oasemon: PoolOptions = {
	host: process.env.DB_HOST_OASEMON,
	port: +process.env.DB_PORT_OASEMON!,
	user: process.env.DB_USER_OASEMON,
	password: process.env.DB_PASSWORD_OASEMON,
	database: process.env.DB_SCHEMA_OASEMON,
	waitForConnections: true,
	connectionLimit: 10,
	queueLimit: 0,
	charset: process.env.DB_CHARSET_OASEMON,
	connectTimeout: 50000,
};

export const vision4 = {
	server: process.env.DB_SERVER_VISION,
	authentication: {
		type: "default",
		options: {
			userName: process.env.DB_USER_VISION,
			password: process.env.DB_PASSWORD_VISION,
		},
	},
	pool: {
		max: 10,
		min: 10,
		idleTimeoutMillis: 30000,
	},
	options: {
		// If you are on Microsoft Azure, you need encryption:
		encrypt: false,
	},
	database: process.env.DB_SCHEMA_VISION,
	port: +process.env.DB_PORT_VISION!,
	connectTimeout: +process.env.DB_CONNECTION_TIMEOUT_VISION!,
	requestTimeout: +process.env.DB_REQUEST_TIMEOUT_VISION!,
};

export { };

