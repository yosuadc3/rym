import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import useFetch from "../../../../../../hooks/useFetch";
import CustomGrid from "../../../../../../utilities/CustomGrid";
import IsLoading from "../../../../../../utilities/IsLoading";

export default function CurrentIncident({
  scrollTo = false,
  ticketId = "",
  wsidId = "",
  handleWSIDChange,
  handleWSIDChange_
}) {
  const [firstLoad, setFirstLoad] = useState(true);
  const { ticketId: selectTicketId } = useSelector(
    (state) => state.incidentManagement
  );
  const { data, error, isLoading, fetch } = useFetch(
    `incident?ticketId=${ticketId}&wsid=${wsidId}`,
    "incident"
  );

  useEffect(() => {
    if (data && data.data) {
      handleWSIDChange_(data.data._wsid);
      handleWSIDChange(data.data.wsid);
    }
  }, [data]);

  useEffect(() => {
    if (firstLoad) {
      setFirstLoad((prev) => false);
      return;
    }
    if (!firstLoad && selectTicketId && selectTicketId !== ticketId) {
      fetch(`incident?ticketId=${selectTicketId}`, "incident");
    }
  }, [selectTicketId]);

  useEffect(() => {
    if (!isLoading && scrollTo) {
      setTimeout(() => {
        window.scrollTo({
          top: 140,
          behavior: "smooth",
        });
      }, 300);
    }
  }, [isLoading]);

  if (isLoading) {
    return <IsLoading />;
  }

  const { currentDetails, incidentNumber } = data.data;

  return (
    <>
      <Grid sx={{ marginBottom: 4 }}>
        <CustomGrid
          title="Incident Number"
          description={incidentNumber ?? "-"}
          xs={12}
        />
      </Grid>
      <Grid container spacing={4}>
        {Object.keys(currentDetails).slice(1).map((item, i) => (
          <CustomGrid
            key={i}
            title={item}
            description={currentDetails[item]}
            xs={4}
            useContainer
          />
        ))}
      </Grid>
    </>
  );
}
