type TColumns<T> = {
	[key: string]: T;
};

export default (
	usingAll: boolean,
	columns: TColumns<string | number>,
	columnsStr: TColumns<string>
) => {
	let query = " and ( ";
	let flag = true;
	const columnsKeys = Object.keys(columns);

	columnsKeys.forEach((key) => {
		if (columns[key]) {
			const splitParams = columnsStr[key].split(",");
			const joinParams = splitParams.join("|");
			const toQuery = ` (${key} regexp '${joinParams}') `;
			if (flag) {
				query += toQuery;
				flag = false;
			} else {
				if (usingAll) {
					query += " or " + toQuery;
				} else {
					query += " and " + toQuery;
				}
			}
		}
	});

	query += " ) ";

	return query;
};

// export default (
//   usingAll: boolean,
//   columns: TColumns<string | number>,
//   columnsStr: TColumns<string>
// ) => {
//   const columnQueries = Object.keys(columns)
//     .filter(key => columns[key])
//     .map(key => {
//       const splitParams = columnsStr[key].split(",");
//       const joinParams = splitParams.join("|");
//       return `(${key} regexp '${joinParams}')`;
//     });

//   const operator = usingAll ? " or " : " and ";
//   const query = ` and (${columnQueries.join(operator)})`;

//   return query;
// };

// export { };

