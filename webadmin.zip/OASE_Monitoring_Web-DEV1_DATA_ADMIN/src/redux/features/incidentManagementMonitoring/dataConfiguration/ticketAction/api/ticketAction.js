
import { createApi } from "@reduxjs/toolkit/query/react";
import axiosBaseQuery from "../../../../../utils/axiosBaseQuery";
import { BASE_URL_API_MONITORING } from "../../../../../../constants/Api";

const path = "/data-admin/ticket/action/";

export const ticketActionApi = createApi({
    reducerPath: "ticketActionApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getTicketAction: builder.query({
            query: (params = { page: 0, limit: 10, sortBy: "", orderBy: "", search: {}, advancedSearchValue: {}, advancedSearchPeriode: {} }) => ({
                url: `${path}`, method: "get", params: params
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total: data.total,
                }
            }
        }),
        getSearchTicketAction: builder.query({ // masih belum digunakan
            query: () => ({ url: `${path}/search-items`, method: "get" }),
            transformResponse: (res) => (res.data)
        }),
    })
});

export const {
    useGetTicketActionQuery,
    useGetSearchTicketActionQuery,
} = ticketActionApi;