import { IPagination, IRequestAPI, TFilter, TPeriode, TSearch } from "../global.type";

export type TSearchParams = {
    search?: TSearch;
    advancedSearch?: TFilter
    advancedSearchPeriode?: TPeriode
}

export type TQueryParams = {
    query: string;
    params: (string | number)[]
}

export interface IRequestQueryParams extends Partial<IPagination>, IRequestCatalogId {
    offset?: any;
    search?: string;
    advancedSearch?: string;
    advancedSearchPeriode?: string;
}

export interface IRequestCatalogId {
    catalog_id?: string;
}

export type TRequestParams = {
    id?: number;
}

export interface IGetAllRequest extends IRequestAPI {
    query: IRequestQueryParams;
    params: TRequestParams;
}

export type TDbResponse = [any, any];

export type TRequestBodyUpdateEventCode = {
    event_code?: string;
    description?: string;
    group_id?: number;
    rule_id?: number;
    source_id?: number;
}

export type TRequestBodyInsertEventCode = {
    event_code: string;
    description: string;
    group_id: number;
    rule_id: number;
    source_id: number;
}