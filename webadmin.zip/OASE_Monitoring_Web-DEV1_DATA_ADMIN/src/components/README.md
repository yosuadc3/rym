# OASE Monitoring Web - Components

A library of reusable React components, specifically for OASE Monitoring Web's purposes.

*Please be aware that we are using Material UI v5...*

## Available components
* [Accordion](#accordion)
* [Search](#search)
* [Skeleton](#skeleton)
* [Table](#table)

*...others coming soon*

---
### **Accordion**

| Props | Default | Description |
| --- | --- | --- |
| `title` | `null` | If set, sets the title for the accordion |
| `children` | `null` | A React prop. Please refer to this [link](https://codeburst.io/a-complete-guide-to-props-children-in-react-c315fab74e7c?gi=2322f981af23#:~:text=children%20is%20a%20special%20prop,official%20documentation%20as%20%E2%80%9Cboxes%E2%80%9D.)
| `defaultExpanded` | `true` | If set to `true`, the accordion is expanded upon rendering |
| `isSkeleton` | `null` | If set to `true`, children will be rendered as loading upon getting the data | 

```js
// Please specify your current working directory
import { StyledAccordion } from "components/accordion/StyledAccordion";

<StyledAccordion title="This is title" defaultExpanded={true}>
</StyledAccordion>
```
---
### **Search**

| Props | Default | Description |
| --- | --- | --- |
| `selectMenuItems` | `null` | If is set, will render menu items for `MenuItem` |
| `handleSearchClick` | `null` | Function handler upon clicking search | 
| `useAdvancedSearch` | `false` | If `true`, advanced search feature will be displayed |
| `handleAdvancedSearchSubmit` | `null` | Function handler upon applying advanced search |
| `isResetSearch` | A `useState` variable to reset the values of search input and advanced search
| `setIsResetSearch` | Function handler to reset the values of search input and advanced search

```js
// Please specify your current working directory
import React, { useState } from "react";
import { StyledSearch } from "components/search/StyledSearch";

export const SEARCH_MENU_ITEMS = [
   { value: "all", label: "All" },
	{ value: "name", label: "Name" },
	{ value: "age", label: "Age" },
]

export default function SearchExample() {
   const [searchInput, setSearchInput] = useState({
      text: "",
      column: "all",
   });
   const [isResetSearch, setIsResetSearch] = useState(false);

   const handleSearchClick = (searchInput) => {
      const { text, column } = searchInput;

      // Validation
      if (text.trim() === "" && column !== "all") {
         alert("Input tidak boleh kosong!");
         return;
      }

      let query = "";

      // handle API query
      // ...
   };

   const handleAdvancedSearchSubmit = (data) => {
      const { selectedDates, advancedData } = data;
      let query = "";
      if (Array.isArray(advancedData)) {
         advancedData.forEach((item) => {
            let { category } = item;
            let categoryQuery = `&${category}=`;

            item["chips"].forEach((chip) => {
               categoryQuery += chip + ",";
            });

            // Remove last comma
            query += categoryQuery.slice(0, -1);
         });
      }
      if (selectedDates?.startDate) {
         const formatStartDate = MSSQLTimeFormat(selectedDates.startDate);
         query += `&startDate=${formatStartDate}`;
      }
      if (selectedDates?.endDate) {
         const formatEndDate = MSSQLTimeFormat(selectedDates.endDate);
         query += `&endDate=${formatEndDate}`;
      }

      // handle redux dispatch logic
      dispatch({
         type: REDUCER.SET_ADVANCED_SEARCH_QUERY,
         payload: {
            data: {
               advancedSearchQuery: query,
            },
            message: "Berhasil mengupdate data!",
         },
      });
   };

   return (
      <StyledSearch
         selectMenuItems={SEARCH_MENU_ITEMS}
         handleSearchClick={handleSearchClick}
         useAdvancedSearch
         handleAdvancedSearchSubmit={handleAdvancedSearchSubmit}
         isResetSearch={isResetSearch}
         setIsResetSearch={setIsResetSearch}
      />
   );
};
```
---

### **Skeleton**

* **Skeleton Table**

| Props | Default | Description |
| --- | --- | --- |
| `amount` | `5` | Specifies the amount of skeletons to render vertically |

```js
// Please specify your current working directory
import { SkeletonTable } from "components/skeleton/SkeletonTable"

export default function SkeletonExample() {
   return (
      <SkeletonTable amount={10} />
   )
}
```

* **Skeleton Text**

| Props | Default | Description |
| --- | --- | --- |
| `width` | `200` | Specifies the width of a skeleton |
| `height` | `35` | Specifies the height of a skeleton |

```js
// Please specify your current working directory
import { SkeletonTable } from "components/skeleton/SkeletonTable"

export default function SkeletonExample() {
   return (
      <SkeletonText width={300} height={25} />
   )
}
```
---

### **Table**

| Props | Default | Description |
| --- | --- | --- |
| `headers` | `null` | If set, sets the columns for the table |
| `rows` | `null` | If set, sets the data for each of the columns |
| `pageSize` | `null` | If set, sets the current rows per page |
| `loading` | `null` | If set, sets table into loading mode |
| `page` | `null` | If set, sets the page of the table |
| `totalRows` | `null` | If set, sets the total number of rows |
| `setPage` | `null` | Function handler to set the value of `page` |
| `setPageSizeChange` | `null` | Function handler to set the number of rows per page` |
| `useStripesWhiteGray` | `null` | If set, set the color of the rows to be striped (white & gray) |
| `selectModelChange` | `null` | Function handler to get the id of current selected row |
| `paginationMode` | `server` | By default is set to `server`, it can also do `client` side fetching by specifying the value to `client` 
| `sortingMode` | `server` | By default is set to `server`, it can also do `client` side fetching by specifying the value to `client` |
| `useSort` | `true` | By default it is set to `true`, if not wanting to sort, then specify it to `false` |

You can also include Material UI's DataGrid's props as our Table's props by passing it through our Table's props.

```js
import React, { useState, useEffect } from "react";
import moment from "moment";

export const dayInMonthComparator = (v1, v2) => moment(v1) - moment(v2);

export const CENTER_COLUMNS = {
  headerAlign: "center",
  align: "center",
  flex: 1
};

export const COLUMNS = [
   {
		field: "id",
		headerName: "Incident ID",
		...CENTER_COLUMNS,
	},
	{
		field: "start_time",
		headerName: "Start Time",
		type: "date",
		valueGetter: (params) => params.row.start_time,
		sortComparator: dayInMonthComparator,
		...CENTER_COLUMNS,
	},
	{
		field: "end_time",
		headerName: "End Time",
		type: "date",
		valueGetter: (params) => params.row.end_time,
		sortComparator: dayInMonthComparator,
		...CENTER_COLUMNS,
	},
];

export default function TableExample() {
   const [rows, setRows] = useState([]);
   const [page, setPage] = useState(0);

   const [currRowsPerPage, setCurrRowsPerPage] = useState(5);
   const [totalRows, setTotalRows] = useState(0);

   const [sortBy, setSortBy] = useState("id");
   const [orderBy, setOrderBy] = useState("desc");

   const [firstRender, setFirstRender] = useState(true);

   const { data, error, isLoading, fetch } = useFetch(
      // api endpoint
   );

   const handleRowClick = (id) => {
		const ticketId = id[0];
		if (ticketId) {
			setTicketId(ticketId);
		}
	};

   const handleSortModelChange = useCallback((sortModel) => {
      if (sortModel.length) {
         setSortBy(sortModel[0]?.field);
         setOrderBy(sortModel[0]?.sort);
      } else {
         setSortBy("id");
         setOrderBy("desc");
      }
   }, []);

   useEffect(() => {
      if (data && data.data) {
         // extract the fetched data, then proprocess on this line
         // setTotalRows(total);
         // setRows(data);
      }
   }, [data]);

   useEffect(() => {
      if (firstRender) {
         setFirstRender((prev) => false);
         return;
      } else {
         fetch(
            // api endpoint
         );
      }
   }, [page, currRowsPerPage, orderBy, sortBy]);

   if (error) {
      return <div>Terjadi kesalahan saat mengambil data!</div>;
   }

   return (
      <StyledTable
			headers={INCIDENT_MANAGEMENT_TABLE_COLUMNS}
			page={page}
			rows={rows}
			pageSize={currRowsPerPage}
			loading={isLoading}
			rowCount={total}
			setPage={(e) => setPage(e)}
			useStripesWhiteGray
			setPageSizeChange={(e) => setCurrRowsPerPage(e)}
			onSortModelChange={handleSortModelChange}
			selectModelChange={(id) => handleRowClick(id, category)}
		/>
   );
}
```

