import { axiosGet } from "../utilities/Fetch";

export function getDSA() {
    return async (dispatch) => {
        try {
            const res = await axiosGet("dsa");
            dispatch({
                type: "GET_DSA",
                payload: {
                    data: res?.data,
                    message: res?.error_message?.english
                }
            })
        }
        catch (error) {
            throw error;
        }
    }
}

export function getDSAReport() {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_DSA_REPORT",
                loading: {
                    report: true
                }
            }
            dispatch(dispatchAction);
            const res = await axiosGet("dsa/report");
            dispatch({
                ...dispatchAction,
                payload: {
                    data: res?.data,
                    message: res?.error_message?.english
                },
                loading: {
                    report: false
                }
            })
        }
        catch (error) {
            throw error;
        }
    }
}