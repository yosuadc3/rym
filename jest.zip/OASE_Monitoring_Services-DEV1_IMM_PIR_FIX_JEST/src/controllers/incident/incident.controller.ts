import { Response } from "express";
import * as status from "../../constants/httpResponseCodes.constant";
import * as incidentRepo from "../../repositories/incident.repository";
import {
	IGetIncidentCategoryRequest,
	IGetIncidentCommentsRequest,
	IGetIncidentCurrentRequest,
	IGetIncidentHistoryRequest,
	IGetIncidentIDRequest,
	IGetIncidentReportInfoRequest,
	IGetIncidentReportRequest,
	IGetTerminalCurrentStatusRequest,
	IGetTerminalDetailsRequest,
	IPostIncidentCommentRequest,
} from "../../types/incident/incident.type";
import * as clientError from "../../utils/clientErrorHelper.util";
import * as timeFormatter from "../../utils/dateTime.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import { getOperationalDaysByInitial } from "../../utils/operationalDays.util";
import * as visionHelper from "../../utils/visionHelper.util";
import { handleAdvancedSearch, handleHistoryAdvancedSearch, handleProcessIncidentCurrent, handleProcessTerminalDetails, paginate } from "./helper";


/**
 * Get all fault category oldest, average and recent durations
 */
export const getIncidentCategory = async (
	req: IGetIncidentCategoryRequest,
	res: Response
) => {
	try {
		const all = req.query?.all;
		const ticket_id = req.query?.ticket_id;
		const wsid = req.query?.wsid;
		const status_code = req.query?.status_code;
		const start_time = req.query?.start_time;
		const end_time = req.query?.end_time;
		const lok = req.query?.lok;
		const lokasi = req.query?.lokasi;
		const tipe_mesin = req.query?.tipe_mesin;
		const vendor_mesin = req.query?.vendor_mesin;
		const duration = req.query?.duration;
		const status_code_description = req.query?.status_code_description;
		const last_comment = req.query?.last_comment;
		const startDate = req.query?.startDate;
		const endDate = req.query?.endDate;

		const { vendor_site_id: vendorSiteId, koordinator: koordinatorId } = req.kauth?.grant?.access_token?.content || "";
		const name = req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		let allFaultCategory = await incidentRepo.getAllFaultCategory();
		let data = await incidentRepo.getIncidentCategory(
			startDate,
			endDate,
			vendorSiteId,
			koordinatorId
		);

		let totalActiveTerminal = 0;
		let [{ total_wsid_in_service: totalInService }] = await incidentRepo.getCountTerminalInService(vendorSiteId, koordinatorId, { ...req.query });

		if (data) {
			data.forEach((item: any) => {
				item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
				item["duration"] = timeFormatter.secondsToReadableFormat(
					item["age_seconds"]
				);
				Object.keys(item).forEach(
					(key) => (item[key] = item[key] === null ? "-" : item[key])
				);
			});

			const store = handleAdvancedSearch(
				data,
				all,
				ticket_id,
				wsid,
				lok,
				lokasi,
				tipe_mesin,
				vendor_mesin,
				status_code,
				start_time,
				end_time,
				duration,
				status_code_description,
				last_comment
			);

			if (
				ticket_id ||
				wsid ||
				lokasi ||
				status_code ||
				duration ||
				status_code_description ||
				all ||
				start_time ||
				last_comment
			) {
				data = store;
			}
		}

		// Mengambil seluruh kategori
		// @ts-ignore
		const allCategory = [...new Set(data.map((item) => item.category))];
		let categorizeTickets = {};

		// Memuat setiap category sebagai key pada categorizeTickets
		// @ts-ignore
		allCategory.forEach((category: any) => (categorizeTickets[category] = []));
		// Menambahkan setiap ticket kedalam categorynya masing-masing
		// @ts-ignore
		data.forEach((item: any) => categorizeTickets[item.category].push(item));

		// Preprocessing setiap data tiket
		// @ts-ignore
		Object.keys(categorizeTickets).forEach((item: any) =>
			// @ts-ignore
			categorizeTickets[item].forEach((ticket: any) => {
				delete ticket.category;
			})
		);

		// calculate each category to seconds
		Object.keys(categorizeTickets).forEach((category) => {
			let totalSeconds = 0,
				oldestIncident = Number.MIN_SAFE_INTEGER,
				recentIncident = Number.MAX_SAFE_INTEGER;
			// @ts-ignore
			categorizeTickets[category].forEach((ticket) => {
				const { age_seconds } = ticket;
				totalSeconds += +age_seconds;
				oldestIncident = Math.max(+age_seconds, oldestIncident);
				recentIncident = Math.min(+age_seconds, recentIncident);
			});
			const averageIncident = Math.floor(
				// @ts-ignore
				totalSeconds / categorizeTickets[category].length
			);
			// @ts-ignore
			categorizeTickets[category] = {
				"Oldest Incident":
					timeFormatter.secondsToReadableFormat(oldestIncident),
				"Recent Incident":
					timeFormatter.secondsToReadableFormat(recentIncident),
				"Average Incident":
					timeFormatter.secondsToReadableFormat(averageIncident),
				// @ts-ignore
				total: categorizeTickets[category].length,
			};
		});

		const hasWSID = Object.keys(req.query).includes('wsid');
		const hasAll = Object.keys(req.query).includes('all');
		const hasLokasi = Object.keys(req.query).includes('lokasi');
		const hasParams = Object.keys(req.query).length > 0;

		const includeInService = (hasWSID || hasAll || hasLokasi) || !hasParams;

		const listFaultCategory = allFaultCategory.reduce(
			(item: any, curr: any) => {
				let obj = {
					"Oldest Incident": "-",
					"Recent Incident": "-",
					"Average Incident": "-",
					total: 0,
					color: curr.faultCategoryColor,
				};

				// @ts-ignore
				if (categorizeTickets[curr.category]) {
					obj = {
						// @ts-ignore
						...categorizeTickets[curr.category],
						color: curr.faultCategoryColor,
					};
				} else if (curr.category.toLowerCase() === "In Service".toLowerCase()) {
					if (includeInService) {
						obj = {
							...obj,
							total: totalInService,
						};
					} else {
						obj = {
							...obj,
							total: 0,
						};
					}
				}
				totalActiveTerminal = totalActiveTerminal + obj.total;
				item[curr.category] = obj;
				return item;
			},
			{}
		);


		data = {
			lastUpdate: timeFormatter.getCurrent(),
			totalActiveTerminal: totalActiveTerminal,
			data: {
				faultCategory: listFaultCategory,
			},
		};
		const message = {
			english: `Successfully Retrieved Fault Category Data`,
			indonesia: `Berhasil Mengambil Data Fault Category`,
		};

		res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, data));
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to process fault category data");
	}
};

/**
 * Get tickets for each category
 */
export const getIncidentID = async (
	req: IGetIncidentIDRequest,
	res: Response
) => {
	try {
		const category = req.query?.category;
		const page = req.query?.page;
		const limit = req.query?.limit;
		const sortBy = req.query?.sortBy;
		const orderBy = req.query?.orderBy;
		const all = req.query?.all;
		const ticket_id = req.query?.ticket_id;
		const wsid = req.query?.wsid;
		const lok = req.query?.lok;
		const lokasi = req.query?.lokasi;
		const tipe_mesin = req.query?.tipe_mesin;
		const vendor_mesin = req.query?.vendor_mesin;
		const status_code = req.query?.status_code;
		const start_time = req.query?.start_time;
		const end_time = req.query?.end_time;
		const duration = req.query?.duration;
		const status_code_description = req.query?.status_code_description;
		const last_comment = req.query?.last_comment;
		const startDate = req.query?.startDate;
		const endDate = req.query?.endDate;

		const { vendor_site_id: vendorSiteId, koordinator: koordinatorId } = req.kauth?.grant?.access_token?.content || "";

		const name = req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		if (page && limit && sortBy && orderBy && category) {
			let data = await incidentRepo.getIncidentID(
				category,
				page,
				limit,
				sortBy,
				orderBy,
				startDate,
				endDate,
				vendorSiteId,
				koordinatorId
			);
			let isUsingAdvSearch = false;

			if (data) {
				data.forEach((item: any) => {
					Object.keys(item).forEach(
						(key) => (item[key] = item[key] === null ? "-" : item[key])
					);
					item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
					item["duration"] = timeFormatter.secondsToReadableFormat(
						item["age_seconds"]
					);
					// item['_id'] = encrypt(item.id);
					// item['_wsid'] = encrypt(item.wsid);
					delete item["age_seconds"];
					delete item["rn"];
				});

				const store = handleAdvancedSearch(
					data,
					all,
					ticket_id,
					wsid,
					lok,
					lokasi,
					tipe_mesin,
					vendor_mesin,
					status_code,
					start_time,
					end_time,
					duration,
					status_code_description,
					last_comment
				);

				if (
					ticket_id ||
					wsid ||
					lokasi ||
					status_code ||
					duration ||
					status_code_description ||
					all ||
					start_time ||
					last_comment
				) {
					data = paginate(store, +page, +limit);
					isUsingAdvSearch = true;
				}
			}

			if (!isUsingAdvSearch) {
				data = paginate(data, +page, +limit);
			}

			const hasWSID = Object.keys(req.query).includes('wsid');
			const hasAll = Object.keys(req.query).includes('all');
			const hasLokasi = Object.keys(req.query).includes('lokasi');
			const hasParams = Object.keys(req.query).length > 5;

			const includeInService = (hasWSID || hasAll || hasLokasi) || !hasParams;

			const isInService = category === "In Service";

			let result = {};

			if ((isInService && includeInService) || !isInService) {
				result = {
					lastUpdate: timeFormatter.getCurrent(),
					tickets: data
				};
			}
			else {
				result = {
					lastUpdate: timeFormatter.getCurrent(),
					tickets: []
				};
			}

			const message = {
				english: `Successfully Retrieved Fault Category Data`,
				indonesia: `Berhasil Mengambil Data Fault Category`,
			};

			res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, result));
			return;
		}
		const requiredParams = {
			page,
			limit,
			sortBy,
			orderBy,
			category,
		};
		clientError.incompleteQuery(requiredParams, res);
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to process fault category's tickets");
	}
};

/**
 * Get Current Incident details for Incident Detail page
 */
export const getIncidentCurrent = async (
	req: IGetIncidentCurrentRequest,
	res: Response
) => {
	try {
		const { vendor_site_id: vendorSiteId, koordinator: koordinatorId } = req.kauth?.grant?.access_token?.content || "";

		const name = req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const ticketId = req.query?.ticketId;
		const wsid = req.query?.wsid;

		if (ticketId === "-") {
			const message = {
				english: `Successfully Retrieved Incident Current Data`,
				indonesia: `Berhasil Mengambil Data Incident Current`,
			};

			const data = await incidentRepo.getTerminalDetails(wsid, vendorSiteId, koordinatorId);

			// klo misalnya tidak ada gimana?

			const response = {
				wsid: data[0]['WSID'],
				_wsid: data[0]['_wsid'],
				currentDetails: {
					"Status Code": "-",
					Component: "-",
					Detail: "-",
					"Start Time": "-",
					"End Time": "-",
					"Created By": "-",
				},
			};

			res.send(jsonMessage.jsonSuccess(message, response));
			return;
		}

		let ticketIdData = await incidentRepo.getIncidentCurrent(
			ticketId,
			vendorSiteId,
			koordinatorId
		);

		const data = handleProcessIncidentCurrent(ticketIdData);

		const message = {
			english: `Successfully Retrieved Incident Current Data`,
			indonesia: `Berhasil Mengambil Data Incident Current`,
		};

		res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, data));
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to process current incident data");
	}
};

/**
 * Get Terminal Details for Incident Management Detail
 */
export const getTerminalDetails = async (
	req: IGetTerminalDetailsRequest,
	res: Response
) => {
	try {
		const wsid = req.query?.wsid;
		// if (wsid) wsid = decrypt(wsid);
		const ticketId = req.query?.ticketId;
		// if (ticketId) ticketId = decrypt(ticketId);

		const obj = { message: "WSID is undefined!" };

		const name = req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		if (wsid) {
			const { vendor_site_id: vendorSiteId, koordinator: koordinatorId } = req.kauth?.grant?.access_token?.content || "";

			let data = await incidentRepo.getTerminalDetails(wsid, vendorSiteId, koordinatorId);

			if (!data.length) {
				const message = {
					english: `WSID ${wsid} does not exist!`,
					indonesia: `Tidak ditemukan WSID ${wsid}`,
				};

				const response = {
					"terminalDetails": {
						"locationGroup": {
							"WSID": "-",
							"Location 1": "-",
							"Location 2": "-",
							"State/Country": "-",
							"City": "-",
							"ZIP": "-",
							"Operational Hour": "-",
							"Area": "-",
							"Branch": "-",
							"District": "-",
							"Institution": "-",
							"Latitude": "-",
							"Longitude": "-",
							"Region": "-"
						},
						"machineGroup": {
							"Manufacturer": "-",
							"Tipe Mesin": "-",
							"Serial Number": "-",
							"Vendor Mesin": "-",
							"Cassette Out Table": "-",
							"Jumlah Kaset": "-"
						},
						"networkGroup": {
							"IP Address": "-",
							"INIDIU": "-"
						},
						"status": "-",
						"lastUpdate": "-"
					}
				}

				res.send(jsonMessage.jsonSuccess(message, response));
				return;
			}

			data = handleProcessTerminalDetails(data);
			let { terminalDetails } = data;
			const operationalHour = `${getOperationalDaysByInitial(terminalDetails["Operational Days"])} ${terminalDetails["Operational Hour"]}`
			const locationGroup = {
				WSID: terminalDetails["WSID"],
				"Location 1": terminalDetails["Location 1"],
				"Location 2": terminalDetails["Location 2"],
				"State/Country": terminalDetails["State/Country"],
				City: terminalDetails["City"],
				ZIP: terminalDetails["ZIP"],
				"Operational Hour": operationalHour === "- -" ? "-" : operationalHour,
				Area: terminalDetails["Area"],
				Branch: terminalDetails["Branch"],
				District: terminalDetails["District"],
				Institution: terminalDetails["Institution"],
				Latitude: terminalDetails["Latitude"],
				Longitude: terminalDetails["Longitude"],
				Region: terminalDetails["Region"],
			};

			// Machine Group
			const machineGroup = {
				Manufacturer: terminalDetails["Manufacturer"],
				"Tipe Mesin": terminalDetails["Tipe Mesin"],
				"Serial Number": terminalDetails["Serial Number"],
				"Vendor Mesin": terminalDetails["Vendor Mesin"],
				"Cassette Out Table": terminalDetails["Cassette Out Table"],
				"Jumlah Kaset": terminalDetails["Jumlah Kaset"],
			};

			// Network Group
			const networkGroup = {
				"IP Address": terminalDetails["IP Address"],
				INIDIU: terminalDetails["INIDIU"],
			};

			let isExist = "-";

			if (ticketId) {
				let getStatus = await incidentRepo.getTerminalStatus(ticketId);
				if (getStatus && getStatus[0] && getStatus[0].category)
					isExist = getStatus[0].category;
			}

			data.terminalDetails = {
				locationGroup,
				machineGroup,
				networkGroup,
				status: isExist,
				lastUpdate: timeFormatter.getCurrent(),
			};

			const message = {
				english: `Successfully Retrieved Terminal Detail's Data`,
				indonesia: `Berhasil Mengambil Data Terminal`,
			};

			res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, data));
			return;
		}
		throw obj;
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to process terminal's detail");
	}
};

export const getTerminalCurrentStatus = async (
	req: IGetTerminalCurrentStatusRequest,
	res: Response
) => {
	try {
		const ticketId = req.query.ticketId;
		// if (ticketId) ticketId = decrypt(ticketId);

		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		if (ticketId) {
			const data = await incidentRepo.getTerminalCurrentStatus(ticketId);
			const message = {
				indonesia: "Berhasil mengambil status terminal",
				english: "Successfully retrived terminal status",
			};

			try {
				const status = data[0].FAULT_CATEGORY;

				const response = {
					status,
				};

				// console.log(jsonMessage.jsonSuccess(message, response));

				res.send(jsonMessage.jsonSuccess(message, response));
				return;
			} catch (e) {
				// check if wsid exists from database
				const hasWSID = await incidentRepo.getHasWSID(ticketId);
				const [wsid] = hasWSID;
				if (wsid.count === 0) {
					const response = {
						status: "-",
					};
					res.send(jsonMessage.jsonSuccess(message, response));
					return;
				}

				const response = {
					status: "In Service",
				};
				res.send(jsonMessage.jsonSuccess(message, response));
				return;
			}
		}

		const requiredParams = {
			ticketId,
		};
		clientError.incompleteQuery(requiredParams, res);
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to process current terminal status");
	}
};

/**
 * Get Incident History details for Incident Detail page
 */
export const getIncidentHistory = async (
	req: IGetIncidentHistoryRequest,
	res: Response
) => {
	try {
		const wsid = req.query?.wsid;
		const page = req.query?.page;
		const limit = req.query?.limit;
		const sortBy = req.query?.sortBy;
		const orderBy = req.query?.orderBy;
		const status_code = req.query?.status_code;
		const all = req.query?.all;
		const ticket_id = req.query?.ticket_id;
		const action_code = req.query?.action_code;
		const action_code_description = req.query?.action_code_description;
		const start_time = req.query?.start_time;
		const end_time = req.query?.end_time;
		const status_code_description = req.query?.status_code_description;
		const last_comment = req.query?.last_comment;
		const startDate = req.query?.startDate;
		const endDate = req.query?.endDate;

		const obj = { message: "Page or limit is not defined" };

		const { vendor_site_id: vendorSiteId, koordinator: koordinatorId } =
			req.kauth?.grant?.access_token?.content || "";

		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		if (page && limit && sortBy && orderBy) {
			let terminalIncidentHistory;
			const getTotal = await incidentRepo.getTotalIncidentHistory(
				wsid,
				vendorSiteId,
				koordinatorId
			);
			let { total } = getTotal[0];

			if (
				all ||
				ticket_id ||
				start_time ||
				end_time ||
				action_code ||
				action_code_description ||
				status_code ||
				status_code_description ||
				startDate ||
				endDate ||
				last_comment
			) {
				terminalIncidentHistory = await incidentRepo.getIncidentHistory(
					wsid,
					0,
					total,
					sortBy,
					orderBy,
					vendorSiteId,
					koordinatorId
				);
				// Set start_time and end time to UTC time format
				terminalIncidentHistory.forEach((item: any) => {
					item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
					item["end_time"] = timeFormatter.UTCTimeFormat(item["end_time"]);
					delete item["rn"];
					Object.keys(item).forEach(
						(key) => (item[key] = item[key] === null ? "-" : item[key])
					);
				});

				const data = handleHistoryAdvancedSearch(
					terminalIncidentHistory,
					all,
					ticket_id,
					start_time,
					end_time,
					action_code,
					action_code_description,
					status_code,
					status_code_description,
					last_comment
				);
				total = data.length;
				terminalIncidentHistory = paginate(data, +page, +limit);
			} else {
				terminalIncidentHistory = await incidentRepo.getIncidentHistory(
					wsid,
					page,
					limit,
					sortBy,
					orderBy,
					vendorSiteId,
					koordinatorId
				);
				// Set start_time and end time to UTC time format
				terminalIncidentHistory.forEach((item: any) => {
					item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
					item["end_time"] = timeFormatter.UTCTimeFormat(item["end_time"]);
					delete item["rn"];
					Object.keys(item).forEach(
						(key) => (item[key] = item[key] === null ? "-" : item[key])
					);
				});

			}

			if (!terminalIncidentHistory && !terminalIncidentHistory.length) {
				const message = {
					english: `Data history does not exist!`,
					indonesia: `Tidak ditemukan riwayat!`,
				};

				res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, {}));
				return;
			}


			const data = {
				total,
				rows: terminalIncidentHistory,
			};

			const message = {
				english: `Successfully Retrieved Incident History Data`,
				indonesia: `Berhasil Mengambil Data Incident History`,
			};

			res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, data));
			return;
		}
		const requiredParams = {
			wsid,
			page,
			limit,
			sortBy,
			orderBy,
		};
		clientError.incompleteQuery(requiredParams, res);
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to process current incident's history");
	}
};

export const postIncidentComment = async (
	req: IPostIncidentCommentRequest,
	res: Response
) => {
	try {
		const incidentId = req.query?.incident_id;
		let commentText = req.query?.comment_text;

		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;
		commentText = name + " ~ " + commentText;
		// Get token
		// TODO: Kasi timeout untuk jaga-jaga jika tidak bisa konek ke API vision
		let visionToken = "";
		try {
			visionToken = await visionHelper.getToken(name);
		} catch (err) {
			res
				.status(status.HTTP_BAD_GATEWAY)
				.send(
					jsonMessage.jsonFailed(
						status.HTTP_BAD_GATEWAY,
						"-",
						"Unable to authenticate to upstream server",
						"-"
					)
				);
			return;
		}

		const getIncidentNumber = await incidentRepo.getIncidentNumber(incidentId);
		const incidentNumber = getIncidentNumber[0].ticket_key;

		// Post comment
		// TODO: Kasi timeout untuk jaga-jaga jika tidak bisa konek ke API vision
		try {
			// await visionHelper.//devtriton01.dti.co.id/incident-service/incidentManagement/incidents/66782/locks
			const res = await visionHelper.postComment(
				visionToken,
				commentText,
				incidentNumber,
				name
			);
		} catch (err) {
			res
				.status(status.HTTP_BAD_GATEWAY)
				.send(
					jsonMessage.jsonFailed(
						status.HTTP_BAD_GATEWAY,
						"-",
						"Unable to post comment to upstream server",
						"-"
					)
				);
			return;
		}

		const message = {
			english: `Successfully inserted a new comment!`,
			indonesia: `Berhasil menambahkan komentar baru!`,
		};

		res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message));
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to process request to upstream server");
	}
};

export const getIncidentComments = async (
	req: IGetIncidentCommentsRequest,
	res: Response
) => {
	try {
		const incidentId = req.query?.incidentId;

		const name =
			req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		if (incidentId) {
			const incidentComments = await incidentRepo.getIncidentComments(
				incidentId
			);
			incidentComments.forEach((comment: any, idx: number) => {
				comment["id"] = idx;
				comment["created_date"] = timeFormatter.UTCTimeFormat(
					comment["created_date"]
				);
				comment["created_by"] = comment.created_by_oase
					? comment.created_by_oase
					: comment.created_by;
			});

			const message = {
				english: `Successfully Retrieved Incident History Data`,
				indonesia: `Berhasil Mengambil Data Incident History`,
			};

			const data = {
				rows: incidentComments,
			};

			res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, data));
			return;
		}
		const requiredParams = {
			incidentId,
		};
		clientError.incompleteQuery(requiredParams, res);
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to get incident's comments");
	}
};

/** Report */
export const getIncidentReport = async (
	req: IGetIncidentReportRequest,
	res: Response
) => {
	try {
		const all = req.query?.all;
		const ticket_id = req.query?.ticket_id;
		const wsid = req.query?.wsid;
		const lok = req.query?.lok;
		const lokasi = req.query?.lokasi;
		const tipe_mesin = req.query?.tipe_mesin;
		const vendor_mesin = req.query?.vendor_mesin;
		const status_code = req.query?.status_code;
		const start_time = req.query?.start_time;
		const end_time = req.query?.end_time;
		const duration = req.query?.duration;
		const status_code_description = req.query?.status_code_description;
		const last_comment = req.query?.last_comment;

		const startDate = req.query?.startDate;
		const endDate = req.query?.endDate;

		const name = req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const { vendor_site_id: vendorSiteId, koordinator: koordinatorId } =
			req.kauth?.grant?.access_token?.content || "";

		let data = await incidentRepo.getIncidentReport(
			startDate,
			endDate,
			vendorSiteId,
			koordinatorId
		);

		data.forEach((item: any) => {
			Object.keys(item).forEach((key) => {
				item[key] = item[key] === null ? "-" : item[key];
			});
			item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
			item["end_time"] = timeFormatter.UTCTimeFormat(item["end_time"]);
			item["duration"] = timeFormatter.secondsToReadableFormat(
				item["age_seconds"],
				true
			);
		});

		const store = handleAdvancedSearch(
			data,
			all,
			ticket_id,
			wsid,
			lok,
			lokasi,
			tipe_mesin,
			vendor_mesin,
			status_code,
			start_time,
			end_time,
			duration,
			status_code_description,
			last_comment
		);

		if (
			ticket_id ||
			wsid ||
			lok ||
			lokasi ||
			tipe_mesin ||
			vendor_mesin ||
			status_code ||
			duration ||
			status_code_description ||
			all ||
			start_time ||
			last_comment
		) {
			data = store;
		}

		data = data.reduce((acc: any[], item: any) => {
			acc.push({
				'Incident Number': item['id'],
				'WSID': item['wsid'],
				'Lok': item['lok'],
				'Lokasi': item['lokasi'],
				'Tipe Mesin': item['tipe_mesin'],
				'Vendor Mesin': item['vendor_mesin'],
				'Start Time': item['start_time'],
				'End Time': item['end_time'],
				'Duration': item['duration'],
				'Status Code - Description': item['status_code_description'],
				'Last Comment': item['last_comment']
			})
			return acc
		}, []);

		const message = {
			indonesia: "Berhasil mengambil report incidents",
			english: "Successfully generated an incident report",
		};

		const response = {
			rows: data,
		};

		res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, response));
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to get incident report");
	}
};

export const getIncidentReportPreview = async (
	req: IGetIncidentReportRequest,
	res: Response
) => {
	try {
		const all = req.query?.all;
		const ticket_id = req.query?.ticket_id;
		const wsid = req.query?.wsid;
		const lok = req.query?.lok;
		const lokasi = req.query?.lokasi;
		const tipe_mesin = req.query?.tipe_mesin;
		const vendor_mesin = req.query?.vendor_mesin;
		const status_code = req.query?.status_code;
		const start_time = req.query?.start_time;
		const end_time = req.query?.end_time;
		const duration = req.query?.duration;
		const status_code_description = req.query?.status_code_description;
		const last_comment = req.query?.last_comment;

		const startDate = req.query?.startDate;
		const endDate = req.query?.endDate;

		const name = req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const { vendor_site_id: vendorSiteId, koordinator: koordinatorId } = req.kauth?.grant?.access_token?.content || "";

		let data = await incidentRepo.getIncidentReport(
			startDate,
			endDate,
			vendorSiteId,
			koordinatorId
		);

		data.forEach((item: any) => {
			Object.keys(item).forEach(
				(key) => (item[key] = item[key] === null ? "-" : item[key])
			);
			item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
			item["end_time"] = timeFormatter.UTCTimeFormat(item["end_time"]);
			item["duration"] = timeFormatter.secondsToReadableFormat(
				item["age_seconds"],
				true
			);
			delete item["age_seconds"];
			delete item["rn"];
		});

		const store = handleAdvancedSearch(
			data,
			all,
			ticket_id,
			wsid,
			lok,
			lokasi,
			tipe_mesin,
			vendor_mesin,
			status_code,
			start_time,
			end_time,
			duration,
			status_code_description,
			last_comment
		);

		if (
			ticket_id ||
			wsid ||
			lok ||
			lokasi ||
			tipe_mesin ||
			vendor_mesin ||
			status_code ||
			duration ||
			status_code_description ||
			all ||
			start_time ||
			last_comment
		) {
			data = store;
		}

		const message = {
			indonesia: "Berhasil mengambil report incidents",
			english: "Successfully generated an incident report",
		};

		// slice data to maximum of 10
		const maxRows = data.slice(0, 10);

		const response = {
			rows: maxRows,
			total: maxRows.length,
		};

		res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, response));
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to get preview incident report");
	}
};

export const getIncidentReportInfo = async (
	req: IGetIncidentReportInfoRequest,
	res: Response
) => {
	try {
		const all = req.query?.all;
		const ticket_id = req.query?.ticket_id;
		const wsid = req.query?.wsid;
		const lok = req.query?.lok;
		const lokasi = req.query?.lokasi;
		const tipe_mesin = req.query?.tipe_mesin;
		const vendor_mesin = req.query?.vendor_mesin;
		const status_code = req.query?.status_code;
		const start_time = req.query?.start_time;
		const end_time = req.query?.end_time;
		const duration = req.query?.duration;
		const status_code_description = req.query?.status_code_description;
		const last_comment = req.query?.last_comment;

		const startDate = req.query?.startDate;
		const endDate = req.query?.endDate;

		const name = req.kauth.grant.access_token.content.preferred_username || null;
		req.name = name;

		const { vendor_site_id: vendorSiteId, koordinator: koordinatorId } = req.kauth?.grant?.access_token?.content || "";

		let data = await incidentRepo.getIncidentReport(
			startDate,
			endDate,
			vendorSiteId,
			koordinatorId
		);

		data.forEach((item: any) => {
			Object.keys(item).forEach(
				(key) => (item[key] = item[key] === null ? "-" : item[key])
			);
			item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
			item["end_time"] = timeFormatter.UTCTimeFormat(item["end_time"]);
			item["duration"] = timeFormatter.secondsToReadableFormat(
				item["age_seconds"],
				true
			);
			delete item["age_seconds"];
			delete item["rn"];
		});

		const store = handleAdvancedSearch(
			data,
			all,
			ticket_id,
			wsid,
			lok,
			lokasi,
			tipe_mesin,
			vendor_mesin,
			status_code,
			start_time,
			end_time,
			duration,
			status_code_description,
			last_comment
		);

		if (
			ticket_id ||
			wsid ||
			lokasi ||
			lok ||
			tipe_mesin ||
			vendor_mesin ||
			status_code ||
			duration ||
			status_code_description ||
			all ||
			start_time ||
			last_comment
		) {
			data = store;
		}

		const message = {
			indonesia: "Berhasil mengambil data report incident",
			english: "Successfully retrieved incident report info",
		};

		let total = data.length;
		let showTotal = 0;

		if (total >= 10) {
			showTotal = 10;
		} else {
			showTotal = total;
		}

		const response = {
			showTotal,
			total,
		};

		res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, response));
	} catch (err) {
		jsonMessage.getInternalServerError(err, res, "Unable to get report incident information");
	}
};

export { };

