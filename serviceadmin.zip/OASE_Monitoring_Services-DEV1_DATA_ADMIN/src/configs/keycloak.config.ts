import env from "../env/server.env";

const config = {
  "realm": env.KEYCLOAK_REALM || "",
  "bearer-only": env.KEYCLOAK_BEARER_ONLY === true,
  "auth-server-url": env.KEYCLOAK_URL || "",
  "resource": env.KEYCLOAK_CLIENTID || "",
  "ssl-required": env.KEYCLOAK_SSL_REQUIRED || "",
  "confidential-port": 0,
  "credentials": {
    "secret": env.KEYCLOAK_SECRET,
  }
};

export default config;