import React from "react";

function ImportError() {
    return (
        <h1>500 Internal Error</h1>
    );
}

export default ImportError;