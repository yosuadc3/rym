export default function replaceNullOrEmptyString(obj: any = {}, replaceWith: string = "-") {
    for (let key in obj) {
        const value = obj[key];

        if (value === null || value === "") {
            obj[key] = replaceWith;
        }
    }
}

export { }