import { getDecodedToken } from "./action";

function getGroups() {
    const groups = getDecodedToken()?.user_group || [];

    return groups;
}

function hasGroups(requiredGroups) {
    const groups = getGroups();

    if (requiredGroups) {
        return requiredGroups.some(requiredGroup => groups.includes(requiredGroup));
    }

    return false;
}

export { getGroups, hasGroups }