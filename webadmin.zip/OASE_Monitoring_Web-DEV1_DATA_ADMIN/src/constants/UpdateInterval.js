//Update interval in miliseconds

export const LOSTCOMM_INTERVAL = 20000;
export const SPV_MODE_INTERVAL = 120000;
export const SPV_MODE_DETAIL_INTERVAL = 120000;
export const DSA_INTERVAL = 120000;
export const SERVICE_AVAILABILITY_INTERVAL = 120000;