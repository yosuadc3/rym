const Keycloak = require("keycloak-connect");
const MemoryStore = require("memorystore")(require("express-session"));
const config = require("../configs/keycloak.config");

const environment = `[${process.env.NODE_ENV?.toUpperCase()}]`;

let keycloak: any;

function init() {
  process.stdout.write(`${environment}: Initializing Keycloak...`);
  if (keycloak) {
    return keycloak;
  } else {
    keycloak = new Keycloak(
      {
        store: new MemoryStore({ checkPeriod: 86400000 }),
      },
      config
    );

    process.stdout.write(`\r${environment}: Initialized Keycloak    \n`);

    return keycloak;
  }
}

function get() {
  if (!keycloak) {
    process.stdout.write(`\r${environment}: Keycloak has not been initialized\n`);
    // console.error("Keycloak has not been initialized");
  } else {
    return keycloak;
  }
}

module.exports = {
  init,
  get,
};

export { };

