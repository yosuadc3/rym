import { Avatar, Box, Button, Card, CardContent, Dialog, DialogActions, DialogTitle, Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import profilePicture from "../../assets/image/profile.jpg";
import { getRefreshToken } from "../../token/action";
import { hasGroups } from "../../token/groups";
import { axiosGet, axiosPost, axiosPut } from "../../utilities/AxiosHelper";
import ProfileExternal from "./ProfileExternal";
import ProfileInternal from "./ProfileInternal";

const API_URI = process.env.REACT_APP_API_OASE;

const style = {
    avatar: {
        width: "40%",
        height: "auto",
        border: "1px solid #C4C4C4",
        backgroundColor: "#C4C4C4"
    },
    profile: {
        display: "flex",
        justifyContent: "center",
        textAlign: "center",
        alignItems: "center",
        flexDirection: "column",
        marginTop: "5%"
    },
    profileName: {
        textTransform: "capitalize",
        fontWeight: "bold",
        fontSize: "24px",
        marginTop: "4%"
    },
    buttonChangePass: {
        backgroundColor: "#156db8",
        width: "15em",
        padding: "2%",
        marginTop: "5%",
        color: "white",
        textTransform: "capitalize",
        "&:hover": {
            backgroundColor: "#125fa1",
        },
        "&:active": {
            backgroundColor: "#156db8",
        }
    },
    dialogContentTxt: {
        fontWeight: "bold",
        fontSize: "23px",
        color: "black",
        marginLeft: 50,
        marginRight: 50,
        marginTop: 40,
        marginBottom: 16
    },
    buttonOk: {
        textTransform: "capitalize",
        width: "170px",
        backgroundColor: "#156db8",
        color: "white",
        "&:hover": {
            backgroundColor: "#125fa1",
        },
        "&:active": {
            backgroundColor: "#156db8",
        }
    }
}

async function getUserDetail(setUserDetail) {
    const userDetail = await axiosGet(API_URI, "/user/profile");
    setUserDetail(userDetail.data);
}

function Profile() {
    const [userDetail, setUserDetail] = useState({});
    const [open, setOpen] = useState(false);
    const [openChangePassword, setOpenChangePassword] = useState(false);
    const [message, setMessage] = useState("");
    const checkLDAP_User = hasGroups(["/LDAP_USER"]);

    useEffect(() => {
        getUserDetail(setUserDetail);
    }, []);

    const handleChangePassword = () => {
        axiosPut(API_URI, "/usersession/user-action")
            .then(res => {
                if (res) {
                    const payload = {
                        refresh_token: getRefreshToken()
                    }

                    axiosPost(API_URI, "/usersession/logout-web", payload)
                        .then(() => {
                            localStorage.clear();
                            window.location.reload();
                        })
                        .catch(error => {
                            console.error(error);
                        });
                }
                else {
                    if (res.message !== undefined) {
                        setMessage(res.message);
                        handleOpen();
                    }
                }
            })
            .catch(error => {
                console.error(error);
            });
    }

    const handleOpen = () => {
        setOpen(true);
    }

    const handleClose = () => {
        setOpen(false);
    }

    const handleOpenChangePassword = () => {
        setOpenChangePassword(true);
    }

    const handleCloseChangePassword = () => {
        setOpenChangePassword(false);
    }

    return (
        <>
            <Grid container>
                <Grid item xs={1} />
                <Grid item xs={10}>
                    <Card elevation={2}>
                        <CardContent sx={{ marginBottom: "5%" }}>
                            <Grid container >
                                <Grid item xs={5} sx={style.profile}>
                                    <Avatar alt="Profile Picture" src={profilePicture} sx={style.avatar} />
                                    <Typography variant="h4" component="h3" sx={style.profileName}>{userDetail?.full_name || "-"}</Typography>
                                    <Box width="100%">
                                        {
                                            !checkLDAP_User ?
                                                <Button onClick={handleOpenChangePassword} sx={style.buttonChangePass} variant="contained" >Ubah Password</Button>
                                                :
                                                <></>
                                        }
                                    </Box>
                                </Grid>
                                <Grid item xs={7}>
                                    {checkLDAP_User ?
                                        <ProfileInternal userData={userDetail} />
                                        :
                                        <ProfileExternal
                                            open={open}
                                            handleClose={handleClose}
                                            userData={userDetail}
                                            handleChangePassword={handleChangePassword}
                                            openChangePassword={openChangePassword}
                                            handleCloseChangePassword={handleCloseChangePassword}
                                        />
                                    }
                                </Grid>
                            </Grid>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={1} />
            </Grid>

            <Dialog
                open={open}
                onClose={handleClose}
            >
                <DialogTitle>
                    <Typography sx={style.dialogContentTxt}>{message}</Typography>
                </DialogTitle>

                <DialogActions sx={{ justifyContent: "center", marginBottom: "40px" }}>
                    <Button sx={style.buttonOk} onClick={handleClose} variant="contained">OK</Button>
                </DialogActions>
            </Dialog>
        </>
    );
}

export default Profile;