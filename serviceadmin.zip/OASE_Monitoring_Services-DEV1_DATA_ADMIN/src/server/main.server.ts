//Dependencies
import displayServerInfo from "../utils/displayServerInfo.util";
displayServerInfo();

import bodyParser from "body-parser";
import chalk from "chalk";
import compression from "compression";
import cors from "cors";
import express, { Application, NextFunction } from "express";
import "express-async-errors";
import session from "express-session";
import helmet from "helmet";
import env from "../env/server.env";
import errorHandler from "../middlewares/errorHandler.middleware";
import * as keycloakFn from "../middlewares/keycloakHandler.middleware";
import * as logging from "../middlewares/logging.middleware";
import querySanitizer from "../middlewares/querySanitizer.middleware";
import { IRequestAPI, IResponseAPI } from "../types/global.type";
import { getCurrentDate } from "../utils/dateTime.util";
import printToConsole from "../utils/printToConsole.util";
import log from "../utils/simplifiedLog.util";

const MemoryStore = require("memorystore")(session);
const routes = require("../routes/main.route");

//Variables
let server: any;
const keycloak = keycloakFn.init();

export const init = (): Promise<void> => {
	return new Promise((resolve, reject) => {
		const app: Application = express();
		const port = env.PORT || 8080;

		if (env.NODE_ENV === 'production') {
			app.disable('x-powered-by') // hide the server's software stack

			app.use(helmet()); // add simple web vulnerability patches
			app.use(compression()); // reduce response size by compression using gzip
		}

		const baseurl = env?.URL_SUBDIR
			? `/api/${env.URL_SUBDIR}`
			: "/api";

		//Time
		//@ts-ignore
		app.use((req: IRequestAPI, _res: IResponseAPI, next: NextFunction) => {
			req.startTime = Date.now();
			next();
		});

		//Middleware
		//@ts-ignore
		app.use(querySanitizer);
		app.use(bodyParser.json());
		app.use(cors({ origin: "*" }));
		app.use(express.json({ reviver: reviveJSON }));
		app.use(express.urlencoded({ extended: true }));
		app.use(
			session({
				secret: "secret",
				resave: false,
				saveUninitialized: true,
				store: new MemoryStore({ checkPeriod: 86400000 }),
			})
		);
		app.use(keycloak.middleware());

		//Logging
		app.use(logging.printLogging());

		//Apply Routing
		app.use(baseurl, routes);

		//@ts-ignore
		app.use(errorHandler);

		//Run server
		server = app.listen(port);
		server.on("listening", () => {
			const currDate = chalk.blue`${getCurrentDate()}`;
			const baseURL = chalk.bold`/api/monitoring`;
			const message = `[${currDate}] - Service is running on port ${port} with baseurl ${baseURL}`;
			log("\n" + message + "\n");
			resolve();
		});
		server.on("error", (error: NodeJS.ErrnoException) => {
			printToConsole("serverInit", error.message);
			reject(error);
		});
	});
}

export const close = (): Promise<void> => {
	return new Promise((resolve, reject) => {
		server.close((msg: Error) => {
			if (msg) {
				printToConsole("serverClose", msg);
				reject();
			} else {
				resolve();
			}
		});
		setImmediate(() => server.emit("close"));
	});
}

function reviveJSON(_key: string, value: string) {
	const iso8601RegExp = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/;

	// revive ISO 8601 date strings to instances of Date
	if (typeof value === "string" && iso8601RegExp.test(value)) {
		return new Date(value);
	} else {
		return value;
	}
}

export { };

