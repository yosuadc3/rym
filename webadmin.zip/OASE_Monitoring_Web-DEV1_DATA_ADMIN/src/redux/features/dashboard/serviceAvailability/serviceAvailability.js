import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   timestamp: "",
   refresh: false
}

const serviceAvailabilitySlice = createSlice({
   name: "serviceAvailability",
   initialState: initialState,
   reducers: {
      updateTimestamp: (state, action) => {
         const { payload } = action;

         state.timestamp = payload;
      },
      triggerRefresh: (state) => {
         state.refresh = !state.refresh;
      }
   }
});

export const { updateTimestamp, triggerRefresh } = serviceAvailabilitySlice.actions;

export default serviceAvailabilitySlice;
