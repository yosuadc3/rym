import { Response } from "express";
import { IncomingMessage, ServerResponse } from "http";
import moment from "moment";
import morgan from "morgan";
import { IMorganLoggingRequest, StringOrUndefined } from "../types/global.type";
const chalk = require("chalk");
const uaParser = require('ua-parser-js')
require("dotenv").config();

const NODE_ENV = process.env.NODE_ENV;
const SERVER_SITE = process.env.SERVER_SITE;

const loggingExecptionURL = ["/api/health-check"];

const statusColor = (method: string, status: number): string => {
	const successColor = chalk.bold.green;
	const dangerColor = chalk.bold.red;
	const warningColor = chalk.bold.yellow;
	const infoColor = chalk.bold.cyan;
	const redirectionColor = chalk.bold.gray;

	const serverErrorCode = 500;
	const clientErrorCode = 400;
	const redirectionCode = 300;
	const successfulCode = 200;
	const informationCode = 100;

	const methodStatus = `${method.padEnd(6, ' ')} ${status.toString().padEnd(3, ' ')}`;

	if (status >= serverErrorCode) {
		return dangerColor(methodStatus);
	}

	if (status >= clientErrorCode) {
		return warningColor(methodStatus);
	}

	if (status >= redirectionCode) {
		return redirectionColor(methodStatus);
	}

	if (status >= successfulCode) {
		return successColor(methodStatus);
	}

	return infoColor;
}

const twoDigitDecimal = (n: number) => Number(n).toFixed(2);

export const formatBytes = (bytes: number | undefined, chalkFlag = false) => {

	// if response is 300 ranged, it will be NaN. 
	// by default the num is parsed to number
	if (bytes === undefined || isNaN(bytes)) return "*";

	const bytesToMB = 1000000;
	const bytesToKB = bytesToMB / 1000;

	if (!chalkFlag) {
		if (bytes >= bytesToMB) {
			return `${twoDigitDecimal(bytes / bytesToMB)}MB`;
		} else if (bytes >= bytesToKB) {
			return `${twoDigitDecimal(bytes / bytesToKB)}KB`;
		} else {
			return `${bytes}B`;
		}
	}

	if (bytes >= bytesToMB) {
		return chalk.red`${twoDigitDecimal(bytes / bytesToMB)}MB`;
	} else if (bytes >= bytesToKB) {
		return chalk.green`${twoDigitDecimal(bytes / bytesToKB)}KB`;
	} else {
		return chalk.green`${bytes}B`;
	}
}

export const formatMiliseconds = (num: number | undefined, chalkFlag = false): string => {

	// if response is 300 ranged, it will be NaN. 
	// by default the num is parsed to number
	if (num === undefined || isNaN(num)) return "*";

	const hrsInMs = 3600000;
	const minInMs = hrsInMs / 60;
	const secInMs = minInMs / 60;

	if (!chalkFlag) {
		if (num >= hrsInMs) {
			return `${twoDigitDecimal(num / hrsInMs)}hr`;
		} else if (num >= minInMs) {
			return `${twoDigitDecimal(num / minInMs)}min`;
		} else if (num >= secInMs) {
			return `${twoDigitDecimal(num / secInMs)}s`;
		}
		return `${(num)}ms`;
	}

	if (num >= hrsInMs) {
		return chalk.red`${twoDigitDecimal(num / hrsInMs)}hr`;
	} else if (num >= minInMs) {
		return chalk.red`${twoDigitDecimal(num / minInMs)}min`;
	} else if (num >= secInMs) {
		return chalk.red`${twoDigitDecimal(num / secInMs)}s`;
	}

	return chalk.green`${(num)}ms`;
}

export const printLogging = () => {
	morgan.token("error", (req: IMorganLoggingRequest) => {
		return req.error;
	});
	morgan.token("username", (req: IMorganLoggingRequest, res: Response) => {
		return req.name;
	});
	morgan.token("body", (req: IMorganLoggingRequest) => {
		//@ts-ignore
		return JSON.stringify(req.body || req.rawBody);
	});
	return morgan(
		(
			tokens: morgan.TokenIndexer,
			req: IncomingMessage,
			res: ServerResponse
		) => {

			// Request Type
			//@ts-ignore
			const startTime = moment(req.startTime).format("YYYY/MM/DD HH:mm:ss");
			const timestamp = `[${startTime}]`;
			const method = tokens.method(req, res)!;
			const status = Number(tokens.status(req, res));
			const methodStatus = statusColor(method, status);

			// Path
			const url = tokens.url(req, res);
			const logURL = chalk.blue(tokens.url(req, res)) || "*";

			const body = JSON.stringify(tokens.body(req, res));

			// User
			const userName = tokens.username(req, res);
			const logUser = chalk.bold.magenta(userName) ?? "*";

			// Response
			const responseTime = tokens['response-time'](req, res);
			const responseSize = tokens.res(req, res, 'content-length')! ?? 0;
			const logTime = formatMiliseconds(Number(Number(responseTime).toFixed(0)), true) || "*";
			const logTimeNoChalk = formatMiliseconds(Number(Number(responseTime).toFixed(0))) || "*";
			const logSize = formatBytes(parseInt(responseSize), true) || "*";
			const logSizeNoChalk = formatBytes(parseInt(responseSize)) || "*";
			const responseMetric = `|${logTime} ~ ${logSize}|`

			// User Hardware
			const userAgent = uaParser(req.headers['user-agent']);
			const os = userAgent.os.name || '*';
			const browser = userAgent.browser.name;
			const browserVersion = userAgent.browser.version;
			const logBrowser = `${browser} ${browserVersion}` || '*';

			// User Address
			const remoteAddress = tokens["remote-addr"](req, res);

			const error = tokens.error(req, res);

			if (loggingExecptionURL.includes(tokens.url(req, res)!)) return null;

			if (NODE_ENV === "development") {
				const outputLog = [
					timestamp,
					methodStatus,
					logURL,
					responseMetric,
					logUser,
					os,
					logBrowser,
					remoteAddress,
					error
				];

				return outputLog.join(" ");
			}

			const outputLog = {
				timestamp: startTime,
				method,
				status,
				url,
				duration: logTimeNoChalk,
				size: logSizeNoChalk,
				user: userName,
				os,
				browser,
				browser_version: browserVersion,
				ip: remoteAddress,
				site: SERVER_SITE,
				type: "INTERNAL",
				body,
				header: JSON.stringify({})    	// untuk skrg belum kepake
			}

			return JSON.stringify(outputLog);
		}
	);
};

export { };

