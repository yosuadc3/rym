
import { Grid, Typography, Button } from "@mui/material";
import React from "react";
import Color from "../components/Color"

export default function Information({name,description,defined, last_modified, color, onClick}){
    const options = {
        day: "numeric",
        month: "numeric",
        year: "numeric",
        hour12: false ,
      };

    function convertDate (date){
        const tempDate = new Date(date);
        const converted = tempDate.toLocaleString("id-ID",options);
        const hour = (tempDate.getHours()<10?"0":"")+tempDate.getHours();
        const minute = (tempDate.getMinutes()<10?"0":"") + tempDate.getMinutes();
        return converted+" "+hour+":"+ minute;
    }
    return(
        <Grid container>
            <Grid container spacing={2} columns={16} marginTop={1}>
                <Grid item xs={3} container   direction="column" justifyContent="center" alignItems="flex-start">
                    <Typography sx={{color:"#65748B", fontWeight: "600",fontSize: "16px",lineHeight: "30px" }}>
                        Source Name
                    </Typography>
                        <Typography sx={{fontWeight: "600",fontSize: "16px",lineHeight: "30px"}}>
                            {name}
                        </Typography>
                </Grid>
                <Grid item xs={8} container   direction="column" justifyContent="center" alignItems="flex-start">
                    <Typography sx={{color:"#65748B", fontWeight: "600",fontSize: "16px",lineHeight: "30px" }}>
                        Description
                    </Typography>
                        <Typography sx={{fontWeight: "600",fontSize: "16px",lineHeight: "30px"}}>
                            {description}
                        </Typography>
                </Grid>
            </Grid>
            <Grid container spacing={2} columns={16} marginTop={3} marginBottom={2}>
                <Grid item xs={3} container   direction="column" justifyContent="center" alignItems="flex-start">
                    <Typography sx={{color:"#65748B", fontWeight: "600",fontSize: "16px",lineHeight: "30px" }}>
                        Event Code Defined
                    </Typography>
                    <Typography sx={{fontWeight: "600",fontSize: "16px",lineHeight: "30px" }}>
                        {defined}
                    </Typography>
                </Grid>
                <Grid item xs={3} container   direction="column" justifyContent="center" alignItems="flex-start">
                    <Typography sx={{color:"#65748B", fontWeight: "600",fontSize: "16px",lineHeight: "30px" }}>
                    Last Modified Time
                    </Typography>
                    <Typography sx={{fontWeight: "600",fontSize: "16px",lineHeight: "30px" }}>
                    {convertDate(last_modified)}
                    </Typography>
                </Grid>
            </Grid>
            {/* <Grid container spacing={2} columns={16} marginTop={1}>
                <Grid item xs={3} container   direction="column" justifyContent="center" alignItems="flex-start">
                        <Button variant="contained" disableElevation onClick={onClick} sx={{backgroundColor:"#0D5CAB", fontWeight:"700", fontSize:"16px",textTransform:"capitalize", padding:"10px",paddingX:"25px", borderRadius:"6px"}}>
                            Edit
                        </Button>
                </Grid>
            </Grid> */}
        </Grid>
    );
}