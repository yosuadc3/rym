export const TABLE_ADDONS_SEARCH_ITEMS = [
    {
        value: "all",
        label: "All"
    }
];

export const SEARCH_ITEMS = [
    {
        value: "rule",
        label: "Rule"
    },
    // {
    //     value: "ticket_action",
    //     label: "Ticket Action"
    // },
    // {
    //     value: "email_action",
    //     label: "Email Action"
    // },
    {
        value: "fault_category",
        label: "Fault Category"
    },
    {
        value: "reopen_limit",
        label: "Reopen Limit"
    }
];

export const BREADCRUMBS = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "Incident Management & Monitoring",
        link: null,
        current: false
    },
    {
        item: "Data Configuration",
        link: null,
        current: false
    },
    {
        item: "Event Code Rules",
        link: "/data-configuration/event-code-rules/",
        current: true
    },
];

export const DATA_HEIGHT = 100;