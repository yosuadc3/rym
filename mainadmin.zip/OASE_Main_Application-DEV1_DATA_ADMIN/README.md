<img src="src/assets/image/logo_oase.png" width="600">

# Building Micro Frontends with React and Single-spa

**Getting started**

Clone the repo
git clone --branch STAGING_UAT http://bcagitlab/cts-e/atm_touchpoint/oase/OASE_Main_Application

Install dependencies
using **yarn install** or **npm install**

# Project Structure
```bash
├───config
├───nginx
├───openshift
│   ├───dev
│   ├───prod
│   └───uat
├───public
│   └───font
└───src
    ├───assets
    │   ├───icons
    │   └───image
    ├───components
    │   ├───dialog
    │   ├───error
    │   ├───login
    │   ├───shared
    │   │   └───styles
    │   ├───sidenav
    │   └───svgs
    ├───constant
    ├───containers
    │   ├───home
    │   │   └───components
    │   ├───login
    │   ├───navigation
    │   └───profile
    ├───router
    ├───singleSPA
    ├───styles
    ├───token
    └───utilities
```
* **Config**

    This folder consists of a configuration file where we store webpack config file, We will use this file to set up webpack in your application.

* **Nginx**

    This folder consists of a configuration file where we store nginx.confg

* **Openshift**

    This folder contains openshift yaml file for dev, uat, and production environtment

* **Public**

    The public folder contains static files such as index.html, javascript library files, images, and other assets, etc. which you don’t want to be processed by webpack.
    
* **Src**

    This folder is the heart of React application as it contains JavaScript which needs to be processed by webpack. In this folder, there is a main component App.js, its related styles (App.css), test suite (App.test.js). index.js, and its style (index.css); which provide an entry point into the App. 
    * **Assets**

        This folder contains assets of our project. It consists of images, and icons files.
    
    * **Components**

        Components are the building blocks of any react project. This folder consists of a collection of UI components like buttons, modals, inputs, loader, etc., that can be used across various files in the project. in this project you can custom with html element or material ui component to create a custom components.

    * **Constant**

        This folder contains hardcoded value where we stored in constant file, so we can make it more readable and change the hardcoded value in constant file.

    * **Containers**

        This folder is the parent elements of other components in a React app. They serve as a bridge between the normal components that render the UI and the logic that makes the UI components interactive and dynamic. A container can contain its subfolder. It usually consists of various components grouped.

    * **Router**

        This folder consists of all routes of the application. It consists of private, protected, and all types of routes. Here we can even call our sub-route.

    * **Single Spa**

        This folder consists of single spa file, single spa react is a helper library that helps implement single-spa registered application lifecycle functions (bootstrap, mount and unmount) for use with React to help you build a microfrontend application.

    * **Styles**

        This folder consists of custom global css files.

    * **Token**

        This folder consist of all file about extract token, store token, get token, and etc.

    * **Utilities**

        Utils folder consists of some repeatedly used functions that are commonly used in the project. It should contain only common js functions & objects like dropdown options, regex condition, data formatting, etc.


# Start App
before you start the app, you can create `.env` file on the same level with src, public, etc, and consist of the following variables and values :
```
REACT_APP_KEYCLOAK_URL=https://oase.apps.ocpdev.dti.co.id/auth/
REACT_APP_KEYCLOAK_REALM=OASE
REACT_APP_KEYCLOAK_CLIENTID=oase-monitoring-frontend
REACT_APP_API_OASE=https://oase.apps.ocpdev.dti.co.id/api
REACT_APP_API_OASE_MONITORING=https://oase.apps.ocpdev.dti.co.id/api/monitoring
REACT_APP_IMAGE_PATH=https://oase.apps.ocpdev.dti.co.id/
REACT_APP_IDLE_TIMER=6000000000
```
Start the app by using command
**npm start** or **yarn start**

