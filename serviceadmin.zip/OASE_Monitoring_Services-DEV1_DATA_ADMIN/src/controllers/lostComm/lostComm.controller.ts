//Lost Comm Controller
import { Response } from "express";
import { IGetLostCommRequest } from "../../types/lostComm/lostComm.type";
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import * as dateTime from "../../utils/dateTime.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import printToConsole from "../../utils/printToConsole.util";
const lostCommRepo = require("../../repositories/lostComm.repository");

export const getLostComm = async (req: IGetLostCommRequest, res: Response) => {
	addPayloadToRequestHeader(req);

	const data = await lostCommRepo.get();
	let counterLostComm = 0;

	data.rows.map((item: any) => {
		counterLostComm = counterLostComm + item.JUMLAH;
	});

	const response = {
		total: counterLostComm,
		lastUpdate: dateTime.getCurrent(),
		data: data.rows,
	};
	const message = {
		english: `Successfully Retrieved Lost Communication Data`,
		indonesia: `Berhasil Mengambil Data Lost Communication`,
	};

	res.send(jsonMessage.jsonSuccess(message, response));
};

export const getLostCommReport = async (
	req: IGetLostCommRequest,
	res: Response
) => {
	addPayloadToRequestHeader(req);

	const data = await lostCommRepo.getReport();
	const message = {
		english: `Successfully Retrieved Lost Communication Report`,
		indonesia: `Berhasil Mengambil Report Lost Communication`,
	};

	res.send(jsonMessage.jsonSuccess(message, data.rows));
};

export { };

