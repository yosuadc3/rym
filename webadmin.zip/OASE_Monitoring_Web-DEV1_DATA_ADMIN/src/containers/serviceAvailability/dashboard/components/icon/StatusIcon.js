import React from 'react';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import DoNotDisturbIcon from '@mui/icons-material/DoNotDisturb';

const styles = {
    icon: {
        borderRadius: "50%",
        color: "#FFFFFF",
        fontSize: "2rem",
        padding: 0.5
    }
}

const iconStyles = {
    enable: {
        ...styles.icon,
        backgroundColor: "#25A722"
    },
    warning: {
        ...styles.icon,
        backgroundColor: "#FFD600"
    },
    error: {
        ...styles.icon,
        backgroundColor: "#FF6058"
    },
    stopDeposit: {
        ...styles.icon,
        backgroundColor: "#7B61FF",

    }
}

export function StatusIcon(value = 0) {
    switch (value) {
        case 0:
            return (
                <CheckIcon sx={iconStyles.enable} />
            );
        case 1:
            return (
                <PriorityHighIcon sx={iconStyles.warning} />
            )
        case 2:
            return (
                <CloseIcon sx={iconStyles.error} />
            );
        case 3:
            return (
                <DoNotDisturbIcon sx={iconStyles.stopDeposit} />
            );
        default:
            return (
                <></>
            );
    }
}

export default StatusIcon