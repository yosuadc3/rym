import { Box, Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import EmptyCardWithTitle from "../../../../../components/cards/EmptyCardWithTitle";
import SkeletonText from "../../../../../components/skeleton/SkeletonText";
import { SERVICE_AVAILABILITY_INTERVAL } from "../../../../../constants/UpdateInterval";
import { useGetDsaStatsQuery } from "../../../../../redux/features/dashboard/serviceAvailability/api/serviceAvailability";
import { updateTimestamp } from "../../../../../redux/features/dashboard/serviceAvailability/serviceAvailability";

const styles = {
    itemText: {
        fontSize: "14px",
        color: "#65748B"
    }
}

function Loading({ amount = 3 }) {
    const components = [];

    for (let i = 0; i < amount; i++) {
        components.push(
            <Box key={i} marginBottom={(i + 1) === amount ? 0 : 4}>
                <Grid container>
                    <SkeletonText height={"100%"} width={"100%"} />
                </Grid>
                <Grid container marginTop={2}>
                    <Box sx={{ backgroundColor: "#F0F0F0", borderRadius: "10px", height: 25, overflow: "hidden", width: "100%" }} />
                </Grid>
            </Box>
        );
    }

    return components;
}

function DsaStats({ data, total, loading }) {
    const calcPercentage = (value) => `${Math.round((value / total) * 100)}%`;
    const barColorMap = (type) => {
        switch (type) {
            case "Online":
                return "#97D16C"
            case "Offline":
                return "#FF6058"
            case "Not Installed":
                return "#FFD600"
            default:
                return "#97D16C"
        }
    }

    return (
        <Box marginTop={4}>
            {!loading ? (
                data.map((item, index) => {
                    const percentage = calcPercentage(item.total);
                    const barColor = barColorMap(item.type);

                    return (
                        <Box key={index} marginBottom={(index + 1) === data.length ? 0 : 4}>
                            <Grid container>
                                <Grid item xs={6} textAlign={"left"}>
                                    <Typography sx={{ ...styles.itemText }}>{item.type}</Typography>
                                </Grid>
                                <Grid item display={"flex"} justifyContent={"flex-end"} xs={6}>
                                    <Typography sx={{ ...styles.itemText }}>{item.total} WSID</Typography>
                                    <Typography>&nbsp;</Typography>
                                    <Typography sx={{ ...styles.itemText, color: "#333333", fontWeight: "bold" }}>({percentage})</Typography>
                                </Grid>
                            </Grid>
                            <Grid container marginTop={2}>
                                <Box sx={{ backgroundColor: "#F0F0F0", borderRadius: "10px", height: 25, overflow: "hidden", width: "100%" }}>
                                    <Box sx={{ backgroundColor: barColor, height: "100%", width: percentage }} />
                                </Box>
                            </Grid>
                        </Box>
                    )
                })) : (
                <Loading />
            )}
        </Box>
    );
}

export default function DsaLedStats({ }) {
    const dispatch = useDispatch();
    const refresh = useSelector((state) => state.serviceAvailability.refresh);
    const [tableData, setTableData] = useState([]);
    const [totalTerminal, setTotalTerminal] = useState(0);
    const { data: dsaData, isLoading, refetch } = useGetDsaStatsQuery(null, { pollingInterval: SERVICE_AVAILABILITY_INTERVAL, refetchOnReconnect: true });

    useEffect(() => {
        if (!isLoading) {
            const { data, total_terminal, last_update } = dsaData;
            setTableData(data);
            setTotalTerminal(total_terminal);
            dispatch(updateTimestamp(last_update));
        }
    }, [dsaData, isLoading]);

    useEffect(() => {
        refetch();
    }, [refresh]);

    return (
        <EmptyCardWithTitle sx={{ height: "100%", padding: 3 }} title={"DSA LED"}>
            <DsaStats
                data={tableData}
                total={totalTerminal}
                loading={isLoading} />
        </EmptyCardWithTitle>
    );
}
