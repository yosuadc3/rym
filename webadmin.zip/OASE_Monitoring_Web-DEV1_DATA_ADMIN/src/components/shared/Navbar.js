import React, { useState } from "react";
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Box from '@mui/material/Box';
import { Button, CardMedia, Divider, Fab, Link, Menu, MenuItem, Typography } from '@mui/material';
import { Dialog, DialogActions, DialogTitle, DialogContent, DialogContentText } from '@mui/material/';
import OASELogo from '../../assets/image/OASE.png';
import runningman from '../../assets/image/orang-kabur.png';
import ProfileIcon from '../svgs/ProfileIcon';
import NotifIcon from "../svgs/NotifIcon";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import CloseIcon from '@mui/icons-material/Close';
import moment from 'moment';
import 'moment/locale/id';
import { useKeycloak } from '@react-keycloak/web';
import { Link as LinkRouter } from 'react-router-dom';


const style = {
    date: {
        color: "#65748B",
        fontWeight: 500,
        fontSize: 12
    },
    fabNotif: {
        backgroundColor: "white",
        color: "#FF6058",
        mx: 3
    },
    fabProfile: {
        backgroundColor: "white",
        textTransform: "none"
    },
    helloText: {
        color: "#0F549F",
        display: "inline-block",
        fontWeight: 400,
        fontSize: "12px"
    },
    fullname: {
        color: "#0F549F",
        display: "inline-block",
        fontWeight: 700,
        fontSize: "12px"
    },
    arrowDownIcon: {
        color: "#156db8"
    },
    profileMenu: {
        "& .MuiPaper-root": {
            boxShadow: 0,
            border: 1,
            borderColor: "#d3d4d5",
            marginTop: 0.1,
            width: "8%"
        }
    },
    profileItem: {
        py: 1.2,
        "&:hover": {
            fontWeight: "bold",
            backgroundColor: "#C4D9ED"
        }
    },
    logoutMessage: {
        color: "black",
        fontSize: "1.2em",
        fontWeight: "bold",
        textAlign: "center"
    },
    runningman: {
        width: "50%"
    },
    btnCancelLogout: {
        border: 1,
        borderColor: "#156db8",
        color: "#156db8",
        width: "30%"
    },
    btnConfirmLogout: {
        color: "white",
        backgroundColor: "#156db8",
        width: "30%",
        "&:hover": {
            backgroundColor: "#125fa1",
        },
        "&:active": {
            backgroundColor: "#156db8",
        }
    }
}

function Navbar() {
    const [anchorEl, setAnchorEl] = useState(null);
    const [openLogout, setOpenLogout] = useState(false);

    const { keycloak } = useKeycloak();

    const date = moment().format("dddd, DD MMMM YYYY");
    const fullname = keycloak?.idTokenParsed?.name || "";
    // const fullname = "User";

    //Profile Menu handler
    const handleClickProfile = (event) => {
        setAnchorEl(event.currentTarget);
    }

    const handleCloseProfile = () => {
        setAnchorEl(null);
    }

    //Logout Dialog handler
    const handleOpenLogout = () => {
        setOpenLogout(true);
    }

    const handleCloseLogout = () => {
        setOpenLogout(false);
    }

    //Confirm Logout handler
    const handleConfirmLogout = () => {
        keycloak.logout({
            redirectUri: window.location.origin
        });
    }

    return (
        <>
            <AppBar position="static" elevation={0} sx={{ backgroundColor: "white" }}>
                <Toolbar sx={{ height: 112 }}>
                    <Box sx={{ width: "9.5%", textAlign: "start", ml: 9, mt: 3.8, mb: 2 }} component={LinkRouter} to="/">
                        <CardMedia component="img" image={OASELogo} alt="OASE" />
                    </Box>
                    <Box display="flex" flex={1} justifyContent="flex-end" alignItems="center">
                        <Typography variant="subtitle1" sx={style.date}>{date}</Typography>
                        <Fab size="medium" sx={style.fabNotif} >
                            <NotifIcon />
                        </Fab>
                        <Fab variant="extended" sx={style.fabProfile} onClick={handleClickProfile}>
                            <ProfileIcon />
                            <Box marginRight={1} />
                            <Typography sx={style.helloText}>Hello,&nbsp;</Typography>
                            <Typography sx={style.fullname}>{fullname}</Typography>
                            <ArrowDropDownIcon sx={style.arrowDownIcon} />
                        </Fab>
                        <Menu
                            anchorEl={anchorEl}
                            open={Boolean(anchorEl)}
                            onClose={handleCloseProfile}
                            anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'center',
                            }}
                            transformOrigin={{
                                vertical: 'top',
                                horizontal: 'center',
                            }}
                            MenuListProps={{ disablePadding: true }}
                            sx={style.profileMenu}
                        >
                            <Link color="black" component={LinkRouter} underline="none" to="/profile">
                                <MenuItem sx={style.profileItem}>Profile</MenuItem>
                            </Link>
                            <MenuItem sx={style.profileItem} onClick={handleOpenLogout}>Keluar</MenuItem>
                        </Menu>
                    </Box>
                </Toolbar>
                <Box sx={{ ml: 12, mr: 3 }}>
                    <Divider />
                </Box>
            </AppBar>

            <Dialog
                fullWidth={true}
                open={openLogout}
                onClose={handleCloseLogout}
            >
                <DialogTitle sx={{ textAlign: "end" }}>
                    <Button sx={{ minHeight: 0, minWidth: 0, padding: 0, color: "black" }} onClick={handleCloseLogout} ><CloseIcon /></Button>
                    {/* <CloseIcon onClick={handleCloseLogout} /> */}
                </DialogTitle>
                <DialogContent>
                    <Box display="flex" marginTop={3} justifyContent="center">
                        <CardMedia component="img" image={runningman} sx={style.runningman} />
                    </Box>
                    <DialogContentText sx={style.logoutMessage}>Yakin ingin keluar?</DialogContentText>
                </DialogContent>
                <DialogActions sx={{ justifyContent: "center", mt: 2.5, mb: 5 }}>
                    <Button onClick={handleCloseLogout} sx={style.btnCancelLogout}>Tidak</Button>
                    <Button onClick={handleConfirmLogout} sx={style.btnConfirmLogout}>Ya</Button>
                </DialogActions>
            </Dialog>
        </>
    );
}


export default Navbar;