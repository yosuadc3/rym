import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   color : "#000000"
}

const colorPickerSlice = createSlice({
   name: "colorPicker",
   initialState: initialState,
   reducers: {
     setColorPicker: (state,action)=>{
        const { payload } = action;
        state.color =  payload;
     }
     
   }
});

export const {setColorPicker } = colorPickerSlice.actions;

export default colorPickerSlice;
