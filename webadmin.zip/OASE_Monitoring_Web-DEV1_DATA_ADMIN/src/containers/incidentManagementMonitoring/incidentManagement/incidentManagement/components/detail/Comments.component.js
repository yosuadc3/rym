import { Box, CircularProgress, Grid, Stack, Typography } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import ButtonCommon from "../../../../../../components/buttons/ButtonCommon";
import StyledDivider from "../../../../../../components/divider/StyledDivider";
import FormTextInput from "../../../../../../components/form/FormTextInput";
import useFetch from "../../../../../../hooks/useFetch";
import usePost from "../../../../../../hooks/usePost";
import { setToggleFetchComments } from "../../../../../../redux/features/incident-management-monitoring/incident-management/imm";
import { toParams } from "../../../../../../utilities/Axios";
import {
  createEmptyFormTargets,
} from "../../../../../../utilities/Form";

const CommentBox = ({ id, user, date, comment }) => {
  return (
    <>
      <Grid item xs={12} marginTop={id === 0 ? 3 : 0} width="100%">
        <Stack direction="row" gap={1}>
          <Typography
            sx={{
              fontSize: 16,
              color: "#65748B",
              lineHeight: "19.5px",
            }}
          >
            {user}
          </Typography>
          <Typography
            sx={{
              fontSize: 12,
              color: "#65748B",
              lineHeight: "19.5px",
            }}
          >
            {date}
          </Typography>
        </Stack>
      </Grid>
      <Grid item xs={12} marginTop={1}>
        <Typography fontSize={16} fontWeight={400} lineHeight="19.5px"
          sx={{
            wordWrap: "break-word"
          }}>
          {comment.split("\n").map((paragraph, index) => (
            <React.Fragment key={index}>
              {paragraph}
              <br />
            </React.Fragment>
          ))}
        </Typography>
      </Grid>
      <Grid item xs={12}>
        <StyledDivider />
      </Grid>
    </>
  );
};

export default function Comments() {
  const dispatch = useDispatch();
  const { ticketIdComment, isOpenDialog, toggleFetchComments } = useSelector(
    (state) => state.incidentManagement
  );
  const [comments, setComments] = useState([]);

  const { data, isLoading, fetch } = useFetch(
    `comment?incidentId=${ticketIdComment}`,
    "incident"
  );

  useEffect(() => {
    if (data && data.data) {
      const { rows } = data.data;
      setComments((_) => rows);
    }
  }, [data]);

  const formTargets = [
    "comment",
  ];

  const emptyFormTargets = createEmptyFormTargets(formTargets);

  const refComment = useRef();
  const [form, setForm] = useState(emptyFormTargets);

  const [isDisabled, setIsDisabled] = useState(false);

  useEffect(() => {
    if (!isOpenDialog) {
      setForm((_) => emptyFormTargets);
    }
  }, [isOpenDialog]);

  const handleChangeInput = (e, target) => {
    const { value } = e.target;
    setForm((prevForm) => ({ ...prevForm, [target]: value }));
  };

  const handleSubmitDialog = async () => {
    setIsDisabled(true);

    const paramsDict = {
      incident_id: ticketIdComment,
      comment_text: form.comment,
    }

    const params = toParams(paramsDict);


    await usePost(`comment?${params}`, "incident");
    setIsDisabled(false);
    dispatch(setToggleFetchComments({
      data: {
        toggleFetchComments: !toggleFetchComments
      }
    }))
    fetch(`comment?incidentId=${ticketIdComment}`, "incident");
    refComment.current.value = "";
    setForm((_) => emptyFormTargets);
    // setTimeout(() => {

    // }, 1000);
  };

  return (
    <>
      <Grid item xs={12} marginTop={-4}>
        <Typography
          sx={{
            fontWeight: "600",
            fontSize: "18px",
            color: "#0D5CAB",
          }}
        >
          Comment
        </Typography>
      </Grid>
      {
        isDisabled ? (
          <Grid item container marginTop={-3} width="full" display="flex" justifyContent="center" alignItems="center">
            <CircularProgress />
          </Grid>
        ) : (
            <>
              <Grid item xs={12} marginTop={-3}>
                <FormTextInput
                  inputRef={refComment}
                  value={form.comment}
                  onChange={(e) => handleChangeInput(e, "comment")}
                  maxLength={512}
                  useMultiline
                />
              </Grid>
              <Grid item xs={12} marginTop={-2} textAlign="right">
                <ButtonCommon
                  label="Add Comment"
                  disabled={form.comment.trim().length === 0}
                  handleClick={handleSubmitDialog}
                  sx={{
                    backgroundColor: "#0D5CAB",
                    height: 48,
                    color: "white",
                    borderRadius: 1,
                    fontSize: 16,
                    fontFamily: "Montserrat",
                    textTransform: "inherit",
                    marginLeft: 2,
                    "&:hover": {
                      backgroundColor: "#125fa1",
                    },
                    "&:active": {
                      backgroundColor: "#0D5CAB",
                    },
                  }}
                />
              </Grid>
            </>
          )
      }
      <Grid item container marginTop={2} width="full">
        <Box
          sx={{
            height:
              comments.length >= 5
                ? "400px"
                : comments.length > 0 || isLoading
                  ? "auto"
                  : 0,
            overflowY: "auto",
            width: "100%",
            display: isLoading ? "flex" : "block",
            justifyContent: isLoading ? "center" : "inherit",
            alignItems: isLoading ? "center" : "inherit",
          }}
        >
          {isLoading ? (
            <CircularProgress />
          ) : (
              <>
                {comments.map((item, i) => (
                  <CommentBox
                    key={i}
                    date={item.created_date}
                    comment={item.comment}
                    user={item.created_by}
                  />
                ))}
              </>
            )}
        </Box>
      </Grid>
    </>
  );
}
