import singleSpaReact from "single-spa-react";
import React from "react";
import ReactDOM from "react-dom";
import AppRouter from "../router/AppRouter";
import App from '../App';

const lifecycles = singleSpaReact({
    React,
    ReactDOM,
    rootComponent: App,
    errorBoundary(err, info, props) {
        if(err) {
            return <h1>Oase Main Application Under Maintenance</h1>
        }
        return null;
    }
});

export const { bootstrap, mount, unmount } = lifecycles;