import { Response } from "express";
import { IGetAllRequest, TDbResponse } from "../../types/dataAdmin/dataAdmin.types";
import * as db from "../../repositories/dataAdmin/ticketAction.repository";
import { jsonSuccess } from "../../utils/jsonMessage.util";

const message = {
    "english": `Successfully Retrieved Ticket Action`,
    "indonesia": `Berhasil Mengambil Ticket Action`,
}

export async function getTicketAction(req: IGetAllRequest, res: Response) {
    const dbRes: TDbResponse = await db.getTicketAction();

    const [data] = dbRes;

    const payload = {
        ...data
    }

    res.send(jsonSuccess(message, data));
}