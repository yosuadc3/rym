import { get as getAxios } from "../utilities/AxiosInstance";

const axios = getAxios();
const BASE_URL = process.env.REACT_APP_API_OASE_MONITORING;
const API_VERSION = process.env.REACT_APP_API_VERSION_OASE_MONITORING;
const USE_GET_MSG = {
	ERROR: "Tidak dapat mengirim data!",
};

const useGet = async (url, container) => {
	const endpoint = `${BASE_URL}/${container}/${API_VERSION}/${url}`;

	try {
		const response = await axios.get(endpoint);
		if (response.status === 200) {
			return response.data;
		}
	} catch (err) {
		console.log(USE_GET_MSG.ERROR);
		throw err;
	}
};

export default useGet;
