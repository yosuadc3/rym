import React, { useState } from "react";
import TextField from '@mui/material/TextField';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { Button, Grid, Typography } from "@mui/material";


const styles = {
    text: {
        fontSize: "1vw",
        fontWeight: "bold"
    },
    button: {
        fontSize: "1vw",
        fontWeight: "bold"
    }
}

function TimeRange() {
    const [from, setFrom] = useState(new Date());
    const [to, setTo] = useState(new Date());

    return (
        <Grid container alignItems="center" justifyContent="end">
            <Grid item xs={1}>
                <Typography sx={styles.text}>From</Typography>
            </Grid>
            <Grid item xs={2.2}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DateTimePicker
                        renderInput={(props) => <TextField {...props} />}
                        value={from}
                        onChange={(newValue) => {
                            setFrom(newValue);
                        }}
                        maxDateTime={new Date()}
                    />
                </LocalizationProvider>
            </Grid>
            <Grid item xs={1}>
                <Typography sx={styles.text}>To</Typography>
            </Grid>
            <Grid item xs={2.2}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DateTimePicker
                        renderInput={(props) => <TextField {...props} />}
                        value={to}
                        onChange={(newValue) => {
                            setTo(newValue);
                        }}
                        maxDateTime={new Date()}
                    />
                </LocalizationProvider>
            </Grid>
            <Grid item xs={1.5}>
                <Button color="success" variant="contained" sx={styles.button}>Apply</Button>
            </Grid>
        </Grid>
    );
}

export default TimeRange;