import * as React from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Error from "../tooltip/Error";

function a11yProps(index) {
  return {
    id: `vertical-tab-${index}`,
    "aria-controls": `vertical-tabpanel-${index}`,
  };
}

export default function StyledTabVertical({
  tabLabels,
  value,
  setValue,
  // children,
  style,
}) {
  const styles = {
    tabs: {
      ".MuiTab-textColorPrimary": {
        border: "none",
      },
      ".MuiTabs-indicator": {
        background: "none"
      },
      "& .MuiTab-root": {
        backgroundColor: "white",
        color: "black",
        marginTop: 1,
        whiteSpace: "nowrap",
        height: 40,
        paddingLeft: 3,
        paddingRight: 15,
        paddingY: 4,
        fontSize: 20,
        outline: "none",
        border: "none",
        textAlign: "left",
        "&:first-of-type": {
          borderTopRightRadius: 10,
          marginTop: 0,
        },
        ...style,
      },
      "	.MuiTab-wrapped": {
        alignItems: "flex-start",
      },
      ".MuiTab-root.Mui-selected": {
        color: "white",
        backgroundColor: "#0D5CAB",
        zIndex: 2,
        borderBottom: "5px solid #86C7FF",
        outline: "none",
        "&:first-of-type": {
          borderTopRightRadius: 10,
          marginTop: 0,
        },
      },
    },
  };

  // if (!children) {
  //   return (
  //     <Error description="Harap memasukkan children pada komponen StyledTabs!" />
  //   );
  // }

  const typeTabLabelsCheck = Array.isArray(tabLabels) && tabLabels.length;

  if (!typeTabLabelsCheck) {
    return (
      <Error description="Format untuk tabs harus dalam bentuk array dan tidak boleh kosong!" />
    );
  }

  return (
    <Box
      sx={{
        flexGrow: 1,
        display: "flex",
        height: "100%",
      }}
    >
      <Tabs
        orientation="vertical"
        value={value}
        onChange={setValue}
        aria-label="Vertical tabs example"
        sx={styles.tabs}
        centered={false}
      >
        {tabLabels.map((label, i) => (
          <Tab
            key={i}
            fullWidth
            wrapped
            sx={{
              fontWeight: "bold",
              fontSize: 20,
              textTransform: "none",
              textAlign: "left",
              ".MuiTab-wrapped": {
                alignItems: "self-start",
                justifyContent: "flex-start",
              },
            }}
            label={label}
            {...a11yProps(i)}
          />
        ))}
      </Tabs>
    </Box>
  );
}
