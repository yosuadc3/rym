import { body, param, query } from "express-validator";

const getIncidentDefault = [
    query("all").optional().isString(),
    query("ticket_id").optional().isString(),
    query("wsid").optional().isString(),
    query("status_code").optional().isString(),
    query("start_time").optional().isString(),
    query("end_time").optional().isString(),
    query("lokasi").optional().isString(),
    query("duration").optional().isNumeric(),
    query("status_code_description").optional().isString(),
    query("last_comment").optional().isString(),
    query("startDate").optional().isString(),
    query("endDate").optional().isString()
]

export const getIncidentCategory = [
    ...getIncidentDefault
];

export const getIncidentID = [
    query("category").isString(),
    query("page").isNumeric(),
    query("limit").isNumeric(),
    query("sortBy").isString(),
    query("orderBy").isString(),
    ...getIncidentDefault
];