import {
	FormControl,
	FormHelperText,
	Grid,
	MenuItem,
	Select,
} from "@mui/material";
import React from "react";
import FormLabel from "./FormLabel";

const styles = {
	select: (notEmpty, disabled) => ({
		background: disabled ? "#E0E0E0" : notEmpty ? "#E4F2FF" : "#FFFFFF",
		fontWeight: 700,
		width: "100%",
		"& .MuiSvgIcon-root": {
			color: "#156db8",
			fontSize: "2.5rem",
		},
	}),
	items: {
		fontWeight: 700,
	},
};

function FormSelect({ label, disabled, helperText, items, onChange, value }) {
	return (
		<Grid container direction={"column"} textAlign={"left"}>
			<Grid item>
				<FormLabel label={label} />
			</Grid>
			<Grid item>
				<Select
					disabled={disabled}
					onChange={onChange}
					value={value}
					sx={styles.select(value, disabled)}
				>
					{items.map((value, key) => {
						return (
							<MenuItem key={key} value={value} sx={styles.items}>
								{value}
							</MenuItem>
						);
					})}
				</Select>
				<FormHelperText>{helperText}</FormHelperText>
			</Grid>
		</Grid>
	);
}

export default FormSelect;
