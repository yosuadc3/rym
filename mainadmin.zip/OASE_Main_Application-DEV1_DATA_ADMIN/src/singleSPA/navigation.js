import singleSpaReact from "single-spa-react";
import React from "react";
import ReactDOM from "react-dom";
import NavigationBar from '../containers/navigation/NavigationBar';

const lifecycles = singleSpaReact({
    React,
    ReactDOM,
    rootComponent: NavigationBar,
    errorBoundary(err, info, props) {
        return null;
    }
});

export const { bootstrap, mount, unmount } = lifecycles;