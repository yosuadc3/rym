import React from "react";
import CustomBreadcrumbs from "../../../../../components/breadcrumb/CustomBreadcrumbs";
import StyledSearch from "../../../../../components/search/StyledSearch";
import {useCallback,useState,useEffect} from 'react';
import { Grid, Button} from "@mui/material";
import StyledTable from "../../../../../components/table/StyledTable";
import {useGetEventCodeGroupQuery, useChangePriorityEventCodeGroupMutation} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeGroup/api/eventCodeGroup'
import { customFormat } from "../../../../../utilities/TimeConverter";
import { TABLE_ADDONS_SEARCH_ITEMS , BREADCRUMBS, SEARCH_ITEMS} from "../../../../../constants/IncidentManagement/EventCodeGroup"; 
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import FormPopUp from "./FormPopUp";
import { handleInsertGroup, handleRemoveGroup, handleUpdateGroup, setData } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeGroup/eventCodeGroup";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { STYLES } from "../../../../../constants/IncidentManagement/Styles";
import TableV2 from "../../components/TableV2";
import GroupAction from "../../components/action/GroupAction";

function mapSearchItems() {
    return [
        ...TABLE_ADDONS_SEARCH_ITEMS,
        ...SEARCH_ITEMS
    ];
}

function EventCodeGroup(){
    const [offSet, setOffSet] = useState(0);
    const [total, setTotal] = useState(0);
    const [firstRender, setFirstRender] = useState(true);
    const [tableData, setTableData] = useState([]);
    const [isResetSearch, setIsResetSearch] = useState(false);
    const [searchFlag, setSearchFlag] = useState(false);
    const [advancedSearchFlag, setAdvancedSearchFlag] = useState(false);
    const [searchValue, setSearchValue] = useState(null);
    const [advancedSearchValue, setAdvancedSearchValue] = useState(null);
    const [advancedSearchPeriode, setAdvancedSearchPeriode] = useState({ startDate: null, endDate: null });
    const sortBy= "priority";
    const orderBy= "asc";
    const data_height = 100;
    const dispatch = useDispatch();
    const navigate = useNavigate();
    
    const handleCellClick = (id) =>{
        navigate('/data-configuration/event-code-group/'+id);
    }

    const [queryParams, setQueryParams] = useState({
        page: 0,
        limit: data_height,
        sortBy: sortBy,
        orderBy: orderBy,
        offset: offSet,
        search: null,
        advancedSearch: null,
        advancedSearchPeriode: null
    });
    const { data: eventCodeGroupData, isLoading: eventCodeGroupIsLoading, refetch:eventCodeGroupRefetch } = useGetEventCodeGroupQuery(queryParams,{ refetchOnMountOrArgChange: true });
    const [changePriority,{isLoading:changePriorityLoading,error:changePriorityError,isSuccess: changePrioritySuccess}] = useChangePriorityEventCodeGroupMutation();
    
    const headers = [
        {
            title: "Priority",
            field: "priority",
            align: "center",
            width: "15%",
        },
        {
            title: "Group",
            field: "group",
            align: "left",
            width: "30%",
        },
        {
            title: "Description",
            field: "description",
            align: "left",
            width: "40%",
        },
        {
            title: "Action",
            field: "-",
            align: "center",
            width: "15%",
            component: (data)=> <GroupAction data={data}/>
        },
        
    ];


   useEffect(() => {
        if (!eventCodeGroupIsLoading) {
            const { data, total} = eventCodeGroupData;
            setTableData(data);
            setTotal(total);
        }
    }, [eventCodeGroupData, eventCodeGroupIsLoading]);

    useEffect(() => {
        const commonParams = {
            page: 0,
            limit: data_height,
            sortBy: sortBy,
            orderBy: orderBy,
            offset: offSet,

        }

        if (searchFlag) {
            setQueryParams({
                ...commonParams,
                search: searchValue
            });
        }
        else if (advancedSearchFlag) {
            setQueryParams({
                ...commonParams,
                advancedSearch: advancedSearchValue,
                advancedSearchPeriode: advancedSearchPeriode
            });
        }
        else {
            setQueryParams(commonParams);
        }
    }, [offSet, sortBy, orderBy, searchValue, advancedSearchValue, advancedSearchPeriode]);

    useEffect(() => {
        if (firstRender) {
            setFirstRender(false);
        }else{
            eventCodeGroupRefetch();
        }
    }, [useSelector((state) => state.eventCodeGroup.refresh)]);

    useEffect(()=>{
        if(changePrioritySuccess){
           eventCodeGroupRefetch();
        }
    },[changePrioritySuccess]);

    const handleSearchClick = (searchInput) => {
        const { text, column } = searchInput;
        const data = {};

        if (column === "all") {
            SEARCH_ITEMS.forEach((item) => {
                data[item.value] = text;
            });
        }
        else {
            data[column] = text;
        }

        setSearchValue(data);
        setSearchFlag(true);
        setAdvancedSearchFlag(false);
    }

    const handleAdvancedSearchSubmit = (data) => {
        const { selectedDates, advancedData } = data;
        const temp = {};

        if (advancedData[0]?.category !== null) {
            advancedData.forEach((item) => {
                temp[item.category] = item.chips;
            });

            setAdvancedSearchValue(temp);
        }

        setAdvancedSearchPeriode({
            startDate: customFormat(selectedDates.startDate),
            endDate: customFormat(selectedDates.endDate)
        });
        setAdvancedSearchFlag(true);
        setSearchFlag(false);
    }

    const handleOpenInsertClick = () => {
        dispatch(handleInsertGroup());
    }


    return (
        <>
            <Grid container alignItems={"center"} height={50} marginBottom={2}>
                <Grid item xs={12}>
                    <CustomBreadcrumbs breadcrumbs={BREADCRUMBS} />
                </Grid>
            </Grid>
            <Grid container alignItems={"center"}>
                <Grid item xs={8} marginRight={"auto"}>
                    <StyledSearch
                        useAdvancedSearch
                        selectMenuItems={mapSearchItems()}
                        handleSearchClick={handleSearchClick}
                        handleAdvancedSearchSubmit={handleAdvancedSearchSubmit}
                        isResetSearch={isResetSearch}
                        setIsResetSearch={setIsResetSearch}
                    />
                </Grid>
            </Grid>
            <Grid container alignItems={"center"} marginTop={4}>
                <Grid item sx={STYLES.scroll} xs={12}>
                    <DndProvider backend={HTML5Backend}>
                        <TableV2
                            rows={tableData} 
                            setOffSet={setOffSet} 
                            setChangeIndex={changePriority} 
                            total={total}
                            DATA_HEIGHT={data_height}
                            headers={headers}
                        />
                    </DndProvider>
                </Grid>
                <Grid item marginTop={3}>
                    <Button 
                        variant="contained"
                        disableElevation 
                        sx={{backgroundColor:"#0D5CAB", fontWeight:"700", fontSize:"16px",textTransform:"capitalize", padding:"10px",paddingX:"55px", borderRadius:"6px"}}
                        onClick={handleOpenInsertClick}
                        >
                        Tambah
                    </Button>
                </Grid>
            </Grid>       
            <FormPopUp/>
        </>
    );
}

export default EventCodeGroup;
