import { Box, Divider, Grid, List, Typography } from "@mui/material";
import React from "react";

const styles = {
    box: {
        height: "100%",
        borderRadius: "8px",
        paddingTop: "3%",
        paddingBottom: "8%",
        boxShadow: "6",
        textAlign: "center"
    },
    title: {
        fontSize: "1.5vw",
        fontWeight: "bold",
        color: "#156db8"
    },
    item: {
        fontSize: "1.2vw",
        marginBottom: 1
    },
    list: {
        position: "relative",
        overflow: "auto",
        height: 250
    }
}

function CardList(props) {
    const { data } = props;
    const total = data.content.length;

    return (
        <Box sx={styles.box}>
            <Typography sx={styles.title}>{`${data.title} (${total})`}</Typography>
            <Box mx={3} my={1}>
                <Divider />
            </Box>
            <List sx={styles.list}>
                <Grid container px={2}>
                    {
                        data.content.map((value, index) => {
                            return (
                                <Grid key={index} item xs={total < 3 ? (total < 2 ? 12 : 6) : 4} >
                                    <Typography sx={styles.item}>{value}</Typography>
                                </Grid>
                            );
                        })
                    }
                </Grid>
            </List>
        </Box>
    );
}

export default CardList;