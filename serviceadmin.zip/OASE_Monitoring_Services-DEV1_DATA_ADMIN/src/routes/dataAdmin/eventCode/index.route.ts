import * as controller from "../../../controllers/dataAdmin/eventCode/index.controller";
import validation from "../../../middlewares/validator.middleware";
import errorWrapper from "../../../utils/errorWrapper.util";
import * as validationRules from "../../../validators/dataAdmin/eventCode/index.validator";
const router = require("express").Router();
const keycloak = require("../../../middlewares/keycloakHandler.middleware").get();

router.get("/", validationRules.getEventCodes, validation(validationRules.getEventCodes), errorWrapper(controller.getEventCodes));
router.post("/", validationRules.postEventCode, validation(validationRules.postEventCode), errorWrapper(controller.postEventCode));
router.get("/:id", validationRules.getEventCode, validation(validationRules.getEventCode), errorWrapper(controller.getEventCode));
router.put("/:id", validationRules.putEventCode, validation(validationRules.putEventCode), errorWrapper(controller.putEventCode));
router.delete("/:id", validationRules.deleteEventCode, validation(validationRules.deleteEventCode), errorWrapper(controller.deleteEventCode));

export default router;