import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import ButtonExport from "../../../../../components/buttons/ButtonExport";
import EmptyCard from "../../../../../components/cards/EmptyCard";
import NoDataFoundCard from "../../../../../components/cards/NoDataFound";
import StyledTable from "../../../../../components/table/StyledTable";
import { useGetReportDownloadQuery, useGetReportQuery } from "../../../../../redux/features/report/atlas/api/reportAtlas";

const tableColumnsCommonProps = {
    headerAlign: "center",
    align: "center",
    minWidth: 85
};

const tableColumns = [
    {
        ...tableColumnsCommonProps,
        field: "wsid",
        headerName: "WSID",
    },
    {
        ...tableColumnsCommonProps,
        field: "50k",
        headerName: "50K",
    },
    {
        ...tableColumnsCommonProps,
        field: "100k",
        headerName: "100K",
    },
    {
        ...tableColumnsCommonProps,
        field: "deposit",
        headerName: "Deposit",
    },
    {
        ...tableColumnsCommonProps,
        field: "receipt",
        headerName: "Receipt",
    },
    {
        ...tableColumnsCommonProps,
        field: "non_cash",
        headerName: "Non Cash",
    },
    {
        ...tableColumnsCommonProps,
        field: "dsa_led",
        headerName: "DSA LED",
    },
    {
        ...tableColumnsCommonProps,
        field: "start_problem",
        headerName: "Start Problem",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "end_problem",
        headerName: "End Problem",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "notes",
        headerName: "Notes",
        width: 250,
    },
    {
        ...tableColumnsCommonProps,
        field: "duration",
        headerName: "Duration",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "pengelola",
        headerName: "Pengelola",
        width: 250,
    },
    {
        ...tableColumnsCommonProps,
        field: "kota",
        headerName: "Kota",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "daerah",
        headerName: "Daerah",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "provinsi",
        headerName: "Provinsi",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "vendor_mesin",
        headerName: "Vendor Mesin",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "group_ip",
        headerName: "Group IP",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "tandem",
        headerName: "Tandem",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "lokasi",
        headerName: "Lokasi",
        width: 200,
    },
    {
        ...tableColumnsCommonProps,
        field: "kanwil",
        headerName: "Deskcw (Kanwil)",
        width: 200,
    },
];

function ReportTable({ getLength }) {
    const periode = useSelector((state) => state.reportAtlas.periode);
    const filter = useSelector((state) => state.reportAtlas.filter);
    const type = useSelector((state) => state.reportAtlas.type);
    const [tableData, setTableData] = useState([]);
    const [queryParams, setQueryParams] = useState({
        periode: null,
        filter: null,
        type: ""
    });
    const [skipUseQuery, setSkipUseQuery] = useState(true);
    const { data: reportData, isLoading } = useGetReportQuery(queryParams, { skip: skipUseQuery });

    useEffect(() => {
        if (!isLoading && !skipUseQuery) {
            const { data, total } = reportData;

            setTableData(data);
            getLength({
                data: data.length,
                total: total
            });
        }
    }, [reportData, isLoading, skipUseQuery]);

    useEffect(() => {
        if (filter !== null && periode.startDate !== null && periode.endDate !== null && type !== "") {
            setQueryParams({
                periode: periode,
                filter: filter,
                type: type
            });
            setSkipUseQuery(false);
        }
        else {
            setSkipUseQuery(true);
        }
    }, [periode, filter, type]);

    const exportUseQuery = (params, options) => useGetReportDownloadQuery(params, options);

    if (!isLoading && !skipUseQuery) {
        return (
            <Grid container direction={"column"}>
                <Grid item >
                    {tableData.length > 0 ? (
                        <EmptyCard >
                            <StyledTable
                                headers={tableColumns}
                                page={0}
                                rows={tableData}
                                pageSize={10}
                                loading={isLoading}
                                rowCount={10}
                                useStripesWhiteGray
                                useSort={false}
                                usePagination={false}
                                disableRowClick
                                useGray
                                hideFooter={true}
                            />
                        </EmptyCard>) : (
                        <NoDataFoundCard />
                    )}
                </Grid>
                <Grid item marginTop={3} textAlign={"right"} >
                    {tableData.length > 0 && (
                        <ButtonExport text={"Download File"} useQuery={exportUseQuery} queryParams={queryParams} fileName={type} extension={"xlsx"} timestamp={true} />
                    )}
                </Grid>
            </Grid>
        );
    }
    else {
        return (<></>);
    }
}

export default ReportTable;