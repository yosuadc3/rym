import React, { useEffect, useRef, useState } from "react";
import { Box, Button, Card, Grid, TextField, Typography } from "@mui/material";
import OASELogo from "../svgs/OASELogo";

const styles = {
    root: {
        height: "100vh",
        // px: "10vw",
        width:'100%',
        marginTop: -1,
        marginBottom: -1
    },
    cardContainer:{
        width:'70%',
    },

    textFieldTitle: {
        fontWeight: "bold"
    },
    textField: {
        borderColor: "#156db8",
        width: "100%",
        border: 'none',
    },
    errorMessageBox: (hasError, flag) => ({
        backgroundColor: flag ? "transparent" : "#FDF2E5",
        border: flag ? "1px solid red" : "1px solid #EE9033",
        borderRadius: "6px",
        padding: 1.5,
        visibility: hasError ? "visible" : "hidden",
        width: "100%"
    }),
    errorMessage: {
        fontWeight: "bold"
    },
    btnLogin: {
        textTransform:'inherit',
        width: "50%",
        backgroundColor: "#156db8",
        color: "white",
        marginTop: 3,
        "&:hover": {
            backgroundColor: "#125fa1",
        },
        "&:active": {
            backgroundColor: "#156db8",
        }
    },
    logoContainer: {
        backgroundColor: "#156db8",
        height: "100%",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
    },
    inputLoginStyle: (hasError) => ({
        '& .MuiOutlinedInput-notchedOutline': {
            border: 'none'
        },
        '& .MuiInputBase-input': {
            width: '100%',
            border: hasError ? '1px solid red' : '1px solid rgba(0, 0, 0, 0.23)',
        }
        
    })
};

function InputForm({ loginMode, infoFlag, errorMessage, handleLogin, handleChangePassword }) {
    const firstFieldTitle = loginMode ? "Username" : "New Password";
    const secondFieldTitle = loginMode ? "Password" : "Confirm Password";

    const [invalidMessage, setInvalidMessage] = useState(null);
    const [invalidMessageFlag, setInvalidMessageFlag] = useState(null);
    const [fieldValue, setFieldValue] = useState({ first: "", second: "" });
    const [fieldError, setFieldError] = useState({ first: null, second: null });
    const fieldInputRef = useRef(null);

    useEffect(() => {
        setFieldValue({ first: "", second: "" });
        setFieldError({ first: null, second: null });
    }, [loginMode]);

    useEffect(() => {
        setInvalidMessage(errorMessage);
    }, [errorMessage]);

    useEffect(() => {
        setInvalidMessageFlag(!infoFlag);
    }, [infoFlag]);

    //Form function
    const removeFocus = () => {
        fieldInputRef.current.blur();
    }

    const handleChange = (name) => (event) => {
        if (name === 'first' && event.target.value.length > 0) {
            setFieldError(prevFieldError => ({ ...prevFieldError, first: "" }));
        }
        if (name === 'second' && event.target.value.length > 0) {
            setFieldError(prevFieldError => ({ ...prevFieldError, second: "" }));
        }
        setFieldValue({ ...fieldValue, [name]: event.target.value });
    }

    const handleValidation = () => {
        let valid = true;

        setFieldError(prevFieldError => ({ ...prevFieldError, first: null, second: null }));

        if (fieldValue.first.length === 0) {
            setFieldError(prevFieldError => ({ ...prevFieldError, first: "Tidak boleh kosong" }));
            valid = false;
        }
        if (fieldValue.second.length === 0) {
            setFieldError(prevFieldError => ({ ...prevFieldError, second: "Tidak boleh kosong" }));
            valid = false;
        }

        if (!loginMode) {
            if (fieldValue.first.length < 8) {
                // setFieldError(prevFieldError => ({ ...prevFieldError, first: "Kurang dari 8 karakter" }));
                setInvalidMessage("Invalid password: minimum length 8");
                valid = false;
            }
            if (fieldValue.second.length < 8) {
                // setFieldError(prevFieldError => ({ ...prevFieldError, second: "Kurang dari 8 karakter" }));
                setInvalidMessage("Invalid password: minimum length 8");
                valid = false;
            }
            if (fieldValue.second !== fieldValue.first) {
                // setFieldError(prevFieldError => ({ ...prevFieldError, second: "Password tidak cocok" }));
                setInvalidMessage("Password don't match");
                valid = false;
            }
        }

        return valid;
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        removeFocus();
        setInvalidMessage(null);

        const valid = handleValidation();

        if (valid) {
            if (loginMode) {
                const data = {
                    username: fieldValue.first,
                    password: fieldValue.second
                }

                handleLogin(data);
            }
            else {
                handleChangePassword(fieldValue.first);
            }
        }
        else {
            setInvalidMessageFlag(true);
        }
    }

    return (
        <Box display="flex" justifyContent={"center"} alignItems={"center"} sx={styles.root}>
            <Card elevation={8} sx={styles.cardContainer}>
                <Grid container>
                    <Grid item xs={6}>
                        <Box sx={styles.logoContainer}>
                            <OASELogo white={true} props={{ height: "100%", width: "60%" }} />
                        </Box>
                    </Grid>
                    <Grid item xs={6} sx={{ px: 6, py: 4 }}>
                        <form onSubmit={handleSubmit}>
                            <Grid container direction={"column"} spacing={2} textAlign={"start"}>
                                <Grid item display="flex" height="100px" alignItems="center">
                                    <Box sx={styles.errorMessageBox(invalidMessage, invalidMessageFlag)}>
                                        <Typography sx={styles.errorMessage}>{invalidMessage}</Typography>
                                    </Box>
                                </Grid>
                                <Grid item>
                                    <Typography sx={styles.textFieldTitle}>{firstFieldTitle}</Typography>
                                </Grid>
                                <Grid item height="90px">
                                    <TextField
                                        type={loginMode ? "text" : "password"}
                                        error={fieldError.first !== null}
                                        helperText={fieldError.first}
                                        inputRef={fieldInputRef}
                                        onChange={handleChange("first")}
                                        variant="outlined"
                                        value={fieldValue.first}
                                        sx={styles.textField}
                                        InputProps={{
                                            sx:styles.inputLoginStyle(fieldError.first && !fieldValue.first)
                                        }}
                                    />
                                </Grid>
                                <Grid item>
                                    <Typography sx={styles.textFieldTitle}>{secondFieldTitle}</Typography>
                                </Grid>
                                <Grid item height="90px">
                                    <TextField
                                        type="password"
                                        error={fieldError.second !== null}
                                        helperText={fieldError.second}
                                        inputRef={fieldInputRef}
                                        onChange={handleChange("second")}
                                        variant="outlined"
                                        value={fieldValue.second}
                                        sx={styles.textField}
                                        InputProps={{
                                            sx:styles.inputLoginStyle(fieldError.second && !fieldValue.second)
                                        }}
                                    />
                                </Grid>
                                <Grid direction="row" item textAlign="right" marginBottom={5}>
                                    <Button type="submit" variant="contained" color="primary" sx={styles.btnLogin}>{loginMode ? "Login" : "Submit"}</Button>
                                </Grid>
                            </Grid>
                        </form>
                    </Grid>
                </Grid>
            </Card>
        </Box>
    );
}

export default InputForm;