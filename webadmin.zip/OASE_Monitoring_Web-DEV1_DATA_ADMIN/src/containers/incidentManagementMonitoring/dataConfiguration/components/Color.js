import React from 'react';
import { Box } from '@mui/material';

export default function Color(value="#000000"){
    return(
        <Box sx={{backgroundColor: value, width:"60px", height:"36px", border:"1px solid #110F0F", borderRadius:"4px"}}/>
    );
}