import { Box } from "@mui/material";
import React from "react";

function EmptyCard({ children, sx }) {
	return (
		<Box
			sx={{
				borderRadius: "8px",
				boxShadow: "6",
				padding: 4,
				width: "100%",
				...sx,
			}}
		>
			{children}
		</Box>
	);
}

export default EmptyCard;
