import { Response } from "express";
import * as status from "../constants/httpResponseCodes.constant";
import { jsonFailed } from "./jsonMessage.util";

export const incompleteQuery = (requiredParams: object, res: Response) => {
	const output = {
		bool: true,
		message: "",
	};

	const reqParKeys = Object.keys(requiredParams);
	const hasUndefined = reqParKeys.every((key) => key !== undefined);
	if (!hasUndefined) return output;

	const missingParams = reqParKeys.reduce((acc, curr) => {
		const key = curr as keyof typeof requiredParams;
		if (requiredParams[key] === undefined) acc.push(curr);
		return acc;
	}, [] as string[]);

	output.bool = false;
	output.message =
		"Missing required params: " + missingParams.join(", ").trim();

	res
		.status(status.HTTP_BAD_REQUEST)
		.send(jsonFailed(status.HTTP_BAD_REQUEST, "-", output.message, "XX"));
};
