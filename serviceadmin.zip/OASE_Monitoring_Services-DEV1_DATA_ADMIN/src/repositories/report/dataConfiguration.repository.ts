import { EVENT_CODE, FAULT_CATEGORY } from "../../constants/dbQuery.constant";
import { query as dbQuery } from "../../databases/oase.database";

const dataConf = [
   { id: '1', value: 'Event Code Rules', filter: 'ec.rule_id' },
   { id: '2', value: 'Event Code Source', filter: 'ec.catalog_id' },
   { id: '3', value: 'Event Code Group', filter: 'ec.group_id' },
   { id: '4', value: 'Fault Category', filter: 'ecr.fault_category_id' }
];

export function getListDataConfiguration() {
   return dataConf.map(({ filter, ...value }) => value);
}

export function getReportType() {
   return [
      { id: '1', value: 'Report Data Configuration' },
      { id: '2', value: 'Report Log Perubahan' }
   ];
}

export function getReportCategory(type: number) {
   const queryObj = [
      `select json_arrayagg(json_object('id', id, 'value', concat(priority, ' - ', rule))) as list from ${EVENT_CODE.VIEW_RULE}`,
      `select json_arrayagg(json_object('id', id, 'value', source)) as list from ${EVENT_CODE.VIEW_SOURCE}`,
      `select json_arrayagg(json_object('id', id, 'value', \`group\`)) as list from ${EVENT_CODE.VIEW_TABLE_GROUP}`,
      `select json_arrayagg(json_object('id', id, 'value', category)) as list from ${FAULT_CATEGORY.VIEW}`]

   return dbQuery(queryObj[type - 1]);
};

export function getReportData(categories: [{ type: number, filters: [string] }]) {
   let query =
      `
      FROM event_code ec
         LEFT JOIN event_code_group ecg ON ec.group_id = ecg._id
         LEFT JOIN event_code_rule ecr ON ec.rule_id = ecr._id
         LEFT JOIN event_code_catalog ecs ON ec.catalog_id = ecs._id
         LEFT JOIN fault_category fc ON ecr.fault_category_id = fc._id
      WHERE ec.is_delete = 0 `;

   if (categories.length > 0) query += ' AND ';

   categories.forEach((catValue, catIdx) => {
      query += '(';
      catValue.filters.forEach((value, idx) => {
         if ((idx + 1) === catValue.filters.length) query += dataConf[(catValue.type - 1)].filter + ' = ' + `'${value}'`;
         else query += dataConf[(catValue.type - 1)].filter + ' = ' + `'${value}'` + ' OR ';
      });
      query += ') ';
      if ((catIdx + 1) !== categories.length) query += ' AND '
   });

   const queryTotal = `SELECT 
                        count(ec._id) AS total ` + query;
   const queryData = `SELECT 
                        ec._id AS id,
                        ec.event_code AS event_code,
                        ec.description AS description,
                        ecg.group AS 'group',
                        concat(ecr.priority, ' - ', ecr.rule) AS rule,
                        ecs.source AS catalog,
                        ec.message AS message,
                        fc.category AS fault_category ` + query + 'LIMIT 10';

   const data = dbQuery(queryData);
   const total = dbQuery(queryTotal);

   return Promise.all([data, total]);
};

export function getReportLog(startPeriod: string, endPeriod: string, types: [number]) {
   // console.log('startPeriod: ', startPeriod);
   // console.log('endPeriod: ', endPeriod);
   // console.log('types: ', types);

   //dummy
   return Promise.all([[
      {
         id: '1',
         time: '06/06/2021',
         last_updated_by: 'rode',
         activity: 'Edit',
         before: '-',
         after: '-',
         reason: 'gabut'
      },
      {
         id: '2',
         time: '07/06/2021',
         last_updated_by: 'cun',
         activity: 'Create',
         before: '-',
         after: '-',
         reason: 'pengen'
      }], [
      {
         total: 2
      }]]);
};