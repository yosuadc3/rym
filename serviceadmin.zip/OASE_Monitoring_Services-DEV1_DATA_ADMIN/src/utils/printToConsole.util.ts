const getTimestamp = require("./dateTime.util").forLogging;
import log from "../utils/simplifiedLog.util";

export default function (
	tag: string | null | undefined = "common",
	error: string | unknown,
	timestamp = true
) {
	if (timestamp) {
		log(`[${tag} | ${getTimestamp()}]`, error);
	} else {
		log(`[${tag}]`, error);
	}
}
export { };

