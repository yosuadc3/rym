import * as React from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import Error from "../tooltip/Error";

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

export default function StyledTab({ tabLabels, value, setValue, children, style }) {
  const styles = {
    tabs: {
      "& .MuiTabs-indicator": {
        backgroundColor: "white",
        height: 40,
      },
      "& .MuiTab-root": {
        backgroundColor: "#0D5CAB",
        color: "white",
        height: 40,
        borderTopLeftRadius: 5,
        borderTopRightRadius: 5,
        borderTop: "10px solid #0D5CAB",
        ...style
      },
      ".MuiTab-root.Mui-selected": {
        color: "#0D5CAB",
        backgroundColor: "white",
        zIndex: 2,
      },
    },
  };

  if (!children) {
    return (
      <Error description="Harap memasukkan children pada komponen StyledTabs!" />
    );
  }

  const typeTabLabelsCheck = Array.isArray(tabLabels) && tabLabels.length;

  if (!typeTabLabelsCheck) {
    return (
      <Error description="Format untuk tabs harus dalam bentuk array dan tidak boleh kosong!" />
    );
  }

  return (
    <Box sx={{ width: "100%" }}>
      <Tabs
        sx={styles.tabs}
        value={value}
        onChange={setValue}
        aria-label="basic tabs example"
      >
        {tabLabels.map((label, i) => (
          <Tab
            key={i}
            sx={{
              paddingX: 8,
              paddingBottom: 2,
              fontWeight: "bold",
              fontSize: 20,
              textTransform: "none",
            }}
            label={label}
            {...a11yProps(i)}
          />
        ))}
      </Tabs>
      {children}
    </Box>
  );
}
