import { body, param, query } from "express-validator";

export const getEventCodeSources = [
   query("page").isNumeric(),
   query("limit").isNumeric(),
   query("sortBy").isString(),
   query("orderBy").isAlpha(),
   query("search").optional().isJSON(),
   query("advancedSearch").optional().isJSON(),
   query("advancedSearchPeriode").optional().isJSON()
];

export const getEventCodeSource = [
   param("id").isUUID()
];

export const postEventCodeSource = [
   body("source").isString(),
   body("description").isString(),
];

export const putEventCodeSource = [
   param("id").isUUID(),
   body("source").isString(),
   body("description").isString(),
];

export const deleteEventCodeSource = [
   param("id").isUUID(),
];