//DSA Router
import * as dsa from "../../controllers/dsa/dsa.controller";
import { protect } from "../../middlewares/keycloakHandler.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
let router = require("express").Router();

router.get("/", protect(["GET_DSA"]), errorWrapper(dsa.getDSA));
router.get(
	"/report",
	protect(["GET_DSA_REPORT"]),
	errorWrapper(dsa.getDSAReport)
);

export default router;
export { };

