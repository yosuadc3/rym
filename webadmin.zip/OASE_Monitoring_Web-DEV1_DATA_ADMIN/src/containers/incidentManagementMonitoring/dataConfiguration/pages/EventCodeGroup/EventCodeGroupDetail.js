import { Typography,Grid } from "@mui/material"; 
import CustomBreadcrumbs from "../../../../../components/breadcrumb/CustomBreadcrumbs";
import {useParams} from "react-router-dom"
import {useGetEventCodeGroupByIdQuery} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeGroup/api/eventCodeGroup'
import { useState, useEffect } from "react";
import React from "react";

export default function EventCodeGroupDetail(){
    const {id} = useParams()
    const { data: GroupData, isLoading: GroupIsLoading} = useGetEventCodeGroupByIdQuery(id);
    const [data, setData] = useState({});

    const BREADCRUMBS = [
        {
            item: "Home",
            link: "/",
            current: false
        },
        {
            item: "Incident Management & Monitoring",
            link: null,
            current: false
        },
        {
            item: "Data Configuration",
            link: null,
            current: false
        },
        {
            item: "Event Code Group",
            link: null,
            current: false
        },
        {
            item: data.group,
            link: null,
            current: true
        },
    ];
    
    useEffect(() => {
        if (!GroupIsLoading) {
            const { data} = GroupData;
            setData(data);
        }
    }, [GroupData, GroupIsLoading]);

    return(
        <>
            <Grid container alignItems={"center"} height={50} marginBottom={2}>
                <Grid item xs={12}>
                    <CustomBreadcrumbs breadcrumbs={BREADCRUMBS} />
                </Grid>
            </Grid>
            <Typography variant="h3">ID: {data.id}</Typography>
            <Typography variant="h3">Group: {data.group}</Typography>
            <Typography variant="h3">Description: {data.description}</Typography>
        </>
        
    );
}