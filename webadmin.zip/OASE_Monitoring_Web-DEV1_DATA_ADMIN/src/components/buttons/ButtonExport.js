import { Button } from "@mui/material";
import * as FileSaver from 'file-saver';
import moment from 'moment';
import React, { useEffect, useState } from "react";
import * as XLSX from 'xlsx';

function exportToCSV(json, bookType, fileName, fileType, fileExtension, timestamp) {
	const ws = XLSX.utils.json_to_sheet(json);
	const wb = { Sheets: { 'data': ws }, SheetNames: ['data'] };
	const excelBuffer = XLSX.write(wb, { bookType: bookType, type: 'array' });
	const data = new Blob([excelBuffer], { type: fileType });

	const datetime = timestamp === true ? `_${moment().format("DDMMYYYY_HH-mm-ss")}` : "";

	FileSaver.saveAs(data, fileName + datetime + fileExtension);
}

function ButtonExport({ text = "Export", useQuery, queryParams, timestamp, fileName, extension = "csv", sx, disabled = false, ...props }) {
	//Flag for buttonclick
	const [flag, setFlag] = useState(false);

	//Props for exporting to csv
	const { data, isLoading } = useQuery(queryParams, { skip: !flag });
	const fileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
	const fileExtension = `.${extension}`;
	const name = fileName.replace(/\s/g, '');

	const handleClick = () => {
		// refetch();
		setFlag(true);
	}

	useEffect(() => {
		if (flag && !isLoading) {
			if (Array.isArray(data)) {
				exportToCSV(data, extension, name, fileType, fileExtension, timestamp);
				setFlag(false);
			}
		}
	}, [data, isLoading]);

	return (
		<Button
			disabled={disabled}
			onClick={handleClick}
			variant="contained"
			size="small"
			sx={{
				fontSize: "0.8vw",
				fontWeight: "bold",
				px: 4,
				py: 1.2,
				textTransform: "none",
				"&.MuiButton-contained": {
					backgroundColor: disabled ? "#F0EBEB" : "#156db8"
				},
				...sx
			}}
			{...props}
		>
			{text}
		</Button>
	);
}

export default ButtonExport;