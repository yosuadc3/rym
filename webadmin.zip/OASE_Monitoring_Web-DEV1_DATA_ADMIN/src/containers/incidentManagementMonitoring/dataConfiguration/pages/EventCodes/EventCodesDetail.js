import { Typography,Grid } from "@mui/material";
import CustomBreadcrumbs from "../../../../../components/breadcrumb/CustomBreadcrumbs";
import React from "react";
import {useParams} from "react-router-dom"
import { useGetEventCodesByIdQuery } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodes/api/eventCodes";
import { useState, useEffect } from "react";

export default function EventCodeRulesDetail(){
    const {id} = useParams()
    const { data: codeData, isLoading: codeIsLoading} = useGetEventCodesByIdQuery(id);
    const [data, setData] = useState({});

    const BREADCRUMBS = [
        {
            item: "Home",
            link: "/",
            current: false
        },
        {
            item: "Incident Management & Monitoring",
            link: null,
            current: false
        },
        {
            item: "Data Configuration",
            link: null,
            current: false
        },
        {
            item: "Event Code",
            link: null,
            current: false
        },
        {
            item: data.event_code,
            link: null,
            current: true
        },
    ];

    useEffect(() => {
        if (!codeIsLoading) {
            const { data} = codeData;
            setData(data);
        }
    }, [codeData, codeIsLoading]);

    return(
        <>
         <Grid container alignItems={"center"} height={50} marginBottom={2}>
                <Grid item xs={12}>
                    <CustomBreadcrumbs breadcrumbs={BREADCRUMBS} />
                </Grid>
            </Grid>
            <Typography variant="h4">ID: {data.id}</Typography>
            <Typography variant="h4">Event Code: {data.event_code}</Typography>
            <Typography variant="h4">Description: {data.description}</Typography>
            <Typography variant="h4">Group: {data.group}</Typography>
            <Typography variant="h4">Rule: {data.rule}</Typography>
            {/* <Typography variant="h4">Source: {data.source}</Typography> */}
        </>
        
    );
}