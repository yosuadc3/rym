import { Button } from "@mui/material";
import React from "react";

const VARIANTS_TYPES = {
	SUCCESS: "success",
	DANGER: "danger",
	WARNING: "warning",
	PRIMARY: "primary",
};

const VARIANTS = {
	PRIMARY: "#0d5cab",
	SUCCESS: "#16a34a",
	DANGER: "#b91c1c",
	WARNING: "#eab308",
};

const buttonStyles = (variant) => {
	let variantColor = "";

	switch (variant) {
		case VARIANTS_TYPES.SUCCESS:
			variantColor = VARIANTS.SUCCESS;
			break;
		case VARIANTS_TYPES.DANGER:
			variantColor = VARIANTS.DANGER;
			break;
		case VARIANTS_TYPES.WARNING:
			variantColor = VARIANTS.WARNING;
			break;
		case VARIANTS_TYPES.PRIMARY:
			variantColor = VARIANTS.PRIMARY;
			break;
		default:
			variantColor = VARIANTS.PRIMARY;
			break;
	}

	return {
		fontWeight: "bold",
		fontSize: 16,
		width: "100%",
		height: 40,
		paddingX: 2,
		textTransform: "none",
		borderRadius: 2,
		backgroundColor: variantColor,
		color: "white",
		transition: "transform 1s ease-in-out",
		"&:hover": {
			backgroundColor: variantColor,
		},
		"&:active": {
			backgroundColor: variantColor,
		},
	};
};

export default function BaseFormButton({
	variant,
	label,
	icon,
	handleOnClick,
}) {
	return (
		<Button sx={buttonStyles(variant)} startIcon={icon} onClick={handleOnClick}>
			{label}
		</Button>
	);
}
