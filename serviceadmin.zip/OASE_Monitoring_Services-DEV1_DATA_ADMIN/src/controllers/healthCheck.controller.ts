import { Request, Response } from "express";

export const getStatusApplication = async (req: Request, res: Response) => {
	res.send("Success to health check OASE Monitoring API Services");
};

export { };

