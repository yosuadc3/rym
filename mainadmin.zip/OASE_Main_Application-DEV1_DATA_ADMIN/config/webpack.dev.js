const { merge } = require("webpack-merge");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const Dotenv = require("dotenv-webpack");
const path = require("path");
const commonConfig = require("./webpack.common");

const PORT = 3002;
const REMOTE_OASE_MONITORING = "http://localhost:3001";
const REMOTE_OASE_ASSET = "http://localhost:3003";

const devConfig = {
	mode: "development",

	output: {
		publicPath: `auto`,
	},

	devtool: "source-map",

	devServer: {
		port: PORT,
		headers: {
			"Access-Control-Allow-Origin": "*",
		},
		historyApiFallback: true,
	},

	plugins: [
		new ModuleFederationPlugin({
			remotes: {
				OASE_MONITORING: `oase_monitoring@${REMOTE_OASE_MONITORING}/remoteEntry.js`,
				OASE_ASSET: `oase_asset@${REMOTE_OASE_ASSET}/remoteEntry.js`,
			},
		}),
		new Dotenv({
			path: path.resolve(".env.dev"),
		}),
	],
};

module.exports = merge(commonConfig, devConfig);
