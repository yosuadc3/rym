import * as controller from "../../controllers/dataAdmin/faultCategory.controller";
import validation from "../../middlewares/validator.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
import * as validationRules from "../../validators/dataAdmin/faultCategrory.validator";
const router = require("express").Router();

router.get("/", validationRules.getFaultCategories, validation(validationRules.getFaultCategories), errorWrapper(controller.getFaultCategories));
router.post("/", validationRules.postFaultCategory, validation(validationRules.postFaultCategory), errorWrapper(controller.postFaultCategory));
router.get("/list", errorWrapper(controller.getFaultCategoryList));
router.get("/:id", validationRules.getFaultCategory, validation(validationRules.getFaultCategory), errorWrapper(controller.getFaultCategory));
router.put("/change-orders", validationRules.changeOrdersFaultCategory, validation(validationRules.changeOrdersFaultCategory), errorWrapper(controller.changeOrdersFaultCategory));
router.put("/:id", validationRules.putFaultCategory, validation(validationRules.putFaultCategory), errorWrapper(controller.putFaultCategory));
router.delete("/:id", validationRules.deleteFaultCategory, validation(validationRules.deleteFaultCategory), errorWrapper(controller.deleteFaultCategory));


export default router;