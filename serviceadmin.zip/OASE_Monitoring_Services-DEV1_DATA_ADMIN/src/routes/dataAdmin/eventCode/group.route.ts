import * as controller from "../../../controllers/dataAdmin/eventCode/group.controller";
import validation from "../../../middlewares/validator.middleware";
import errorWrapper from "../../../utils/errorWrapper.util";
import * as validationRules from "../../../validators/dataAdmin/eventCode/group.validator";
const router = require("express").Router();
const keycloak = require("../../../middlewares/keycloakHandler.middleware").get();

router.get("/", validationRules.getEventCodeGroups, validation(validationRules.getEventCodeGroups), errorWrapper(controller.getEventCodeGroups));
router.post("/", validationRules.postEventCodeGroup, validation(validationRules.postEventCodeGroup), errorWrapper(controller.postEventCodeGroup));
// router.post("/inject", validationRules.postEventCodeGroup, validation(validationRules.postEventCodeGroup), errorWrapper(controller.injectEventCodeGroup));
router.get("/list", errorWrapper(controller.getEventCodeGroupList));
router.get("/:id", validationRules.getEventCodeGroup, validation(validationRules.getEventCodeGroup), errorWrapper(controller.getEventCodeGroup));
router.put("/change-orders", validationRules.changeOrdersEventCodeRule, validation(validationRules.changeOrdersEventCodeRule), errorWrapper(controller.changeOrdersEventCodeGroup));
router.put("/:id", validationRules.putEventCodeGroup, validation(validationRules.putEventCodeGroup), errorWrapper(controller.putEventCodeGroup));
router.delete("/:id", validationRules.deleteEventCodeGroup, validation(validationRules.deleteEventCodeGroup), errorWrapper(controller.deleteEventCodeGroup));
//router.post("/", validation(validationRules.postEventCodeGroup), controller.testInterupt);

export default router;