import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   insertOpen: false,
   updateOpen: false,
   removeOpen: false,
   refresh : false,
   data : {id:"",group:"",description:""}
}

const eventCodeGroupSlice = createSlice({
   name: "eventCodeGroup",
   initialState: initialState,
   reducers: {
      handleInsertGroup: (state) => {
         state.insertOpen = !state.insertOpen;
      },
      handleUpdateGroup: (state) => {
        state.updateOpen = !state.updateOpen;
     },
     handleRemoveGroup: (state) => {
        state.removeOpen = !state.removeOpen;
     },
     handleRefresh: (state) => {
        state.refresh = !state.refresh;
     },
     setData: (state,action)=>{
        const { payload } = action;
        state.data =  payload;
     }
     
   }
});

export const { handleInsertGroup,handleRefresh, handleRemoveGroup, handleUpdateGroup,setData } = eventCodeGroupSlice.actions;

export default eventCodeGroupSlice;
