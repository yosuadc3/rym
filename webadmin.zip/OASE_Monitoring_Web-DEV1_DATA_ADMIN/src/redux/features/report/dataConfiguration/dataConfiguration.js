import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   reportType: "",
   logPerubahanQuery: {
      period: {
         start: null,
         end: null,
      },
      types: []
   }
}

const reportDataConfigurationSlice = createSlice({
   name: "reportDataConfigurationSlice",
   initialState: initialState,
   reducers: {
      setReportType: (state, action) => {
         state.reportType = action.payload;
      },
      setLogPerubahanQueryStartPeriod: (state, action) => {
         state.logPerubahanQuery.period.start = action.payload;
      },
      setLogPerubahanQueryEndPeriod: (state, action) => {
         state.logPerubahanQuery.period.end = action.payload;
      },
      setLogPerubahanQueryTypes: (state, action) => {
         state.logPerubahanQuery.types = action.payload;
      }
   }
});

export const {
   setReportType,
   setLogPerubahanQueryEndPeriod,
   setLogPerubahanQueryStartPeriod,
   setLogPerubahanQueryTypes
} = reportDataConfigurationSlice.actions;

export default reportDataConfigurationSlice;
