import React from "react";
import FormDialogV2 from "../../../../../components/form/FormDialogV2";
import FormInput from "../../components/FormInput";
import {useState,useEffect} from 'react';
import { Grid, Button, DialogContent, DialogActions,Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { handleInsertSource, handleRefresh, handleRemoveSource, handleUpdateSource, setData } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/eventCodeSource";
import {useDeleteEventCodeSourceMutation,usePostEventCodeSourceMutation,usePutEventCodeSourceMutation} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/api/eventCodeSource'
import ConfirmDialog from "../../components/ConfirmDialog";
import { STYLES } from "../../../../../constants/IncidentManagement/Styles";
import TextInput from "../../../../../components/input/TextInput";


export default function FormPopUp(){
    const [inputSource, setInputSource ] = useState("");
    const [inputDesc, setInputDesc ] = useState("");
    const [isChange, setIsChange] = useState(false);
    const [openInsert2, setOpenInsert2 ] = useState(false);
    const [openUpdate2, setOpenUpdate2 ] = useState(false);
    const [insertIntoApi,{isLoading:insertLoading,isSuccess: insertSuccess}] = usePostEventCodeSourceMutation();
    const [updateApi,{isLoading:updateLoading,isSuccess: updateSuccess}] = usePutEventCodeSourceMutation();
    const [deleteApi, {isSuccess:deleteSuccess}] = useDeleteEventCodeSourceMutation();

    const data = useSelector((state) => state.eventCodeSource.data);
    const dispatch = useDispatch();
    const insert = () =>{
        if(inputSource !=""){
            const insertData = {
                source: inputSource,
                description: inputDesc,
            }
            insertIntoApi(insertData);
        }
    }

    const update = () =>{
        if(data.id!= ""  && inputSource != ""){
            const data_update = {
                source: inputSource,
                description: inputDesc,
            }
            updateApi({ id: data.id, data: data_update });
        }
    }

    const remove = () =>{
        if(data.id != ""){
            deleteApi(data.id);
            dispatch(handleRefresh());
        }
    }

    const handleCloseInsertClick = () => {
        setIsChange(false);
        dispatch(handleInsertSource());
    }
    const handleOpenInsert2Click = () => {
        dispatch(handleInsertSource());
        setOpenInsert2(true);
    }
    const handleCloseInsert2Click = () => {
        setIsChange(false);
        setOpenInsert2(false);
    }

    const handleCloseUpdateClick = () => {
        setIsChange(false);
        dispatch(handleUpdateSource());
    }

    const handleOpenUpdate2Click = () => {
        dispatch(handleUpdateSource());
        setOpenUpdate2(true);
    }

    const handleCloseUpdate2Click = () => {
        setIsChange(false);
        setOpenUpdate2(false);
    }
    
    const handleCloseRemoveClick = () => {
        dispatch(handleRemoveSource());
    }

    useEffect(() => {  
        if(insertSuccess){
            dispatch(handleRefresh());
            handleCloseInsert2Click();
         }  
    }, [insertSuccess]);

    useEffect(() => {  
        if(updateSuccess){
            dispatch(handleRefresh());
            handleCloseUpdate2Click();
         }  
    }, [updateSuccess]);

    useEffect(() => {  
        if(deleteSuccess){
            dispatch(handleRemoveSource());
            dispatch(handleRefresh());
         }  
    }, [deleteSuccess]);

    useEffect(() => {
        if(!isChange){
            setInputSource(data.source);
            setInputDesc(data.description);
        }
    }, [data,useSelector((state) =>  state.eventCodeSource.updateOpen)]);

    useEffect(()=>{
        if(!isChange){
            setInputSource("");
            setInputDesc("");
        }
    },[useSelector((state) => state.eventCodeSource.insertOpen)]);

    return(
        <>
        <FormDialogV2
                isOpen={useSelector((state) => state.eventCodeSource.insertOpen)}
                handleToggle={handleCloseInsertClick}
                title = {"Tambah Event Code Catalog"}
                sx={STYLES.dialogForm}
            >
                <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={3}>
                            <FormInput
                            changed={inputSource !=""}
                            label={"Source"}
                            autoFocus
                            onChange={(e) => {setInputSource(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item>
                            <FormInput
                            changed={inputDesc!=""}
                            label={"Description"}
                            useMultiline
                            onChange={(e) => {setInputDesc(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions>
                <Grid container justifyContent={"center"} marginBottom={4} marginTop={2} gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseInsertClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenInsert2Click} 
                            disabled = {inputSource == ""}
                            >
                            Simpan
                        </Button>
                    </Grid>
                </DialogActions>

            </FormDialogV2>    

            <FormDialogV2
                isOpen={useSelector((state) => state.eventCodeSource.updateOpen)}
                handleToggle={handleCloseUpdateClick}
                title = {"Detail Event Code Catalog"}
                sx={STYLES.dialogForm}
            >
                <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={3}>
                            <FormInput
                            changed={inputSource !=""}
                            label={"Source"}
                            autoFocus
                            value={data.source}
                            onChange={(e) => {setInputSource(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item >
                            <FormInput
                            changed={inputDesc != "" && inputDesc!=""}
                            label={"Description"}
                            value={data.description}
                            useMultiline
                            onChange={(e) => {setInputDesc(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={4} marginTop={2} gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseUpdateClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenUpdate2Click} 
                            disabled = {inputSource == ""|| !isChange}
                            >
                            Simpan
                        </Button>
                    </Grid>
                </DialogActions>

            </FormDialogV2>   

            <ConfirmDialog
                isOpen={useSelector((state)=> state.eventCodeSource.removeOpen)}
                handleClose={handleCloseRemoveClick}
                title={`Yakin akan menghapus Event Code Catalog “${data.source}” ?`}
                handleSave={remove}
                paddingX= "30px"
            />
             <ConfirmDialog
                isOpen={openUpdate2}
                handleClose = {handleCloseUpdate2Click}
                title = {"Yakin akan menyimpan perubahan Event Code Catalog?"}
                handleSave = {update}
            />
            
             <ConfirmDialog
                isOpen={openInsert2}
                handleClose={handleCloseInsert2Click}
                title={`Yakin akan menambah Event Code Catalog “${inputSource}” ?`}
                handleSave={insert}
                paddingX= "20px"
                paddingTop = "30px"
            />
            
         </>
    );
}