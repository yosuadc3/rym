import axios from "axios";
import jwt_decode from "jwt-decode";
import { getVPNUrl } from "../utilities/Vpn";

const LOCAL_STORAGE_TOKEN = "token";
const LOCAL_STORAGE_REFRESH_TOKEN = "refreshToken";

function tokenExist() {
    if (getToken()) {
        return true;
    }

    return false;
}

function refreshTokenExist() {
    return getRefreshToken() !== null;
}

function getToken() {
    return localStorage.getItem(LOCAL_STORAGE_TOKEN);
}

function setToken(token) {
    localStorage.setItem(LOCAL_STORAGE_TOKEN, token);
}

function getRefreshToken() {
    return localStorage.getItem(LOCAL_STORAGE_REFRESH_TOKEN);
}

function setRefreshToken(refreshToken) {
    localStorage.setItem(LOCAL_STORAGE_REFRESH_TOKEN, refreshToken);
}

function getDecodedToken() {
    return tokenExist() ? jwt_decode(getToken()) : {};
}

function getDecodedRefreshToken() {
    return tokenExist() ? jwt_decode(getRefreshToken()) : {};
}

function renewToken() {
    const API_URL = process.env.REACT_APP_API_OASE_TOOL;

    return new Promise((resolve, reject) => {
        axios.post(`${API_URL}/usersession/refresh-token`, { refresh_token: getRefreshToken() }, { baseURL: getVPNUrl() })
            .then((res) => {
                if (res.data.data?.access_token && res.data.data?.refresh_token) {
                    setToken(res.data.data.access_token);
                    setRefreshToken(res.data.data.refresh_token);

                    resolve(res.data);
                }
                else {
                    reject(res.data);
                }
            })
            .catch((error) => {
                reject(error);
            });
    });
}

export {
    getDecodedRefreshToken, getDecodedToken, getRefreshToken, getToken, refreshTokenExist, renewToken, setRefreshToken, setToken, tokenExist
};

