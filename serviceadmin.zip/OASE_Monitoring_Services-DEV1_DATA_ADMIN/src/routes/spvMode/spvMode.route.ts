//SPV Router
import * as spvMode from "../../controllers/spvMode/spvMode.controller";
import { protect } from "../../middlewares/keycloakHandler.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
let router = require("express").Router();

router.get("/", protect(["GET_SPV_MODE"]), errorWrapper(spvMode.getSPVMode));
router.get(
	"/flm",
	protect(["GET_SPV_MODE"]),
	errorWrapper(spvMode.getSPVModeByFLM)
);
router.get(
	"/detail",
	protect(["GET_SPV_MODE_DETAIL"]),
	errorWrapper(spvMode.getDetailSPVMode)
);
router.get(
	"/report",
	protect(["GET_SPV_MODE_REPORT"]),
	errorWrapper(spvMode.getSPVModeReport)
);

export default router;
export { };

