import { Grid } from "@mui/material";
import React from "react";

const styles = {
  hr: {
    border: "1px solid #F1F1F7",
    width: "100%",
    marginTop: "1.5rem",
    marginBottom: "1.5rem",
  },
};

export default function StyledDivider() {
  return (
    <Grid width="100%">
      <Grid item container xs={12} width="100%">
        <hr style={styles.hr} />
      </Grid>
    </Grid>
  );
}
