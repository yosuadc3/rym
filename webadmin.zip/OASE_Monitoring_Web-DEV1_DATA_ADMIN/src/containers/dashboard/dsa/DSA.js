import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import CustomBreadcrumbs from "../../../components/breadcrumb/CustomBreadcrumbs";
import ButtonExport from "../../../components/buttons/ButtonExport";
import { DSA_INTERVAL } from "../../../constants/UpdateInterval";
import { useGetDsaQuery, useGetDsaReportQuery } from "../../../redux/features/dashboard/dsa/api/dsa";
import { hasRoles } from "../../../token/roles";
import CardList from "../components/cards/CardList";

const breadcrumbs = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "DSA",
        link: null,
        current: true
    },
];

function DSA() {
    const [cardData, setCardData] = useState([]);
    const { data: dsaData, isLoading } = useGetDsaQuery(null, { pollingInterval: DSA_INTERVAL, refetchOnReconnect: true });

    useEffect(() => {
        if (!isLoading) {
            setCardData(dsaData);
        }
    }, [dsaData, isLoading]);

    const exportUseQuery = (_, options) => useGetDsaReportQuery(null, options)

    return (
        <>
            <Grid container alignItems={"center"} height={60}>
                <Grid item xs>
                    <CustomBreadcrumbs breadcrumbs={breadcrumbs} />
                </Grid>
                <Grid item xs textAlign={"end"}>
                    {
                        hasRoles(["GET_DSA_REPORT"]) && <ButtonExport useQuery={exportUseQuery} timestamp={true} fileName={"DSALedOff"} />
                    }
                </Grid>
            </Grid>
            <Grid container spacing={2}>
                {
                    cardData.map((value, index) => {
                        //dummyDSA(5, 3).map((value, index) => {
                        const data = {
                            title: value?.PENGELOLA || "-",
                            content: value?.WSID || []
                        }

                        return (
                            <Grid item key={index} xs={2.4}>
                                <CardList data={data} />
                            </Grid>
                        );
                    })
                }
            </Grid>
        </>
    );
}

export default DSA;