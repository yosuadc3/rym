import React from "react";
import { Box, Typography } from "@mui/material";
import { ResponsivePie } from "@nivo/pie";

function calcPercentage(total, value) {
    const result = value / total || 0;

    return `${Math.round((result * 100) * 10) / 10}%`;
}

function customTooltips(data) {
    const style = {
        box: {
            backgroundColor: "white",
            padding: 2,
            borderRadius: "6px",
            boxShadow: "6",
        },
        text: {
            fontSize: 16
        }
    }

    return (
        <Box sx={style.box}>
            <Typography sx={style.text}>{data.label}</Typography>
            <Typography sx={{ ...style.text, fontWeight: "bold", color: "#0D5CAB" }}>{data.value} WSID</Typography>
        </Box>
    )
}

function PieChart({ data, total, legendsProps, ...props }) {
    return (
        <ResponsivePie
            data={data}
            margin={{ top: 40, bottom: 50, left: 0, right: 0 }}
            activeOuterRadiusOffset={8}
            colors={{ scheme: 'nivo' }}
            borderWidth={1}
            borderColor={{
                from: 'color',
                modifiers: [
                    [
                        'darker',
                        0.2
                    ]
                ]
            }}
            arcLinkLabel={(e) => calcPercentage(total, e.value)}
            arcLinkLabelsTextColor="#333333"
            arcLinkLabelsDiagonalLength={16}
            arcLinkLabelsStraightLength={24}
            arcLinkLabelsThickness={2}
            arcLinkLabelsColor={{ from: 'color' }}
            arcLinkLabelsSkipAngle={5}
            arcLabel={false}
            tooltip={(e) => customTooltips(e.datum)}
            legends={[
                {
                    anchor: 'bottom-right',
                    direction: 'column',
                    justify: false,
                    translateX: 0,
                    translateY: 0,
                    itemsSpacing: 5,
                    itemWidth: 20,
                    itemHeight: 20,
                    itemTextColor: '#999',
                    itemDirection: 'left-to-right',
                    itemOpacity: 1,
                    symbolSize: 14,
                    symbolShape: 'circle',
                    effects: [
                        {
                            on: 'hover',
                            style: {
                                itemTextColor: '#000'
                            }
                        }
                    ],
                    ...legendsProps
                }
            ]}
            theme={{
                fontSize: 14
            }}
            {...props}
        />
    );
}

export default PieChart;