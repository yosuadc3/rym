import { createSlice } from '@reduxjs/toolkit';

const initialState = {
   ticketId: "",
   _ticketId: "",
   ticketIdComment: "",
   wsid: "",
   start_time: "",
   end_time: "",
   action_code: "",
   status_code: "",
   duration: "",
   action_code_description: "",
   status_code_description: "",
   wsidStaus: "",
   advancedSearchQuery: "",
   isOpenDialog: false,
   dialogIncidentID: "",
   toggleFetchComments: false,
   isOpenDialogViewComments: false,
   isResetSearch: false,
   toggleRefresh: false,
   lastUpdate: '-'
};

const incidentManagementSlice = createSlice({
   name: 'incidentManagement',
   initialState,
   reducers: {
      setWsid: (state, action) => {
         state.wsid = action.payload.data.wsid;
      },
      setTicketId: (state, action) => {
         state.ticketId = action.payload.data.ticketId;
         state.lastUpdate = action.payload.data.lastUpdate || "-";
      },
      setTicketId_: (state, action) => {
         state._ticketId = action.payload._ticketId;
      },
      setToggleRefresh: (state, action) => {
         state.toggleRefresh = action.payload.toggleRefresh;
      },
      setTicketIdComment: (state, action) => {
         state.ticketIdComment = action.payload.data.ticketIdComment;
      },
      setStatusCode: (state, action) => {
         state.status_code = action.payload.data.status_code;
      },
      setDuration: (state, action) => {
         state.duration = action.payload.data.duration;
      },
      setStartTime: (state, action) => {
         state.start_time = action.payload.data.start_time;
      },
      setStatusCodeDescription: (state, action) => {
         state.status_code_description = action.payload.data.status_code_description;
      },
      setAll: (state, action) => {
         const data = action.payload.data;
         state.ticketId = data.ticketId;
         state.wsid = data.wsid;
         state.duration = data.duration;
         state.status_code_description = data.status_code_description;
         state.status_code = data.status_code;
         state.start_time = data.start_time;
         state.lastUpdate = data.lastUpdate || "-";
      },
      setAdvancedSearchQuery: (state, action) => {
         state.advancedSearchQuery = action.payload.data.advancedSearchQuery;
      },
      setWsidStatus: (state, action) => {
         state.wsidStatus = action.payload.data.wsidStatus;
         state.lastUpdate = action.payload.data.lastUpdate || "-";
      },
      setDialogToggle: (state, action) => {
         state.isOpenDialog = action.payload.data.isOpenDialog;
      },
      setDialogIncidentId: (state, action) => {
         state.dialogIncidentID = action.payload.data.dialogIncidentID;
      },
      setToggleFetchComments: (state, action) => {
         state.toggleFetchComments = action.payload.data.toggleFetchComments;
      },
      setIsOpenDialogViewComments: (state, action) => {
         state.isOpenDialogViewComments = action.payload.data.isOpenDialogViewComments;
      },
      setIsResetSearch: (state, action) => {
         state.isResetSearch = action.payload.isResetSearch;
      },
      setCurrentDetailComment: (state, action) => {
         const data = action.payload.data;
         state.incident_number = data.incident_number
         state.start_time = data.start_time
         state.end_time = data.end_time
         state.action_code = data.action_code
         state.action_code_description = data.action_code_description
         state.status_code = data.status_code
         state.status_code_description = data.status_code_description
      }
   },
});

export const {
   setWsid,
   setTicketId,
   setTicketId_,
   setTicketIdComment,
   setStatusCode,
   setDuration,
   setStartTime,
   setStatusCodeDescription,
   setAll,
   setAdvancedSearchQuery,
   setWsidStatus,
   setDialogToggle,
   setDialogIncidentId,
   setToggleFetchComments,
   setIsOpenDialogViewComments,
   setCurrentDetailComment,
   setIsResetSearch,
   setToggleRefresh
} = incidentManagementSlice.actions;

export default incidentManagementSlice;
