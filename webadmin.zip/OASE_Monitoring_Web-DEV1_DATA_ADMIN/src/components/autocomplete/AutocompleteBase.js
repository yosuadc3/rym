import { Autocomplete, TextField } from "@mui/material";
import React from "react";

const styles = {
   autocomplete: (disabled) => ({
      background: disabled ? "#E0E0E0" : "#FFFFFF",
      ".MuiAutocomplete-tag": {
         backgroundColor: "#E4F2FF",
         textOverflow: "ellipsis",
         maxWidth: "75px",
         color: "#65748B",
         fontWeight: 500,
      },
   }),
};

export default function AutocompleteBase({
   onChange = (event, values) => { },
   options = [],
   value = [],
   freeSolo = false,
   multiple = true,
   disabled = false,
   ...props
}) {
   return (
      <Autocomplete
         disabled={disabled}
         multiple={multiple}
         value={value}
         options={options}
         getOptionLabel={(option) => option}
         renderInput={(params) => <TextField {...params} />}
         onChange={onChange}
         freeSolo={freeSolo}
         sx={styles.autocomplete(disabled)}
         {...props}
      />
   );
}
