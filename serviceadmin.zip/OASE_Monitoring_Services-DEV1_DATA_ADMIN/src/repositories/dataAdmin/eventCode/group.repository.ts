import { EVENT_CODE } from "../../../constants/dbQuery.constant";
import { query as dbQuery } from "../../../databases/oase.database";
import { TQueryParams, TSearchParams } from "../../../types/dataAdmin/dataAdmin.types";
import { handleAdvancedSearchParams, handleSearchParams } from "../../../utils/dbQueryHelper.util";
import { getObjectValues, getObjectValuesOfArrayObject } from "../../../utils/object/convertToArray.util";

export function getEventCodeGroups(page: number, limit: number, sortBy: string, orderBy: string, offset: number = page * limit, searchParams?: TSearchParams) {
    let searchData: TQueryParams = {
        query: "",
        params: []
    }

    if (searchParams?.search) {
        searchData = handleSearchParams(searchParams.search);
    }

    if (searchParams?.advancedSearch || searchParams?.advancedSearchPeriode) {
        searchData = handleAdvancedSearchParams(searchParams.advancedSearchPeriode!, searchParams.advancedSearch, "created_time");
    }

    const queryData = `select id, \`group\`, description, priority
        from ${EVENT_CODE.VIEW_TABLE_GROUP} ${searchData.query}
        order by \`${sortBy}\` ${orderBy} limit ${limit} offset ${offset}`;

    const queryTotal = `select count(id) as total from ${EVENT_CODE.VIEW_TABLE_GROUP} ${searchData.query} `;

    const result = dbQuery(queryData, searchData.params);
    const total = dbQuery(queryTotal, searchData.params);

    return Promise.all([result, total]);
}

export function getEventCodeGroup(id: number | undefined) {
    const baseQuery = `select id, \`group\`, description
        from ${EVENT_CODE.VIEW_TABLE_GROUP} where id = ?`;

    return dbQuery(baseQuery, [id]);
}

export function getEventCodeGroupList() {
    const baseQuery = `select json_arrayagg(json_object('id', id, 'value', \`group\`)) as list from ${EVENT_CODE.VIEW_TABLE_GROUP}`;

    return dbQuery(baseQuery);
}

export function postEventCodeGroup(data: { [k: string]: unknown }, createdBy: string | undefined) {
    const baseQuery =
        `INSERT INTO ${EVENT_CODE.TABLE_GROUP} (\`group\`, description, is_delete, created_by, priority) 
    SELECT ?, ?, 0, ?, subquery.priority 
    FROM (SELECT (IFNULL(priority, 0) + 1) AS priority FROM ${EVENT_CODE.TABLE_GROUP} WHERE is_delete != 1 ORDER BY priority DESC LIMIT 1) AS subquery`;

    return dbQuery(baseQuery, [...getObjectValues(data), createdBy]);
}

// export function injectEventCodeGroup(data: { [k: string]: unknown }, createdBy: string | undefined) {
//     const baseQuery =
//         `INSERT INTO ${EVENT_CODE.TABLE_GROUP} (\`group\`, description, is_delete, created_by, modified_by, priority)
//     SELECT ?, ?, 0, ?, ?, subquery.priority
//     FROM (SELECT (priority + 1) AS priority FROM ${EVENT_CODE.TABLE_GROUP} WHERE is_delete != 1 ORDER BY priority DESC LIMIT 1) AS subquery`;

//     return dbQuery(baseQuery, [...getObjectValues(data), createdBy, createdBy]);
// }

export function changeOrdersEventCodeGroup(body: { [key: string]: unknown }, modifiedBy: string | undefined) {

    const operator = body.start_priority! < body.end_priority! ? '-' : '+'
    const data = {
        param1: operator === '-' ? '>' : '>=',
        param2: operator === '-' ? body.start_priority : body.end_priority,
        param3: operator === '-' ? '<=' : '<',
        param4: operator === '-' ? body.end_priority : body.start_priority
    }

    const query =
        `UPDATE ${EVENT_CODE.TABLE_GROUP} t
    SET t.priority = 
    CASE 
        WHEN t.priority ${data.param1} ? AND t.priority ${data.param3} ? AND t._id <> ? THEN (t.priority ${operator} 1)
        WHEN t._id = ? THEN ?
        ELSE t.priority
    END,
    t.modified_by = ?
    WHERE t.is_delete <> 1 AND t.priority >= ? AND t.priority <= ?`;

    return dbQuery(query, [data.param2, data.param4, body.id, body.id, body.end_priority, modifiedBy, data.param2, data.param4]);
}

export function putEventCodeGroup(body: { [k: string]: unknown }, id: number | undefined, modifiedBy: string | undefined) {
    const baseQuery = `UPDATE ${EVENT_CODE.TABLE_GROUP} t SET t.group = ?, t.description = ?, t.modified_by = ? where t._id = ?`;

    return dbQuery(baseQuery, [...getObjectValues(body), modifiedBy, id]);
}


export function deleteEventCodeGroup(id: number | undefined, priority: number | undefined, modifiedBy: string | undefined) {
    const baseQuery = `
    UPDATE ${EVENT_CODE.TABLE_GROUP} t 
        SET t.is_delete = CASE
            WHEN _id = ? THEN 1
            ELSE t.is_delete
        END,
        t.priority = CASE
            WHEN t.priority > ? THEN (t.priority - 1)
            ELSE t.priority
        END,
        t.modified_by = ?
    WHERE t.is_delete <> 1`;

    return dbQuery(baseQuery, [id, priority, modifiedBy]);
}

export { };

