import env from "../env/server.env";
export const DB_MONITORING = env.DB_SCHEMA_OASEMON;

export const VISION4_QUERY_ERRORS = {
   ETIMEOUT: {
      message: "Query exceeds execution time",
      code: "DATABASE_VISION4_QUERY_TIMEOUT",
   },
   EARGS: {
      message: "Invalid number of arguments",
      code: "DATABASE_VISION4_INVALID_ARGUMENTS",
   },
   ELOGIN: {
      message: "Error while logging into the database",
      code: "DATABASE_VISION4_LOGIN_ERROR",
   },
   EREQUEST: {
      message: "Error while processing the query",
      code: "DATABASE_VISION4_QUERY_ERROR",
   },
   ENOCONN: {
      message: "No connection established",
      code: "DATABASE_VISION4_NO_CONNECTION",
   },
};

export const OASE_QUERY_ERRORS = {
   ETIMEOUT: {
      message: "Query exceeds execution time",
      code: "DATABASE_OASE_QUERY_TIMEOUT",
   },
   ER_PARSE_ERROR: {
      message: "Syntax error in the query",
      code: "DATABASE_OASE_SYNTAX_ERROR",
   },
   ER_ACCESS_DENIED_ERROR: {
      message: "Access denied. Insufficient privileges",
      code: "DATABASE_OASE_ACCESS_DENIED",
   },
   ER_DUP_ENTRY: {
      message: "Duplicate entry violation",
      code: "DATABASE_OASE_DUPLICATE_ENTRY",
   },
   ER_NO_REFERENCED_ROW: {
      message: "Referenced row does not exist",
      code: "DATABASE_OASE_REFERENCED_ROW_NOT_FOUND",
   },
   ER_LOCK_WAIT_TIMEOUT: {
      message: "Lock wait timeout exceeded",
      code: "DATABASE_OASE_LOCK_WAIT_TIMEOUT",
   },
   ER_DATA_TOO_LONG: {
      message: "Data too long for column",
      code: "DATABASE_OASE_DATA_TOO_LONG",
   },
   ER_NO_SUCH_TABLE: {
      message: "Table does not exist",
      code: "DATABASE_OASE_NO_SUCH_TABLE",
   },
   ER_TABLE_EXISTS_ERROR: {
      message: "Table already exists",
      code: "DATABASE_OASE_TABLE_EXISTS_ERROR",
   },
   ER_UNKNOWN_COLUMN: {
      message: "Unknown column in query",
      code: "DATABASE_OASE_UNKNOWN_COLUMN",
   },
   ER_LOCK_DEADLOCK: {
      message: "Deadlock detected",
      code: "DATABASE_OASE_LOCK_DEADLOCK",
   },
   ER_SP_UNDECLARED_VAR: {
      message: "Undeclared variable detected (NaN / undefined)",
      code: "DATABASE_OASE_UNDECLARED_VAR",
   },
   ER_BAD_FIELD_ERROR: {
      message: "Unknown column",
      code: "DATABASE_OASE_BAD_VAR",
   }
};
