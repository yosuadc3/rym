export const isNull = (T) => {
  return T ? T : "-";
};
