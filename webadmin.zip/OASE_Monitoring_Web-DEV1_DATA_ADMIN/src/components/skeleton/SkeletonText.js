import Skeleton from "@mui/material/Skeleton";
import React from "react";

export default function SkeletonText({width = 200, height = 35}) {
  return <Skeleton animation="wave" width={width} height={height} />;
}
