import moment from "moment";

export const dayInMonthComparator = (v1, v2) => moment(v1) - moment(v2);
