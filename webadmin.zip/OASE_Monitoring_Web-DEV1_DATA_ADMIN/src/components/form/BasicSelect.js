import { FormControl, MenuItem, Select } from "@mui/material";
import React from "react";

const styles = {
  menuItem: {
    "&.Mui-selected": {
      display: "none",
    },
  },
  select: (disabled, notEmpty) => ({
    background: disabled ? "#E0E0E0" : notEmpty ? "#E4F2FF" : "#FFFFFF",
    width: "100%",
    "& .MuiSvgIcon-root": {
      color: "#156db8",
      fontSize: "2.5rem",
    },
    "& .MuiOutlinedInput-input": {
      fontWeight: "bold"
    },
  }),
  selectMenu: {
    PaperProps: {
      style: {
        maxHeight: 300,
      },
    },
  },
};

export default function BasicSelect({
  items,
  onChange,
  value = "",
  disabled = false,
  useSmallSize = false,
}) {
  return (
    <FormControl fullWidth>
      <Select
        sx={styles.select(disabled, value)}
        disabled={disabled}
        size={useSmallSize ? "small" : "medium"}
        onChange={onChange}
        value={value}
        MenuProps={styles.selectMenu}
      >
        {items.map((item, index) => {
          return (
            <MenuItem key={index} value={item.id} sx={styles.menuItem}>
              {item.label}
            </MenuItem>
          );
        })}
      </Select>
    </FormControl>
  );
}
