function handleDateClause(
  startColumn: string,
  startDate: string,
  endDate: string
) {
  let dateClause = "";
  if (!startDate && endDate) {
    dateClause = `and ${startColumn} <= date('${endDate}')`;
  } else if (startDate && !endDate) {
    dateClause = `and ${startColumn} >= date('${startDate}')`;
  } else if (startDate && endDate) {
    dateClause = `and (${startColumn} between date('${startDate}') and date('${endDate}'))`;
  }
  return dateClause;
}

module.exports = handleDateClause;
