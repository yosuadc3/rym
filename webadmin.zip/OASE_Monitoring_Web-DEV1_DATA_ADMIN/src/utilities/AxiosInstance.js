import axios from "axios";
import { getDecodedRefreshToken, getToken, renewToken } from "../token/action";
import { getVPNUrl } from "./Vpn";

const axiosInstance = axios.create({
    baseURL: getVPNUrl()
});

export function get() {
    return axiosInstance;
}

export function initInterceptors(setOpenDialog, setOpenProgress, setErrorMessage) {
    axiosInstance.interceptors.request.use(
        function (config) {
            const token = getToken();
            config.headers.authorization = `Bearer ${token}`;

            // setOpenProgress(true);

            return config;
        },
        function (error) {
            return Promise.reject(error);
        }
    );

    axiosInstance.interceptors.response.use(
        function (response) {
            // setOpenProgress(false);

            return response;
        },
        function (error) {
            setOpenProgress(false);
            const errorMessage = error.response?.data?.error_message;
            const responseStatusCode = error.response?.status;
            const unixTimeNow = Math.floor(Date.now() / 1000)
            const { exp: refreshTokenExpireTime } = getDecodedRefreshToken();

            if (error && error.message === 'Network Error' && error.response === undefined) {
                setErrorMessage("Mohon maaf, koneksi Anda terputus. Silahkan coba beberapa saat lagi.");
                //setOpenDialog(true);
            }

            if (responseStatusCode === 401 || responseStatusCode === 403) {
                if (refreshTokenExpireTime < unixTimeNow) {
                    localStorage.clear();
                    window.location.reload();
                }

                return renewToken()
                    .then(res => {
                        const token = res.data.access_token;

                        const config = error.config;
                        config.headers.authorization = `Bearer ${token}`;

                        return new Promise((resolve, reject) => {
                            axios.request(config)
                                .then(res => resolve(res))
                                .catch(error => reject(error));
                        });
                    })
                    .catch(() => {
                        localStorage.clear();
                        window.location.reload();
                    });
            }

            if (errorMessage) {
                if (errorMessage?.message) {
                    setErrorMessage(errorMessage.message);
                }

                if (errorMessage?.indonesia) {
                    setErrorMessage(errorMessage.indonesia);
                }
            }
            else {
                setErrorMessage("Server Error!");
            }

            // if (responseStatusCode === 500 && !error.response.config.url.match("api/usersession/refresh-token")) {
            //     setOpenDialog(true);
            // }
            if (!error.response.config.url.match("api/usersession/refresh-token")) {
                //setOpenDialog(true);
            }

            return Promise.reject(error);
        }
    );
}