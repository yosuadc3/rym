import { axiosGet } from "../../utilities/Fetch";

const PATH = "report/atlas";

export function getReport(periode, filter, type) {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_REPORT_ATLAS",
            }
            const params = {
                type: type,
                periode: periode,
                filter: filter
            }
            const res = await axiosGet(`${PATH}/`, params);

            dispatch({
                ...dispatchAction,
                payload: res?.data
            })
        }
        catch (error) {
            throw error;
        }
    }
}

export function getReportDownload(periode, filter, type) {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_REPORT_ATLAS_DOWNLOAD",
                loading: {
                    download: true
                }
            }
            const params = {
                type: type,
                periode: periode,
                filter: filter
            }

            dispatch(dispatchAction);

            const res = await axiosGet(`${PATH}/download`, params);

            dispatch({
                ...dispatchAction,
                payload: res?.data,
                loading: {
                    download: false
                }
            })
        }
        catch (error) {
            throw error;
        }
    }
}

export function getReportFilter(type) {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_REPORT_ATLAS_FILTER"
            }
            const params = {
                type: type
            }
            const res = await axiosGet(`${PATH}/filter`, params);

            dispatch({
                ...dispatchAction,
                payload: res?.data
            })
        }
        catch (error) {
            throw error;
        }
    }
}

export function getReportType() {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_REPORT_ATLAS_TYPE"
            }
            const res = await axiosGet(`${PATH}/type`);

            dispatch({
                ...dispatchAction,
                payload: res?.data
            })
        }
        catch (error) {
            throw error;
        }
    }
}