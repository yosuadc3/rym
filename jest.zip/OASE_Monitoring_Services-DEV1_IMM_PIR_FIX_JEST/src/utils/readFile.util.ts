const fs = require("fs");
const path = require("path");

const filePath = path.resolve(__dirname, "..", "..", "DATA_terpadu.txt");

function getContent() {
  fs.readFile(filePath, "utf-8", (err: any, data: any) => {
    if (err) {
      console.log(err);
      return;
    }
    console.log(data);
  });
}

module.exports = {
  getContent,
};
