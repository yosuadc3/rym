import React from "react";
import { Typography } from "@mui/material";
import EmptyCard from "./EmptyCard";

function NoDataFoundCard({ cardSx: card_sx, text_sx }) {
    return (
        <EmptyCard sx={{ ...card_sx }}>
            <Typography
                sx={{
                    fontSize: 14,
                    fontWeight: 600,
                    color: "#333333",
                    height: "50vh",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    ...text_sx
                }}
            >
                Data tidak ditemukan
            </Typography>
        </EmptyCard>
    )
}

export default NoDataFoundCard;