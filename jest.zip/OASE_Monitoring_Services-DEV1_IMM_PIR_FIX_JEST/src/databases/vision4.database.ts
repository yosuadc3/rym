import * as databaseConfig from "../configs/database.config";
import printToConsole from "../utils/printToConsole.util";
import log from "../utils/simplifiedLog.util";
const sql = require("mssql");

const environment = `[${process.env.NODE_ENV?.toUpperCase()}]`;

let pool: any;

export const initSQLServer = async () => {
	process.stdout.write(`${environment}: Connecting to VISION4...`)
	try {
		pool = await sql.connect(databaseConfig.vision4);
		process.stdout.write(`\r${environment}: Connected to VISION4    \n`);
	} catch (error) {
		process.stdout.write(`\r${environment}: Failed to connect to VISION4\n`);
		log("\n");
		printToConsole("createPool", error);
	}
};

export const execMssql = async (query: string) => {
	try {
		// let pool = await sql.connect(databaseConfig.vision4);
		let res = await pool.request().query(query);
		return res.recordset;
	} catch (err) {
		console.log("Error : " + err);
	}
};

export { };

