import { getDecodedToken } from "./action";

function getFullname() {
    const fullname = getDecodedToken()?.name || "";

    return fullname;
}

export { getFullname };