import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import SPVModeIcon from "../../../assets/image/spv_mode.png";
import CustomBreadcrumbs from "../../../components/breadcrumb/CustomBreadcrumbs";
import { SPV_MODE_INTERVAL } from "../../../constants/UpdateInterval";
import { useGetSpvModeQuery } from "../../../redux/features/dashboard/spvMode/api/spvMode";
import CardCarousel from "../components/cards/CardCarousel";
import Cards from "../components/cards/Cards";

const breadcrumbs = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "SPV Mode",
        link: null,
        current: true
    },
];

function SPV() {
    const [smallCardData, setSmallCardData] = useState([]);
    const [total, setTotal] = useState(0);
    const [lastUpdate, setLastUpdate] = useState("");
    const { data: spvModeData, isLoading } = useGetSpvModeQuery(null, { pollingInterval: SPV_MODE_INTERVAL, refetchOnReconnect: true });

    useEffect(() => {
        if (!isLoading) {
            const { data, total, lastUpdate } = spvModeData;

            setSmallCardData(data);
            setTotal(total);
            setLastUpdate(lastUpdate);
        }
    }, [spvModeData, isLoading]);

    return (
        <>
            <Grid container alignItems={"center"} height={60}>
                <Grid item xs>
                    <CustomBreadcrumbs breadcrumbs={breadcrumbs} />
                </Grid>
            </Grid>
            <Grid container>
                <Grid item paddingTop={2} paddingRight={1.5} xs={5}>
                    <Cards type="big" title={"SPV Mode"} icon={SPVModeIcon} text={total} subText={lastUpdate} detail={"detail"} />
                </Grid>
                <Grid item paddingTop={2} paddingLeft={0.5} xs={7}>
                    <CardCarousel data={smallCardData} />
                </Grid>
            </Grid>
        </>
    );
}

export default SPV;