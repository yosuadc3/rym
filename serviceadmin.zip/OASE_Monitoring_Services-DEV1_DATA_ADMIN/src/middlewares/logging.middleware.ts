import chalk from "chalk";
import { Response } from "express";
import { IncomingMessage, ServerResponse } from "http";
import moment from "moment";
import morgan from "morgan";
import env from "../env/server.env";
import { IMorganLoggingRequest, IRequestAPI, StringOrUndefined } from "../types/global.type";
const uaParser = require("ua-parser-js");

const loggingExecptionURL = ["/api/health-check"];
interface IIncomingMessage extends IncomingMessage {
	startTime?: number;
}

const statusColor = (method: string, status: number): string => {
	const colorMap: { [key: number]: chalk.Chalk } = {
		100: chalk.bold.cyan,
		200: chalk.bold.green,
		300: chalk.bold.gray,
		400: chalk.bold.yellow,
		500: chalk.bold.red,
	};

	const methodStatus = `${method.padEnd(6, " ")} ${status
		.toString()
		.padEnd(3, " ")}`;

	const color = colorMap[Math.floor(status / 100) * 100] || chalk.bold.white;

	return color(methodStatus);
};

const twoDigitDecimal = (n: number) => Number(n).toFixed(2);

export const formatBytes = (bytes: number | undefined, chalkFlag = false) => {
	if (bytes === undefined || isNaN(bytes)) return "*";

	const bytesToMB = 1000000;
	const bytesToKB = bytesToMB / 1000;
	const result =
		bytes >= bytesToMB
			? `${twoDigitDecimal(bytes / bytesToMB)}MB`
			: bytes >= bytesToKB
				? `${twoDigitDecimal(bytes / bytesToKB)}KB`
				: `${bytes}B`;

	return chalkFlag ? chalk.green(result) : result;
};

export const formatMilliseconds = (num: number | undefined, chalkFlag = false): string => {

	// if response is 300 ranged, it will be NaN. 
	// by default the num is parsed to number
	if (num === undefined || isNaN(num)) return "*";

	const hrsInMs = 3600000;
	const minInMs = hrsInMs / 60;
	const secInMs = minInMs / 60;

	if (!chalkFlag) {
		if (num >= hrsInMs) {
			return `${twoDigitDecimal(num / hrsInMs)}hr`;
		} else if (num >= minInMs) {
			return `${twoDigitDecimal(num / minInMs)}min`;
		} else if (num >= secInMs) {
			return `${twoDigitDecimal(num / secInMs)}s`;
		}
		return `${(num)}ms`;
	}

	if (num >= hrsInMs) {
		return chalk.red`${twoDigitDecimal(num / hrsInMs)}hr`;
	} else if (num >= minInMs) {
		return chalk.red`${twoDigitDecimal(num / minInMs)}min`;
	} else if (num >= secInMs) {
		return chalk.red`${twoDigitDecimal(num / secInMs)}s`;
	}

	return chalk.green`${(num)}ms`;
}


export const printLogging = () => {
	morgan.token("error", (req: IMorganLoggingRequest) => {
		return req.error;
	});
	morgan.token("username", (req: IMorganLoggingRequest, _res: Response) => {
		return req.name;
	});
	morgan.token("body", (req: IMorganLoggingRequest) => {
		return JSON.stringify(req.body || req.rawBody);
	});
	return morgan(
		(
			tokens: morgan.TokenIndexer,
			req: IncomingMessage,
			res: ServerResponse
		) => {
			const logReq: IIncomingMessage = req;

			// Request Type
			const startTime = moment(logReq.startTime).format("YYYY/MM/DD HH:mm:ss");
			const timestamp = `[${startTime}]`;
			const method = tokens.method(logReq, res)!;
			const status = Number(tokens.status(logReq, res));
			const methodStatus = statusColor(method, status);

			// Path
			const url = tokens.url(logReq, res);
			const logURL = chalk.blue(tokens.url(logReq, res)) || "*";

			const body = JSON.stringify(tokens.body(logReq, res));

			// User
			const userName = tokens.username(logReq, res);
			const logUser = chalk.bold.magenta(userName) ?? "*";

			// Response
			const responseTime = tokens['response-time'](logReq, res);
			const responseSize = tokens.res(logReq, res, 'content-length')! ?? 0;
			const logTime = formatMilliseconds(Number(Number(responseTime).toFixed(0)), true) || "*";
			const logTimeNoChalk = formatMilliseconds(Number(Number(responseTime).toFixed(0))) || "*";
			const logSize = formatBytes(parseInt(responseSize), true) || "*";
			const logSizeNoChalk = formatBytes(parseInt(responseSize)) || "*";
			const responseMetric = `|${logTime} ~ ${logSize}|`

			// User Hardware
			const userAgent = uaParser(logReq.headers['user-agent']);
			const os = userAgent.os.name || '*';
			const browser = userAgent.browser.name;
			const browserVersion = userAgent.browser.version;
			const logBrowser = `${browser} ${browserVersion}` || '*';

			// User Address
			const remoteAddress = tokens["remote-addr"](logReq, res);

			const error = tokens.error(logReq, res);

			if (loggingExecptionURL.includes(tokens.url(logReq, res)!)) return null;

			if (env.NODE_ENV === "development") {
				const outputLog = [
					timestamp,
					methodStatus,
					logURL,
					responseMetric,
					logUser,
					os,
					logBrowser,
					remoteAddress,
					error
				];

				return outputLog.join(" ");
			}

			const outputLog = {
				timestamp: startTime,
				method,
				status,
				url,
				duration: logTimeNoChalk,
				size: logSizeNoChalk,
				user: userName,
				os,
				browser,
				browser_version: browserVersion,
				ip: remoteAddress,
				site: env.SERVER_SITE,
				type: "INTERNAL",
				body,
				header: JSON.stringify({})    	// untuk skrg belum kepake
			}

			return JSON.stringify(outputLog);
		}
	);
};

export { };

