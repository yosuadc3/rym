import { Response } from "express";
import { IGetAllRequest, TDbResponse } from "../../types/dataAdmin/dataAdmin.types";
import * as db from "../../repositories/dataAdmin/emailAction.repository";
import { jsonSuccess } from "../../utils/jsonMessage.util";

const message = {
    "english": `Successfully Retrieved Email Action`,
    "indonesia": `Berhasil Mengambil Email Action`,
}

export async function getEmailAction(req: IGetAllRequest, res: Response) {
    const dbRes: TDbResponse = await db.getEmailAction();

    const [data] = dbRes;

    const payload = {
        ...data
    }

    res.send(jsonSuccess(message, payload));
}