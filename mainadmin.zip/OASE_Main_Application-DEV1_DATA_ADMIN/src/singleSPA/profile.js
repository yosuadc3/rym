import singleSpaReact from "single-spa-react";
import React from "react";
import ReactDOM from "react-dom";
import Profile from "../containers/profile/Profile";

const lifecycles = singleSpaReact({
    React,
    ReactDOM,
    rootComponent: Profile,
    errorBoundary(err, info, props) {
        return null;
    }
});

export const { bootstrap, mount, unmount } = lifecycles;