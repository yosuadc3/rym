import { IRequestAPI, StringOrUndefined } from "../global.type";

interface IType {
	type: StringOrUndefined;
}

interface IPeriode {
	periode: string;
}

interface IFilter {
	filter: StringOrUndefined;
}

interface IGetReportQuery extends IType, IPeriode, IFilter { }
export interface IGetReportRequest extends IRequestAPI {
	query: IGetReportQuery;
}

interface IGetReportDownloadQuery extends IType, IPeriode, IFilter { }
export interface IGetReportDownloadRequest extends IRequestAPI {
	query: IGetReportDownloadQuery;
}

interface IGetReportFilterQuery extends IType { }
export interface IGetReportFilterRequest extends IRequestAPI {
	query: IGetReportFilterQuery;
}

export interface IGetReportTypeRequest extends IRequestAPI { }
