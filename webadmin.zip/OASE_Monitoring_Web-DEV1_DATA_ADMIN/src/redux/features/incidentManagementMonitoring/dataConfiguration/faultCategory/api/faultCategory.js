import { createApi } from "@reduxjs/toolkit/query/react";
import axiosBaseQuery from "../../../../../utils/axiosBaseQuery";
import { BASE_URL_API_MONITORING } from "../../../../../../constants/Api";

const path = "/data-admin/fault-category/";

export const faultCategoryApi = createApi({
    reducerPath: "faultCategoryApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getFaultCateogry: builder.query({
            query: (params = { page: 0, limit: 10, sortBy: "", orderBy: "", search: {}, advancedSearch: {}, advancedSearchPeriode: {} }) => ({
                url: `${path}`, method: "get", params: params
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total: data.total,
                }
            }
        }),
        getFaultCategoryById: builder.query({
            query: (id) => ({
                url: `${path}${id}/`, method: "get"
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data,
                }
            }
          }),
        getFaultCategoryList: builder.query({
            query: () => ({
                url: `${path}list/`, method: "get"
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data,
                }
            }
        }),
        postFaultCategory: builder.mutation({
            query: (data) => ({
                url: `${path}`,
                method: "POST",
                data: data
            })
        }),
        putFaultCategory: builder.mutation({
            query: ({id,data}) => ({
                url: `${path}${id}`,
                method: "PUT",
                data: data
            })
        }),
        deleteFaultCategory: builder.mutation({
            query: ({id,data}) => ({
              url: `${path}${id}`,
              method: 'DELETE',
              data: data,
              credentials: 'include',
            }),
        }),
        changePriorityFaultCategory: builder.mutation({
            query: (data) => ({
                url: `${path}change-orders/`,
                method: "PUT",
                data: data
            })
        }),
    })
});

export const {
    useGetFaultCateogryQuery,
    useGetFaultCategoryByIdQuery,
    useGetFaultCategoryListQuery,
    usePostFaultCategoryMutation,
    usePutFaultCategoryMutation,
    useDeleteFaultCategoryMutation,
    useChangePriorityFaultCategoryMutation,
} = faultCategoryApi;