import { IRequestAPI } from "../types/global.type";

function addPayloadToRequestHeader(req: IRequestAPI) {
    const name = req.kauth.grant?.access_token.content.preferred_username || null;
    req.name = name;
}

export default addPayloadToRequestHeader;