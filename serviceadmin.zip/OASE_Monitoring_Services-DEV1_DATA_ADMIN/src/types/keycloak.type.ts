import { Request } from "express";
import { IUser } from "../types/global.type";

export type TRoles = {
   id: string;
   name: string;
   composite: boolean;
   clientRole: boolean;
   containerId: string;
};

export interface ICustomKeycloakProtectRequest
   extends IUser,
   Request<any, any, any, any, any> { }
