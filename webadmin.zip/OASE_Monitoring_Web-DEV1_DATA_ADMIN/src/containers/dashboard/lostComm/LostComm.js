import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import LostCommIcon from "../../../assets/image/lost_comm.png";
import CustomBreadcrumbs from "../../../components/breadcrumb/CustomBreadcrumbs";
import ButtonExport from "../../../components/buttons/ButtonExport";
import { MAX_LOST_COMM } from "../../../constants/MaxLost";
import { LOSTCOMM_INTERVAL } from "../../../constants/UpdateInterval";
import { useGetLostcommQuery, useGetLostcommReportQuery } from "../../../redux/features/dashboard/lostcomm/api/lostcomm";
import { hasRoles } from "../../../token/roles";
import CardCarousel from "../components/cards/CardCarousel";
import Cards from "../components/cards/Cards";

const breadcrumbs = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "Lost Comm",
        link: null,
        current: true
    },
];

function LostComm() {
    const [smallCardData, setSmallCardData] = useState([]);
    const [total, setTotal] = useState(0);
    const [lastUpdate, setLastUpdate] = useState("");
    const [warning, setWarning] = useState(0);
    const { data: lostcommData, isLoading } = useGetLostcommQuery(null, { pollingInterval: LOSTCOMM_INTERVAL, refetchOnReconnect: true });

    useEffect(() => {
        if (!isLoading) {
            const { data, total, lastUpdate } = lostcommData;

            setSmallCardData(data);
            setTotal(total);
            setLastUpdate(lastUpdate);
        }
    }, [lostcommData, isLoading]);

    useEffect(() => {
        if (total > MAX_LOST_COMM[1]) {
            setWarning(2);
        }
        else if (total > MAX_LOST_COMM[0]) {
            setWarning(1);
        }
        else if (!total) {
            setWarning(null);
        }
        else {
            setWarning(0);
        }
    }, [total]);

    const exportUseQuery = (_, options) => useGetLostcommReportQuery(null, options)

    return (
        <>
            <Grid container alignItems={"center"} height={60}>
                <Grid item xs>
                    <CustomBreadcrumbs breadcrumbs={breadcrumbs} />
                </Grid>
                <Grid item xs textAlign={"end"}>
                    {
                        hasRoles(["GET_LOST_COMM_REPORT"]) && <ButtonExport useQuery={exportUseQuery} timestamp={true} fileName={"LostComm"} />
                    }
                </Grid>
            </Grid>
            <Grid container>
                <Grid item paddingTop={2} paddingRight={1.5} xs={5}>
                    <Cards type="big" title={"Lost Comm"} icon={LostCommIcon} text={total} subText={lastUpdate} warning={warning} />
                </Grid>
                <Grid item paddingTop={2} paddingLeft={0.5} xs={7}>
                    <CardCarousel data={smallCardData} />
                </Grid>
            </Grid>
        </>
    );
}

export default LostComm;