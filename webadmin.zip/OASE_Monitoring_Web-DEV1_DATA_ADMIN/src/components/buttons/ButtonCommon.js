import { Button } from "@mui/material";
import React from "react";

function ButtonCommon({ label, disabled = false, handleClick, sx, ...props }) {
  return (
    <Button
      disabled={disabled}
      onClick={handleClick}
      variant="contained"
      size="small"
      sx={{
        fontSize: "16px",
        fontWeight: "bold",
        px: 3,
        py: 1.5,
        textTransform: "none",
        "&.MuiButton-contained": {
          backgroundColor: disabled ? "#F0EBEB" : "#156db8",
        },
        ...sx,
      }}
      {...props}
    >
      {label}
    </Button>
  );
}

export default ButtonCommon;
