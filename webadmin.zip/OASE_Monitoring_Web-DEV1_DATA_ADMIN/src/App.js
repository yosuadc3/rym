// import axios from "axios";
import React, { useState } from "react";
import { Provider } from "react-redux";
import BaseDialog from "./components/dialog/BaseDialog";
import "./index.css";
import AppRouter from "./router/Router";
// import store from "./Store";
import { store } from "./redux/store";
// import { getToken } from "./token/action";
import { initInterceptors as initAxiosInterceptors } from "./utilities/AxiosInstance";
// import { getVPNUrl } from "./utilities/Vpn";

function App() {
	const [openDialog, setOpenDialog] = useState(false);
	const [openProgress, setOpenProgress] = useState(false);
	const [errorMessage, setErrorMessage] = useState("");

	initAxiosInterceptors(setOpenDialog, setOpenProgress, setErrorMessage);

	return (
		<div className="App-monitoring">
			<Provider store={store}>
				<AppRouter />
			</Provider>
			<BaseDialog
				open={openDialog}
				title={errorMessage}
				handleClose={() => setOpenDialog(false)}
				type="info"
				buttonText="OK"
			/>
			{/* <BaseDialog
				open={openProgress}
				title="Permintaan Anda sedang diproses"
				type="progress"
			/> */}
		</div>
	);
}

export default App;
