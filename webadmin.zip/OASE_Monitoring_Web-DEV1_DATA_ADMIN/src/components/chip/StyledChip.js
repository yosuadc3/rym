import { Box, Chip, OutlinedInput } from "@mui/material";
import React from "react";

/**
 * A chip component that will render a single chip
 * @param {String} val Text
 * @param {Function} handleDeleteChip Parent function that is passed and will handle deletion when a user clicks the delete button on the chip
 * @param {Integer} index Marks the position of the current element array in the array that we are on, so later we can easily map the chips and also helping to delete the chip at a certain element located in the array from the parent component
 * @returns A functional component that will create a chip
 */
const StyledChip = ({ val, handleDeleteChip, index }) => {
  return (
    <Chip
      sx={{
        color: "#65748B",
        fontWeight: 500,
        margin: ".5rem .5rem 0 0",
        backgroundColor: "#E4F2FF",
        textOverflow: "ellipsis",
        maxWidth: "250px",
      }}
      label={val}
      onDelete={() => handleDeleteChip(index, val)}
    />
  );
};

/**
 * A custom chip component
 * @param {Function} handleAddChip A parent function that will push new chips
 * @param {Function} handleDeleteChip A parent function that will handle deletion for chips
 * @param {Hook} chipRef A useRef hook by React that will point the the text value from OutlinedInput
 * @param {string[]} chips An array of strings that will be rendered as chips
 * @param {Integer} idx An integer pointing to the current element in the array from parent component
 * @returns Renders a chip component
 */
export default function StyledChips({
  handleAddChip,
  handleDeleteChip,
  chipsRef,
  chips,
  index,
}) {
  return (
    <form onSubmit={(e) => e.preventDefault()} style={{ width: "100%" }}>
      <OutlinedInput
        inputRef={chipsRef}
        fullWidth
        sx={{
          display: "flex",
          flexFlow: "row wrap",
          width: "274px",
        }}
        size="medium"
        margin="none"
        placeholder=""
        startAdornment={
          <Box sx={{ margin: "0 0.2rem 0 0" }}>
            {chips.map((data, i) => {
              return (
                <StyledChip
                  index={index}
                  val={data}
                  handleDeleteChip={handleDeleteChip}
                  key={i}
                />
              );
            })}
          </Box>
        }
        onKeyDown={(e) => {
          if (e.key === ";") {
            e.preventDefault();
            handleAddChip(e, index, chipsRef);
          }
        }}
      />
    </form>
  );
}
