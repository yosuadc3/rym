import { createApi } from "@reduxjs/toolkit/query/react";
import axiosBaseQuery from "../../../../../utils/axiosBaseQuery";
import { BASE_URL_API_MONITORING } from "../../../../../../constants/Api";

const path = "/data-admin/event-code/source/";

export const eventCodeSourceApi = createApi({
    reducerPath: "eventCodeSourceApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getEventCodeSource: builder.query({
            query: (params = { page: 0, limit: 10, sortBy: "", orderBy: "", search: {}, advancedSearchValue: {}, advancedSearchPeriode: {} }) => ({
                url: `${path}`, method: "get", params: params
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total: data.total,
                }
            }
        }),
        getEventCodeSourceById: builder.query({
            query: (id) => ({
                url: `${path}${id}/`, method: "get"
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data,
                }
            }
          }),
          getEventCodeSourceList: builder.query({
            query: () => ({
                url: `${path}/list/`, method: "get"
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data,
                }
            }
        }),
        postEventCodeSource: builder.mutation({
            query: (data) => ({
                url: `${path}`,
                method: "POST",
                data: data
            })
        }),
        putEventCodeSource: builder.mutation({
            query: ({id,data}) => ({
                url: `${path}${id}`,
                method: "PUT",
                data: data
            })
        }),
        deleteEventCodeSource: builder.mutation({
            query: (id) => ({
              url: `${path}${id}`,
              method: 'DELETE',
              credentials: 'include',
            }),
        }),
    })
});

export const {
    useGetEventCodeSourceQuery,
    useGetEventCodeSourceByIdQuery,
    useGetEventCodeSourceListQuery,
    usePostEventCodeSourceMutation,
    usePutEventCodeSourceMutation,
    useDeleteEventCodeSourceMutation
} = eventCodeSourceApi;