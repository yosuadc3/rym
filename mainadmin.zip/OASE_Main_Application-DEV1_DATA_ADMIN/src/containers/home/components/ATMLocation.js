import React from 'react';
import { Box, Typography } from '@mui/material';
import MapsContainer from './MapsContainer';

const useStyles = {
    boxRoot: {
        borderRadius: '8px',
        padding: '22px',
        height: '100%',
    },

    title: {
        fontSize: 20,
        fontWeight: 700,
        color: '#156db8',
        fontFamily: 'Montserrat',
        textAlign: 'center'
    },
    
    main: {
        textAlign: 'center',
        marginTop: 20
    },
};

const data = [
    {
        id: 1,
        name: 'Lubuk Lingga',
        color: '#4287f5',
        position: [-3.2995563, 102.8429573]

    },
    {
        id: 2,
        name: 'Bandung',
        color: '#706bd6',
        position: [-6.9032739, 107.5731172]


    },
    {
        id: 3,
        name: 'Jakarta',
        color: '#fc47ed',
        position: [-6.2293867, 106.689432]

    }, {
        id: 4,
        name: 'Surabaya',
        color: '#3d0f39',
        position: [-7.2754438, 112.6426434]

    },
    {
        id: 5,
        name: 'Lubuk Lingga',
        color: '#4287f5',
        position: [-3.2995563, 102.8429573]

    },
    {
        id: 6,
        name: 'Bandung',
        color: '#706bd6',
        position: [-6.9032739, 107.5731172]


    },
    {
        id: 7,
        name: 'Jakarta',
        color: '#fc47ed',
        position: [-6.2293867, 106.689432]

    }, {
        id: 8,
        name: 'Surabaya',
        color: '#3d0f39',
        position: [-7.2754438, 112.6426434]

    }
]

function ATMLocation() {
    return (
        <div>
            <Box sx={useStyles.boxRoot} boxShadow={6} >
                <Typography sx={useStyles.title}>Temukan Lokasi ATM di sini</Typography>
                <div style={useStyles.main}>
                    <MapsContainer data={data} />
                </div>
            </Box>
        </div>
    )
}

export default ATMLocation