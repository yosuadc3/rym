import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import { Autocomplete, Box, Checkbox, ClickAwayListener, TextField } from "@mui/material";
import React, { useState } from "react";

const styles = {
	autocomplete: {
		background: "#FFFFFF",
		".MuiAutocomplete-tag": {
			backgroundColor: "#E4F2FF",
			textOverflow: "ellipsis",
			maxWidth: "100px",
			color: "#65748B",
			fontWeight: 500,
		},
		".MuiAutocomplete-endAdornment, .MuiSvgIcon-root": {
			color: "#65748B",
		}
	},
	arrowDropDown: {
		color: "#156db8",
		fontSize: "2.5rem",
	}
};

export default function AutocompleteMultipleValues({
	onChange = (event, values) => { },
	options = [],
	value = [],
	disabled = false
}) {
	const [open, setOpen] = useState(false);

	const handleClickAway = (e) => {
		setOpen((_) => false);
	};

	const toggleOpen = () => {
		setOpen((prev) => !prev)
	}

	const getOptionLabel = (option) => option.value;
	const rendererInput = (params) => <TextField {...params} />;
	const getOptionEqualToValue = (option, anotherOption) => option.value === anotherOption.value;

	return (
		<ClickAwayListener onClickAway={handleClickAway}>
			<Box>
				<Autocomplete
					multiple
					size="small"
					disableCloseOnSelect
					open={open}
					onOpen={toggleOpen}
					onClose={toggleOpen}
					disabled={disabled}
					value={value}
					options={options}
					getOptionLabel={getOptionLabel}
					isOptionEqualToValue={getOptionEqualToValue}
					renderInput={rendererInput}
					renderOption={(props, option, { selected }) => (
						<li {...props}>
							<Checkbox
								icon={<CheckBoxOutlineBlankIcon fontSize="small" />}
								checkedIcon={<CheckBoxIcon fontSize="small" />}
								style={{ marginRight: "8px" }}
								checked={selected}
							/>
							{option.value}
						</li>
					)}
					onChange={onChange}
					sx={styles.autocomplete}
				/>

			</Box>
		</ClickAwayListener>
	);
}