import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   insertOpen: false,
   updateOpen: false,
   removeOpen: false,
   refresh : false,
   data : {id:"",source:"",description:""}
}

const eventCodeSourceSlice = createSlice({
   name: "eventCodeSource",
   initialState: initialState,
   reducers: {
      handleInsertSource: (state) => {
         state.insertOpen = !state.insertOpen;
      },
      handleUpdateSource: (state) => {
        state.updateOpen = !state.updateOpen;
     },
     handleRemoveSource: (state) => {
        state.removeOpen = !state.removeOpen;
     },
     handleRefresh: (state) => {
        state.refresh = !state.refresh;
     },
     setData: (state,action)=>{
        const { payload } = action;
        state.data =  payload;
     }
     
   }
});

export const { handleInsertSource,handleRefresh, handleRemoveSource, handleUpdateSource,setData } = eventCodeSourceSlice.actions;

export default eventCodeSourceSlice;
