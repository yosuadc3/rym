import * as healthCheck from "../controllers/healthCheck.controller";
import errorWrapper from "../utils/errorWrapper.util";
var router = require("express").Router();

router.get("/", errorWrapper(healthCheck.getStatusApplication));

export default router;
export { };

