import { createApi } from "@reduxjs/toolkit/query/react";
import { BASE_URL_API_MONITORING } from "../../../../../constants/Api";
import axiosBaseQuery from "../../../../utils/axiosBaseQuery";

const path = "/spv-mode";

export const spvModeApi = createApi({
    reducerPath: "spvModeApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getSpvMode: builder.query({
            query: () => ({ url: `${path}`, method: "get" }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total: data.total,
                    lastUpdate: data.lastUpdate
                }
            }
        }),
        getSpvModeDetail: builder.query({
            query: () => ({ url: `${path}/detail`, method: "get" }),
            transformResponse: (res) => (res.data.data)
        }),
        getSpvModeReport: builder.query({
            query: () => ({ url: `${path}/report`, method: "get" }),
            transformResponse: (res) => (res.data)
        }),
    })
});

export const { useGetSpvModeQuery, useGetSpvModeDetailQuery, useGetSpvModeReportQuery } = spvModeApi;
