import { TextField } from "@mui/material";
import { DesktopDatePicker } from "@mui/x-date-pickers";
import React from "react";
import { customFormat } from "../../utilities/TimeConverter";
import DateIcon from "../svgs/Date";

export default function DatePicker({
	label,
	startDate,
	endDate,
	placeholder,
	onChange,
	onError,
	isStartDate = false,
	isSmall = true,
	disabled = false,
	minDate,
	maxDate
}) {
	const _currDate = customFormat(new Date());
	// const _minDate = isStartDate ? minDate : startDate ? startDate : minDate;
	// const _maxDate = isStartDate ? (endDate ? endDate : _currDate) : _currDate;
	const _date = isStartDate ? startDate : endDate;

	let _minDate = "1950-01-01";
	let _maxDate = _currDate;

	if (isStartDate) {
		_minDate = minDate;

		if (endDate) _maxDate = endDate;
	}
	else {
		if (startDate) _minDate = startDate;

		if (maxDate && maxDate < _currDate) _maxDate = maxDate;
	}

	return (
		<DesktopDatePicker
			disabled={disabled}
			minDate={_minDate}
			maxDate={_maxDate}
			label={label}
			inputFormat="DD/MM/YYYY"
			value={_date}
			onError={onError}
			components={{
				OpenPickerIcon: () => (
					<DateIcon
						sx={{
							fontSize: 16,
						}}
					/>
				),
			}}
			onChange={onChange}
			renderInput={({ inputRef, inputProps, InputProps, error, disabled }) => (
				<>
					<TextField
						ref={inputRef}
						{...inputProps}
						error={error}
						disabled={disabled}
						placeholder={placeholder}
						InputProps={{
							endAdornment: {
								...InputProps?.endAdornment,
							},
						}}
						size={isSmall ? "small" : "medium"}
						sx={{
							backgroundColor: disabled ? "#C4C4C4" : _date ? "#E4F2FF" : "#FFFFFF"
						}}
					/>
				</>
			)}
		/>
	);
}
