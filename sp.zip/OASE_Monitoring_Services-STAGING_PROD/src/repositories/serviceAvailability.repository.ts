import constant from "../constants/dbQuery.constant";
import { query as dbQuery } from "../databases/oase.database";
import { TPeriode } from "../types/global.type";
import { handleAdvancedSearchParams, handleSearchParams } from "../utils/dbQueryHelper.util";

const { VIEW_SERVICE_AVAILABILITY, TABLE_TERMINAL_TERPADUS, TABLE_TERMINALS, TABLE_MASTER_DROPDOWNS, TABLE_DASHBOARD_SERVICE_AVAILABILITY, TABLE_MAPPING_DSA_SUMMARY } = constant;

type TSearch = {
	[k: string]: string;
};

type TAdvancedSearch = {
	[k: string]: string[];
};

type TSearchData = {
	query: string;
	params: string[];
};

type TFilter = {
	category: string;
	value: string;
};

export const getStatus = (
	page: number,
	limit: number,
	sortBy: string,
	orderBy: string,
	search?: TSearch | null,
	advancedSearch?: TAdvancedSearch | null,
	advancedSearchPeriode?: TPeriode
) => {
	let searchData: TSearchData = {
		query: "",
		params: [],
	};

	if (search) {
		searchData = handleSearchParams(search);
	}
	if (advancedSearch || advancedSearchPeriode) {
		searchData = handleAdvancedSearchParams(
			advancedSearchPeriode!,
			advancedSearch,
			"last_received"
		);
	}

	const queryData = `select wsid as id, wsid, 50k, 100k, deposit, receipt, non_cash, dsa_led, last_received, notes, duration, pengelola, lokasi
		from ${VIEW_SERVICE_AVAILABILITY}
        ${searchData.query}
        order by ?? ${orderBy} limit ${limit} offset ${page}`;
	const queryTotal = `select count(*) as ?? from ${VIEW_SERVICE_AVAILABILITY} ${searchData.query}`;

	const execQueryData = dbQuery(queryData, [...searchData.params, sortBy]);
	const execQueryTotal = dbQuery(queryTotal, ["total", ...searchData.params]);

	return Promise.all([execQueryData, execQueryTotal]);
};

export const getReport = (
	sortBy: string,
	orderBy: string,
	search?: TSearch | null,
	advancedSearch?: TAdvancedSearch | null,
	advancedSearchPeriode?: TPeriode
) => {
	let searchData: TSearchData = {
		query: "",
		params: [],
	};

	if (search) {
		searchData = handleSearchParams(search);
	}
	if (advancedSearch || advancedSearchPeriode) {
		searchData = handleAdvancedSearchParams(
			advancedSearchPeriode!,
			advancedSearch,
			"last_received"
		);
	}

	const queryData = `select wsid as id, wsid, 50k, 100k, deposit, receipt, non_cash, dsa_led, last_received, notes, duration, pengelola, kota, daerah, provinsi, vendor_mesin, group_ip, tandem, lokasi, kanwil
		from ${VIEW_SERVICE_AVAILABILITY}
        ${searchData.query}
        order by ?? ${orderBy}`;

	return dbQuery(queryData, [...searchData.params, sortBy]);
};

export const getDsaStats = () => {
	const baseQuery = `select count(*) as ?? from ${TABLE_DASHBOARD_SERVICE_AVAILABILITY} where dsa_led = ?`;

	const execQueryOnline = dbQuery(baseQuery, ["online", 0]);
	const execQueryOffline = dbQuery(baseQuery, ["offline", 2]);

	return Promise.all([execQueryOnline, execQueryOffline]);
};

export const getSummaryCount = (filter: TFilter | null) => {
	const searchData: TSearchData = {
		query: "",
		params: [],
	};

	if (filter) {
		searchData["query"] = "where ?? = ?";
		searchData["params"] = [`sa.${filter.category}`, filter.value];
	}

	const baseQuery = `select mds.id, mds.summary, mds.color, count(*) as count
		from ${TABLE_MAPPING_DSA_SUMMARY} mds
		join ${VIEW_SERVICE_AVAILABILITY} sa ON mds.summary = sa.summary
		${searchData.query}
		group by mds.id, mds.summary, mds.color
		order by mds.id asc`;

	return dbQuery(baseQuery, searchData.params);
};

export const getTotalTerminal = () => {
	const query = `select count(tt.wsid) as total from ${TABLE_TERMINAL_TERPADUS} tt
		join ${TABLE_TERMINALS} t on t.serial_number = tt.serial_number
		where (t.wsid, t.updated_at) in (select wsid, max(updated_at) from ${TABLE_TERMINALS} group by wsid)`;

	return dbQuery(query);
};

export const getMappingSummary = () => {
	const query = `select * from ${TABLE_MAPPING_DSA_SUMMARY}`;

	return dbQuery(query);
};

export const getSearchItems = () => {
	const query = `select field, label from ${TABLE_MASTER_DROPDOWNS} where menu = ?`;

	return dbQuery(query, ["Table DSA Status"]);
};

export { };

