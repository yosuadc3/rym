type TColumns = (string | number | undefined)[];

const toEntries = (a: TColumns, b: TColumns) => {
	return a.map((el, i) => [el, b[i]]);
};

export default (
	tableColumnsArr: TColumns,
	existingColumnsArr: TColumns,
	columnsValArr: TColumns
) => {
	const existColumns = Object.fromEntries(
		toEntries(tableColumnsArr, existingColumnsArr)
	);
	const columnsVal = Object.fromEntries(
		toEntries(tableColumnsArr, columnsValArr)
	);
	return [existColumns, columnsVal];
};

export {};
