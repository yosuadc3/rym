
import React from "react";
import {useState,useEffect} from 'react';
import { Grid, Button, DialogContent, DialogActions,Typography, Dialog } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { handleInsertGroup,handleRefresh, handleRemoveGroup, handleUpdateGroup, setData } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeGroup/eventCodeGroup";
import {usePostEventCodeGroupMutation,usePutEventCodeGroupMutation, useDeleteEventCodeGroupMutation} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeGroup/api/eventCodeGroup'
import FormDialogV2 from "../../../../../components/form/FormDialogV2";
import FormInput from "../../components/FormInput";
import ConfirmDialog from "../../components/ConfirmDialog";
import { HmacSHA256} from 'crypto-js';
import { STYLES } from "../../../../../constants/IncidentManagement/Styles";

export default function FormPopUp(){
    const [inputGroup, setInputGroup ] = useState("");
    const [inputDesc, setInputDesc ] = useState("");
    const [isChange, setIsChange] = useState(false);
    const [openInsert2, setOpenInsert2 ] = useState(false);
    const [openUpdate2, setOpenUpdate2 ] = useState(false);
    const [insertIntoApi,{isLoading:insertLoading,isSuccess: insertSuccess}] = usePostEventCodeGroupMutation();
    const [updateApi,{isLoading:updateLoading,isSuccess: updateSuccess}] = usePutEventCodeGroupMutation();
    const [deleteApi, {isSuccess:deleteSuccess}] = useDeleteEventCodeGroupMutation();

    const data = useSelector((state) => state.eventCodeGroup.data);
    const dispatch = useDispatch();
    const insert = () =>{
        if(inputGroup != ""){
            const insertData = {
                group: inputGroup,
                description: inputDesc,
            }
            // const secretKey = "SecretKeyFromFrontEnd";
            // const jsonString = JSON.stringify(insertData);
            // const hashedData = HmacSHA256(jsonString,secretKey).toString();
            //insertIntoApi({data:jsonString,hash:hashedData});
            insertIntoApi(insertData);
        }  
    }

    const update = () =>{
        if(data.id!= ""  && inputGroup != ""){
            const data_update = {
                group: inputGroup,
                description: inputDesc,
            }
            updateApi({ id: data.id, data: data_update });
        }
        
    }

    const remove = () =>{
        if(data.id != "" && data.priority !=""){
            const data_priority = {
                priority: data.priority
            }
            deleteApi({id:data.id,data:data_priority});
            dispatch(handleRefresh());
        }
    }

    const handleCloseInsertClick = () => {
        setIsChange(false);
        dispatch(handleInsertGroup());
    }

    const handleOpenInsert2Click = () => {
        dispatch(handleInsertGroup());
        setOpenInsert2(true);
    }

    const handleCloseInsert2Click = () => {
        setOpenInsert2(false);
        setIsChange(false);
    }

    const handleCloseUpdateClick = () => {
        setIsChange(false);
        dispatch(handleUpdateGroup());
    }

    const handleOpenUpdate2Click = () => {
        dispatch(handleUpdateGroup());
        setOpenUpdate2(true);
    }

    const handleCloseUpdate2Click = () => {
        setOpenUpdate2(false);
        setIsChange(false);
    }

    
    const handleCloseRemoveClick = () => {
        dispatch(handleRemoveGroup());
    }

    useEffect(() => {  
        if(insertSuccess){
            dispatch(handleRefresh());
            handleCloseInsert2Click();
         }  
    }, [insertSuccess]);

    useEffect(() => {  
        if(updateSuccess){
            dispatch(handleRefresh());
            handleCloseUpdate2Click();
         }  
    }, [updateSuccess]);

    useEffect(() => {  
        if(deleteSuccess){
            dispatch(handleRemoveGroup());
            dispatch(handleRefresh());
         }  
    }, [deleteSuccess]);

    useEffect(() => {
        if(!isChange){
            setInputGroup(data.group);
            setInputDesc(data.description);
        }
    }, [data,useSelector((state) =>  state.eventCodeGroup.updateOpen)]);

    useEffect(()=>{
        if(!isChange){
            setInputGroup("");
            setInputDesc("");
        }
    },[useSelector((state) => state.eventCodeGroup.insertOpen)]);
    

    return(
        <>
        <FormDialogV2
                isOpen={useSelector((state) => state.eventCodeGroup.insertOpen)}
                handleToggle={handleCloseInsertClick}
                title = {"Tambah Event Code Group"}
                sx={STYLES.dialogForm}
            >
                <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={3}>
                            <FormInput
                            changed={inputGroup != ""}
                            label={"Group"}
                            autoFocus
                            onChange={(e) => {setInputGroup(e.target.value);setIsChange(true)}}
                            />
                        </Grid>
                        <Grid item>
                            <FormInput
                            changed={inputDesc != ""}
                            label={"Description"}
                            useMultiline
                            onChange={(e) => {setInputDesc(e.target.value);setIsChange(true)}}
                            />
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={4} marginTop={2} gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseInsertClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenInsert2Click} 
                            disabled = {inputGroup == ""}
                            >
                            Simpan
                        </Button>
                    </Grid>
                </DialogActions>
            </FormDialogV2>    

            <FormDialogV2
                isOpen={useSelector((state) => state.eventCodeGroup.updateOpen)}
                handleToggle={handleCloseUpdateClick}
                title = {"Detail Event Code Group"}
                sx={STYLES.dialogForm}
            >
                <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={3}>
                            <FormInput
                            changed={inputGroup != ""}
                            label={"Group"}
                            autoFocus
                            value={data.group}
                            onChange={(e) => {setInputGroup(e.target.value); setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item>
                            <FormInput
                            changed={inputDesc != ""}
                            label={"Description"}
                            useMultiline
                            value={data.description}
                            onChange={(e) => {setInputDesc(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                    </Grid>
                   
                </DialogContent>
                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={4} marginTop={2} gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseUpdateClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenUpdate2Click} 
                            disabled = {inputGroup == "" || !isChange}
                            >
                            Simpan
                        </Button>
                    </Grid>
                </DialogActions>

            </FormDialogV2>   

            <ConfirmDialog
                isOpen={useSelector((state)=> state.eventCodeGroup.removeOpen)}
                handleClose={handleCloseRemoveClick}
                title={`Yakin akan menghapus Event Code Group “${data.group}” ?`}
                handleSave={remove}
                paddingX= "40px"
            />
            <ConfirmDialog
                isOpen={openUpdate2}
                handleClose = {handleCloseUpdate2Click}
                title = {"Yakin akan menyimpan perubahan Event Code Group?"}
                handleSave = {update}
            />
            
             <ConfirmDialog
                isOpen={openInsert2}
                handleClose={handleCloseInsert2Click}
                title={`Yakin akan menambah Event Code Group “${inputGroup}” ?`}
                handleSave={insert}
                paddingX= "30px"
                paddingTop = "30px"
            />

            </>
    );
}