import React from "react";
import { Grid, Typography } from "@mui/material";
import CircleIcon from '@mui/icons-material/Circle';

export default function StatusTableLegend({ items }) {
    return (
        <Grid container direction={"row"} sx={{ height: "100%", width: "100%" }}>
            {
                items.map((item, index) => {
                    return (
                        <Grid item key={index} paddingRight={(index === items.length) ? 0 : 3}>
                            <Grid container direction={"row"} >
                                <Grid item paddingRight={1}>
                                    <CircleIcon sx={{ color: item.color }} />
                                </Grid>
                                <Grid item>
                                    <Typography>{item.text}</Typography>
                                </Grid>
                            </Grid>
                        </Grid>
                    );
                })
            }
        </Grid>
    )
}