import { axiosGet } from "../utilities/Fetch";

const PATH = "service-availability";

export function getStatus(page, limit, sortBy, orderBy, searchValue, advancedSearchValue, advancedSearchPeriode) {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_SERVICE_AVAILABILITY_STATUS",
                loading: {
                    status: true
                }
            }
            const params = {
                page: page,
                limit: limit,
                sortBy: sortBy,
                orderBy: orderBy,
                search: searchValue,
                advancedSearch: advancedSearchValue,
                advancedSearchPeriode: advancedSearchPeriode
            }

            dispatch(dispatchAction);

            const res = await axiosGet(`${PATH}`, params);

            dispatch({
                ...dispatchAction,
                payload: res?.data,
                loading: {
                    status: false
                }
            });
        }
        catch (error) {
            throw error;
        }
    }
}

export function getReport(sortBy, orderBy, searchValue, advancedSearchValue, advancedSearchPeriode) {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_SERVICE_AVAILABILITY_REPORT",
                loading: {
                    report: true
                }
            }
            const params = {
                sortBy: sortBy,
                orderBy: orderBy,
                search: searchValue,
                advancedSearch: advancedSearchValue,
                advancedSearchPeriode: advancedSearchPeriode
            }

            dispatch(dispatchAction);

            const res = await axiosGet(`${PATH}/report`, params);

            dispatch({
                ...dispatchAction,
                payload: res?.data,
                loading: {
                    report: false
                }
            });
        }
        catch (error) {
            throw error;
        }
    }
}

export function getDsaStats() {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_SERVICE_AVAILABILITY_DSA",
                loading: {
                    dsaStats: true
                }
            }

            dispatch(dispatchAction);

            const res = await axiosGet(`${PATH}/dsa-stats`);

            dispatch({
                ...dispatchAction,
                payload: res?.data,
                loading: {
                    dsaStats: false
                }
            })
        }
        catch (error) {
            throw error;
        }
    }
}

export function getSummary(category, value) {
    return async (dispatch) => {
        try {
            const dispatchAction = {
                type: "GET_SERVICE_AVAILABILITY_SUMMARY",
                loading: {
                    summary: true
                }
            }
            const params = {
                category: category,
                value: value
            }

            dispatch(dispatchAction);

            const res = await axiosGet(`${PATH}/summary`, params);

            dispatch({
                ...dispatchAction,
                payload: res?.data,
                loading: {
                    summary: false
                }
            })
        }
        catch (error) {
            throw error;
        }
    }
}

export function getSearchItems() {
    return async (dispatch) => {
        try {
            const res = await axiosGet(`${PATH}/search-items`);

            dispatch({
                type: "GET_SERVICE_AVAILABILITY_SEARCH_ITEMS",
                payload: res?.data
            })
        }
        catch (error) {
            throw error;
        }
    }
}
