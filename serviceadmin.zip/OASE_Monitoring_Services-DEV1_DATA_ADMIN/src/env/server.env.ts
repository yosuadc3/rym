// @ts-check
import { z } from "zod";

const validateMiliseconds = z.number().refine((value) => {
   const stringValue = String(value);
   return stringValue.length >= 4 && Number.isInteger(value);
});

export const serverSchema = z.object({
   PORT: z.number(),
   NODE_ENV: z.enum(["development", "test", "production"]),

   // GASPER
   DB_USER: z.string(),
   DB_PASSWORD: z.string(),
   DB_HOST: z.string().ip({ version: "v4" }),
   DB_PORT: z.string().length(4),
   DB_SERVICE_NAME: z.string(),

   // OASE
   DB_USER_OASEMON: z.string(),
   DB_PASSWORD_OASEMON: z.string(),
   DB_HOST_OASEMON: z.string().ip({ version: "v4" }),
   DB_PORT_OASEMON: z.string().length(4),
   DB_SCHEMA_OASE: z.string(),
   DB_SCHEMA_OASEMON: z.string(),
   DB_CHARSET_OASEMON: z.string(),

   // VISION
   DB_SERVER_VISION: z.string().ip({ version: "v4" }),
   DB_USER_VISION: z.string(),
   DB_PASSWORD_VISION: z.string(),
   DB_PORT_VISION: z.string().length(4),
   DB_SCHEMA_VISION: z.string(),
   DB_CONNECTION_TIMEOUT_VISION: validateMiliseconds,
   DB_REQUEST_TIMEOUT_VISION: validateMiliseconds,

   // KEYCLOAK
   KEYCLOAK_REALM: z.string(),
   KEYCLOAK_CLIENTID: z.string(),
   KEYCLOAK_URL: z.string().url(),
   KEYCLOAK_BEARER_ONLY: z.boolean(),
   KEYCLOAK_SSL_REQUIRED: z.string(),
   KEYCLOAK_SECRET: z.string().uuid(),
   NODE_TLS_REJECT_UNAUTHORIZED: z.number(),

   // API URL
   URL_SUBDIR: z.string(),

   // EAI
   EAI_API_URL: z.string().url(),
   EAI_CLIENT_ID: z.string(),

   // EAI TOKEN
   EAI_TOKEN_URL: z.string().url(),
   EAI_TOKEN_CLIENT_ID: z.string(),
   EAI_TOKEN_CLIENT_SECRET: z.string(),
   EAI_TOKEN_GRANT_TYPE: z.string(),

   // VISION API
   VISION_API_URL: z.string().url(),
   VISION_API_CLIENT_ID: z.string(),
   VISION_API_CLIENT_AUTH: z.string(),

   SERVER_SITE: z.string(),
});

const procEnv = process.env;

export const serverEnv = {
   PORT: Number(procEnv.PORT),
   NODE_ENV: procEnv.NODE_ENV,

   // GASPER
   DB_USER: procEnv.DB_USER,
   DB_PASSWORD: procEnv.DB_PASSWORD,
   DB_HOST: procEnv.DB_HOST,
   DB_PORT: procEnv.DB_PORT,
   DB_SERVICE_NAME: procEnv.DB_SERVICE_NAME,

   // OASE
   DB_USER_OASEMON: procEnv.DB_USER_OASEMON,
   DB_PASSWORD_OASEMON: procEnv.DB_PASSWORD_OASEMON,
   DB_HOST_OASEMON: procEnv.DB_HOST_OASEMON,
   DB_PORT_OASEMON: procEnv.DB_PORT_OASEMON,
   DB_SCHEMA_OASE: procEnv.DB_SCHEMA_OASE,
   DB_SCHEMA_OASEMON: procEnv.DB_SCHEMA_OASEMON,
   DB_CHARSET_OASEMON: procEnv.DB_CHARSET_OASEMON,

   // VISION
   DB_SERVER_VISION: procEnv.DB_SERVER_VISION,
   DB_USER_VISION: procEnv.DB_USER_VISION,
   DB_PASSWORD_VISION: procEnv.DB_PASSWORD_VISION,
   DB_PORT_VISION: procEnv.DB_PORT_VISION,
   DB_SCHEMA_VISION: procEnv.DB_SCHEMA_VISION,
   DB_CONNECTION_TIMEOUT_VISION: Number(procEnv.DB_CONNECTION_TIMEOUT_VISION),
   DB_REQUEST_TIMEOUT_VISION: Number(procEnv.DB_REQUEST_TIMEOUT_VISION),

   // KEYCLOAK
   KEYCLOAK_REALM: procEnv.KEYCLOAK_REALM,
   KEYCLOAK_CLIENTID: procEnv.KEYCLOAK_CLIENTID,
   KEYCLOAK_URL: procEnv.KEYCLOAK_URL,
   KEYCLOAK_BEARER_ONLY: Boolean(procEnv.KEYCLOAK_BEARER_ONLY),
   KEYCLOAK_SSL_REQUIRED: procEnv.KEYCLOAK_SSL_REQUIRED,
   KEYCLOAK_SECRET: procEnv.KEYCLOAK_SECRET,
   NODE_TLS_REJECT_UNAUTHORIZED: Number(procEnv.NODE_TLS_REJECT_UNAUTHORIZED),

   // API URL
   URL_SUBDIR: procEnv.URL_SUBDIR,

   // EAI
   EAI_API_URL: procEnv.EAI_API_URL,
   EAI_CLIENT_ID: procEnv.EAI_CLIENT_ID,

   // EAI TOKEN
   EAI_TOKEN_URL: procEnv.EAI_TOKEN_URL,
   EAI_TOKEN_CLIENT_ID: procEnv.EAI_TOKEN_CLIENT_ID,
   EAI_TOKEN_CLIENT_SECRET: procEnv.EAI_TOKEN_CLIENT_SECRET,
   EAI_TOKEN_GRANT_TYPE: procEnv.EAI_TOKEN_GRANT_TYPE,

   // VISION API
   VISION_API_URL: procEnv.VISION_API_URL,
   VISION_API_CLIENT_ID: procEnv.VISION_API_CLIENT_ID,
   VISION_API_CLIENT_AUTH: procEnv.VISION_API_CLIENT_AUTH,

   // HCP API
   HCP_TOKEN: procEnv.HCP_TOKEN,
   HCP_URL: procEnv.HCP_URL,

   BASE_PATH_CERT_FILE: procEnv.BASE_PATH_CERT_FILE,
   MAX_FILE_SIZE: Number(procEnv.MAX_FILE_SIZE),

   SERVER_SITE: procEnv.SERVER_SITE,
};

const _serverEnv = serverSchema.safeParse(serverEnv);

// @ts-ignore
const displayInvalidVariables = (errors) => {
   return Object.entries(errors)
      .map(([name, value]) => {
         // @ts-ignore
         if (value && "_errors" in value) {
            // @ts-ignore
            return `[ENV] ${name}: ${value._errors.join(", ")}\n`;
         }
      })
      .filter(Boolean);
};

if (!_serverEnv.success) {
   // eslint-disable-next-line
   console.error(
      "❌ Invalid environment variables:\n",
      ...displayInvalidVariables(_serverEnv.error.format())
   );

   throw new Error("Invalid environment variables");
}

export default _serverEnv.data;