import { PoolOptions } from "mysql2/typings/mysql";
import env from "../env/server.env";

export const gasper = {
	user: env.DB_USER,
	password: env.DB_PASSWORD,
	connectString: `${env.DB_HOST}:${env.DB_PORT}/${env.DB_SERVICE_NAME}?expire_time=1`,
	poolMin: 10,
	poolMax: 10,
	poolIncrement: 0,
	enableStatistics: true,
};

export const oasemon: PoolOptions = {
	host: env.DB_HOST_OASEMON,
	port: +env.DB_PORT_OASEMON,
	user: env.DB_USER_OASEMON,
	password: env.DB_PASSWORD_OASEMON,
	database: env.DB_SCHEMA_OASEMON,
	waitForConnections: true,
	connectionLimit: 10,
	queueLimit: 0,
	charset: env.DB_CHARSET_OASEMON,
	connectTimeout: 50000,
};

export const vision4 = {
	server: env.DB_SERVER_VISION,
	authentication: {
		type: "default",
		options: {
			userName: env.DB_USER_VISION,
			password: env.DB_PASSWORD_VISION,
		},
	},
	pool: {
		max: 10,
		min: 10,
		idleTimeoutMillis: 30000,
	},
	options: {
		// If you are on Microsoft Azure, you need encryption:
		encrypt: false,
	},
	database: env.DB_SCHEMA_VISION,
	port: +env.DB_PORT_VISION!,
	connectTimeout: +env.DB_CONNECTION_TIMEOUT_VISION!,
	requestTimeout: +env.DB_REQUEST_TIMEOUT_VISION!,
};

export { };

