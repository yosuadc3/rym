import ArrowLeftIcon from '@mui/icons-material/ArrowLeft';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';
import { Box, Grid } from "@mui/material";
import React from "react";
import Carousel from "react-material-ui-carousel";
import Cards from "../cards/Cards";

function CardCarousel({ data }) {
    const length = data.length;
    const chunkSize = 20;
    let groupsOfItems = [];

    for (let i = 0; i < length; i += chunkSize) {
        const chunk = data.slice(i, i + chunkSize);
        groupsOfItems.push(chunk);
    }

    const arrayOfJumlah = data.map(item => item.JUMLAH);
    const warning = Math.max(...arrayOfJumlah);

    if (length === 0) {
        return <></>
    }

    return (
        <Box sx={{ height: "100%", borderRadius: "8px", px: 3, py: 8, boxShadow: "6" }}>
            <Carousel
                height={"34vw"}
                indicators={true}
                navButtonsAlwaysVisible={true}
                activeIndicatorIconButtonProps={{ style: { color: "#156db8" } }}
                indicatorIconButtonProps={{ style: { color: "#C4D9ED" } }}
                NextIcon={<ArrowRightIcon viewBox="5 7 10 10" sx={{ fontSize: 50 }} />}
                PrevIcon={<ArrowLeftIcon viewBox="9 7 10 10" sx={{ fontSize: 50 }} />}
                navButtonsWrapperProps={{ style: { top: -25 } }}
                navButtonsProps={{ style: { backgroundColor: "transparent ", color: "#156db8", margin: 0, padding: 0 } }}
                sx={{ px: 7 }}
            >
                {
                    groupsOfItems.map((items, index) => {
                        return (
                            <Grid key={index} container >
                                {
                                    items.map((item, index) => {
                                        const title = item?.PENGELOLA || "-";
                                        const text = item?.JUMLAH || "-";
                                        const warningFlag = item.JUMLAH >= warning;

                                        return (
                                            <Grid key={index} item xs={2.4}>
                                                <Cards type="small" title={title} text={text} warning={warningFlag} altBgColor={index % 2 === 0} />
                                            </Grid>
                                        );
                                    })
                                }
                            </Grid>
                        )
                    })
                }
            </Carousel>
        </Box>
    );
}

export default CardCarousel;