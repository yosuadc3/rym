import { Typography,Grid } from "@mui/material"; 
import CustomBreadcrumbs from "../../../../../components/breadcrumb/CustomBreadcrumbs";
import {useParams} from "react-router-dom"
import {useGetFaultCategoryByIdQuery} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/faultCategory/api/faultCategory'
import { useState, useEffect } from "react";
import React from "react";

export default function FaultCategoryDetail(){
    const {id} = useParams()
    const { data: faultData, isLoading: faultIsLoading} = useGetFaultCategoryByIdQuery(id);
    const [data, setData] = useState({});

    const BREADCRUMBS = [
        {
            item: "Home",
            link: "/",
            current: false
        },
        {
            item: "Incident Management & Monitoring",
            link: null,
            current: false
        },
        {
            item: "Data Configuration",
            link: null,
            current: false
        },
        {
            item: "Fault Category",
            link: null,
            current: false
        },
        {
            item: data.category,
            link: null,
            current: true
        },
    ];
    
useEffect(() => {
    if (!faultIsLoading) {
        const { data} = faultData;
        setData(data);
    }
}, [faultData, faultIsLoading]);

    return(
        <>
            <Grid container alignItems={"center"} height={50} marginBottom={2}>
                <Grid item xs={12}>
                    <CustomBreadcrumbs breadcrumbs={BREADCRUMBS} />
                </Grid>
            </Grid>
            <Typography variant="h3">ID: {data.id}</Typography>
            <Typography variant="h3">Fault Category : {data.category}</Typography>
            <Typography variant="h3">Priority: {data.priority}</Typography>
            <Typography variant="h3">Color: {data.color}</Typography>
        </>
        
    );
}