import { Request } from "express";
import { IUser } from "../global.type";

export interface IGetDSARequest
	extends IUser,
	Request<any, any, any, any, any> { }

export interface IGetDSAReportRequest
	extends IUser,
	Request<any, any, any, any, any> { }
