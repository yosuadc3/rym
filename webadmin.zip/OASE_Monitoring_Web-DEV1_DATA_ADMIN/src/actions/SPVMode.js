import { axiosGet } from "../utilities/Fetch";

export function getSPVMode() {
	return async (dispatch) => {
		try {
			const res = await axiosGet("spv-mode");
			dispatch({
				type: "GET_SPV_MODE",
				payload: {
					data: res?.data,
					message: res?.error_message?.english,
				},
			});
		} catch (error) {
			throw error;
		}
	};
}

export function getSPVModeDetail() {
	return async (dispatch) => {
		try {
			const res = await axiosGet("spv-mode/detail");
			dispatch({
				type: "GET_SPV_MODE_DETAIL",
				payload: {
					data: res?.data,
					message: res?.error_message?.english,
				},
			});
		} catch (error) {
			throw error;
		}
	};
}

export function getSPVModeReport() {
	return async (dispatch) => {
		try {
			const dispatchAction = {
				type: "GET_SPV_MODE_REPORT",
				loading: {
					report: true
				}
			}
			dispatch(dispatchAction);
			const res = await axiosGet("spv-mode/report");
			dispatch({
				...dispatchAction,
				payload: {
					data: res?.data,
					message: res?.error_message?.english,
				},
				loading: {
					report: false
				}
			});
		} catch (error) {
			throw error;
		}
	};
}
