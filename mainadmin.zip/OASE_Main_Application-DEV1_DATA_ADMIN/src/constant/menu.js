import { SearchOutlined } from "@ant-design/icons";
import AssetIcon from "../components/svgs/AssetIcon";
import DashboardIcon from "../components/svgs/DashboardIcon";
import TicketIcon from "../components/svgs/TicketIcon";
import { vpnRedirect } from "../utilities/Vpn";

export const getSidenavMenu = (countData) => {
	return [
		{
			key: "Asset Management",
			label: "Asset Management",
			link: null,
			roles: ["MENU_ASSET_MANAGEMENT"],
			isPrimary: true,
			icon: AssetIcon,
			children: [
				{
					key: "Dashboard Asset",
					label: "Dashboard",
					link: "/asset/asset/dashboard",
					roles: ["DASHBOARD_ASSET"],
				},
				{
					key: "Mesin",
					label: "Mesin",
					link: null,
					onTitleClick: () => {
						window.location.assign(vpnRedirect("/asset/asset"));
					},
					roles: ["MENU_MESIN"],
					children: [
						{
							key: "Penerimaan Mesin",
							label: "Penerimaan Mesin",
							link: null,
							roles: ["MENU_PENERIMAAN_MESIN"],
							children: [
								{
									key: "PO dan Batch Kedatangan (SPV)",
									label: "PO dan Batch Kedatangan (SPV)",
									link: "/asset/asset/machine/procurement/reception-spv",
									roles: ["LIST_PO_SPV"],
									count: countData?.outstandingPoMesin,
								},
								{
									key: "PO dan Batch Kedatangan",
									label: "PO dan Batch Kedatangan",
									link: "/asset/asset/machine/procurement/reception-opr",
									roles: ["LIST_PO"],
									count: countData?.outstandingPoMesin,
								},
								{
									key: "Generate WSID",
									label: "Generate WSID",
									link: "/asset/asset/machine/procurement/generate-wsid",
									roles: ["GENERATE_WSID"],
								},

								{
									key: "Registrasi WSID dan MK",
									label: "Registrasi WSID dan MK",
									link: "/asset/asset/machine/procurement/registrasi-wsid-mk",
									roles: ["LIST_REGISTRASI_WSID"],
									count: countData?.outstandingRegistrasiWsid,
								},
							],
						},
						{
							key: "Penerimaan Mesin (Admin Mover)",
							label: "Penerimaan Mesin (Admin Mover)",
							link: "/asset/asset/machine/procurement/reception-warehouse",
							roles: ["MENU_PENERIMAAN_MESIN_ADMIN_MOVER"],
							count: countData?.outstandingRegistrasiMesin,
						},
						{
							key: "Pemasangan Baru",
							label: "Pemasangan Baru",
							link: null,
							roles: ["MENU_PEMASANGAN"],
						},
						{
							key: "Replace",
							label: "Replace",
							link: null,
							roles: ["MENU_REPLACE"],
						},
						{
							key: "Trade In",
							label: "Trade In",
							link: null,
							roles: ["MENU_TRADE_IN"],
						},
						{
							key: "Relokasi",
							label: "Relokasi",
							link: null,
							roles: ["MENU_RELOKASI"],
						},
						{
							key: "Reposisi",
							label: "Reposisi",
							link: null,
							roles: ["MENU_REPOSISI"],
						},
						{
							key: "Renovasi",
							label: "Renovasi",
							link: null,
							roles: ["MENU_RENOVASI"],
						},
						{
							key: "Penutupan",
							label: "Penutupan",
							link: null,
							roles: ["MENU_PENUTUPAN"],
						},
						{
							key: "Write Off",
							label: "Write Off",
							link: null,
							roles: ["MENU_WRITE_OFF"],
						},
						{
							key: "Pemasangan Mesin",
							label: "Pemasangan Mesin",
							link: "/asset/pemasangan-mesin",
							roles: ["MENU_PEMASANGAN_MESIN"],
						},
					],
				},
				{
					key: "Aksesoris",
					label: "Aksesoris",
					link: null,
					roles: ["MENU_AKSESORIS"],
					children: [
						{
							key: "Penerimaan & Write Off",
							label: "Penerimaan & Write Off",
							link: "/asset/asset/accessories/reception-and-write-off/accessories-opr",
							roles: ["LIST_PO_ACCESSORIES"],
							count: countData?.outstandingPoAccessories,
						},
						{
							key: "Penerimaan & Write Off (SPV)",
							label: "Penerimaan & Write Off (SPV)",
							link: "/asset/asset/accessories/reception-and-write-off/accessories-spv",
							roles: ["LIST_PO_ACCESSORIES_SPV"],
							count: countData?.outstandingPoAccessories,
						},
						{
							key: "Stock",
							label: "Stock",
							link: "/asset/accessories/stock/stock-opr",
							roles: ["LIST_STOCK"],
							count: countData?.outstandingPindahGudang,
						},
						{
							key: "Stock (SPV)",
							label: "Stock (SPV)",
							link: "/asset/accessories/stock/stock-spv",
							roles: ["LIST_STOCK_SPV"],
							count: countData?.outstandingPindahGudang,
						},
						{
							key: "In/Out",
							label: "In/Out",
							link: "/asset/asset/accessories/in-out",
							roles: ["LIST_IN_OUT"],
						},
					],
				},
				{
					key: "Maintenance",
					label: "Maintenance",
					link: null,
					roles: ["MENU_MAINTENANCE"],
					children: [
						{
							key: "Laporan Kerusakan",
							label: "Laporan Kerusakan",
							link: "/asset/accessories/laporan-kerusakan",
							roles: ["MENU_LAPORAN_KERUSAKAN"],
						},
						{
							key: "Perbaikan Aksesoris",
							label: "Perbaikan Aksesoris",
							link: "/asset/asset/accessories/perbaikan",
							roles: ["MENU_PERBAIKAN_AKSESORIS"],
						},
					],
				},
				{
					key: "Registrasi Asset Existing",
					label: "Create QR dan Pendaftaran Aset Eksisting",
					link: "/asset/asset/accessories/registrasi-asset-existing",
					roles: ["CREATE_QR_PENDAFTARAN_ASSET_EKSISTING"],
					count: countData?.outstanding_pendaftaran_aset_eksisting,
				},
				{
					key: "Perubahan Serial Number",
					label: "Perubahan Serial Number",
					link: "/asset/perubahan-serial-number",
					roles: ["LIST_PERUBAHAN_SN"],
				},
			],
		},
		{
			key: "Dashboard",
			label: "Dashboard",
			link: null,
			roles: ["MENU_MONITORING_DASHBOARD"],
			isPrimary: true,
			icon: DashboardIcon,
			children: [
				{
					key: "SPV Mode",
					label: "SPV Mode",
					link: "/monitoring/dashboard/spv-mode",
					roles: ["GET_SPV_MODE"],
				},
				{
					key: "Lost Communication",
					label: "Lost Comm",
					link: "/monitoring/dashboard/lost-comm",
					roles: ["GET_LOST_COMM"],
				},
				{
					key: "DSA",
					label: "DSA",
					link: "/monitoring/dashboard/dsa",
					roles: ["GET_DSA"],
				},
				{
					key: "ATLAS",
					label: "ATLAS",
					link: null,
					roles: ["MENU_DASHBOARD_ATLAS"],
					children: [
						{
							key: "Service Availability",
							label: "Service Availability",
							link: "/monitoring/dashboard/service-availability",
							roles: ["GET_SERVICE_AVAILABILITY"]
						}
					],
				},
			],
		},
		{
			key: "Incident Management & Monitoring",
			label: "Incident Management & Monitoring",
			link: null,
			roles: ["MENU_INCIDENT_MANAGEMENT_MONITORING"],
			isPrimary: true,
			icon: TicketIcon,
			children: [
				{
					key: "Incident Management",
					label: "Incident Management",
					link: "/monitoring/incident-management",
					roles: ["MENU_INCIDENT_MANAGEMENT"],
				},
				{
					key: "Incidents",
					label: "Incidents",
					link: "/monitoring/incidents",
					roles: null
				},
				{
					key: "Data Configuration",
					label: "Data Configuration",
					link: null,
					roles: ["MENU_INCIDENT_MANAGEMENT"], //need to change
					children: [
						{
							key: "Event Code Rules",
							label: "Event Code Rules",
							link: "/monitoring/data-configuration/event-code-rules",
							roles: ["GET_EVENT_CODE_RULE"],
						},
						{
							key: "Event Code Catalog",
							label: "Event Code Catalog",
							link: "/monitoring/data-configuration/event-code-catalog",
							roles: ["GET_EVENT_CODE_SOURCE"], //need to change
						},
						{
							key: "Event Code Group",
							label: "Event Code Group",
							link: "/monitoring/data-configuration/event-code-group",
							roles: ["GET_EVENT_CODE_GROUP"],
						},
						{
							key: "Fault Category",
							label: "Fault Category",
							link: "/monitoring/data-configuration/fault-category",
							roles: ["GET_FAULT_CATEGORY"],
						},
					],
				},
			],
		},
		{
			key: "Inquiry Report",
			label: "Inquiry & Report",
			link: null,
			roles: ["MENU_INQUIRY_REPORT"],
			isPrimary: true,
			icon: SearchOutlined,
			children: [
				{
					key: "Inquiry",
					label: "Inquiry",
					link: null,
					roles: ["MENU_INQUIRY"],
					children: [
						{
							key: "Inquiry Daily Activity",
							label: "Inquiry Aktivitas Harian",
							link: "/asset/data-inquiry/inquiry-daily-activity",
							roles: ["MENU_INQUIRY_DAILY_ACTIVITY"],
						},
						{
							key: "Inquiry Task",
							label: "Inquiry Task",
							link: "/asset/data-inquiry/inquiry-task",
							roles: ["MENU_INQUIRY_TASK"],
						},
						{
							key: "Inquiry Mesin",
							label: "Inquiry Mesin",
							link: "/asset/data-inquiry/inquiry-machine",
							roles: ["MENU_INQUIRY_MACHINE"],
						},
						{
							key: "Inquiry PO",
							label: "Inquiry PO",
							link: "/asset/data-inquiry/inquiry-po",
							roles: ["INQUIRY_PO"],
						},
						{
							key: "Inquiry Aksesoris",
							label: "Inquiry Aksesoris",
							link: "/asset/data-inquiry/inquiry-accessories",
							roles: ["MENU_INQUIRY_ACCESSORIES"],
						},
					],
				},
				{
					key: "Report",
					label: "Report",
					link: null,
					roles: ["MENU_REPORT"],
					children: [
						{
							key: "Report Inventory",
							label: "Report Inventory",
							link: "/asset/report/report-inventory",
							roles: ["MENU_REPORT_INVENTORY"],
						},
						{
							key: "Report Task",
							label: "Report Task",
							link: "/asset/report/report-task",
							roles: ["MENU_REPORT_TASK"],
						},
						{
							key: "Report PO",
							label: "Report PO",
							link: "/asset/report/report-po",
							roles: ["MENU_REPORT_PO"],
						},
						{
							key: "Report ATLAS",
							label: "Report ATLAS",
							link: "/monitoring/report/report-atlas",
							roles: ["MENU_REPORT_ATLAS"],
						},
						{
							key: "Report Data Configuration",
							label: "Report Data Configuration",
							link: "/monitoring/report/report-data-configuration",
							roles: null,
						},
						{
              				key: "Report Incident Management",
              				label: "Report Incident Management",
              				link: "/monitoring/report/report-incident-management",
              				roles: ["MENU_REPORT_INCIDENT_MANAGEMENT"]
		    	        },
					],
				},
			],
		},
	];
};
