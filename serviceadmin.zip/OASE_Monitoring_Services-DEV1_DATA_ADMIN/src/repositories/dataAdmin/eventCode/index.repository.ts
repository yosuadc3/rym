import { EVENT_CODE } from "../../../constants/dbQuery.constant";
import { query as dbQuery } from "../../../databases/oase.database";
import { TQueryParams, TSearchParams } from "../../../types/dataAdmin/dataAdmin.types";
import { handleAdvancedSearchParams, handleSearchParams, handleUpdate } from "../../../utils/dbQueryHelper.util";
import { getObjectValues } from "../../../utils/object/convertToArray.util";

export function getEventCodes(catalog_id: string, page: number, limit: number, sortBy: string, orderBy: string, searchParams?: TSearchParams) {

    let searchData: TQueryParams = {
        query: "",
        params: []
    }

    if (searchParams?.search) {
        searchData = handleSearchParams(searchParams.search);
    }

    if (searchParams?.advancedSearch || searchParams?.advancedSearchPeriode) {
        searchData = handleAdvancedSearchParams(searchParams.advancedSearchPeriode!, searchParams.advancedSearch, "created_time");
    }


    const offset = page * limit;

    let queryData = `select id, event_code, description, \`group\`, rule, message, knowledge_base
        from ${EVENT_CODE.VIEW} ${searchData.query} AND catalog_id = "${catalog_id}"
        order by \`${sortBy}\` ${orderBy} limit ${limit} offset ${offset}`;

    let queryTotal = `select count(id) as total from ${EVENT_CODE.VIEW} ${searchData.query} AND catalog_id = "${catalog_id}"`;

    if (!queryData.includes("where")) {
        queryData = `select id, event_code, description, \`group\`, rule, message, knowledge_base
        from ${EVENT_CODE.VIEW} where catalog_id = "${catalog_id}"
        order by \`${sortBy}\` ${orderBy} limit ${limit} offset ${offset}`;

        queryTotal = `select count(id) as total from ${EVENT_CODE.VIEW} where catalog_id = "${catalog_id}"`;
    }

    const result = dbQuery(queryData, searchData.params);
    const total = dbQuery(queryTotal, searchData.params);

    return Promise.all([result, total]);
}

export function getEventCode(id: number | undefined) {
    const baseQuery = `select id, event_code, description, \`group\`, rule, source, message, knowledge_base
        from ${EVENT_CODE.VIEW} where id = ?`;

    return dbQuery(baseQuery, [id]);
}

export function putEventCode(id: number | undefined, data: { [k: string]: string | number | unknown }, name: string | undefined) {
    let updateData: { query: string; params: (string | number | unknown)[] } = {
        query: "",
        params: []
    }
    let tempData;
    data.modified_by = name;
    if (!data.group_id) {
        tempData = { ...data, group_id: null }
        updateData = handleUpdate(tempData);
    } else {
        updateData = handleUpdate(data);
    }

    const baseQuery = `update ${EVENT_CODE.TABLE} ${updateData.query} WHERE _id = ?`;

    return dbQuery(baseQuery, [...updateData.params, id]);
}

export function postEventCode(data: { [k: string]: unknown }, createdBy: string | undefined) {
    const baseQuery = `insert into ${EVENT_CODE.TABLE} (event_code, description, group_id, rule_id, catalog_id, knowledge_base, created_by, is_delete) values
    (?, ?, ?, ?, ?, ?, ?, 0)`;
    return dbQuery(baseQuery, [...getObjectValues(data), createdBy]);
}

export function deleteEventCode(id: number | undefined, modifiedBy: string | undefined) {
    const baseQuery = `UPDATE ${EVENT_CODE.TABLE} t SET t.is_delete = 1, t.modified_by = ? WHERE t._id = ?`;

    return dbQuery(baseQuery, [modifiedBy, id]);
}

export function getSearchDropdown() {

}

export function getAdvancedSearchDropdown() {

}

export { };

