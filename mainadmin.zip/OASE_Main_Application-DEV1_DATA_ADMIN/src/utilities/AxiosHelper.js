import { get } from "./AxiosInstance";

const axios = get();

export const axiosGet = (url, path, params) => {
    return new Promise(async (resolve, reject) => {
        try {
            const { data } = await axios.get(`${url}${path}`, { params: params });
            resolve(data);
        }
        catch (e) {
            reject(e);
        }
    });
}

export const axiosPost = (url, path, body, params) => {
    return new Promise(async (resolve, reject) => {
        try {
            const { data } = await axios.post(`${url}${path}`, body, { params: params });
            resolve(data);
        }
        catch (e) {
            reject(e);
        }
    });
}

export const axiosPostFile = (url, body) => {
    return new Promise(async (resolve, reject) => {
        try {
            const { data } = await axios.post(`${url}/files`, body);
            resolve(data);
        }
        catch (e) {
            reject(e);
        }
    });
}

export const axiosPut = (url, path, body, params) => {
    return new Promise(async (resolve, reject) => {
        try {
            const { data } = await axios.put(`${url}${path}`, body, { params: params });
            resolve(data);
        }
        catch (e) {
            reject(e);
        }
    });
}

export const axiosDelete = (url, path, params) => {
    return new Promise(async (resolve, reject) => {
        try {
            const { data } = await axios.delete(`${url}${path}`, { params: params });
            resolve(data);
        }
        catch (e) {
            reject(e);
        }
    });
}

export const axiosRequest = (config) => {
    return new Promise(async (resolve, reject) => {
        try {
            const { data } = await axios.config(config);
            resolve(data);
        }
        catch (e) {
            reject(e);
        }
    });
}