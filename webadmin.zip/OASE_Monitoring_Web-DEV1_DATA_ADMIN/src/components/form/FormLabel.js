import React from "react";
import { Typography } from "@mui/material";

const styles = {
    label: {
        fontWeight: "bold",
        opacity: "0.8",
        color: "#546E7A",
        margin: "5px 0"
    },
}

function FormLabel({ label }) {
    return (
        <Typography sx={styles.label}>{label}</Typography>
    );
}

export default FormLabel;