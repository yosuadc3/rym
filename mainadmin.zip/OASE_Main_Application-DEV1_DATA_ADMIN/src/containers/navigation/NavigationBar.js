import React, { useEffect, useState } from "react";
import Navbar from '../../components/shared/Navbar';
import Sidenav from '../../components/shared/Sidenav';
import { renewToken, tokenExist } from "../../token/action";
import { Navigate, Route, Routes, BrowserRouter, HashRouter } from "react-router-dom";
import {getVPNUrl, hasVPNURrl} from '../../utilities/Vpn';

async function checkTokenActive(setTokenActive) {
  renewToken()
      .then(() => {
          setTokenActive(true);
      })
      .catch(() => {
          localStorage.clear();   
          setTokenActive(false);
      });
}

function NavigationBar() {
  const [tokenActive, setTokenActive] = useState(tokenExist());
  const urlVpn = getVPNUrl();

  useEffect(() => {
    checkTokenActive(setTokenActive);
  }, []);

  if (tokenActive) {
    return (
        <HashRouter>
            <Sidenav/>
            <Navbar/>
        </HashRouter>
    );
  }
  return <></>
}

export default NavigationBar;