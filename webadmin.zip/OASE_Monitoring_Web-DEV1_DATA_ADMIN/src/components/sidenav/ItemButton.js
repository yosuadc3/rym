import React from 'react';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import Typography from '@mui/material/Typography';
import { Link } from 'react-router-dom';


const styles = {
    itemIcon: {
        color: "white",
        marginLeft: 1,
    },
    itemText: {
        color: "white",
        height: "auto",
        "&:hover": {
            color: "#c5b7b7",
            fontWeight: "bold",
        },
    },
    expandIcon: {
        color: "white",
    },
}


function ItemButton(props) {
    const text = props.text;
    const icon = props.icon;
    const level = props?.level || 0;
    const link = props.link;
    const onClickFunction = props.onClickFunction;
    const state = props.state;

    return (
        <ListItemButton onClick={onClickFunction} component={link === undefined ? ListItemButton : Link} to={link}>
            <ListItemIcon sx={styles.itemIcon}>{icon}</ListItemIcon>
            <ListItemText primary={<Typography marginLeft={level} sx={styles.itemText}>{text}</Typography>} />
            {state ? <ExpandLess sx={styles.expandIcon} /> : <ExpandMore sx={styles.expandIcon} />}
        </ListItemButton>
    );
}


export default ItemButton;