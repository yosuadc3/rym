export const SUMMARY_ADDON_FILTER_ITEMS = [
    {
        id: "all",
        label: "All",
    }
]

export const TABLE_ADDONS_SEARCH_ITEMS = [
    {
        value: "all",
        label: "All"
    }
];

export const SUMMARY_FILTER_TYPE = "Report DSA";