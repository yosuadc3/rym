import React from "react";
import { Breadcrumbs, Link, Typography } from "@mui/material";
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { Link as LinkRouter } from "react-router-dom";

const style = {
    breadcrumbs: {
        color: "#156db8"
    },
    text: (current) => ({
        fontWeight: current ? "bold" : "medium"
    })
}

function CustomBreadcrumbs(props) {
    const { breadcrumbs } = props;

    return (
        <Breadcrumbs sx={style.breadcrumbs} separator={<NavigateNextIcon fontSize="small" />}>
            {
                breadcrumbs.map((value, index) => {
                    if (value.link === null) {
                        return (
                            <Typography key={index} sx={style.text(value.current)}>{value.item}</Typography>
                        );
                    }
                    else {
                        const props = {
                            key: index,
                            underline: "hover",
                            sx: style.text(value.current)
                        }

                        if (value.link === "/") {
                            props.href = "#/";
                        }
                        else {
                            props.component = LinkRouter;
                            props.to = value.link
                        }

                        return (
                            //<Link key={index} underline="hover" component={LinkRouter} to={value.link} sx={style.text(value.current)}>
                            //    {value.item}
                            //</Link>

                            <Link {...props}>
                                {value.item}
                            </Link>
                        );
                    }
                })
            }
        </Breadcrumbs>
    );
}

export default CustomBreadcrumbs;