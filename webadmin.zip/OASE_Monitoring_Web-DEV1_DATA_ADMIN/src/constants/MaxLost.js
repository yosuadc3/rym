//MAX_LOST Constant
export const MAX_LOST_COMM = {
	0: 300,
	1: 400,
};
