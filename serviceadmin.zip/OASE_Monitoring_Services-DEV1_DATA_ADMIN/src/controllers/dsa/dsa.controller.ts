import { Response } from "express";
import {
	IGetDSAReportRequest,
	IGetDSARequest,
} from "../../types/dsa/dsa.type";

//DSA Controller
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import printToConsole from "../../utils/printToConsole.util";
const dsaRepo = require("../../repositories/dsa.repository");

export const getDSA = async (req: IGetDSARequest, res: Response) => {
	addPayloadToRequestHeader(req);

	const data = await dsaRepo.get();
	let total = 0;

	const responseArray = data.rows.map((value: any) => {
		total += value.JUMLAH;

		return {
			PENGELOLA: value.PENGELOLA,
			WSID: value.ID.split(","),
			JUMLAH: value.JUMLAH,
		};
	});

	const response = {
		total: total,
		data: responseArray,
	};
	const message = {
		english: `Successfully Retrieved DSA Data`,
		indonesia: `Berhasil Mengambil Data DSA`,
	};

	res.send(jsonMessage.jsonSuccess(message, response));
};

export const getDSAReport = async (
	req: IGetDSAReportRequest,
	res: Response
) => {
	addPayloadToRequestHeader(req);

	const data = await dsaRepo.getReport();
	const message = {
		english: `Successfully Retrieved DSA Report`,
		indonesia: `Berhasil Mengambil Report DSA`,
	};

	res.send(jsonMessage.jsonSuccess(message, data.rows));
};

export { };

