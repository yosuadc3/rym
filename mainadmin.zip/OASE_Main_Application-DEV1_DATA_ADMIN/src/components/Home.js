import React from "react";
import { Link } from "react-router-dom";

function Home() {
    return (<h1 style={{ textAlign: "center" }}>OASE Main Page</h1>);
    // <Link to="asset"></Link>
}

export default Home;