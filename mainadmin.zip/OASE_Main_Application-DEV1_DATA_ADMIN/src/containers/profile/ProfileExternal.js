import React from "react";
import { Box, Button, CardMedia, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Grid, Typography } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import changePassword1 from "../../assets/image/change-password1.PNG";
import changePassword2 from "../../assets/image/change-password2.PNG";
import changePassword3 from "../../assets/image/change-password3.PNG";

const style = {
    textLabel: {
        textAlign: "left",
        fontWeight: "bold",
        fontSize: "16px",
        lineHeight: "19.5px",
        color: "#65748B"
    },
    textValue: {
        fontWeight: "bold",
        lineHeight: "19.5px",
        fontSize: "16px",
        color: "black"
    },
    btnChangePassword: {
        backgroundColor: "#156db8",
        width: "80%",
        padding: "2.5%",
        marginTop: "20%",
        color: "white",
        textTransform: "capitalize",
        "&:hover": {
            backgroundColor: "#125fa1"
        },
        "&:active": {
            backgroundColor: "#156db8"
        },
    },
    btnChangePasswordDialog: {
        backgroundColor: "#156db8",
        width: "35%",
        padding: "1.5%",
        marginTop: 15,
        color: "white",
        textTransform: "capitalize",
        "&:hover": {
            backgroundColor: "#125fa1"
        },
        "&:active": {
            backgroundColor: "#156db8"
        },
    },
    dialogContent: {
        textAlign: "center",
        width: "100%",
        marginBottom: "3%"
    },
    dialogContentTxt: {
        fontWeight: "bold",
        fontSize: "23px",
        color: "black"
    },
    changePassword: {
        marginTop: "3%",
        marginBottom: "3%",
        fontSize: "16px",
        fontWeight: "bold"
    },
    description: {
        fontSize: "15px"
    },
    dialogTitle: {
        color: "#000",
        textAlign: "right"
    },
    btnLanjut: {
        textTransform: "capitalize",
        width: "15%",
        marginLeft: "20px",
        backgroundColor: "#156db8",
        color: "white",
        "&:hover": {
            backgroundColor: "#125fa1"
        },
        "&:active": {
            backgroundColor: "#156db8"
        }
    },
    btnBatal: {
        textTransform: "capitalize",
        width: "15%",
        fontWeight: "bold",
        color: "#156db8",
        borderColor: "#156db8"
    },
    closeIcon: {
        "&:hover": {
            cursor: "pointer"
        }
    },
    containerItem: {
        marginTop: "6%"
    }
}

function ProfileExternal(props) {
    const { userData, handleChangePassword, openChangePassword, handleCloseChangePassword } = props;

    return (
        <>
            <Grid container textAlign="left">
                <Grid container sx={style.containerItem}>
                    <Grid item xs={3}>
                        <Typography variant="h6" component="h2" sx={style.textLabel}>Username</Typography>
                    </Grid>
                    <Grid item xs={9}>
                        <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.username || '-'}</Typography>
                    </Grid>
                </Grid>
                <Grid container sx={style.containerItem}>
                    <Grid item xs={3}>
                        <Typography variant="h6" component="h2" sx={style.textLabel}>Email</Typography>
                    </Grid>
                    <Grid item xs={9}>
                        <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.email || '-'}</Typography>
                    </Grid>
                </Grid>
                <Grid container sx={style.containerItem}>
                    <Grid item xs={3}>
                        <Typography variant="h6" component="h2" sx={style.textLabel}>Telepon</Typography>
                    </Grid>
                    <Grid item xs={9}>
                        <Box display="flex">
                            <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.telephone?.[0] || '-'}</Typography>
                            <Typography marginLeft="20%" variant="h6" component="h2" sx={style.textLabel}>Ext</Typography>
                            <Typography marginLeft="10%" variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.extension?.[0] || '-'}</Typography>
                        </Box>
                    </Grid>
                </Grid>
                <Grid container sx={style.containerItem}>
                    <Grid item xs={3}>
                        <Typography variant="h6" component="h2" sx={style.textLabel}>No HP</Typography>
                    </Grid>
                    <Grid item xs={9}>
                        <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.phone_number?.[0] || '-'}</Typography>
                    </Grid>
                </Grid>
                <Grid container sx={style.containerItem}>
                    <Grid item xs={3}>
                        <Typography variant="h6" component="h2" sx={style.textLabel}>Nama Perusahaan</Typography>
                    </Grid>
                    <Grid item xs={9}>
                        <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.company_name?.[0] || '-'}</Typography>
                    </Grid>
                </Grid>
                <Grid container sx={style.containerItem}>
                    <Grid item xs={3}>
                        <Typography variant="h6" component="h2" sx={style.textLabel}>Cabang Perusahaan</Typography>
                    </Grid>
                    <Grid item xs={9}>
                        <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.company_branch?.[0] || '-'}</Typography>
                    </Grid>
                </Grid>
                <Grid container sx={style.containerItem}>
                    <Grid item xs={3}>
                        <Typography variant="h6" component="h2" sx={style.textLabel}>Jenis Pekerjaan</Typography>
                    </Grid>
                    <Grid item xs={9}>
                        <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.task_type?.[0] || '-'}</Typography>
                    </Grid>
                </Grid>
                <Grid container sx={style.containerItem}>
                    <Grid item xs={3}>
                        <Typography variant="h6" component="h2" sx={style.textLabel}>NIP</Typography>
                    </Grid>
                    <Grid item xs={9}>
                        <Typography variant="h6" component="h2" sx={style.textValue}>: {userData?.attributes?.nip?.[0] || '-'}</Typography>
                    </Grid>
                </Grid>
            </Grid>

            <Dialog
                fullWidth={true}
                maxWidth="xl"
                open={openChangePassword}
                onClose={handleCloseChangePassword}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title" sx={style.dialogTitle}>
                    <CloseIcon sx={style.closeIcon} onClick={handleCloseChangePassword} />
                </DialogTitle>

                <DialogContent sx={style.dialogContent} >
                    <DialogContentText sx={style.dialogContentTxt} id="alert-dialog-description">
                        Anda akan diminta untuk login ulang sebelum melakukan penggantian password.<br />
                        Berikut langkah penggantian password:
                    </DialogContentText>

                    <Grid container width="100%" spacing={2}>
                        <Grid item xs={4}>
                            <CardMedia component="img" image={changePassword1} />
                            <Typography sx={style.changePassword}>Langkah 1</Typography>
                            <Typography sx={style.description} >Relogin menggunakan password lama</Typography>
                        </Grid>
                        <Grid item xs={4}>
                            <CardMedia component="img" image={changePassword2} />
                            <Typography sx={style.changePassword} >Langkah 2</Typography>
                            <Typography sx={style.description} >Ganti password.<br /> <span style={{ color: 'red' }}>Pastikan password alfanumerik <br />minimal 8 karakter</span></Typography>
                        </Grid>
                        <Grid item xs={4}>
                            <CardMedia component="img" image={changePassword3} />
                            <Typography sx={style.changePassword} >Langkah 3</Typography>
                            <Typography sx={style.description} >Ketika berhasil, anda otomatis akan masuk ke halaman dashboard oase</Typography>
                        </Grid>
                    </Grid>
                </DialogContent>

                <DialogActions sx={{ justifyContent: 'center', marginBottom: '40px' }}>
                    <Button sx={style.btnBatal} onClick={handleCloseChangePassword} variant="outlined" >
                        Batal
                    </Button>
                    <Button sx={style.btnLanjut} onClick={handleChangePassword} variant="contained" >
                        Lanjut
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
}

export default ProfileExternal;