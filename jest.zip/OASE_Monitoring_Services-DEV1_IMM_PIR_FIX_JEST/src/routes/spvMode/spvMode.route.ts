//SPV Router
import * as spvMode from "../../controllers/spvMode/spvMode.controller";
const keycloak = require("../../middlewares/keycloakHandler.middleware").get();
let router = require("express").Router();

router.get("/", keycloak.protect("realm:GET_SPV_MODE"), spvMode.getSPVMode);
router.get(
	"/flm",
	keycloak.protect("realm:GET_SPV_MODE"),
	spvMode.getSPVModeByFLM
);
router.get(
	"/detail",
	keycloak.protect("realm:GET_SPV_MODE_DETAIL"),
	spvMode.getDetailSPVMode
);
router.get(
	"/report",
	keycloak.protect("realm:GET_SPV_MODE_REPORT"),
	spvMode.getSPVModeReport
);

export default router;
export { };

