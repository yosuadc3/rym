import { Router } from "express";
import eventCode from "./eventCode/eventCode.route";
import faultCategory from "./faultCategory.route";
import emailAction from "./emailAction.route";
import ticketAction from "./ticketAction.route"
import incidents from "./incidents.route";

const router = Router();

router.use("/event-code", eventCode);
router.use("/fault-category", faultCategory);
router.use("/ticket-action", ticketAction);
router.use("/email-action", emailAction);
router.use("/v1/incidents", incidents);

export default router;