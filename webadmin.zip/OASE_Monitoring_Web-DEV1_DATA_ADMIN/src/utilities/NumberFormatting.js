export const numberWithCommas = (number = 0, locale = "en-US") => {
    return new Intl.NumberFormat(locale).format(number);
}