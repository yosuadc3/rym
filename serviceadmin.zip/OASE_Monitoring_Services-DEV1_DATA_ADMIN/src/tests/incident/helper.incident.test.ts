import { handleAdvancedSearch, handleProcessIncidentCurrent, handleProcessTerminalDetails } from "../../controllers/incident/helper.incident";

const sampleAdvSearch = [{
   id: 94985,
   category: 'Out of Service',
   age_seconds: 1650373,
   wsid: '1147_new',
   lokasi: '-',
   start_time: '12/05/2023 14:33',
   end_time: '12/05/2024 14:33',
   status_code: 'IDC00S5',
   status_code_description: 'CARD READER HARDWARE ERROR',
   last_comment: '-',
   duration: '19 days 2 hours 26 minutes',
   lok: 'testlok-123',
   tipe_mesin: 'CRM',
   vendor_mesin: 'Hyosung',
}]

describe('Incident Management', () => {
   test('handleProcessIncidentCurrent', () => {
      const sample = handleProcessIncidentCurrent([{
         'Incident Number': 94985,
         'Status Code': 'IDC00S5',
         Component: 'CardReader',
         Detail: 'CARD READER HARDWARE ERROR',
         WSID: '1147_new',
         _wsid: '6F65248EFCD2E3E978B8F5975F297D4BF964B78439F77AE480909E0C1044E122',
         'Start Time': '2023-05-12T14:33:00.000Z',
         'End Time': null,
         'Created by': 'vision_rode'
      }])
      const expectSample = expect(sample);

      expectSample.toStrictEqual({
         wsid: '1147_new',
         _wsid: '6F65248EFCD2E3E978B8F5975F297D4BF964B78439F77AE480909E0C1044E122',
         incidentNumber: 94985,
         currentDetails: {
            'Incident Number': 94985,
            'Status Code': 'IDC00S5',
            Component: 'CardReader',
            Detail: 'CARD READER HARDWARE ERROR',
            'Start Time': '12/05/2023 14:33',
            'End Time': '-',
            'Created by': 'vision_rode'
         }
      })
   })
   test('handleProcessTerminalDetails', () => {
      const sample = handleProcessTerminalDetails([{
         WSID: '1147_new',
         _wsid: '6F65248EFCD2E3E978B8F5975F297D4BF964B78439F77AE480909E0C1044E122',
         Status: null,
         'Location 1': null,
         'Location 2': null,
         City: null,
         Latitude: null,
         Longitude: null,
         'Serial Number': null,
         'State/Country': null,
         ZIP: null,
         Area: 'Default',
         Branch: 'Default',
         District: 'Default',
         Institution: 'Default',
         Region: 'Default',
         'Cassette Out Table': null,
         'IP Address': null,
         Manufacturer: null,
         'Tipe Mesin': null,
         'Jumlah Kaset': null,
         INIDIU: null,
         'Vendor Mesin': null,
         'Operational Days': null,
         'Operational Hour': null
      }])
      const expectSample = expect(sample);

      expectSample.toStrictEqual({
         terminalDetails: {
            WSID: '1147_new',
            _wsid: '6F65248EFCD2E3E978B8F5975F297D4BF964B78439F77AE480909E0C1044E122',
            Status: '-',
            'Location 1': '-',
            'Location 2': '-',
            City: '-',
            Latitude: '-',
            Longitude: '-',
            'Serial Number': '-',
            'State/Country': '-',
            ZIP: '-',
            Area: 'Default',
            Branch: 'Default',
            District: 'Default',
            Institution: 'Default',
            Region: 'Default',
            'Cassette Out Table': '-',
            'IP Address': '-',
            Manufacturer: '-',
            'Tipe Mesin': '-',
            'Jumlah Kaset': '-',
            INIDIU: '-',
            'Vendor Mesin': '-',
            'Operational Days': '-',
            'Operational Hour': '-'
         }
      })
   })
   describe('handleAdvancedSearch', () => {
      test('returns data - all', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, '9', undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - ticket_id', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, 85, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - wsid', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, '11', undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - lok', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, 'tes', undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - lokasi', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, '-', undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - tipe_mesin - 1', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, 'rm', undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - tipe_mesin - 2', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, 'RM', undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - vendor_mesin', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, 'Hyosung', undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - status_code - 1', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, 'I', undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - status_code - 2', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, 'DC', undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - start_time - 1', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, '33', undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - start_time - 2', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, ':', undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - end_time - 1', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, '4', undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - end_time - 1', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, ':', undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      // test('returns data - duration - 1', () => {
      //    const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, 19, undefined, undefined));
      //    expectSample.toStrictEqual(sampleAdvSearch);
      // })
      // test('returns data - duration - 2', () => {
      //    const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, 2, undefined, undefined));
      //    expectSample.toStrictEqual(sampleAdvSearch);
      // })
      test('returns data - status_code_description', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, 'error', undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - last_comment', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, '-'));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - (ticket_id, wsid, lok)', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, 5, 'n', 'tes', undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - (ticket_id, tipe_mesin)', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, 9, undefined, undefined, undefined, undefined, 'C', undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('returns data - (end_time, last_comment)', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, '5', undefined, undefined, '-'));
         expectSample.toStrictEqual(sampleAdvSearch);
      })
      test('does not return data', () => {
         const expectSample = expect(handleAdvancedSearch(sampleAdvSearch, '1234', undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined));
         expectSample.toStrictEqual([]);
      })
   })
})