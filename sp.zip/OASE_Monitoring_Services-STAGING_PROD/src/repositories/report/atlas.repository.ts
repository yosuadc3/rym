import constant from "../../constants/dbQuery.constant";
import { query as dbQuery } from "../../databases/oase.database";
import { TFilter, TPeriode, TSearchData } from "../../types/global.type";
import { handleAdvancedSearchParams } from "../../utils/dbQueryHelper.util";
const {
	VIEW_REPORT_ATLAS_FILTER_VALUES,
	VIEW_SERVICE_AVAILABILITY_REPORT,
	TABLE_MASTER_DROPDOWNS,
} = constant;

export const getReportDsa = (periode: TPeriode, filter: TFilter) => {
	let searchData: TSearchData = {
		query: "",
		params: [],
	};

	if (filter) {
		searchData = handleAdvancedSearchParams(periode, filter, "start_problem");
	} else {
		searchData = handleAdvancedSearchParams(periode, null, "start_problem");
	}

	const queryReport = `select id, wsid, 50k, 100k, deposit, receipt, non_cash, dsa_led, start_problem, end_problem, notes, duration, pengelola, kota, daerah, provinsi, vendor_mesin, group_ip, tandem, lokasi, kanwil
        from ${VIEW_SERVICE_AVAILABILITY_REPORT}
        ${searchData.query}
        order by start_problem desc
        limit 10`;
	const queryCount = `select count(*) as ?? from ${VIEW_SERVICE_AVAILABILITY_REPORT} ${searchData.query}`;

	const execQueryReport = dbQuery(queryReport, searchData.params);
	const execQueryCount = dbQuery(queryCount, ["total", ...searchData.params]);

	return Promise.all([execQueryReport, execQueryCount]);
};

export const getReportDsaDownload = (
	periode: TPeriode,
	filter: TFilter | null
) => {
	let searchData: TSearchData = {
		query: "",
		params: [],
	};

	if (filter) {
		searchData = handleAdvancedSearchParams(periode, filter, "start_problem");
	} else {
		searchData = handleAdvancedSearchParams(periode, null, "start_problem");
	}

	const query = `select wsid, 50k, 100k, deposit, receipt, non_cash, dsa_led, start_problem, end_problem, notes, duration, pengelola, kota, daerah, provinsi, vendor_mesin, group_ip, tandem, lokasi, kanwil
    from ${VIEW_SERVICE_AVAILABILITY_REPORT}
    ${searchData.query}
    order by start_problem desc`;

	return dbQuery(query, searchData.params);
};

export const getReportFilterDropdowns = (type: string) => {
	const query = `select field, label from ${TABLE_MASTER_DROPDOWNS} where menu = ?`;

	return dbQuery(query, [type]);
};

export const getReportFilterDsa = (field: string) => {
	const query = `select ?? from ${VIEW_REPORT_ATLAS_FILTER_VALUES}`;

	return dbQuery(query, [field], true);
};

export const getReportType = () => {
	const query = `select label as id, label, role_name from ${TABLE_MASTER_DROPDOWNS} where menu = ?`;

	return dbQuery(query, ["Report ATLAS"]);
};
