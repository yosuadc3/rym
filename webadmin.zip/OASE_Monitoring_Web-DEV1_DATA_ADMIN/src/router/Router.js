import React, { lazy, useEffect, useState } from "react";
import { HashRouter, Route, Routes } from "react-router-dom";
import NotFound from "../components/error/NotFound";
import { renewToken, tokenExist } from "../token/action";
import { hasRoles } from "../token/roles";
import AsyncLoader from "../utilities/AsyncLoader";

const routes = [
  {
    key: "DSA",
    path: "dashboard/dsa",
    fetchComponent: () => import("../containers/dashboard/dsa/DSA"),
    roles: ["GET_DSA"],
  },
  {
    key: "Lost Comm",
    path: "dashboard/lost-comm",
    fetchComponent: () => import("../containers/dashboard/lostComm/LostComm"),
    roles: ["GET_LOST_COMM"],
  },
  {
    key: "SPV Mode",
    path: "dashboard/spv-mode",
    fetchComponent: () => import("../containers/dashboard/spvMode/SPVMode"),
    roles: ["GET_SPV_MODE"],
  },
  {
    key: "SPV Mode Detail",
    path: "dashboard/spv-mode/detail",
    fetchComponent: () =>
      import("../containers/dashboard/spvMode/SPVModeDetail"),
    roles: ["GET_SPV_MODE_DETAIL"],
  },
  {
    key: "Service Availability",
    path: "dashboard/service-availability",
    fetchComponent: () => import("../containers/serviceAvailability/dashboard/index"),
    roles: ["GET_SERVICE_AVAILABILITY"],
  },
  {
    key: "Report ATLAS",
    path: "report/report-atlas",
    fetchComponent: () => import("../containers/report/atlas/index"),
    roles: ["MENU_REPORT_ATLAS"],
  },
  {
    key: "Report Data Configuration",
    path: "report/report-data-configuration",
    fetchComponent: () => import("../containers/report/dataConfiguration/index"),
    roles: null,
  },
  {
    key: "Incident Management",
    path: "incident-management",
    fetchComponent: () =>
      import(
        "../containers/incidentManagementMonitoring/incidentManagement/incidentManagement/IncidentManagement"
      ),
    roles: ["LIST_INCIDENT_MANAGEMENT"],
  },
  {
    key: "Incident Summary Detail",
    path: "incident-management/:ticketId/:wsidId",
    fetchComponent: () =>
      import(
        "../containers/incidentManagementMonitoring/incidentManagement/incidentManagement/Detail"
      ),
    roles: ["GET_INCIDENT_DETAIL"],
  },
  {
    key: "Report Incident Management",
    path: "report/report-incident-management",
    fetchComponent: () =>
      import(
        "../containers/report/reportIncidentManagement/ReportIncidentManagement"
      ),
    roles: null,
  },
  {
    key: "Event Codes",
    path: "data-configuration/event-codes",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/EventCodes/EventCodes"),
    roles: null, // need to change
  },
  {
    key: "Event Codes Detail",
    path: "data-configuration/event-codes/:id",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/EventCodes/EventCodesDetail"),
    roles: null, // need to change
  },
  {
    key: "Event Code Rules",
    path: "data-configuration/event-code-rules",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/EventCodeRules/EventCodeRules"),
    roles: ["GET_EVENT_CODE_RULE"],
  },
  {
    key: "Event Code Rules Detail",
    path: "data-configuration/event-code-rules/:id",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/EventCodeRules/EventCodeRulesDetail"),
    roles: null, // need to change
  },
  {
    key: "Event Code Catalog",
    path: "data-configuration/event-code-catalog",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/EventCodeSource/EventCodeSource"),
    roles: ["GET_EVENT_CODE_SOURCE"], //need to change
  },
  {
    key: "Event Code Source Detail",
    path: "data-configuration/event-code-catalog/:id",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/EventCodeSource/EventCodeSourceDetail"),
    roles: null, // need to change
  },
  {
    key: "Event Code Group",
    path: "data-configuration/event-code-group",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/EventCodeGroup/EventCodeGroup"),
    roles: ["GET_EVENT_CODE_GROUP"],
  },
  {
    key: "Event Code Group Detail",
    path: "data-configuration/event-code-group/:id",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/EventCodeGroup/EventCodeGroupDetail"),
    roles: null, // need to change
  },
  {
    key: "Fault Category",
    path: "data-configuration/fault-category",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/FaultCategory/FaultCategory"),
    roles: ["GET_FAULT_CATEGORY"],
  },
  {
    key: "Fault Category Detail",
    path: "data-configuration/fault-category/:id",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/FaultCategory/FaultCategoryDetail"),
    roles: null, // need to change
  },
  {
    key: "Incidents",
    path: "incidents",
    fetchComponent: () => import("../containers/incidentManagementMonitoring/dataConfiguration/pages/Incidents/index"),
    roles: null, // need to change
  },
];

function checkTokenActive(setTokenActive) {
  renewToken()
    .then(() => {
      setTokenActive(true);
    })
    .catch(() => {
      localStorage.clear();
      setTokenActive(false);
    });
}

function AppRouter() {
  const [tokenActive, setTokenActive] = useState(tokenExist());
  const [preloadedRoutes, setPreloadedRoutes] = useState([]);

  useEffect(() => {
    checkTokenActive(setTokenActive);
  }, []);

  if (tokenActive) {
    useEffect(() => {
      routes.forEach((route) => {
        if (hasRoles(route.roles)) {
          const temp = { ...route };
          const preload = temp
            .fetchComponent()
            .catch(() => import("../components/error/ImportError"));

          temp.component = lazy(() => preload);

          setPreloadedRoutes((route) => [...route, temp]);
        }
      });
    }, []);

    return (
      <div
        style={{
          width: "100%",
          paddingLeft: "24px",
          paddingBottom: "24px",
          paddingRight: "16px",
        }}
      >
        <HashRouter basename="monitoring">
          <Routes>
            {preloadedRoutes.map(({ key, path, component: Component }) => {
              return (
                <Route
                  key={key}
                  exact
                  path={path}
                  element={
                    <AsyncLoader>
                      <Component />
                    </AsyncLoader>
                  }
                />
              );
            })}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </HashRouter>
      </div>
    );
  }

  return <></>;
}

export default AppRouter;
