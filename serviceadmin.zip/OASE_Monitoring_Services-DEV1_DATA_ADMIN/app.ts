//ASAP DEPENDENCIES
require("dotenv").config();

//DEPENDENCIES
const os = require("os");
const server = require("./src/server/main.server");
const oracle = require("./src/databases/gasper.database");
import * as oase from "./src/databases/oase.database";
import * as vision4 from "./src/databases/vision4.database";
import GlobalError from "./src/errors/global.error";
import { InternalServerError, ServiceUnavailable } from "./src/errors/server.error";

// env.UV_THREADPOOL_SIZE = os.cpus().length;
// console.log(`NumOfCPU: ${os.cpus().length}`);

//Function to Establish DB Connection and Start the Server
async function start() {
	try {
		// console.log("Init oracle database");
		// await oracle.init();

		await oase.connect();

		await vision4.connect();

		await server.init();

		// console.log("Init scheduler");
		// scheduler();
	} catch (error) {
		if (error instanceof GlobalError) {
			throw error;
		}
		throw new ServiceUnavailable("Unable to start the server", "SERVICE_UNAVAILABLE")
	}
}

//Function to Terminate DB Connection and Shutdown the Server
// @ts-ignore
async function shutdown(e) {
	let error = e;
	try {
		console.log("Shutting OASE Monitoring Services...");
		await server.close();

		// console.log("Shutting database");
		// await oracle.close();

		await oase.disconnect();
	} catch (error) {
		if (error instanceof GlobalError) {
			throw error;
		}
		throw new InternalServerError("Unable to close the server", "SERVICE_SHUTDOWN_ERROR")
	}

	console.log("Goodbye, and see you on the next session ~");

	if (error) {
		process.exit(1);
	} else {
		process.exit(0);
	}
}

process.on("SIGTERM", (e) => {
	console.log("SIGTERM");
	shutdown(e);
});

process.on("SIGINT", (e) => {
	console.log("SIGINT");
	shutdown(e);
});

process.on("uncaughtException", (e) => {
	console.log("Uncaught exception");
	console.error(e);

	shutdown(e);
});

start();
