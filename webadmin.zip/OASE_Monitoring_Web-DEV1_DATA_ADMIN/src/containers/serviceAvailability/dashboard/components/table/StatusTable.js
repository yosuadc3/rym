import { Grid } from "@mui/material";
import React, { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ButtonExport from "../../../../../components/buttons/ButtonExport";
import EmptyCardWithTitle from "../../../../../components/cards/EmptyCardWithTitle";
import StyledSearch from "../../../../../components/search/StyledSearch";
import SkeletonTable from "../../../../../components/skeleton/SkeletonTable";
import StyledTable from "../../../../../components/table/StyledTable";
import { TABLE_ADDONS_SEARCH_ITEMS } from "../../../../../constants/ServiceAvailability";
import { SERVICE_AVAILABILITY_INTERVAL } from "../../../../../constants/UpdateInterval";
import { useGetReportQuery, useGetSearchItemsQuery, useGetStatusQuery } from "../../../../../redux/features/dashboard/serviceAvailability/api/serviceAvailability";
import { updateTimestamp } from "../../../../../redux/features/dashboard/serviceAvailability/serviceAvailability";
import { hasRoles } from "../../../../../token/roles";
import { customFormat } from "../../../../../utilities/TimeConverter";
import StatusIcon from "../icon/StatusIcon";
import StatusTableLegend from "../legend/StatusTableLegend";

const tableColumnsCommonProps = {
    headerAlign: "center",
    align: "center",
    // width: 120,
    flex: 0.7
};

const tableColumns = [
    {
        ...tableColumnsCommonProps,
        field: "wsid",
        headerName: "WSID",
    },
    {
        ...tableColumnsCommonProps,
        field: "50k",
        headerName: "50K",
        renderCell: (params) => StatusIcon(params?.value),
    },
    {
        ...tableColumnsCommonProps,
        field: "100k",
        headerName: "100K",
        renderCell: (params) => StatusIcon(params?.value),
    },
    {
        ...tableColumnsCommonProps,
        field: "deposit",
        headerName: "Deposit",
        renderCell: (params) => StatusIcon(params?.value),
    },
    {
        ...tableColumnsCommonProps,
        field: "receipt",
        headerName: "Receipt",
        renderCell: (params) => StatusIcon(params?.value),
    },
    {
        ...tableColumnsCommonProps,
        field: "non_cash",
        headerName: "Non Cash",
        renderCell: (params) => StatusIcon(params?.value),
    },
    {
        ...tableColumnsCommonProps,
        field: "dsa_led",
        headerName: "DSA LED",
        renderCell: (params) => StatusIcon(params?.value),
    },
    {
        ...tableColumnsCommonProps,
        field: "last_received",
        headerName: "Last Received",
        // width: 200,
        flex: 1,
    },
    {
        ...tableColumnsCommonProps,
        field: "notes",
        headerName: "Notes",
        // width: 200,
        flex: 1,
    },
    {
        ...tableColumnsCommonProps,
        field: "duration",
        headerName: "Duration",
        // width: 200,
        flex: 1,
    },
    {
        ...tableColumnsCommonProps,
        field: "lokasi",
        headerName: "Lokasi",
        // width: 200,
        flex: 1,
    },
    {
        ...tableColumnsCommonProps,
        field: "pengelola",
        headerName: "Pengelola",
        // width: 200,
        flex: 1,
    },
];

const tableLegendItems = [
    {
        text: "Enable",
        color: "#25A722"
    },
    {
        text: "Warning",
        color: "#FFD600"
    },
    {
        text: "Disable",
        color: "#FF6058"
    },
    {
        text: "Stop Deposit",
        color: "#7B61FF"
    }
];

const styles = {
    table: {
        "& .MuiDataGrid-iconButtonContainer": {
            marginLeft: "0px !important"
        }
    }
}

function mapSearchItems(data) {
    const items = data.map((item) => {
        return {
            value: item.field,
            label: item.label
        }
    });

    return [
        ...TABLE_ADDONS_SEARCH_ITEMS,
        ...items
    ];
}

export default function StatusTable({ }) {
    const dispatch = useDispatch();
    const refresh = useSelector((state) => state.serviceAvailability.refresh);
    const [firstRender, setFirstRender] = useState(true);
    const [tableData, setTableData] = useState([]);
    const [total, setTotal] = useState(0);
    const [searchItems, setSearchItems] = useState([]);
    const [page, setPage] = useState(0);
    const [currRowsPerPage, setCurrRowsPerPage] = useState(10);
    const [sortBy, setSortBy] = useState("id");
    const [orderBy, setOrderBy] = useState("desc");
    const [isResetSearch, setIsResetSearch] = useState(false);
    const [searchFlag, setSearchFlag] = useState(false);
    const [advancedSearchFlag, setAdvancedSearchFlag] = useState(false);
    const [searchValue, setSearchValue] = useState(null);
    const [advancedSearchValue, setAdvancedSearchValue] = useState(null);
    const [advancedSearchPeriode, setAdvancedSearchPeriode] = useState({ startDate: null, endDate: null });
    const [queryParams, setQueryParams] = useState({
        page: 0,
        limit: 10,
        sortBy: "id",
        orderBy: "desc",
        search: null,
        advancedSearch: null,
        advancedSearchPeriode: null
    });
    const { data: statusData, isLoading: statusIsLoading, refetch: refetchStatus } = useGetStatusQuery(queryParams, { pollingInterval: SERVICE_AVAILABILITY_INTERVAL, refetchOnReconnect: true });
    const { data: searchItemsData, isLoading: searchItemsIsLoading } = useGetSearchItemsQuery();

    useEffect(() => {
        if (!statusIsLoading) {
            const { data, total, last_update } = statusData;
            setTableData(data);
            setTotal(total);
            dispatch(updateTimestamp(last_update));

            if (firstRender) {
                setFirstRender(false);
            }
        }
    }, [statusData, statusIsLoading]);

    useEffect(() => {
        if (!searchItemsIsLoading) {
            setSearchItems(searchItemsData);
        }
    }, [searchItemsData, searchItemsIsLoading]);

    useEffect(() => {
        const commonParams = {
            page: page,
            limit: currRowsPerPage,
            sortBy: sortBy,
            orderBy: orderBy
        }

        if (searchFlag) {
            setQueryParams({
                ...commonParams,
                search: searchValue
            });
        }
        else if (advancedSearchFlag) {
            setQueryParams({
                ...commonParams,
                advancedSearch: advancedSearchValue,
                advancedSearchPeriode: advancedSearchPeriode
            });
        }
        else {
            setQueryParams(commonParams);
        }
    }, [page, currRowsPerPage, sortBy, orderBy, searchValue, advancedSearchValue, advancedSearchPeriode]);

    useEffect(() => {
        refetchStatus();
    }, [refresh]);

    const handleSortModelChange = useCallback((sortModel) => {
        if (sortModel.length) {
            setSortBy(() => sortModel[0]?.field);
            setOrderBy(() => sortModel[0]?.sort);
        } else {
            setSortBy(() => "id");
            setOrderBy(() => "desc");
        }
    }, []);

    const handlePageSizeChange = (e) => {
        setCurrRowsPerPage(e);
        setPage(0);
    }

    const handleSearchClick = (searchInput) => {
        const { text, column } = searchInput;
        const data = {};

        if (column === "all") {
            searchItems.forEach((item) => {
                data[item.field] = text;
            });
        }
        else {
            data[column] = text;
        }

        setSearchValue(data);
        setSearchFlag(true);
        setAdvancedSearchFlag(false);
    }

    const handleAdvancedSearchSubmit = (data) => {
        const { selectedDates, advancedData } = data;
        const temp = {};

        if (advancedData[0]?.category !== null) {
            advancedData.forEach((item) => {
                temp[item.category] = item.chips;
            });

            setAdvancedSearchValue(temp);
        }

        setAdvancedSearchPeriode({
            startDate: customFormat(selectedDates.startDate),
            endDate: customFormat(selectedDates.endDate)
        });
        setAdvancedSearchFlag(true);
        setSearchFlag(false);
    }

    const exportUseQuery = (params, options) => useGetReportQuery(params, options);

    return (
        <EmptyCardWithTitle title={"DSA Availability Status"}>
            <Grid container direction={"column"} spacing={2}>
                <Grid item>
                    <Grid container direction={"row"} alignItems={"center"}>
                        <Grid item xs={7}>
                            <StyledSearch
                                selectMenuItems={mapSearchItems(searchItems)}
                                handleSearchClick={handleSearchClick}
                                useAdvancedSearch
                                handleAdvancedSearchSubmit={handleAdvancedSearchSubmit}
                                isResetSearch={isResetSearch}
                                setIsResetSearch={setIsResetSearch}
                            />
                        </Grid>
                        <Grid item xs={4}>
                            <StatusTableLegend items={tableLegendItems} />
                        </Grid>
                        <Grid item xs={1} textAlign={"end"}>
                            {
                                hasRoles(["GET_SERVICE_AVAILABILITY_REPORT"]) &&
                                <ButtonExport useQuery={exportUseQuery} queryParams={queryParams} fileName={"ServiceAvailabilityReport"} extension={"xlsx"} timestamp={true} variant="outlined" />
                            }
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item sx={styles.table}>
                    {!firstRender ? (
                        <StyledTable
                            headers={tableColumns}
                            page={page}
                            rows={tableData}
                            pageSize={currRowsPerPage}
                            loading={statusIsLoading}
                            rowCount={total}
                            setPage={(e) => setPage(e)}
                            useStripesWhiteGray
                            setPageSizeChange={handlePageSizeChange}
                            onSortModelChange={handleSortModelChange}
                            disableRowClick
                        />) : (
                        <SkeletonTable amount={currRowsPerPage} />
                    )}
                </Grid>
            </Grid>
        </EmptyCardWithTitle>
    );
}