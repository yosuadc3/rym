import { Grid } from "@mui/material";
import React from "react";
import CustomBreadcrumbs from "./CustomBreadcrumbs";

export default function BaseBreadcrumbs({ breadcrumbs }) {
	return (
		<Grid container alignItems="center" height={60}>
			<Grid item xs>
				<CustomBreadcrumbs breadcrumbs={breadcrumbs} />
			</Grid>
		</Grid>
	);
}
