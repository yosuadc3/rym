import React from "react";
import { createUseStyles} from "react-jss";
import { Grid, Typography, TextField,Menu, Button, Box } from '@mui/material';
import { useState } from 'react';
import { HexColorInput, HexColorPicker } from 'react-colorful';
import { useEffect } from 'react';
import "../colorPicker/style.css";
import ArrowDown2 from "../../../../../components/svgs/ArrowDown2";
const useStyles = createUseStyles({
  icon:{
    width: "100px",
    height: "100px",
  },
  teks:{
    fontFamily: 'Montserrat', 
    fontWeight:"bold",
    fontSize: "12px",
    lineHeight: "20px",
    marginLeft: "5px",
  },
  rgb:{
    display: "block",
    boxSizing: "border-box",
    paddingLeft: "10px",
    width: "64px",
    height: "40px",
    padding: "6px",
    outline: "nonen",
    font: "inherit",
    textAlign: "center",
    background: "#ffffff",
    border: "1px solid #E5E8E8",
    borderRadius: "8px",
  },
  menu:{
    backgroundColor: "transparent",
    boxShadow: "none",
    height:"386px",
    width:"352px"
  }
});

function componentToHex(c) {
  var hex = c.toString(16);
  return hex.length == 1 ? "0" + hex : hex;
}

function rgbToHex(r, g, b) {
  return  "#"+componentToHex(r) + componentToHex(g) + componentToHex(b);
}

function hexToRgb(hex) {
  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}
function convert3HexTo6Hex(hex3) {
    var digits = hex3.substring(1).split("");
    var hex6 = "#" + digits[0] + digits[0] + digits[1] + digits[1] + digits[2] + digits[2];
    return hex6;
}


export default function ColorPicker({
  handleInputColor = () => { },
  hex = "#C4C4C4",
}){
    
  const classes = useStyles();
  const [color,setColor] = useState("#C4C4C4");
  const [rgb, setRgb] = useState([196,196,196]);
  const [changeRgb, setChangeRgb] = useState(true);
  const [changeHex, setChangeHex] = useState(true);
  const [open, setOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [firstRender, setFirstRender] = useState(true);

  const handleChangeR = (e)=>{
      if(e.target.value.toString().length <= 3){
        let input;
        if(e.target.value.toString().includes("-")){
          input = 0;
        }else{
          input = parseInt(e.target.value);
        }
          let val = [input,rgb[1],rgb[2]];
          if(e.target.value < 0){
            val = [0,rgb[1],rgb[2]];
          }else if(e.target.value >255){
            val = [255,rgb[1],rgb[2]];
          }
          setRgb(val);
          setChangeRgb(!changeRgb);
      }
  }

  const handleChangeG = (e)=>{
    if(e.target.value.toString().length <= 3 && e.target.value != "-"){
        const input = parseInt(e.target.value);
        let val = [rgb[0],input,rgb[2]];
        if(e.target.value < 0){
          val = [rgb[0],0,rgb[2]];
        }else if(e.target.value >255){
          val = [rgb[0],255,rgb[2]];
        }
        setRgb(val);
        setChangeRgb(!changeRgb);
    }
}

const handleChangeB = (e)=>{
  if(e.target.value.toString().length <= 3 && e.target.value != "-"){
    const input = parseInt(e.target.value);
      let val = [rgb[0],rgb[1],input];
      if(e.target.value < 0){
        val = [rgb[0],rgb[1],0];
      }else if(e.target.value >255){
        val = [rgb[0],rgb[1],255];
      }
      setRgb(val);
      setChangeRgb(!changeRgb);
  }
}

const handleClose = () =>{
  setOpen(!open);
}

const handleOpen = (e) =>{
  setOpen(true);
  setAnchorEl(e.currentTarget);
}
const handleChangeHex = (e)=>{
  setColor(e);
  handleInputColor(e);
  setChangeHex(!changeHex);
}

useEffect(() => {
    if(firstRender){
      setFirstRender(false);
    }else{
      setColor(rgbToHex(rgb[0],rgb[1],rgb[2]));
      handleInputColor(rgbToHex(rgb[0],rgb[1],rgb[2]));
    }
}, [changeRgb]);

useEffect(() => {
  if(color.length===7){
    setRgb([hexToRgb(color).r,hexToRgb(color).g,hexToRgb(color).b]);
  }else if(color.length===4){
    const temp = convert3HexTo6Hex(color);
    setRgb([hexToRgb(temp).r,hexToRgb(temp).g,hexToRgb(temp).b]);
  }
}, [changeHex]);

useEffect(() => {
  if(hex!== "-"){
    setColor(hex);
    setRgb([hexToRgb(hex).r,hexToRgb(hex).g,hexToRgb(hex).b]);
  }
}, []);

    return(  
    <Grid>
        <Button id="basic-button" 
                aria-controls={open ? 'basic-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={open ? 'true' : undefined}
                variant="outlined" endIcon={<ArrowDown2/>}
                sx={{width:"100px", padding:"0",height:"50px", borderColor:"#C4C4C4"}}
                onClick={handleOpen}>
            <Box sx={{width:"60%", height:"85%",backgroundColor:color, borderRadius:"5%"}}/>
        </Button>
        <Menu id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            anchorOrigin={{ vertical: 'center', horizontal: 'center' }}
            transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}
            onClose={handleClose}
            classes = {{paper: classes.menu}}
           >
          <Grid container padding={3} justifyContent="center" sx={{width:"100%", backgroundColor:"#FFFFFF",paddingBottom:"15px", borderRadius:"10px"}} className={"menucontainer"}  >
            <Grid item sx={{width:"319px"}} className={"wpicker"}>
                <HexColorPicker color={color} onChange={handleChangeHex} className={"picker"}/>
            </Grid>
            <Grid item container justifyContent={"start"} marginY={1} spacing={1}>
                <Grid item >
                  <Typography variant='p' className={classes.teks}>Hex</Typography>
                  <HexColorInput  color={color} onChange={handleChangeHex} className={"hexInput"}/>
                </Grid>
                <Grid item>
                  <Typography variant='p' className={classes.teks}>R</Typography>
                    <TextField variant='standard'
                    InputProps={{
                      disableUnderline: true,
                    }} type="number" className={classes.rgb} onChange={handleChangeR} value={rgb[0]}/>
                </Grid>
                <Grid item>
                  <Typography variant='p' className={classes.teks}>G</Typography>
                  <TextField variant='standard'
                    InputProps={{
                      disableUnderline: true,
                    }} type="number" className={classes.rgb}
                  onChange={handleChangeG} value={rgb[1]}/>
                </Grid>
                <Grid item>
                  <Typography variant='p' className={classes.teks}>B</Typography>
                  <TextField variant='standard'
                    InputProps={{
                      disableUnderline: true,
                    }} type="number" className={classes.rgb}
                  onChange={handleChangeB} value={rgb[2]}/>
                </Grid>
            </Grid>
        </Grid>
        </Menu>
        
        
      </Grid>
      );
}