import { LinearProgress, TablePagination, Typography } from "@mui/material";
import {
	DataGrid,
	gridPageSelector,
	useGridApiContext,
	useGridSelector,
} from "@mui/x-data-grid";
import React, { useCallback, useEffect, useState } from "react";
import useFetch from "../../hooks/useFetch";
import SkeletonTable from "../skeleton/SkeletonTable";
import ArrowDown from "../svgs/ArrowDown";
import ArrowUp from "../svgs/ArrowUp";
import EmptyTableMessage from "./EmptyTable";

const ROW_COLOR = {
	border: "none",
	// borderRadius: 2,
	cursor: "pointer",
};

const styles = {
	dataGrid: (useGrayTheme, usePagination, disableRowClick) => ({
		boxShadow: "0px 0px 3px rgb(0 0 0 / 7%)",
		textAlign: "center",
		border: "none",
		overflow: "hidden",
		".MuiDataGrid-root": {
			overflow: "hidden",
			border: "none",
		},
		".MuiDataGrid-cellContent": {
			fontSize: "14px",
			color: useGrayTheme ? "#65748B" : "black",
			whiteSpace: "normal",
			paddingX: 1,
			paddingY: 2,
		},
		".MuiDataGrid-selectedRowCount": {
			visibility: "visible!important",
		},
		".MuiDataGrid-footerContainer": {
			borderBottom: "1px solid rgba(224, 224, 224, 1)",
			borderLeft: "1px solid rgba(224, 224, 224, 1)",
			borderRight: "1px solid rgba(224, 224, 224, 1)",
			"&:first-of-type": {
				display: "flex",
				padding: usePagination ? "4px" : "0px",
			},
			visibility: usePagination ? "visible" : "hidden",
			minHeight: usePagination ? "auto" : "0px",
		},
		".MuiDataGrid-cell:focus": {
			outline: "none",
		},
		".MuiDataGrid-columnHeader:focus": {
			outline: "none",
		},
		".MuiDataGrid-columnHeaders": {
			backgroundColor: useGrayTheme ? "#E0E0E0" : "rgb(134, 199, 255)",
			opacity: useGrayTheme ? "0.7" : "none",
			fontSize: "14px",
			fontWeight: 900,
			border: "none",
			borderRadiusTopLeft: 2,
			borderRadiusTopRight: 2,
		},
		".MuiDataGrid-row.Mui-odd": {
			backgroundColor: "#E2E2EB",
		},
		".super-app-theme--rowColor": {
			...ROW_COLOR,
			backgroundColor: "#E2E2EB",
		},
		".super-app-theme--rowColor-blue": {
			...ROW_COLOR,
			backgroundColor: "#CDE8FF",
		},
		".super-app-theme--rowColor-blue-2": {
			...ROW_COLOR,
			backgroundColor: "#CDE8FF",
		},
		".super-app-theme--rowColor-gray": {
			...ROW_COLOR,
			backgroundColor: "#E2E2EB",
			// "&.Mui-selected, &:hover": {
			// backgroundColor: disableRowClick ? "E2E2EB" : "#CDE8FF",
			// },
			"&:hover": {
				fontWeight: disableRowClick ? "normal" : "bold",
				backgroundColor: disableRowClick ? "#E2E2EB" : "#CDE8FF",
			},
		},
		".super-app-theme--rowColor-white": {
			...ROW_COLOR,
			backgroundColor: "white",
			"&:hover": {
				fontWeight: disableRowClick ? "normal" : "bold",
				backgroundColor: disableRowClick ? "white" : "#CDE8FF",
			},
			// "&.Mui-selected, &:hover": {
			// backgroundColor: disableRowClick
			// ? useGrayTheme
			// ? "F5F5F5"
			// : "white"
			// : "#CDE8FF",
			// },
		},
		"& > .MuiDataGrid-columnSeparator": {
			visibility: "hidden",
		},
		".MuiDataGrid-cell": {
			border: "none",
			outline: "none !important",
			padding: 0,
		},
		// ".MuiDataGrid-row": {
		//   "&:hover": {
		//     fontWeight: disableRowClick ? "normal" : "bold",
		//     backgroundColor: disableRowClick ? "transparent" : "#CDE8FF",
		//   },
		// },
		".MuiDataGrid-columnHeaderTitle": {
			fontSize: "14px",
			color: useGrayTheme ? "#333333" : "black",
			fontWeight: 600,
			overflow: "visible",
			lineHeight: "1.43rem",
			whiteSpace: "normal",
		},
		".MuiDataGrid-columnSeparator": {
			display: "none",
		},
		"& .MuiDataGrid-iconButtonContainer": {
			marginLeft: "10px",
			visibility: "visible !important",
			width: "auto !important",
		},
	}),
};

function SortedDescendingIcon() {
	return (
		<ArrowDown
			sx={{
				opacity: 1,
				backgroundColor: "white",
				color: "#0D5CAB",
				borderRadius: 1,
			}}
		/>
	);
}

function SortedAscendingIcon() {
	return (
		<ArrowUp
			sx={{
				opacity: 1,
				backgroundColor: "white",
				color: "#0D5CAB",
				borderRadius: 1,
			}}
		/>
	);
}

export default function StyledTableV2({
	headers,
	link,
	route,
	defaultSortBy = 1,
	defaultOrderBy = "desc",
	onCellClick = () => { },
	onRowClick,
	searchQuery,
	refetchDependencies,
	useSort = true,
	usePagination = true,
	initialTotalRows = 5,
	disableRowClick = false,
	showFirstTenRows = false,
	useEmptyReport = false,
	useGrayTheme = false,
	useReportTheme = false,
	enableInterval = false,
}) {
	if (useReportTheme) {
		usePagination = false;
		useSort = false;
		disableRowClick = true;
		showFirstTenRows = true;
		useEmptyReport = true;
		useGrayTheme = true;
	}

	refetchDependencies =
		refetchDependencies === undefined || refetchDependencies.length === 0
			? []
			: refetchDependencies;
	searchQuery = searchQuery ? searchQuery : "";

	const [rows, setRows] = useState([]);
	const [totalRows, setTotalRows] = useState(0);
	const [page, setPage] = useState(0);

	const [currRowsPerPage, setCurrRowsPerPage] = useState(initialTotalRows);

	const [sortBy, setSortBy] = useState(defaultSortBy);
	const [orderBy, setOrderBy] = useState(defaultOrderBy);
	const [firstRender, setFirstRender] = useState(true);

	const { data, error, isLoading, fetch } = useFetch(
		`${link}?page=${page}&limit=${currRowsPerPage}&sortBy=${sortBy}&orderBy=${orderBy}` +
		searchQuery,
		route
	);

	const handleSortModelChange = useCallback((sortModel) => {
		if (sortModel.length) {
			setSortBy((_) => sortModel[0]?.field);
			setOrderBy((_) => sortModel[0]?.sort);
		} else {
			setSortBy((_) => (defaultSortBy ? defaultSortBy : 1));
			setOrderBy((_) => "desc");
		}
	}, []);

	useEffect(() => {
		if (enableInterval) {
			const refetch = setInterval(() => {
				fetch(
					`${link}?page=${page}&limit=${currRowsPerPage}&sortBy=${sortBy}&orderBy=${orderBy}` +
					searchQuery,
					route
				);
			}, 30000);

			return () => clearInterval(refetch);
		}
	}, [page, currRowsPerPage, sortBy, orderBy, searchQuery, route, link])

	useEffect(() => {
		if (data && data.data) {
			let { total, rows } = data.data;
			setTotalRows(+total);
			if (rows === undefined || rows.length === 0) {
				setRows((prev) => []);
				setPage((prev) => 0);
				return;
			}
			setRows(rows);
		}
	}, [data]);

	useEffect(() => {
		if (firstRender) {
			setFirstRender((_) => false);
			return;
		}
		fetch(
			`${link}?page=${page}&limit=${currRowsPerPage}&sortBy=${sortBy}&orderBy=${orderBy}` +
			searchQuery,
			route
		);
	}, [
		currRowsPerPage,
		page,
		orderBy,
		sortBy,
		searchQuery,
		...refetchDependencies,
	]);

	defaultSortBy = defaultSortBy ? defaultSortBy : 1;
	defaultOrderBy = defaultOrderBy ? defaultOrderBy : "desc";

	headers = useSort
		? headers
		: headers.map((item) => {
			return { ...item, sortable: false };
		});

	function CustomPagination() {
		const apiRef = useGridApiContext();
		const page = useGridSelector(apiRef, gridPageSelector);

		return (
			<TablePagination
				component="div"
				page={page}
				rowsPerPage={currRowsPerPage}
				onPageChange={(e, newPage) => setPage(newPage)}
				onRowsPerPageChange={(e) => setCurrRowsPerPage(e.target.value)}
				count={totalRows}
				showFirstButton
				showLastButton
				rowsPerPageOptions={[5, 10, 20, 40, 100]}
			/>
		);
	}

	if (firstRender) {
		return <SkeletonTable amount={6} />;
	}

	if (data && data.data && rows.length === 0 && useEmptyReport) {
		return (
			<Typography
				sx={{
					fontSize: 14,
					fontWeight: 600,
					color: "#333333",
					height: "50vh",
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
				}}
			>
				Data tidak ditemukan
			</Typography>
		);
	}

	return (
		<DataGrid
			sx={styles.dataGrid(useGrayTheme, usePagination, disableRowClick)}
			rows={rows}
			columns={headers}
			pageSize={currRowsPerPage}
			loading={isLoading}
			page={page}
			// pagination={usePagination}
			autoHeight
			getRowHeight={() => "auto"}
			getRowSpacing={(params) => {
				if (params.indexRelativeToCurrentPage === 0) {
					return {
						top: 10,
						bottom: 0,
					};
				} else {
					return {
						top: 0,
						bottom: 0,
					};
				}
			}}
			hideFooterSelectedRowCount={true}
			paginationMode="server"
			sortingMode="server"
			disableColumnMenu
			isRowSelectable={(params) => (disableRowClick ? false : true)}
			rowCount={totalRows ?? 0}
			getRowClassName={(params) => {
				return params.indexRelativeToCurrentPage % 2 === 0
					? "super-app-theme--rowColor-gray"
					: "super-app-theme--rowColor-white";
			}}
			rowsPerPageOptions={[5, 10, 20, 40, 100]}
			components={{
				ColumnSortedDescendingIcon: SortedDescendingIcon,
				ColumnSortedAscendingIcon: SortedAscendingIcon,
				NoRowsOverlay: EmptyTableMessage,
				LoadingOverlay: LinearProgress,
				Pagination: usePagination ? CustomPagination : null,
			}}
			onSelectionModelChange={onRowClick}
			onCellClick={onCellClick}
			onPageChange={setPage}
			onPageSizeChange={setCurrRowsPerPage}
			onSortModelChange={handleSortModelChange}
		/>
	);
}
