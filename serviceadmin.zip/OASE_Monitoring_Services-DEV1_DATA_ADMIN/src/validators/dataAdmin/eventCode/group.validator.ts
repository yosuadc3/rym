import { body, param, query } from "express-validator";

export const getEventCodeGroups = [
    query("page").isNumeric(),
    query("limit").isNumeric(),
    query("sortBy").isString(),
    query("orderBy").isAlpha(),
    query("offset").optional().isNumeric(),
    query("search").optional().isJSON(),
    query("advancedSearch").optional().isJSON(),
    query("advancedSearchPeriode").optional().isJSON()
];

export const getEventCodeGroup = [
    param("id").isUUID()
];

export const postEventCodeGroup = [
    body("group").isString(),
    body("description").isString(),
];

export const changeOrdersEventCodeRule = [
    body("id").isUUID(),
    body("start_priority").isNumeric(),
    body("end_priority").isNumeric()
];

export const putEventCodeGroup = [
    param("id").isUUID(),
    body("group").isString(),
    body("description").isString(),
];

export const deleteEventCodeGroup = [
    param("id").isUUID(),
    body("priority").isNumeric()
];