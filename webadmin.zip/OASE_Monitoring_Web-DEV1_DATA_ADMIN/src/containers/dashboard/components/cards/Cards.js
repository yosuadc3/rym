import { keyframes } from "@emotion/react";
import { Box, Button, Grid, Typography } from "@mui/material";
import React from "react";
import { Link as LinkRouter } from "react-router-dom";

const blink = keyframes`
    from {opacity: 0;}
    to {opacity: 1;}
`;

// Big Card
const bigStyles = {
    box: (warning) => ({
        backgroundColor: warning === 2 ? "#f65a46" : "white",
        borderRadius: "8px",
        boxShadow: "6",
        height: "100%",
        minHeight: "40.8vw",
        padding: "2%"
    }),
    title: (warning) => ({
        color: warning === 2 ? "white" : "#156db8",
        fontSize: "3vw",
        fontWeight: "bold"
    }),
    iconBox: (warning) => ({
        backgroundColor: warning === 2 ? "#f65a46" : warning === 1 ? "#ffd600" : warning === 0 ? "#81E537" : "transparent",
        borderRadius: "8px",
        padding: 2
    }),
    mainText: (warning) => ({
        color: "black",
        fontSize: "15vw",
        fontWeight: "bold",
        animation: warning === 2 ? `${blink} 1.5s ease infinite` : ""
    }),
    subText: (warning) => ({
        color: warning === 2 ? "white" : "#65748B",
        fontSize: "1.2vw",
        fontWeight: "bold"
    }),
    btnDetail: {
        border: 1,
        borderColor: "#156db8",
        color: "#156db8",
        textTransform: "none",
        fontWeight: "bold",
        fontSize: "1vw"
    },
};

// Small Cards
const smallStyles = {
    box: (altBgColor, warning) => ({
        backgroundColor: warning ? "#f65a46" : altBgColor ? "#E8F3FF" : "white",
        py: 1.5,
        textAlign: "center"
    }),
    title: (warning) => ({
        color: warning ? "white" : "#156db8",
        fontSize: "1.2vw",
        fontWeight: 700,
        textTransform: "uppercase"
    }),
    text: (warning) => ({
        color: warning ? "white" : "black",
        fontSize: "3.2vw",
        fontWeight: 1000
    })
};

//Title Card
const titleStyles = {
    box: {
        borderRadius: "8px",
        boxShadow: "6",
        padding: 2
    },
    title: {
        color: "#156db8",
        fontSize: "2vw",
        fontWeight: "bold"
    }
}


function Cards({ type, title, icon, text, subText, warning, altBgColor, detail }) {
    //Type is mandatory for this component

    if (type === "small") {
        // const title = String(data.title).trim();
        // const text = String(data.text).trim();
        // const { warning } = data;

        return (
            <Box sx={smallStyles.box(altBgColor, warning)} >
                <Typography sx={smallStyles.title(warning)}>{title === "" ? "-" : title}</Typography>
                <Typography sx={smallStyles.text(warning)}>{text === "" ? "-" : text}</Typography>
            </Box>
        );
    }
    else if (type === "big") {
        return (
            <Box sx={bigStyles.box(warning)}>
                <Grid container direction={"column"} height={"100%"} justifyContent={"space-between"} paddingBottom={4}>
                    <Grid item>
                        <Grid container direction="row" alignItems="center" padding={1.5}>
                            {
                                icon &&
                                <Grid item xs={3}>
                                    <Box sx={bigStyles.iconBox(warning)}>
                                        <img src={icon} width={"90%"} />
                                    </Box>
                                </Grid>
                            }
                            <Grid item xs>
                                <Typography sx={bigStyles.title(warning)}>{title}</Typography>
                            </Grid>
                        </Grid>
                    </Grid>
                    <Grid item>
                        <Typography sx={bigStyles.mainText(warning)} margin={detail ? "-5%" : ""}>{text}</Typography>
                    </Grid>
                    <Grid item>
                        <Typography sx={bigStyles.subText(warning)}>Last Update :</Typography>
                        <Typography sx={bigStyles.subText(warning)}>{subText}</Typography>
                    </Grid>
                    {
                        detail &&
                        <Grid item alignSelf={"end"} marginRight={4}>
                            <Button sx={bigStyles.btnDetail} component={LinkRouter} to={detail}>Lihat Detail</Button>
                        </Grid>
                    }
                </Grid>
            </Box>
        );
    }
    else {
        return (<></>);
    }
}

export default Cards;