const router = require("express").Router();
import * as controller from "../../controllers/report/dataConfiguration.controller";
import { protect } from "../../middlewares/keycloakHandler.middleware";
import validation from "../../middlewares/validator.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
import * as validationRules from "../../validators/report/dataConfiguration.validator";
const keycloak = require("../../middlewares/keycloakHandler.middleware").get();

router.get("/", validationRules.getReportData, validation(validationRules.getReportData), errorWrapper(controller.getReportData));
router.get("/download", validationRules.getReportData, validation(validationRules.getReportData), errorWrapper(controller.getReportDataExcel));
router.get("/log", validationRules.getReportLog, validation(validationRules.getReportLog), errorWrapper(controller.getReportLog));
router.get("/log/download", validationRules.getReportLog, validation(validationRules.getReportLog), errorWrapper(controller.getReportLogExcel));
router.get("/list", errorWrapper(controller.getListDataConfiguration));
router.get("/category", validationRules.getReportCategory, validation(validationRules.getReportCategory), errorWrapper(controller.getReportCategory));

export default router;
export { };

