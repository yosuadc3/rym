export function dummyDSA(n_pengelola, n_wsid) {
    const data = [];

    for (let i = 0; i < n_pengelola; i++) {
        const pengelola = `Z${i}`;
        const wsid = [];

        for (let n = 0; n < n_wsid; n++) {
            wsid.push(`W${n}`);
        }

        data.push({
            PENGELOLA: pengelola,
            WSID: wsid
        });
    }

    return data;
}

export function dummySPV(n) {
    const data = [];

    for (let i = 0; i < n; i++) {
        const pengelola = `A${i}`;
        const jumlah = Math.floor(Math.random() * 30);

        data.push({
            PENGELOLA: pengelola,
            JUMLAH: jumlah
        });
    }

    return data;
}