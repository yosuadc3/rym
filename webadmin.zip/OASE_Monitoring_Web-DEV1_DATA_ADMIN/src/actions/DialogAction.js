export const HandleDialog = (open,id,action,index) => {
    return {
        type: 'HANDLE_DIALOG',
        dialog:open,
        id:id,
        action:action,
        index:index,
    }
}
