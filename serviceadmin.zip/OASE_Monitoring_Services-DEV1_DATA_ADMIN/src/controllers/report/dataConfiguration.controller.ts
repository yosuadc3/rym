import { Response } from "express";
import ExcelJS from "exceljs";
import moment from "moment";
import * as db from "../../repositories/report/dataConfiguration.repository";
import { IRequestAPI } from "../../types/global.type";
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import { TDbResponse } from "../../types/dataAdmin/dataAdmin.types";
import { replaceNullOrEmptyStringArray } from "../../utils/object/replaceNullOrEmptyStringArray.util";

export const getListDataConfiguration = async (
   req: IRequestAPI,
   res: Response
) => {
   addPayloadToRequestHeader(req);

   const message = {
      english: 'Successfully retrieved list data configuration',
      indonesia: 'Berhasil mengambil daftar data configuration'
   }

   const data = db.getListDataConfiguration();

   res.send(jsonMessage.jsonSuccess(message, data))
};

export const getReportType = async (
   req: IRequestAPI,
   res: Response
) => {
   addPayloadToRequestHeader(req);

   const message = {
      english: 'Successfully retrieved report type',
      indonesia: 'Berhasil mengambil tipe report'
   }

   const data = db.getReportType();

   res.send(jsonMessage.jsonSuccess(message, data))
};

export async function getReportCategory(req: IRequestAPI, res: Response) {
   addPayloadToRequestHeader(req);

   const type = req.query?.type;

   const message = {
      english: "Successfully retrieved report preview",
      indonesia: "Berhasil mengambil preview report",
   }

   const dbRes: TDbResponse = await db.getReportCategory(type);

   const [data] = dbRes;

   const payload = {
      ...data
   }

   res.send(jsonMessage.jsonSuccess(message, payload));
}

export async function getReportData(req: IRequestAPI, res: Response) {

   addPayloadToRequestHeader(req);

   const message = {
      english: "Successfully retrieved report data",
      indonesia: "Berhasil mengambil data report",
   }

   const searchParams = new URLSearchParams(req.originalUrl.split('?')[1]);
   const arrayParamValues = searchParams.getAll('arrayParam');

   const arrayData = arrayParamValues[0] === '' ? [] : arrayParamValues.map((value) => {
      return JSON.parse(decodeURIComponent(value));
   });

   //@ts-ignore
   const dbRes = await db.getReportData(arrayData.length > 0 ? arrayData : []);

   const [data, [total]] = dbRes;

   replaceNullOrEmptyStringArray(data);

   const payload = {
      ...total,
      count: data.length,
      data: data
   }

   res.send(jsonMessage.jsonSuccess(message, payload));
}

export async function getReportDataExcel(req: IRequestAPI, res: Response) {
   try {
      addPayloadToRequestHeader(req);

      const message = {
         english: "Successfully retrieved report data",
         indonesia: "Berhasil mengambil data report",
      }

      const searchParams = new URLSearchParams(req.originalUrl.split('?')[1]);
      const arrayParamValues = searchParams.getAll('arrayParam');

      const arrayData = arrayParamValues[0] === '' ? [] : arrayParamValues.map((value) => {
         return JSON.parse(decodeURIComponent(value));
      });

      //@ts-ignore
      let [data, [total]] = await db.getReportData(arrayData.length > 0 ? arrayData : []);

      data = data.reduce((acc: any[], item: any) => {
         acc.push({
            'Event Code': item['event_code'],
            'Description': item['description'] == null ? '-' : item['description'],
            'Group': item['group'] == null ? '-' : item['group'],
            'Rule': item['rule'] == null ? '-' : item['rule'],
            'Catalog': item['catalog'] == null ? '-' : item['catalog'],
            'Message': item['message'] == null ? '-' : item['message'],
            'Fault Category': item['fault_category'] == null ? '-' : item['fault_category']
         })
         return acc
      }, []);

      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("Sheet 1");

      worksheet.columns = [
         { header: "Event Code", key: "Event Code" },
         { header: "Description", key: "Description" },
         { header: "Group", key: "Group" },
         { header: "Rule", key: "Rule" },
         { header: "Catalog", key: "Catalog" },
         { header: "Message", key: "Message" },
         { header: "Fault Category", key: "Fault Category" },
      ];

      worksheet.addRows(data);

      const filename = `Report_Data_Configuration_${moment().format("DDMMYYYY_HH-mm-ss")}.xlsx`;

      res.setHeader(
         "Content-Type",
         "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
      res.setHeader(
         "Content-Disposition",
         `attachment; filename="${filename}"`
      );

      //set width
      worksheet.columns.forEach(function (column, i) {
         if (i === 1) column.width = 40;
         else column.width = 20;
      });

      // worksheet.eachRow(function (row, rowNumber){
      //    row.alignment.vertical = 'middle'
      // })

      await workbook.xlsx.write(res);
      res.end();

      // res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, response));
   } catch (err) {
      jsonMessage.getInternalServerError(err, res, "Unable to get incident report");
   }
};

export async function getReportLog(req: IRequestAPI, res: Response) {

   addPayloadToRequestHeader(req);

   const message = {
      english: "Successfully retrieved report data",
      indonesia: "Berhasil mengambil data report",
   }

   const startPeriod = req.query.start_period;
   const endPeriod = req.query.end_period;
   const types = req.query?.types?.split('-');

   if (!moment(startPeriod, 'DD/MM/YYYY', true).isValid()) {
      throw new Error('Invalid Start Period');
   }

   if (!moment(endPeriod, 'DD/MM/YYYY', true).isValid()) {
      throw new Error('Invalid End Period');
   }

   const dbRes = await db.getReportLog(startPeriod, endPeriod, types);

   const [data, [total]] = dbRes;

   replaceNullOrEmptyStringArray(data);

   const payload = {
      ...total,
      count: data.length,
      rows: data
   }

   res.send(jsonMessage.jsonSuccess(message, payload));
}

export async function getReportLogExcel(req: IRequestAPI, res: Response) {
   try {
      addPayloadToRequestHeader(req);

      const message = {
         english: "Successfully retrieved report data",
         indonesia: "Berhasil mengambil data report",
      }

      const startPeriod = req.query.start_period;
      const endPeriod = req.query.end_period;
      const types = req.query?.types?.split('-');

      if (!moment(startPeriod, 'DD/MM/YYYY', true).isValid()) {
         throw new Error('Invalid Start Period');
      }

      if (!moment(endPeriod, 'DD/MM/YYYY', true).isValid()) {
         throw new Error('Invalid End Period');
      }

      let [data, [total]] = await db.getReportLog(startPeriod, endPeriod, types);

      data = data.reduce((acc: any[], item: any) => {
         acc.push({
            'Time': item['time'],
            'Last Updated By': item['last_updated_by'] == null ? '-' : item['last_updated_by'],
            'Activity': item['activity'] == null ? '-' : item['activity'],
            'Before': item['before'] == null ? '-' : item['before'],
            'After': item['after'] == null ? '-' : item['after'],
            'Reason': item['reason'] == null ? '-' : item['reason']
         })
         return acc
      }, []);

      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("Sheet 1");

      worksheet.columns = [
         { header: "Time", key: "Time" },
         { header: "Last Updated By", key: "Last Updated By" },
         { header: "Activity", key: "Activity" },
         { header: "Before", key: "Before" },
         { header: "After", key: "After" },
         { header: "Reason", key: "Reason" },
      ];

      worksheet.addRows(data);

      const filename = `Report_Data_Perubahan_${moment().format("DDMMYYYY_HH-mm-ss")}.xlsx`;

      res.setHeader(
         "Content-Type",
         "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
      res.setHeader(
         "Content-Disposition",
         `attachment; filename="${filename}"`
      );

      //set width
      worksheet.columns.forEach(function (column, i) {
         if (i === 1) column.width = 40;
         else column.width = 20;
      });

      // worksheet.eachRow(function (row, rowNumber){
      //    row.alignment.vertical = 'middle'
      // })

      await workbook.xlsx.write(res);
      res.end();

      // res.status(status.HTTP_OK).send(jsonMessage.jsonSuccess(message, response));
   } catch (err) {
      jsonMessage.getInternalServerError(err, res, "Unable to get incident report");
   }
};
