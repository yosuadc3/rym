import express from "express";
import dsa from "./dsa/dsa.route";
import healthCheck from "./healthCheck.route";
import incident from "./incident/incident.route";
import lostComm from "./lostComm/lostComm.route";
import report from "./report/report.route";
import serviceAvailability from "./serviceAvailability/serviceAvailability.route";
import spvMode from "./spvMode/spvMode.route";
import welcomeApp from "./welcomeApp.route";
import swagger from "./swagger.route";
// const b24 = require("./b24/b24.route");
// const token = require("./token/token.route");

const router = express.Router();

//Common
router.use("/", welcomeApp);
router.use("/health-check", healthCheck);

//DSA
router.use("/dsa", dsa);

//LostComm
router.use("/lost-comm", lostComm);

//SPV
router.use("/spv-mode", spvMode);

//Incident
router.use("/incident", incident);

//Service Availability
router.use("/service-availability", serviceAvailability);

//Report
router.use("/report", report);

//Swagger
// router.use("/docs", swagger);

module.exports = router;
export { };
