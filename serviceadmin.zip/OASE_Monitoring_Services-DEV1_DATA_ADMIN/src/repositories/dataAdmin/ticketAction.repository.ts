import { TICKET_ACTION } from "../../constants/dbQuery.constant";
import { query as dbQuery } from "../../databases/oase.database";

export function getFaultCategory(id: number | undefined) {
    const baseQuery = `select id, category, color, description
        from ${TICKET_ACTION.VIEW_TABLE_TICKET_ACTION} where id = ?`;

    return dbQuery(baseQuery, [id]);
}

export function getTicketAction() {
    const baseQuery = `select json_arrayagg(json_object('id', id, 'value', action)) as list from ${TICKET_ACTION.VIEW_TABLE_TICKET_ACTION}`;
    // const baseQuery = `SELECT id, action FROM ${TICKET.VIEW_TABLE_ACTION}`;
    return dbQuery(baseQuery);
}