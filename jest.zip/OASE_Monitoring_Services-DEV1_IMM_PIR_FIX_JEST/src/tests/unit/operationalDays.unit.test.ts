import { getOperationalDaysByInitial } from "../../utils/operationalDays.util";

// N -> Sunday
// M -> Monday
// T -> Tuesday
// W -> Wednesday
// R -> Thursday
// F -> Friday
// S - Saturday

describe('Operational Days', () => {
   test('N,M,T,W,R,F,S', () => {
      const operationalDays = getOperationalDaysByInitial('N,M,T,W,R,F,S');
      const expectOperationalDays = expect(operationalDays);

      expectOperationalDays.toBeDefined();
      expectOperationalDays.toBe('Sun - Sat');
   })
   test('M,T,W,R,F,S', () => {
      const operationalDays = getOperationalDaysByInitial('M,T,W,R,F,S');
      const expectOperationalDays = expect(operationalDays);

      expectOperationalDays.toBeDefined();
      expectOperationalDays.toBe('Sun - Fri');
   })
   test('M,W,R,F,S', () => {
      const operationalDays = getOperationalDaysByInitial('M,W,R,F,S');
      const expectOperationalDays = expect(operationalDays);

      expectOperationalDays.toBeDefined();
      expectOperationalDays.toBe('Sun - Wed, Fri');
   })
   test('M,W,R,F,S', () => {
      const operationalDays = getOperationalDaysByInitial('M,W,R,F,S');
      const expectOperationalDays = expect(operationalDays);

      expectOperationalDays.toBeDefined();
      expectOperationalDays.toBe('Sun - Wed, Fri');
   })
   test('M,R,S', () => {
      const operationalDays = getOperationalDaysByInitial('M,R,S');
      const expectOperationalDays = expect(operationalDays);

      expectOperationalDays.toBeDefined();
      expectOperationalDays.toBe('Sun, Tue, Fri');
   })
   test('N,M,T,W,R,F,S,A,B,C', () => {
      const operationalDays = getOperationalDaysByInitial('N,M,T,W,R,F,S,A,B,C');
      const expectOperationalDays = expect(operationalDays);

      expectOperationalDays.toBeDefined();
      expectOperationalDays.toBe('Sun - Sat');
   });
   test('N', () => {
      const operationalDays = getOperationalDaysByInitial('N');
      const expectOperationalDays = expect(operationalDays);

      expectOperationalDays.toBeDefined();
      expectOperationalDays.toBe('Sat');
   });

   test('!@#$%^&*()', () => {
      const operationalDays = getOperationalDaysByInitial('!@#$%^&*()');
      const expectOperationalDays = expect(operationalDays);

      expectOperationalDays.toBeDefined();
      expectOperationalDays.toBe('-');
   });
})