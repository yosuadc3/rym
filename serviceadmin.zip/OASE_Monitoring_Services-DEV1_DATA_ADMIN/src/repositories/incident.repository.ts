import * as dbController from "../databases/vision4.database";
import { NumberOrUndefined, StringOrUndefined } from "../types/global.type";

const handleFilterAdvancedSearchQuery = (filterOptions: { [key: string]: any }) => {
        let joinQuery = '';
        Object.keys(filterOptions).forEach((key) => {
                const filterValue = filterOptions[key].split(',');
                let advancedSearch: [] = [];
                if (key.toLowerCase() === 'all') {
                        advancedSearch = filterValue.map((item: any, index: any) => {
                                item = item.toLowerCase();
                                return `terminal.value_1 LIKE '%${item}%' OR terminal.value_2 LIKE '%${item}%' ${filterValue.length === 1 || filterValue.length - 1 === index ? '' : 'OR '}`;
                        })
                        joinQuery = joinQuery.concat("AND ", `(${advancedSearch.join('')})`)
                }
                if (key.toLowerCase() === 'wsid') {
                        advancedSearch = filterValue.map((item: any, index: any) => {
                                item = item.toLowerCase();
                                return `terminal.value_1 LIKE '%${item}%' ${filterValue.length === 1 || filterValue.length - 1 === index ? '' : 'OR '}`;
                        })
                        joinQuery = joinQuery.concat("AND ", `(${advancedSearch.join('')})`)
                }
                if (key.toLowerCase() === 'lokasi') {
                        advancedSearch = filterValue.map((item: any, index: any) => {
                                item = item.toLowerCase();
                                return `terminal.value_2 LIKE '%${item}%' ${filterValue.length === 1 || filterValue.length - 1 === index ? '' : 'OR '}`;
                        })
                        joinQuery = joinQuery.concat("AND ", `(${advancedSearch.join('')})`)
                }
        })
        return joinQuery
}

const getTerminalCategoryDescription = (terminalCategoryLink: String | Number, wsid: String) => {
        // return `
        //         SELECT CATGENTRY_DESCRIPTION
        //         FROM TERMINAL t
        //         JOIN VW_TERMINAL_CATEGORIES_LOOKUP vw_tc on vw_tc.TERMINAL_LINK = t.ID
        //         where vw_tc.CATEGORY_LINK = ${terminalCategoryLink} and t.name = ${wsid}
        // `
        return `
                SELECT CATGENTRY_DESCRIPTION
                FROM VW_TERMINAL_CATEGORIES_LOOKUP vw_tc
                WHERE vw_tc.CATEGORY_LINK = ${terminalCategoryLink} AND TERMINAL_LINK = ${wsid}
        `
}

function handleDateClause(
        startDate: StringOrUndefined,
        endDate: StringOrUndefined,
        useStartDate = true
) {
        let dateClause = "";
        const customStartDate = useStartDate ? "t.start_date" : "t.start_time";
        if (!startDate && endDate) {
                dateClause = `and ${customStartDate}<= '${endDate}'`;
        } else if (startDate && !endDate) {
                dateClause = `and ${customStartDate}>= '${startDate}'`;
        } else if (startDate && endDate) {
                dateClause = `and (${customStartDate} between '${startDate} 00:00:00' and '${endDate} 23:59:59')`;
        }
        return dateClause;
}

async function getWSIDByTerminalAssignment(terminalAssignmentCriteria: StringOrUndefined, terminalAssignment: StringOrUndefined) {
        if(terminalAssignmentCriteria && terminalAssignment){
                const position = await dbController.execMssql(`SELECT TOP 1 position from cxp.dbo.CXP_TERMINAL_ATTRIBUTE where attributename = '${terminalAssignmentCriteria}'`)
                const position_value = 'value_' + position[0]?.position
        
                return `select distinct ct.value_1 as terminal
                from cxp.dbo.CXP_TERMINAL ct
                where ct.is_active = 'T'
                and ct.${position_value} like '%${terminalAssignment}%'`;
        }else{
                return null
        }
}

const getListInService = async(terminalAssignmentCriteria: StringOrUndefined, terminalAssignment: StringOrUndefined) => {
        return `SELECT
                DISTINCT
                terminal.value_1 AS wsid,
                CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', CAST(terminal.value_1 AS VARCHAR(50))), 2) as _wsid, 
                CONCAT('- ', terminal.value_1) as id,
                '-' as incident_number,
                '-' as start_time,
                terminal.value_2 AS lokasi,
                '-' as status_code,
                '-' as status_code_description,
                '-' as last_comment
                FROM CXP.dbo.CXP_TERMINAL terminal
                INNER JOIN GASPER_OBJECT g ON g.ID collate SQL_Latin1_General_CP1_CI_AS = terminal.value_1
                INNER JOIN OBJECT_STATE os ON os.object_key = g.object_key
                INNER JOIN CXP.dbo.CXP_TERMINAL_GROUPMEMBERS tgm on tgm.terminal_Id = terminal.id
                INNER JOIN CXP.dbo.CXP_TERMINAL_GROUP tg ON tg.id = tgm.group_Id
                WHERE (os.TICKET_KEY IS NULL AND os.ACTION_CODE = 1)
                AND (g.DELDATE is null)
                AND (terminal.value_1 collate SQL_Latin1_General_CP1_CS_AS in (${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)}) and terminal.is_active = 'T')
        `;
};

export const getCountTerminalInService = async(terminalAssignmentCriteria: StringOrUndefined, terminalAssignment: StringOrUndefined, filterOptions: { [key: string]: any }) => {
        handleFilterAdvancedSearchQuery(filterOptions)
        const query = `SELECT
                COUNT(DISTINCT terminal.value_1) as total_wsid_in_service
                FROM CXP.dbo.CXP_TERMINAL terminal
                INNER JOIN GASPER_OBJECT g ON g.ID collate SQL_Latin1_General_CP1_CI_AS = terminal.value_1
                INNER JOIN OBJECT_STATE os ON os.object_key = g.object_key
                INNER JOIN CXP.dbo.CXP_TERMINAL_GROUPMEMBERS tgm on tgm.terminal_Id = terminal.id
                INNER JOIN CXP.dbo.CXP_TERMINAL_GROUP tg ON tg.id = tgm.group_Id
                WHERE (os.TICKET_KEY IS NULL AND os.ACTION_CODE = 1)
                AND (g.DELDATE is null)
                ${handleFilterAdvancedSearchQuery(filterOptions)}
                AND (terminal.value_1 in (${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)}) and terminal.is_active = 'T')
        `;
        return dbController.execMssql(query);
};

/** Get all fault categories */
export const getAllFaultCategory = async () => {
        const query = `select 
                        trim(mw.description) as category,
                        CASE
                                WHEN mw.description = 'Lost Communications' THEN 'rgba(255, 255, 0, 0.4)'
                                WHEN mw.description = 'In Replenishment' THEN 'rgba(75, 0, 130, 0.3)'
                                WHEN mw.description ='Out of Service' THEN 'rgba(255, 0, 0, 0.3)'
                                WHEN mw.description = 'Needs Attention' THEN 'rgba(255, 140, 0, 0.3)'
                                WHEN LINK = 0 THEN 'rgba(0, 100, 0, 0.3)'
                                ELSE 'rgba(0, 0, 255, 0.3)'
                        END AS faultCategoryColor 
                        from monitor_window mw
                        where object_category = 1
                        order by 
                        CASE WHEN LINK = 0 THEN 1 ELSE 0 END,
                        LINK asc`;
        return dbController.execMssql(query);
};

export const getIncidentCategory = async (
        startDate: StringOrUndefined,
        endDate: StringOrUndefined,
        terminalAssignmentCriteria: StringOrUndefined,
        terminalAssignment: StringOrUndefined
) => {
        let dateClause = handleDateClause(startDate, endDate);

        const query = `select t.TICKET_KEY as id, 
                        trim(t.fault_category) as category, 
                        datediff(second, t.start_date, sysdatetime()) as age_seconds, 
                        t.object_id as wsid,
                        terminal.value_2 as lokasi,
                        t.start_date as start_time, 
                        t.status_code_name as status_code, 
                        t.status_code_desc as status_code_description,
                        TRIM(SUBSTRING(pd.COMMENT_TEXT, CHARINDEX('~', pd.COMMENT_TEXT)+1, LEN(pd.COMMENT_TEXT))) as last_comment
                                from VW_FAULT_CATEGORY_INCIDENTS t
                                join vw_primary_inc_faultcategory vp on vp.TICKET_KEY = t.TICKET_KEY
                                join CXP.dbo.CXP_TERMINAL terminal on terminal.value_1 collate SQL_Latin1_General_CP1_CI_AS = t.OBJECT_ID
                                left join public_diary pd on pd.ticket_key = t.ticket_key
                                left join public_diary pd2 on (pd.ticket_key = pd2.ticket_key and pd.created_date < pd2.created_date)
                        where t.end_date is null ${dateClause} and pd2.ticket_key is null and 
                        terminal.value_1 in (${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)})
                        order by 2`;
        return dbController.execMssql(query);
};

/**
 * Get tickets for each category
 */
export const getIncidentID = async (
        category: string,
        page: number,
        limit: number,
        sortBy: string | number,
        orderBy: string,
        startDate: StringOrUndefined,
        endDate: StringOrUndefined,
        terminalAssignmentCriteria: StringOrUndefined,
        terminalAssignment: StringOrUndefined,
) => {
        let dateClause = handleDateClause(startDate, endDate);

        if (sortBy === "duration") {
                sortBy = 8;
        }

        const query = `select * from 
                        (${category.toLowerCase() === "In Service".toLowerCase() ? await getListInService(terminalAssignmentCriteria, terminalAssignment) :
                        `select t.TICKET_KEY as incident_number,
                        CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', CAST(t.ticket_key AS VARCHAR(50))), 2) as _id, 
                        CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', CAST(t.object_id AS VARCHAR(50))), 2) as _wsid, 
                        t.ticket_key as id, 
                        t.start_date as start_time,
                        t.object_id as wsid,
                        terminal.value_2 as lokasi,
                        t.status_code_name as status_code,
                        t.status_code_desc as status_code_description,
                        datediff(second, t.start_date, sysdatetime()) as age_seconds,
                        TRIM(SUBSTRING(pd.COMMENT_TEXT, CHARINDEX('~', pd.COMMENT_TEXT)+1, LEN(pd.COMMENT_TEXT))) as last_comment,
                        row_number() over(partition by t.TICKET_KEY order by pd.created_date desc) rn
                                from MONITOR_WINDOW mw
                                join VW_FAULT_CATEGORY_INCIDENTS t on t.FAULT_CATEGORY = mw.DESCRIPTION
                                join CXP.dbo.CXP_TERMINAL terminal on terminal.value_1 collate SQL_Latin1_General_CP1_CI_AS = t.OBJECT_ID
                                join vw_primary_inc_faultcategory vp on vp.TICKET_KEY = t.TICKET_KEY
                                left join vision.dbo.public_diary pd on pd.ticket_key = t.ticket_key
                                        where t.end_date is null and t.FAULT_CATEGORY LIKE '%${category}%' ${dateClause}
                        and terminal.value_1 in (${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)})`} ) t
                        ${category.toLowerCase() === "In Service".toLowerCase() ? "" : "where rn = 1"}
                        order by ${sortBy} ${orderBy}`;
        return dbController.execMssql(query);
};

/**
 * Get Current Incident for Incident Detail page
 * @param {String} wsid WSID
 * @returns SQL Server execute method to run query
 */
export const getIncidentCurrent = async (
        ticketId: string,
        terminalAssignmentCriteria: StringOrUndefined,
        terminalAssignment: StringOrUndefined
) => {
        const query = `select top 1 
                        t.ticket_key as "Incident Number",
                        sc.name as "Status Code", 
                        c.description as "Component",
                        sc.description as "Detail",
                        g.id as "WSID",
                        CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', CAST(g.id AS VARCHAR(50))), 2) as _wsid, 
                        t.start_time as "Start Time",
                        t.end_time as "End Time", 
                        t.CREATED_BY as "Created by"
                                from TICKET t
                                left join gasper_object g on t.object_key = g.object_key
                                left join status_code sc on t.status_code_key = sc.link
                                left join action_code ac on t.action_code_key = ac.link
                                left join COMPONENT c on sc.COMPONENT_LINK = c.LINK
                        where HASHBYTES('SHA2_256', CAST(t.ticket_key AS VARCHAR(50))) = CONVERT(VARBINARY(32), '${ticketId}', 2) and 
                        g.id collate SQL_Latin1_General_CP1_CI_AS in ((${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)}))
                        order by t.ticket_key desc`;
        return dbController.execMssql(query);
};

/**
 * Get Terminal Details for Incident Management Detail
 */
export const getTerminalDetails = async (
        wsid: string,
        terminalAssignmentCriteria: StringOrUndefined,
        terminalAssignment: StringOrUndefined
) => {
        const query = `select distinct top 1
                        ct.value_1 as "WSID", 
                        CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', CAST(ct.value_1 AS VARCHAR(50))), 2) as _wsid, 
                        null as "Status", 
                        trim(ct.value_2) as "Location 1", 
                        trim(ct.value_3) as "Location 2", 
                        trim(ct.value_4) as "City", 
                        ct.value_9 as "Latitude", 
                        ct.value_10 as "Longitude", 
                        trim(ct.value_13) as "Serial Number", 
                        trim(ct.value_5) as "State/Country", 
                        trim(ct.value_7) as "ZIP",
                        MAX(CASE WHEN vw_tc.CATEGORY_LINK = 9 THEN vw_tc.CATGENTRY_DESCRIPTION END) as "Area",
                        MAX(CASE WHEN vw_tc.CATEGORY_LINK = 7 THEN vw_tc.CATGENTRY_DESCRIPTION END) as "Branch",
                        MAX(CASE WHEN vw_tc.CATEGORY_LINK = 11 THEN vw_tc.CATGENTRY_DESCRIPTION END) as "District",
                        MAX(CASE WHEN vw_tc.CATEGORY_LINK = 4 THEN vw_tc.CATGENTRY_DESCRIPTION END) as "Institution",
                        MAX(CASE WHEN vw_tc.CATEGORY_LINK = 3 THEN vw_tc.CATGENTRY_DESCRIPTION END) as "Region",
                        ct.value_30 as "Cassette Out Table",
                        ct.value_11 as "IP Address",
                        ct.value_15 as "Manufacturer",
                        ct.value_16 as "Tipe Mesin",
                        ct.value_30  as "Jumlah Kaset",
                        trim(ct.value_19) as "INIDIU",
                        MAX(CASE WHEN vw_tc.CATEGORY_LINK = 15 THEN vw_tc.CATGENTRY_DESCRIPTION END) as "Vendor Mesin",
                        SUBSTRING(ct.value_37, 0, CHARINDEX('(', ct.value_37)) as "Operational Days",
                        SUBSTRING(ct.value_37, CHARINDEX('(', ct.value_37), (CHARINDEX(')', ct.value_37) - CHARINDEX('(', ct.value_37)+1)) AS "Operational Hour"
                                from CXP.dbo.cxp_terminal ct
                                INNER JOIN CXP.dbo.CXP_TERMINAL_GROUPMEMBERS tgm on tgm.terminal_Id = ct.id
                                INNER JOIN CXP.dbo.CXP_TERMINAL_GROUP tg ON tg.id = tgm.group_Id
                                INNER JOIN TERMINAL t ON t.NAME = ct.value_1
                                LEFT JOIN VW_TERMINAL_CATEGORIES_LOOKUP vw_tc ON vw_tc.TERMINAL_LINK = t.ID
                        where (HASHBYTES('SHA2_256', CAST(ct.value_1 AS VARCHAR(50))) = CONVERT(VARBINARY(32), '${wsid}', 2)) and (ct.value_1 in ((${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)})) and ct.is_active = 'T')
                        GROUP BY 
                        ct.value_1,
                        ct.value_2,
                        ct.value_3,
                        ct.value_4,
                        ct.value_5,
                        ct.value_7,
                        ct.value_9,
                        ct.value_10,
                        ct.value_11,
                        ct.value_13,
                        ct.value_15,
                        ct.value_16,
                        ct.value_19,
                        ct.value_30,
                        ct.value_37`;
        return dbController.execMssql(query);
};

export const getHasWSID = async (wsid: string) => {
        const query = `select count(*) as count from CXP.dbo.cxp_terminal where HASHBYTES('SHA2_256', CAST(value_1 AS VARCHAR(50))) = CONVERT(VARBINARY(32), '${wsid}', 2)`;
        return dbController.execMssql(query);
};

export const getTerminalCurrentStatus = async (ticketId: StringOrUndefined) => {
        const query = `select FAULT_CATEGORY from VW_FAULT_CATEGORY_INCIDENTS where HASHBYTES('SHA2_256', CAST(ticket_key AS VARCHAR(50))) = CONVERT(VARBINARY(32), '${ticketId}', 2)`;
        return dbController.execMssql(query);
};

/**
 * Get Terminal status for Incident Management Detail
 */
export const getTerminalStatus = (ticketId: string) => {
        const query = `select mw.DESCRIPTION as category from ticket t
                join FAULTVIEW_ACTION_CODE_FILTER fa on fa.ACTION_CODE_KEY = t.ACTION_CODE_KEY
                join MONITOR_WINDOW mw on mw.LINK = fa.FAULTVIEW_KEY
                where HASHBYTES('SHA2_256', CAST(ticket_key AS VARCHAR(50))) = CONVERT(VARBINARY(32), '${ticketId}', 2)`;
        return dbController.execMssql(query);
};

/**
 * Get Incident History for Incident Detail page
 */
export const getIncidentHistory = async (
        wsid: string,
        page: number,
        limit: number,
        sortBy: string,
        orderBy: string,
        terminalAssignmentCriteria: StringOrUndefined,
        terminalAssignment: StringOrUndefined
) => {
        const dbOffset = page * limit;

        const query = `select * from 
                        (select t.ticket_key as id, 
                                CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', CAST(t.ticket_key AS VARCHAR(50))), 2) as _id, 
                                t.start_time as start_time, 
                                t.end_time as end_time,
                                sc.name as status_code,
                                sc.description as status_code_description,
                                ac.link as action_code, 
                                ac.description as action_code_description, 
                                TRIM(SUBSTRING(pd.COMMENT_TEXT, CHARINDEX('~', pd.COMMENT_TEXT)+1, LEN(pd.COMMENT_TEXT))) as last_comment,
                                row_number() over(partition by t.TICKET_KEY order by pd.created_date desc) rn
                                        from TICKET t
                                        join gasper_object g on t.object_key = g.object_key
                                        join status_code sc on t.status_code_key = sc.link
                                        join action_code ac on t.action_code_key = ac.link
                                        left join public_diary pd on pd.ticket_key = t.ticket_key
                                where g.id = '${wsid}'
                                and g.id collate SQL_Latin1_General_CP1_CI_AS in (${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)})) t
                        where rn = 1
                        order by ${sortBy} ${orderBy} 
                        offset ${dbOffset} rows 
                        fetch next ${limit} rows only`;
        return dbController.execMssql(query);
};

/**
 * Get total incidents for a specified WSID for Incident History
 */
export const getTotalIncidentHistory = async (
        wsid: string,
        terminalAssignmentCriteria: StringOrUndefined,
        terminalAssignment: StringOrUndefined
) => {
        const query = `select count(*) as total from 
                        (select t.ticket_key as id, 
                                t.start_time as start_time, 
                                t.end_time as end_time,
                                sc.name as status_code, 
                                sc.description as status_code_description, 
                                ac.link as action_code, 
                                ac.description as action_code_description, 
                                TRIM(SUBSTRING(pd.COMMENT_TEXT, CHARINDEX('~', pd.COMMENT_TEXT)+1, LEN(pd.COMMENT_TEXT))) as last_comment,
                                row_number() over(partition by t.TICKET_KEY order by pd.created_date desc) rn
                                        from TICKET t
                                        join gasper_object g on t.object_key = g.object_key
                                        join status_code sc on t.status_code_key = sc.link
                                        join action_code ac on t.action_code_key = ac.link
                                        left join public_diary pd on pd.ticket_key = t.ticket_key
                                                where g.id = '${wsid}' and g.id collate SQL_Latin1_General_CP1_CI_AS in (${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)})) t
                        where rn = 1`;
        return dbController.execMssql(query);
};

export const getIncidentComments = async (ticketId: string) => {
        const query = `select 
                        CREATED_DATE as created_date,
                        trim(CREATED_BY) as created_by,
                        TRIM(SUBSTRING(COMMENT_TEXT, CHARINDEX('~', COMMENT_TEXT)+1, LEN(COMMENT_TEXT))) as comment,
                        CASE
                                WHEN CHARINDEX('~', COMMENT_TEXT) = 0 THEN NULL
                                ELSE TRIM(SUBSTRING(COMMENT_TEXT, 0, CHARINDEX('~', COMMENT_TEXT)))
                        END AS created_by_oase
                        from PUBLIC_DIARY
                        where HASHBYTES('SHA2_256', CAST(ticket_key AS VARCHAR(50))) = CONVERT(VARBINARY(32), '${ticketId}', 2)
                        ORDER BY CREATED_DATE desc`;
        return dbController.execMssql(query);
};

export const getIncidentNumber = async (ticketId: string) => {
        const query = `select t.ticket_key from ticket t where HASHBYTES('SHA2_256', CAST(t.ticket_key AS VARCHAR(50))) = CONVERT(VARBINARY(32), '${ticketId}', 2)`;
        return dbController.execMssql(query);
}

/** Report */
export const getIncidentReport = async (
        startDate: string,
        endDate: string,
        terminalAssignmentCriteria: StringOrUndefined,
        terminalAssignment: StringOrUndefined,
) => {
        let dateClause = handleDateClause(startDate, endDate, false);

        const orderBy = "desc";
        const sortBy = "id";

        const query = `select * from 
                        (select t.TICKET_KEY as id,
                                g.ID as wsid,
                                CASE
                                        WHEN (a.description) = 'NON BCA BRANCH' THEN 'T'
                                        WHEN (a.description) = 'BCA BRANCH' THEN 'BCA'
                                        ELSE '-'
                                END AS lok,
                                ct.value_2 as lokasi,
                                ct.value_16 as tipe_mesin,
                                (SELECT top 1 CATGENTRY_DESCRIPTION FROM VW_TERMINAL_CATEGORIES_LOOKUP vw_tc where vw_tc.CATEGORY_LINK = 15 and TERMINAL_LINK = terminal.ID) as "vendor_mesin",
                                t.start_time as start_time,
                                t.end_time as end_time,
                                datediff(second, t.start_time, t.end_time) as age_seconds,
                                CONCAT(sc.name, ' - ', sc.DESCRIPTION) as status_code_description,
                                TRIM(SUBSTRING(pd.COMMENT_TEXT, CHARINDEX('~', pd.COMMENT_TEXT)+1, LEN(pd.COMMENT_TEXT))) as last_comment,
                                row_number() over(partition by t.TICKET_KEY order by pd.created_date desc) rn
                        from ticket t
                        INNER join VISION.dbo.GASPER_OBJECT g on t.object_key = g.object_key
                        INNER JOIN STATUS_CODE sc ON sc.LINK = t.STATUS_CODE_KEY
                        LEFT OUTER JOIN area a ON g.area_link = a.link
                        LEFT join vision.dbo.public_diary pd on pd.ticket_key = t.ticket_key
                        INNER JOIN CXP.dbo.CXP_TERMINAL as ct on ct.value_1 collate SQL_Latin1_General_CP1_CI_AS = g.ID
                        INNER JOIN TERMINAL terminal ON terminal.name = ct.value_1
                        INNER JOIN CXP.dbo.CXP_TERMINAL_GROUPMEMBERS tgm on tgm.terminal_Id = ct.id
                        INNER JOIN CXP.dbo.CXP_TERMINAL_GROUP tg ON tg.id = tgm.group_Id
                        where 1 is not null ${dateClause} and (g.id collate SQL_Latin1_General_CP1_CI_AS in (${await getWSIDByTerminalAssignment(terminalAssignmentCriteria, terminalAssignment)}) and ct.is_active = 'T') and g.deldate is null
                        ) t
                        where t.rn = 1
                        order by ${sortBy} ${orderBy}
                `;
        return dbController.execMssql(query);
};

export { };

