import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";

import StyledDivider from "../../../../../../components/divider/StyledDivider";
import useFetch from "../../../../../../hooks/useFetch";
import { useGetTerminalDetailsQuery, useGetTerminalStatusQuery } from "../../../../../../redux/features/incident-management-monitoring/incident-management/api/imm";
import CustomGrid from "../../../../../../utilities/CustomGrid";
import IsLoading from "../../../../../../utilities/IsLoading";

export default function TerminalDetails({
  ticketId,
  wsid,
  _wsid,
  handleLastUpdateChange,
}) {
  if (wsid === "") return <IsLoading />;

  const [currentStatus, setCurrentStatus] = useState("-");

  const { data: getTerminalDetail, isLoading: getTerminalDetailIsLoading } = useGetTerminalDetailsQuery(_wsid);
  const { data: getTerminalStatus, isLoading: getTerminalStatusIsLoading } = useGetTerminalStatusQuery(ticketId === "-" ? _wsid : ticketId);

  useEffect(() => {
    if (getTerminalStatus && getTerminalStatus.status) {
      setCurrentStatus(getTerminalStatus.status);
    }
  }, [getTerminalStatus]);

  useEffect(() => {
    if (getTerminalDetail && getTerminalDetail.lastUpdate) {
      handleLastUpdateChange(getTerminalDetail.lastUpdate);
    }
  }, [getTerminalDetail]);

  if (getTerminalDetailIsLoading || getTerminalStatusIsLoading) {
    return <IsLoading />;
  }

  const { locationGroup, machineGroup, networkGroup } =
    getTerminalDetail;

  const allGroup = [locationGroup, machineGroup, networkGroup, ""];

  return (
    <>
      {allGroup.map((group, idx) => (
        <React.Fragment key={idx}>
          <Grid container spacing={4}>
            {typeof group === "object" ? (
              <>
                {Object.keys(group).map((item, _) => (
                  <CustomGrid
                    key={`${idx}-${item}`}
                    title={item}
                    description={group[item]}
                    useContainer
                    xs={4}
                  />
                ))}
              </>
            ) : (
              <CustomGrid
                key={`${idx}-status`}
                title="Current Status"
                description={currentStatus}
                useContainer
                xs={4}
              />
            )}
          </Grid>
          {idx !== allGroup.length - 1 ? (
            <StyledDivider key={`${idx}-divider`} />
          ) : null}
        </React.Fragment>
      ))}
    </>
  );
}
