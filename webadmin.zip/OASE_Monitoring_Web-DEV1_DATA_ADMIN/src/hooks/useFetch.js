import { useEffect, useState } from "react";
import { get } from "../utilities/AxiosInstance";

const BASE_URL = process.env.REACT_APP_API_OASE_MONITORING;
const USE_FETCH_MSG = {
	ERROR: "Tidak dapat mengambil data!",
};

const axios = get();

const useFetch = (url, container, version = "v1", skip = false) => {
	const [data, setData] = useState([]);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState("");
	const [isSkip, setIsSkip] = useState(skip);

	const fetch = async (url, container, version = "v1") => {
		const endpoint = `${BASE_URL}/${container}/${version}/${url}`;

		try {
			setIsLoading(true);

			const response = await new Promise((resolve, reject) => {
				(async () => {
					try {
						const res = await axios.get(endpoint);
						resolve(res);
					} catch (err) {
						reject(err);
					}
				})()
			});

			setData(response.data);
		} catch (err) {
			setError(USE_FETCH_MSG.ERROR);
			throw err;
		} finally {
			setIsLoading(false);
		}
	};

	const unSkip = () => {
		setIsSkip(false);
	}

	useEffect(() => {
		if (!isSkip) {
			fetch(url, container, version);
		} else {
			setIsLoading(false);
			setData(undefined);
		}
	}, []);

	return { data, isLoading, error, fetch, unSkip };
};

export default useFetch;
