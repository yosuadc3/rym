import { hasRoles } from "../../token/roles";

function showMenu(items) {
    const roles = items.map(value => value.roles).flat();

    if (hasRoles(roles)) {
        return true;
    }

    return false;
}

export default showMenu;