export const toParams = (paramsDict) => {
	let stringParams = "";
	Object.keys(paramsDict).forEach((key, i) => {
		const param = `${key}=${encodeURIComponent(paramsDict[key])}`;
		if (i === 0) {
			stringParams += param;
		} else {
			stringParams += `&${param}`;
		}
	});
	return stringParams;
};
