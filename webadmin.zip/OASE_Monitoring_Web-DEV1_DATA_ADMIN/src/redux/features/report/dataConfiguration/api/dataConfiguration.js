import { createApi } from "@reduxjs/toolkit/query/react";
import { BASE_URL_API_MONITORING } from "../../../../../constants/Api";
import axiosBaseQuery from "../../../../utils/axiosBaseQuery";

const GET = "GET"
const path = "/report/data-configuration";

export const reportDataConfigurationApi = createApi({
   reducerPath: "reportDataConfigurationApi",
   baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
   endpoints: (builder) => ({
      getListDataConfiguration: builder.query({
         query: (params = '') => ({
            url: path + `/category`, method: GET, params
         }),
         transformResponse: (res) => {
            return res?.data?.list;
         }
      }),
      getLogPerubahanTablePreview: builder.query({
         query: (params) => ({
            url: path + "/log",
            method: GET,
            params
         }),
      }),
   })
});

export const {
   useGetListDataConfigurationQuery,
   useGetLogPerubahanTablePreviewQuery
} = reportDataConfigurationApi;