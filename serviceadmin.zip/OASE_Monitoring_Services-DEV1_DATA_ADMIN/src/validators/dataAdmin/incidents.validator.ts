import { body, param, query } from "express-validator";

export const getIncidents = [
   query("page").isString(),
   query("limit").isString(),
   query("sortBy").isString(),
   query("orderBy").isString(),  
   query("search").optional().isJSON(),
   query("advancedSearch").optional().isJSON(),
   query("advancedSearchPeriode").optional().isJSON()
];