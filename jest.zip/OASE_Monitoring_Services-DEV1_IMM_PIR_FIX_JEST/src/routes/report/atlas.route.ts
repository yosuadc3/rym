const router = require("express").Router();
import * as controller from "../../controllers/report/atlas.controller";
const keycloak = require("../../middlewares/keycloakHandler.middleware").get();

router.get(
	"/",
	keycloak.protect("realm:GET_REPORT_ATLAS"),
	controller.getReport
);
router.get(
	"/download",
	keycloak.protect("realm:GET_REPORT_ATLAS"),
	controller.getReportDownload
);
router.get(
	"/filter",
	keycloak.protect("realm:GET_REPORT_ATLAS"),
	controller.getReportFilter
);
router.get(
	"/type",
	keycloak.protect("realm:GET_REPORT_ATLAS"),
	controller.getReportType
);

export default router;
export { };

