export const CENTER_COLUMNS = {
  headerAlign: "center",
  align: "center",
  flex: 1
};
