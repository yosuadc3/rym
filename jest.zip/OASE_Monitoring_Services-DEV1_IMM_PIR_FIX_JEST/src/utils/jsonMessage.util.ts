import { Response } from "express";
import * as status from "../constants/httpResponseCodes.constant";

type TMessage = {
	english: string;
	indonesia: string;
};

export const jsonSuccess = (msg: TMessage, data: object = {}) => {
	return {
		error_code: "OASE-00",
		error_message: msg,
		data: data,
	};
};

export const jsonFailed = (
	code: string | number,
	errno: string,
	errMessage: string,
	errCode: string
) => {
	return {
		error_code: `OASE-${errCode}`,
		error_message: {
			code,
			errno,
			message: errMessage,
		},
	};
};

export const getInternalServerError = (
	err: any,
	res: Response,
	defaultMessage: string | unknown
) => {
	const { HTTP_INTERNAL_SERVER_ERROR } = status;
	const errMessage = err?.message || defaultMessage;

	if (err) {
		const statusCode = err.response?.status || HTTP_INTERNAL_SERVER_ERROR;

		return res
			.status(statusCode)
			.send(jsonFailed(err.code, err.errno, errMessage, "30"));
	}

	return res
		.status(HTTP_INTERNAL_SERVER_ERROR)
		.send(
			jsonFailed(
				HTTP_INTERNAL_SERVER_ERROR,
				"The request could not be made due to an internal server error",
				errMessage,
				"30"
			)
		);
};

export { };

