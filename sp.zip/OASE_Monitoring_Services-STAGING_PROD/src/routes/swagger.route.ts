import swagger from "swagger-ui-express";
import path from "path";
import yaml from "yamljs";
// const swagger = require("swagger-ui-express");
const router = require("express").Router();
// const path = require("path");
// const yaml = require("yamljs");

const docs = yaml.load(path.resolve("src", "swagger", "docs.yaml"));
const options = {};

router.use("/", swagger.serveFiles(docs, options), swagger.setup(docs));

export default router;
