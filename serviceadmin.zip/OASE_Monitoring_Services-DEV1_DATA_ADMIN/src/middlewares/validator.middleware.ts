import { NextFunction, Response, query } from "express";
import { body, validationResult } from "express-validator";
import { BadRequestError } from "../errors/client.error";
import { IRequestAPI } from "../types/global.type";

const VALIDATOR_ERROR = "VALIDATOR_ERROR";

const getValidationFields = (validations: any[], params: "body" | "query") => {
   return validations
      .filter(
         (validation) =>
            validation.hasOwnProperty("builder") && validation.builder.locations[0] === params
      )
      .map((validation) => validation.builder.fields)
      .flat();
};

const getUnexpectedParams = (req: IRequestAPI, fields: any[], route: string = '') => {
   return Object.keys(req).filter((param) => !fields.includes(param));
};

export default function (validations: any[]) {
   return async (req: IRequestAPI, _res: Response, next: NextFunction) => {

      const bodyFields = getValidationFields(validations, "body");
      const unexpectedBodyParams = getUnexpectedParams(req.body, bodyFields);
      if (unexpectedBodyParams.length > 0) {
         throw new BadRequestError(
            "Unexpected body paramater(s)",
            VALIDATOR_ERROR
         );
      }

      const queryFields = getValidationFields(validations, "query");
      const unexpectedQueryParams = getUnexpectedParams(req.query, queryFields);
      if (unexpectedQueryParams.length > 0) {
         throw new BadRequestError(
            "Unexpected query paramater(s)",
            VALIDATOR_ERROR
         );
      }

      const errors = validationResult(req);

      if (errors.isEmpty()) {
         return next();
      }

      throw new BadRequestError(JSON.stringify(errors.array()), VALIDATOR_ERROR);
   };
}
