import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    type: "",
    filter: null,
    periode: {
        startDate: null,
        endDate: null
    }
}

const reportAtlasSlice = createSlice({
    name: "reportAtlas",
    initialState: initialState,
    reducers: {
        setType: (state, action) => {
            const { payload } = action;
            state.type = payload;
        },
        setFilter: (state, action) => {
            const { payload } = action;
            state.filter = payload;
        },
        setPeriode: (state, action) => {
            const { payload } = action;
            state.periode = payload;
        }
    }
});

export const { setFilter, setPeriode, setType } = reportAtlasSlice.actions;

export default reportAtlasSlice;
