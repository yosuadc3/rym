import * as lostComm from "../../controllers/lostComm/lostComm.controller";
const keycloak = require("../../middlewares/keycloakHandler.middleware").get();
let router = require("express").Router();

router.get("/", keycloak.protect("realm:GET_LOST_COMM"), lostComm.getLostComm);
router.get(
	"/report",
	keycloak.protect("realm:GET_LOST_COMM_REPORT"),
	lostComm.getLostCommReport
);

export default router;
export { };

