import { Box, Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";

import StyledAccordion from "../../../../components/accordion/StyledAccordion";
import CustomBreadcrumbs from "../../../../components/breadcrumb/CustomBreadcrumbs";
import StyledPaper from "../../../../components/paper/StyledPaper";
import { setTicketId } from "../../../../redux/features/incident-management-monitoring/incident-management/imm";
import { INCIDENT_MANAGEMENT_DETAIL_BREADCRUMBS } from "./constants/IncidentManagementDetail";

import CommentDialog from "./components/detail/CommentDialog.component";
import CurrentIncident from "./components/detail/CurrentIncident.component";
import IncidentHistory from "./components/detail/IncidentHistory.component";
import TerminalDetails from "./components/detail/TerminalDetails.component";

export default function IncidentManagementDetail() {
  const dispatch = useDispatch();
  const { ticketId, wsidId } = useParams();

  const { isOpenDialogViewComments } = useSelector(
    (state) => state.incidentManagement
  );

  const [_wsid, setWSID_] = useState();
  const [wsid, setWSID] = useState("");
  const [lastUpdate, setLastUpdate] = useState("-");

  useEffect(() => {
    // setLoadingTicketID(false);
    dispatch(setTicketId({
      data: {
        ticketId
      }
    }))
  }, [ticketId]);

  const handleWSIDChange = (arg) => {
    setWSID((_) => arg);
  };

  const handleWSIDChange_ = (arg) => {
    setWSID_((_) => arg);
  };

  const handleLastUpdateChange = (arg) => {
    setLastUpdate((_) => arg);
  };

  return (
    <Box>
      <Grid container alignItems={"center"} height={60}>
        <Grid item xs>
          <CustomBreadcrumbs
            breadcrumbs={INCIDENT_MANAGEMENT_DETAIL_BREADCRUMBS(
              wsid,
              lastUpdate
            )}
          />
        </Grid>
      </Grid>
      <StyledPaper>
        <Grid container>
          <Grid item xs={12}>
            <StyledAccordion title="Current Incident" defaultExpanded>
              <CurrentIncident
                scrollTo
                ticketId={ticketId}
                wsidId={wsidId}
                handleWSIDChange={handleWSIDChange}
                handleWSIDChange_={handleWSIDChange_}
              />
            </StyledAccordion>
          </Grid>
        </Grid>
        <Grid container paddingTop={2}>
          <Grid item xs={12}>
            <StyledAccordion title="Terminal Details" defaultExpanded>
              <TerminalDetails
                ticketId={ticketId}
                wsid={wsid}
                _wsid={_wsid}
                handleLastUpdateChange={handleLastUpdateChange}
              />
            </StyledAccordion>
          </Grid>
        </Grid>
        <Grid container paddingTop={2}>
          <Grid item xs={12}>
            <StyledAccordion title="Incident History" defaultExpanded>
              <IncidentHistory wsid={wsid} />
            </StyledAccordion>
          </Grid>
        </Grid>
      </StyledPaper>
      <CommentDialog
        isOpenDialog={isOpenDialogViewComments}
      />
    </Box>
  );
}
