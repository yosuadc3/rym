import { getDecodedToken } from "./action";

const LOCAL_STORAGE_ROLES = "roles";

function getRoles() {
  const data = localStorage.getItem(LOCAL_STORAGE_ROLES) || "[]";
  const roles = JSON.parse(data);

  return roles;
}

function hasRoles(requiredRoles) {
  const roles = getRoles();

  if (requiredRoles) {
    return requiredRoles.some((requiredRole) => roles.includes(requiredRole));
  }

  return true;
}

export { getRoles, hasRoles };
