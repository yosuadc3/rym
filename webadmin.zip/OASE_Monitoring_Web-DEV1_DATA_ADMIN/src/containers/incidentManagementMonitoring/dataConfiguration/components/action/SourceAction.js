import React from 'react';
import { Grid,Stack } from '@mui/material';
import Trash from '../Trash';
import Pencil from '../Pencil';
import { useDispatch} from "react-redux";
import { handleRemoveSource, handleUpdateSource, setData } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/eventCodeSource";

const styles = {
    view:{
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)"
    },
    icon:{
        '&:hover': {
          color: '#0D5CAB'
        },
        color: "#8D8D8D",
      }
  }

export default function SourceAction(data){  
    const dispatch = useDispatch();  
    const updateData = (e) => {
        e.stopPropagation();
        dispatch(setData(data));
        dispatch(handleUpdateSource());
    }
    const deleteData = (e) => {
        e.stopPropagation();
        dispatch(setData(data));
        dispatch(handleRemoveSource());
    }
  

    return(
        <Grid >
                <Stack direction="row" gap={2}>
                    <Pencil onClick={updateData}
                        onMouseDown={(e) => e.stopPropagation()}
                        sx={styles.icon}
                    />
                    <Trash onClick={deleteData} 
                        onMouseDown={(e) => e.stopPropagation()}
                        sx={styles.icon}
                    />
                </Stack>
        </Grid>
    );
}