import { CENTER_COLUMNS } from "../../../../utilities/MaterialUI";

export const filterBoxStyles = {
  label: {
    color: "#65748B",
    fontSize: "14px",
    fontWeight: 600,
  },
  btnSearch: {
    width: 120,
    backgroundColor: "#0D5CAB",
    height: 48,
    color: "white",
    borderRadius: 1,
    fontSize: 16,
    fontFamily: "Montserrat",
    textTransform: "inherit",
    marginLeft: 2,
    "&:hover": {
      backgroundColor: "#125fa1",
    },
    "&:active": {
      backgroundColor: "#0D5CAB",
    },
  },
  btnResetFilter: {
    textTransform: "inherit",
    backgroundColor: "transparent",
    border: "transparent",
    fontSize: "14px",
    color: "#156DB8",
    fontFamily: "Montserrat",
    fontWeight: 600,
    px: 1,
    "&:hover": {
      backgroundColor: "transparent",
    },
    "&:active": {
      backgroundColor: "transparent",
    },
  },
  btnAddSearchCategory: {
    marginTop: "10px",
    border: "transparent",
    backgroundColor: "transparent",
    fontSize: "12px",
    color: "#156DB8",
    textDecoration: "underline",
    fontWeight: 600,
    cursor: "pointer",
  },
  btnDeleteSelect: {
    px: 0,
    py: 0,
    "&:hover": {
      backgroundColor: "transparent",
    },
    minWidth: 0,
  },
};

export const styles = {
  reportTitle: {
    fontSize: 20,
    fontFamily: "Montserrat",
    fontWeight: 600,
    color: "#333333",
    textAlign: "left",
  },
  reportDescription: {
    fontSize: 12,
    textAlign: "left",
    fontFamily: "Montserrat",
    fontWeight: 500,
    color: "#333333",
    whiteSpace: "nowrap",
  },
  filterBtnDiv: {
    display: "flex",
    justifyContent: "center",
    alignContent: "center",
  },
  filterBtn: {
    fontFamily: "Montserrat",
    fontWeight: 700,
    textTransform: "inherit",
    width: 127,
    height: 48,
    fontSize: 18,
    backgroundColor: "#FFFF",
    color: "#0D5CAB",
    borderRadius: 1,
    boxSizing: "border-box",
    border: "1px solid #0D5CAB",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingX: 3,
  },
  filterIcon: {
    transform: "scale(1.2)",
  },
  popupBox: {
    marginTop: 2,
    width: 406,
    height: 557,
    borderRadius: 2,
    background: "white",
    padding: 4,
    overflowX: "auto",
  },
  label: {
    color: "#65748B",
    fontWeight: 600,
    fontFamily: "Montserrat",
    fontSize: 14,
    textAlign: "left",
  },
  periode: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 10,
    marginTop: 10,
    height: 5,
  },
  seperator: {
    width: "10%",
    margin: "0 16px",
    alignItems: "center",
    height: 0,
    marginTop: 24,
  },
  tableDiv: (isOpenFilterBox) => ({
    width: "100%",
    marginLeft: isOpenFilterBox ? "16px" : "0px",
    marginTop: "16px",
    display: "flex",
    flexDirection: "column",
  }),
  tableBox: {
    height: 611,
    width: "100%",
    backgroundColor: "white",
    overflowX: "auto",
    padding: 2,
  },
  downloadDiv: {
    marginLeft: "auto",
    marginTop: "12px",
    marginBottom: "12px",
    float: "right",
  },
  downloadBtn: {
    marginRight: "auto",
    width: 120,
    backgroundColor: "#0D5CAB",
    height: 48,
    color: "white",
    borderRadius: 1,
    fontSize: 16,
    fontFamily: "Montserrat",
    textTransform: "inherit",
    marginLeft: 2,
    "&:hover": {
      backgroundColor: "#125fa1",
    },
    "&:active": {
      backgroundColor: "#0D5CAB",
    },
  },
};

export const REPORT_INCIDENT_BREADCRUMBS = [
  {
    item: "Home",
    link: "/",
    current: false,
  },
  {
    item: "Report Incident Management",
    link: null,
    current: true,
  },
];

export const REPORT_FILTER_COLUMNS = [
  { id: "ticket_id", label: "Incident Number" },
  { id: "wsid", label: "WSID" },
  { id: "lok", label: "Lok" },
  { id: "lokasi", label: "Lokasi" },
  { id: "tipe_mesin", label: "Tipe Mesin" },
  { id: "vendor_mesin", label: "Vendor Mesin" },
  { id: "start_time", label: "Start Time" },
  { id: "end_time", label: "End Time" },
  { id: "duration", label: "Duration" },
  { id: "status_code_description", label: "Status Code - Description" },
];

export const REPORT_HEADER = [
  {
    headerName: "Incident Number",
    field: "id",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "WSID",
    field: "wsid",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Lok",
    field: "lok",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Lokasi",
    field: "lokasi",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Tipe Mesin",
    field: "tipe_mesin",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Vendor Mesin",
    field: "vendor_mesin",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Start Time",
    field: "start_time",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "End Time",
    field: "end_time",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Duration",
    field: "duration",
    ...CENTER_COLUMNS,
    minWidth: 150,
  },
  {
    headerName: "Status Code - Description",
    field: "status_code_description",
    ...CENTER_COLUMNS,
    minWidth: 300,
  },
];

export const FILTER_OBJ = {
  category: "",
  values: [],
};

export const DATE_OBJ = {
  start: null,
  end: null,
};