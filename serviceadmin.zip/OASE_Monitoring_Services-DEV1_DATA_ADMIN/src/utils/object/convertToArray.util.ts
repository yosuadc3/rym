export function getObjectKeys(obj: { [key: string]: unknown }) {
    return Object.keys(obj);
}

export function getObjectValues(obj: { [key: string]: unknown }) {
    return Object.values(obj);
}

export function getObjectValuesOfArrayObject(arr: [{ [key: string]: unknown }],) {
    const newArr: any = [];
    arr.forEach((x) => newArr.push(Object.values(x)));
    return newArr.flat();
}

export function getObjectEntries(obj: { [key: string]: unknown }) {
    return Object.entries(obj);
}

export { }