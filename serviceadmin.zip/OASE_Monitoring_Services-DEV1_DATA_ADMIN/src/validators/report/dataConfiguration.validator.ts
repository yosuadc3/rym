import { body, param, query } from "express-validator";

export const getReportCategory = [
    query("type").isNumeric()
];

export const getReportData = [
    query("arrayParam").optional()
];

export const getReportLog = [
    query("start_period").isString(),
    query("end_period").isString(),
    query("types").optional().isString()
];