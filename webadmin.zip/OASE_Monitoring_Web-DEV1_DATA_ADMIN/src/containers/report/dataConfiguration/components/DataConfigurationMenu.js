import Delete from "@mui/icons-material/Delete";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import ButtonCommon from "../../../../components/buttons/ButtonCommon";
import BasicSelect from "../../../../components/form/BasicSelect";
import {
   FILTER_OBJ,
   filterBoxStyles,
} from "../constants/ReportDataConfiguration";
import CategoryDropdown from "./CategoryDropdown";

function FilterCategoryComponent({
   id,
   type,
   categories,
   options,
   handleSelectCategory,
   handleSelectValues,
   handleDelete,
   selectedCategory,
   selectedValues,
   isDisabled = false,
}) {
   return (
      <Grid key={id} container marginBottom={1} paddingRight={1}>
         <Grid item xs={id === 0 ? 6 : 5.5}>
            <BasicSelect
               items={categories}
               onChange={(e) => handleSelectCategory(e, id)}
               value={selectedCategory}
               useSmallSize
               disabled={isDisabled}
            />
         </Grid>
         <Grid item xs={id === 0 ? 6 : 5.5} paddingLeft={1}>
            <CategoryDropdown
               type={type}
               onChange={(_, values) => handleSelectValues(values, id)}
               options={options}
               value={selectedValues}
               useSmallSize
               disabled={isDisabled}
            />
         </Grid>
         {id === 0 ? null : (
            <Grid item alignSelf={"center"} textAlign={"center"} xs={1}>
               <ButtonCommon
                  handleClick={() => handleDelete(id)}
                  label={<Delete sx={{ color: "#8D8D8D" }} />}
                  variant={"text"}
                  sx={filterBoxStyles.btnDeleteSelect}
                  disabled={isDisabled}
               />
            </Grid>
         )}
      </Grid>
   );
}

export default function DataConfigurationMenu({
   categories,
   values,
   freeSolo,
   handleHasSearch,
   getter,
   filter,
   disabled,
   setFilter,
}) {
   const [SelectCategoryComponents, setSelectCategoryComponents] = useState([]);

   const handleSelectCategory = (event, index) => {
      const { value } = event.target;
      const selected = {
         ...FILTER_OBJ,
         category: value,
      };

      setFilter((prev) => Object.assign([...prev], { [index]: selected }));
   };

   const handleSelectValues = (values, index) => {
      const selected = {
         ...filter[index],
         values: values,
      };

      setFilter((prev) => Object.assign([...prev], { [index]: selected }));
   };

   const handleDelete = (index) => {
      const temp = [...filter];
      temp.splice(index, 1);
      setFilter(temp);
   };

   const handleAddSearchCategory = () => {
      setFilter((prev) => [...prev, FILTER_OBJ]);
   };

   useEffect(() => {
      const selectedCategories = filter.map((item) => item.category);
      const components = filter.map((item, index) => {
         const toBeRemoved = selectedCategories.filter(
            (category) => category !== item.category
         );
         const categoryList = categories.filter(
            (x) => !toBeRemoved.includes(x.id)
         );
         const selectedCategory = item?.category;
         const selectedValues = item?.values;
         const selectedCategoryType = selectedCategories[0];

         return FilterCategoryComponent({
            id: index,
            type: selectedCategoryType,
            categories: categoryList,
            handleSelectCategory,
            handleSelectValues,
            handleDelete,
            selectedCategory,
            selectedValues,
            freeSolo,
            isDisabled: disabled,
         });
      });

      setSelectCategoryComponents(components);
   }, [filter, values, disabled]);

   return (
      <>
         <Grid item>
            <Grid container direction="column" spacing={1}>
               <Grid item>
                  <Typography sx={filterBoxStyles.label}>
                     Kategori
                  </Typography>
               </Grid>
               <Grid item>{SelectCategoryComponents}</Grid>
            </Grid>
         </Grid>
         {filter.length < categories.length ? (
            <Grid item marginTop={-3}>
               <button
                  onClick={handleAddSearchCategory}
                  style={filterBoxStyles.btnAddSearchCategory}
               >
                  Tambah kategori pencarian
               </button>
            </Grid>
         ) : null}
      </>)
}