import { NumberOrUndefined } from "./src/types/global.type"

declare namespace NodeJS {
   interface ProcessEnv {
      PORT: string
      NODE_ENV: string

      // vision4
      DB_SERVER_VISION: string
      DB_USER_VISION: string
      DB_PASSWORD_VISION: string
      DB_PORT_VISION: number
      DB_SCHEMA_VISION: string
      DB_CONNECTION_TIMEOUT_VISION: number
      DB_REQUEST_TIMEOUT_VISION: number

      // oase
      DB_USER_OASEMON: string
      DB_PASSWORD_OASEMON: string
      DB_HOST_OASEMON: string
      DB_PORT_OASEMON: number
      DB_SCHEMA_OASEMON: string
      DB_SCHEMA_OASE: string
      DB_CHARSET_OASEMON: string

      // gasper
      DB_USER: string
      DB_PASSWORD: string
      DB_HOST: string
      DB_PORT: number
      DB_SERVICE_NAME: string
   }
}