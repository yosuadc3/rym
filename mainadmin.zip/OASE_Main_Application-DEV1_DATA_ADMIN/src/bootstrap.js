import { CircularProgress } from '@mui/material';
import React from "react";
import ReactDOM from "react-dom";
import { registerApplication, start } from "single-spa";
import BaseDialog from "./components/dialog/BaseDialog";
import { getVPNUrl, hasVPNURrl } from './utilities/Vpn';

const urlVpn = getVPNUrl();

registerApplication({
    name: "navigation",
    app: () => import("./singleSPA/navigation"),
    activeWhen: [`${urlVpn}`]
});

registerApplication({
    name: "main",
    app: () => import("./singleSPA/main"),
    activeWhen: [`${urlVpn}`]
});

registerApplication({
    name: "profile",
    app: () => import("./singleSPA/profile"),
    activeWhen: [`${urlVpn}/#/profile`]
});

registerApplication({
    name: "monitoring",
    app: () => loadApp(
        import("OASE_MONITORING/monitoring")
    ),
    activeWhen: [`${urlVpn}/#/monitoring`]
});

registerApplication({
    name: "asset",
    app: () => loadApp(
        import("OASE_ASSET/asset")
    ),
    activeWhen: [`${urlVpn}/#/asset`]
});

function loadApp(importApp) {
    return Promise.resolve().then(() => {
        placeLoader()
        return importApp
    }).then(app => {
        removeLoader()
        return app;
    }).catch(error => {
        removeLoader()
        return error
    });
}

function placeLoader() {
    const foo = document.createElement('div');
    foo.setAttribute("id", "single-spa-loader");
    document.body.appendChild(foo)

    ReactDOM.render(<BaseDialog open={true} type="progress" />, foo)
}

function removeLoader() {

    ReactDOM.render(<BaseDialog open={false} type="progress" />, document.getElementById('single-spa-loader'))
    document.getElementById('single-spa-loader').remove()
}

start({
    urlRerouteOnly: true
});