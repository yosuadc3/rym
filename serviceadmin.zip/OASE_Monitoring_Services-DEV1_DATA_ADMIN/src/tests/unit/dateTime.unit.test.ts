import { UTCTimeFormat, readableTimeFormat, secondsToReadableFormat } from "../../utils/dateTime.util";

const testReadableTimeFormat = (testCase: string, days: number, hours: number, minutes: number) => {
   test(testCase, () => {
      const currDate = readableTimeFormat(days, hours, minutes);
      const expectCurrDate = expect(currDate);

      expectCurrDate.toBeDefined();
      expectCurrDate.toBe(testCase);
   })
}

describe('utils/dateTime.util', () => {
   describe('readableTimeFormat', () => {
      testReadableTimeFormat('5 days 10 hours 21 minutes', 5, 10, 21);
      testReadableTimeFormat('1 day 10 hours 10 minutes', 1, 10, 10);
      testReadableTimeFormat('21 days 1 hour 10 minutes', 21, 1, 10);
      testReadableTimeFormat('21 days 1 hour 1 minute', 21, 1, 1);
      testReadableTimeFormat('5 days 10 hours 21 minutes', 5, 10, 21);
      testReadableTimeFormat('1 day 1 hour 1 minute', 1, 1, 1);
   })

   describe('secondsToReadbleFormat', () => {
      test('0 minute', () => {
         const seconds = secondsToReadableFormat(0, true);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("0 minute");
      })
      test('59 seconds', () => {
         const seconds = secondsToReadableFormat(59, true);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("0 minute");
      })
      test('Just now!', () => {
         const seconds = secondsToReadableFormat(0, false);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("Just now!");
      })
      test('Just now! - 59 seconds', () => {
         const seconds = secondsToReadableFormat(59, false);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("Just now!");
      })
      test('3600 seconds', () => {
         const seconds = secondsToReadableFormat(3600);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("1 hour");
      })
      test('3601 seconds', () => {
         const seconds = secondsToReadableFormat(3601);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("1 hour");
      })
      test('3660 seconds', () => {
         const seconds = secondsToReadableFormat(3660);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("1 hour 1 minute");
      })
      test('3659 seconds', () => {
         const seconds = secondsToReadableFormat(3659);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("1 hour");
      })
      test('3599 seconds', () => {
         const seconds = secondsToReadableFormat(3599);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("59 minutes");
      })
      test('600 seconds', () => {
         const seconds = secondsToReadableFormat(600);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("10 minutes");
      })
      test('4200 seconds', () => {
         const seconds = secondsToReadableFormat(4200);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("1 hour 10 minutes");
      })
      test('7200 seconds', () => {
         const seconds = secondsToReadableFormat(7200);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("2 hours");
      })
      test('90061 seconds', () => {
         const seconds = secondsToReadableFormat(90061);
         const expectSeconds = expect(seconds);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("1 day 1 hour 1 minute");
      })
   })
   describe('UTCTimeFormat', () => {
      test('2023-05-31T01:58:39Z', () => {
         const utc = UTCTimeFormat('2023-05-31T01:58:39Z');
         const expectSeconds = expect(utc);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("31/05/2023 01:58");
      })
      test('2023-05-22T01:58:39Z', () => {
         const utc = UTCTimeFormat('2023-05-22T01:58:39Z');
         const expectSeconds = expect(utc);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("22/05/2023 01:58");
      })
      test('2022-05-22T01:58:39Z', () => {
         const utc = UTCTimeFormat('2022-05-22T01:58:39Z');
         const expectSeconds = expect(utc);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("22/05/2022 01:58");
      })
      test('2022-05-22T22:58:39Z', () => {
         const utc = UTCTimeFormat('2022-05-22T22:58:39Z');
         const expectSeconds = expect(utc);

         expectSeconds.toBeDefined();
         expectSeconds.toBe("22/05/2022 22:58");
      })
   })
})