//ASAP DEPENDENCIES
require("dotenv").config();

//DEPENDENCIES
const os = require("os");
const server = require("./src/server/main.server");
const oracle = require("./src/databases/gasper.database");
import * as mysql from "./src/databases/oase.database";
const sqlserver = require("./src/databases/vision4.database");

process.env.UV_THREADPOOL_SIZE = os.cpus().length;
// console.log(`NumOfCPU: ${os.cpus().length}`);

//Function to Establish DB Connection and Start the Server
async function start() {
	try {
		await oracle.init();

		await mysql.connect();

		await sqlserver.initSQLServer();

		await server.init();

		// console.log("Init scheduler");
		// scheduler();
	} catch (error) {
		console.log(error);
		process.exit(1);
	}
}

//Function to Terminate DB Connection and Shutdown the Server
// @ts-ignore
async function shutdown(e) {
	let error = e;
	console.log("Shutting down application");

	try {
		console.log("Shutting OASE Monitoring Services");
		await server.close();

		console.log("Shutting GASPER");
		await oracle.close();

		console.log("Shutting doase");
		await mysql.disconnect();
	} catch (msg) {
		error = msg || e;
	}

	console.log("Process exited");

	if (error) {
		process.exit(1);
	} else {
		process.exit(0);
	}
}

process.on("SIGTERM", (e) => {
	console.log("SIGTERM");
	shutdown(e);
});

process.on("SIGINT", (e) => {
	console.log("SIGINT");
	shutdown(e);
});

process.on("uncaughtException", (e) => {
	console.log("Uncaught exception");
	console.error(e);

	shutdown(e);
});

start();
