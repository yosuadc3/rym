import { IPagination, IRequestAPI, StringOrUndefined } from "../global.type";

export type TStatusDataMapperItem = Array<{
	last_received: string,
	duration: number
}>;

export type TMappingItems = {
	id: string;
	summary: string;
	color: string;
	count: number;
};

interface ISortBy {
	sortBy: string;
}

interface IOrderBy {
	orderBy: string;
}

interface ICategory {
	category: StringOrUndefined;
}

interface IValue {
	value: StringOrUndefined;
}

interface ISearch {
	search: StringOrUndefined;
}

interface IAdvancedSearch {
	advancedSearch: StringOrUndefined;
	advancedSearchPeriode: string;
}

interface IGetStatusQuery extends IPagination, ISearch, IAdvancedSearch { }
export interface IGetStatusRequest extends IRequestAPI {
	query: IGetStatusQuery;
}

interface IGetReportQuery extends ISortBy, IOrderBy, ISearch, IAdvancedSearch { }
export interface IGetReportRequest extends IRequestAPI {
	query: IGetReportQuery;
}

export interface IGetDSAStatsRequest extends IRequestAPI { }

interface IGetSummaryQuery extends ICategory, IValue { }
export interface IGetSummaryRequest extends IRequestAPI {
	query: IGetSummaryQuery;
}

export interface IGetSearchItems extends IRequestAPI { }
