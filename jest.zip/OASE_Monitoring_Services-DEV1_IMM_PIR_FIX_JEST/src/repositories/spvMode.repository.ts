const constant = require("../constants/spvMode.constant");
const dbExec = require("../databases/gasper.database").exec;

function get() {
  const query = `SELECT SUBSTR(DESCRIPTION,1,4) AS PENGELOLA, COUNT(*) AS JUMLAH FROM GASPER_OBJECT GO JOIN INSTITUTION I ON GO.INSTITUTION_LINK = I.LINK
        WHERE OBJECT_KEY IN (SELECT DISTINCT OBJECT_KEY FROM OPEN_TICKET WHERE ACTION_CODE_KEY in (${constant.SPV_MODE_ACTION_CODE_KEY}))
        GROUP BY DESCRIPTION
        ORDER BY DESCRIPTION ASC`;

  return dbExec(query);
}

function getByFLM(id: string) {
  const query = `SELECT COUNT(*) as jml, ID, SUBSTR(DESCRIPTION,1,4) as flm FROM GASPER_OBJECT GO JOIN INSTITUTION I ON GO.INSTITUTION_LINK = I.LINK 
        WHERE OBJECT_KEY IN (SELECT DISTINCT OBJECT_KEY FROM OPEN_TICKET WHERE ACTION_CODE_KEY in (${constant.SPV_MODE_ACTION_CODE_KEY}))
        and DESCRIPTION like '%${id}%' GROUP BY DESCRIPTION, id`;

  return dbExec(query);
}

function getDetail() {
  // const query =
  //     `SELECT ID, SUBSTR(DESCRIPTION,1,4) AS PENGELOLA
  //     FROM GASPER_OBJECT GO JOIN INSTITUTION I ON GO.INSTITUTION_LINK = I.LINK
  //     WHERE OBJECT_KEY IN (SELECT DISTINCT OBJECT_KEY FROM OPEN_TICKET WHERE ACTION_CODE_KEY in (${constant.SPV_MODE_ACTION_CODE_KEY}))
  //     ORDER BY DESCRIPTION ASC`;

  const query = `SELECT LISTAGG(ID, ',') WITHIN GROUP(ORDER BY ID) AS ID, COUNT(ID) AS JUMLAH, SUBSTR(DESCRIPTION,1,4) AS PENGELOLA 
    FROM GASPER_OBJECT GO JOIN INSTITUTION I ON GO.INSTITUTION_LINK = I.LINK 
    WHERE OBJECT_KEY IN (SELECT DISTINCT OBJECT_KEY FROM OPEN_TICKET WHERE ACTION_CODE_KEY in (${constant.SPV_MODE_ACTION_CODE_KEY}))
    GROUP BY DESCRIPTION
    ORDER BY DESCRIPTION ASC`;

  return dbExec(query);
}

function getReport() {
  const query = `SELECT ID, TICKET_KEY, ADDRESS as LOCATION, I.DESCRIPTION AS PENGELOLA,s.DESCRIPTION AS STATUS_CODE_DESCRIPTION, 
        to_CHAR(Start_time,'mm/dd/yyyy') as TICKET_START_DATE, 
        to_CHAR(Start_time,'HH24:MI:SS') as TICKET_START_TIME, 
        to_CHAR(end_time, 'mm/dd/yyyy') as TICKET_END_DATE,
        to_CHAR(end_time, 'HH24:MI:SS') as TICKET_END_TIME,
        to_CHAR((end_time-start_time)+(end_time-start_time)*60+(end_time-start_time)*24*60,99999999) as DURATION_IN_MINUTES,
        go.notes AS ADDRESS, floor(go.operation_hour_start1/60) as JAM_OPR_START, 
        CONCAT(CONCAT(to_CHAR(floor(go.operation_hour_end1/60)),':'), to_CHAR(mod(go.operation_hour_end1,60))) as JAM_OPR_END
        FROM gasper_object go join ticket t on go.object_key = t.object_key 
        join status_code s on s.LINK = t.status_code_key 
        join INSTITUTION I on I.LINK = go.INSTITUTION_LINK
        where action_code_key in(${constant.SPV_MODE_ACTION_CODE_KEY}) and
        Start_time >= TRUNC(SYSDATE)`;

  return dbExec(query);
}

function getTotal() {
  const query = `SELECT COUNT(ID) AS JUMLAH
    FROM GASPER_OBJECT GO
    WHERE OBJECT_KEY IN (SELECT DISTINCT OBJECT_KEY FROM OPEN_TICKET WHERE ACTION_CODE_KEY in (${constant.SPV_MODE_ACTION_CODE_KEY}))`;

  return dbExec(query);
}

module.exports = {
  get,
  getByFLM,
  getDetail,
  getReport,
  getTotal,
};

export { };

