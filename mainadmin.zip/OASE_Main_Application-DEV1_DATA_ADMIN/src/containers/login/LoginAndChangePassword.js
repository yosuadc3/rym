import React, { useState } from "react";
import InputForm from "../../components/login/InputForm";
import { setRefreshToken, setToken } from "../../token/action";
import { getGroups } from "../../token/groups";
import { axiosGet, axiosPost } from "../../utilities/AxiosHelper";

const API_URI = process.env.REACT_APP_API_OASE;

function hasOASEGroups(token) {
    const defaultGroups = ["/LDAP_USER", "/USER_MGMT"];
    const groups = getGroups();

    const groupsDifference = groups.filter(el => !defaultGroups.includes(el));

    if (groupsDifference.length === 0) {
        return false;
    }

    return true;
}

function LoginAndChangePassword() {
    const [loginMode, setLoginMode] = useState(true);
    const [errorMessage, setErrorMessage] = useState(null);
    const [username, setUsername] = useState("");

    const handleLogin = async (data) => {
        setErrorMessage(null);

        try {
            const response = await axiosPost(API_URI, "/usersession/login-web", data);
            const token = response.data?.access_token;
            const refreshToken = response.data?.refresh_token;
            const errorMessage = response.error_message?.message || "";

            if (token && refreshToken) {

                // if (hasOASEGroups(token)) {
                // localStorage.setItem("token", token);
                // localStorage.setItem("refreshToken", response.data.data.refresh_token);
                setToken(token);
                setRefreshToken(refreshToken);

                // set id vendor provider, id warehouse, roles,
                let getGroup = await axiosGet(API_URI, "/usersession/groups");
                let getRoles = await axiosGet(API_URI, "/usersession/roles");

                if (getGroup.data) {
                    const idWh = parseInt(getRoles.data.id_warehouse);
                    const idVendor = parseInt(getRoles.data.id_vendor_provider);
                    const is_bca = parseInt(getRoles.data.is_bca);
                    localStorage.setItem(
                        "roles",
                        JSON.stringify(getRoles.data.roles)
                    );
                    localStorage.setItem("id_warehouse", JSON.stringify(idWh));
                    localStorage.setItem("id_vendor_provider", JSON.stringify(idVendor));
                    localStorage.setItem("is_bca", JSON.stringify(is_bca));
                    let user_group = [];
                    getGroup.data.forEach(element => {
                        user_group.push(element.name);
                    });
                    localStorage.setItem("user_group", JSON.stringify(user_group));

                }

                window.location.reload();
                // }
                // else {
                //     setErrorMessage("Not Authorized");
                // }
            }

            switch (response.error_message.code) {
                case 100:
                    setErrorMessage(errorMessage);
                    break;
                case 101:
                    setErrorMessage(errorMessage);
                    break;
                case 102:
                    setUsername(data.username);
                    setLoginMode(false);
                    setErrorMessage(errorMessage);
                    break;
                default:
                    setErrorMessage(errorMessage);
            }
        }
        catch (error) {
            console.error(error);
        }
    }

    const handleChangePassword = async (newPassword) => {
        setErrorMessage(null);

        try {
            const data = {
                user_name: username,
                new_password: newPassword
            }
            const response = await axiosPost(API_URI, "/usersession/password", data);

            if (response?.data === "") {
                localStorage.clear();
                window.location.reload();
            }
        }
        catch (error) {
            setErrorMessage(error.response.data.error_message.message);
        }
    }

    return (
        <>
            <InputForm loginMode={loginMode} errorMessage={errorMessage} handleLogin={handleLogin} handleChangePassword={handleChangePassword} />
        </>
    );
}

export default LoginAndChangePassword;