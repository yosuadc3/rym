import RefreshIcon from '@mui/icons-material/Refresh';
import { Grid, Typography } from "@mui/material";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomBreadcrumbs from "../../../components/breadcrumb/CustomBreadcrumbs";
import ButtonCommon from "../../../components/buttons/ButtonCommon";
import { triggerRefresh } from "../../../redux/features/dashboard/serviceAvailability/serviceAvailability";
import DsaLedStats from "./components/card/DsaLed";
import Summary from "./components/card/Summary";
import StatusTable from "./components/table/StatusTable";

const breadcrumbs = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "Service Availability",
        link: null,
        current: true
    },
];

const styles = {
    textLastUpdate: {
        fontSize: 14,
        fontWeight: "bold",
        textAlign: "right"
    },
    btnRefreshData: {
        px: 0,
        py: 0
    }
}

function ServiceAvailability() {
    const dispatch = useDispatch();
    const timestamp = useSelector((state) => state.serviceAvailability.timestamp);

    const handleClickRefresh = () => {
        dispatch(triggerRefresh());
    }

    return (
        <>
            <Grid container alignItems={"center"} height={50} marginBottom={2}>
                <Grid item xs={6}>
                    <CustomBreadcrumbs breadcrumbs={breadcrumbs} />
                </Grid>
                <Grid item xs={6}>
                    <Grid container direction={"column"}>
                        <Grid item>
                            <Typography sx={styles.textLastUpdate}>
                                Last Update {timestamp}
                            </Typography>
                        </Grid>
                        <Grid item textAlign={"right"}>
                            <ButtonCommon
                                handleClick={handleClickRefresh}
                                label={
                                    <>
                                        <RefreshIcon fontSize="12" />
                                        <Typography fontSize={12}>Refresh Data</Typography>
                                    </>
                                }
                                variant={"text"}
                                sx={styles.btnRefreshData} />
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
            <Grid container>
                <Grid item xs={5} paddingRight={1}>
                    <DsaLedStats />
                </Grid>
                <Grid item xs={6} paddingLeft={1}>
                    <Summary />
                </Grid>
            </Grid>
            <Grid container marginTop={2}>
                <StatusTable />
            </Grid>
        </>
    );
}

export default ServiceAvailability;