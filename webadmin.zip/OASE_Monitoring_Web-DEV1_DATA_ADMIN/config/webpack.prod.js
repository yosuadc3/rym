const { merge } = require("webpack-merge");
const Dotenv = require("dotenv-webpack");
const CopyPlugin = require("copy-webpack-plugin");
const path = require("path");
const commonConfig = require("./webpack.common");

const PUBLIC_PATH = process.env.PUBLIC_PATH || "auto";

console.log(`publicPath: ${PUBLIC_PATH}\n`);


module.exports = (env) => {
    const prodConfig = {
        mode: "production",
        devtool: 'source-map',
        output: {
            filename: '[name].[contenthash].js',
            path: path.resolve("nginx", "html", "monitoring"),
            publicPath: PUBLIC_PATH,
            clean: true,
        },

        optimization: {
            removeAvailableModules: false,
        },

        plugins: [
            new Dotenv({
                // path: path.resolve(env.local ? ".env.dev" : ".env"),
                path: path.resolve(env.local ? ".env.dev" : ".env"),
                systemvars: true,
            }),
            new CopyPlugin({
                patterns: [
                    { from: path.resolve("public", "oase_icon.ico") }
                ]
            }),
        ],
    }

    return merge(commonConfig, prodConfig);
}