const router = require("express").Router();
import * as controller from "../../controllers/report/atlas.controller";
import { protect } from "../../middlewares/keycloakHandler.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
const keycloak = require("../../middlewares/keycloakHandler.middleware").get();

router.get(
	"/",
	protect(["GET_REPORT_ATLAS"]),
	errorWrapper(controller.getReport)
);
router.get(
	"/download",
	protect(["GET_REPORT_ATLAS"]),
	errorWrapper(controller.getReportDownload)
);
router.get(
	"/filter",
	protect(["GET_REPORT_ATLAS"]),
	errorWrapper(controller.getReportFilter)
);
router.get(
	"/type",
	protect(["GET_REPORT_ATLAS"]),
	errorWrapper(controller.getReportType)
);

export default router;
export { };

