import React, { Suspense } from "react";
import ErrorBoundary from "./ErrorBoundary";

function AsyncLoader({ children }) {
	return (
		<Suspense fallback={<></>}>
			{/* <ErrorBoundary> */}
			{children}
			{/* </ErrorBoundary> */}
		</Suspense>
	);
}

export default AsyncLoader;
