export const TABLE_ADDONS_SEARCH_ITEMS = [
    {
        value: "all",
        label: "All"
    }
];

export const SEARCH_ITEMS = [
    {
        value: "event_code",
        label: "Event Code"
    },
    {
        value: "description",
        label: "Description"
    },
    {
        value: "group",
        label: "Group"
    },
    {
        value: "rule",
        label: "Rule"
    },
];
