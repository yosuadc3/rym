

export const TABLE_ADDONS_SEARCH_ITEMS = [
    {
        value: "all",
        label: "All"
    }
];

export const SEARCH_ITEMS = [
    {
        value: "group",
        label: "Group"
    },
    {
        value: "description",
        label: "Description"
    },
];

export const BREADCRUMBS = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "Incident Management & Monitoring",
        link: null,
        current: false
    },
    {
        item: "Data Configuration",
        link: null,
        current: false
    },
    {
        item: "Event Code Group",
        link: "/data-configuration/event-code-group/",
        current: true
    },
];

