import { SvgIcon } from "@mui/material";
import React from "react";

export default function Pencil(props) {
	return (
		<SvgIcon {...props}>
			<svg
				height="20"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M13.3998 3.40001L17.4998 7.50001L7.19985 17.7L3.09985 13.6L13.3998 3.40001ZM20.5998 2.40001L18.7998 0.600012C18.0998 -0.0999878 16.9998 -0.0999878 16.2998 0.600012L14.5999 2.30001L18.6999 6.40001L20.6999 4.40001C21.0999 3.80001 21.0998 2.90001 20.5998 2.40001ZM0.99985 19.4C0.89985 19.7 1.19985 20 1.59985 20L6.09985 18.9L1.99985 14.8L0.99985 19.4Z"
					fill="currentColor"
				/>
			</svg>
		</SvgIcon>
	);
}
