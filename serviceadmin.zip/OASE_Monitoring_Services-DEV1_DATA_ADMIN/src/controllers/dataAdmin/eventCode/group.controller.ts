import { HmacSHA256 } from 'crypto-js';
import express, { Request, Response } from 'express';
import { matchedData } from "express-validator";
import { HTTP_BAD_REQUEST, HTTP_NO_CONTENT } from "../../../constants/httpResponseCodes.constant";
import * as db from "../../../repositories/dataAdmin/eventCode/group.repository";
import { IGetAllRequest, IRequestQueryParams, TDbResponse, TRequestParams } from "../../../types/dataAdmin/dataAdmin.types";
import addPayloadToRequestHeader from "../../../utils/addPayloadToRequestHeader.util";
import { getInternalServerError, jsonSuccess } from "../../../utils/jsonMessage.util";
import { replaceNullOrEmptyStringArray } from "../../../utils/object/replaceNullOrEmptyStringArray.util";
import printToConsole from "../../../utils/printToConsole.util";

const message = {
    "english": `Successfully Retrieved Event Code Group`,
    "indonesia": `Berhasil Mengambil Event Code Group`,
}

export async function getEventCodeGroups(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    let dbRes: TDbResponse = [[], []];
    const page = req?.query?.page;
    const limit = req?.query?.limit;
    const sortBy = req?.query?.sortBy;
    const orderBy = req?.query?.orderBy;
    const offset = req?.query?.offset;
    const search = req?.query?.search;
    const advancedSearch = req?.query?.advancedSearch;
    const advancedSearchPeriode = req?.query?.advancedSearchPeriode;
    if (search) {
        const params = {
            search: JSON.parse(search)
        }

        dbRes = await db.getEventCodeGroups(page!, limit!, sortBy!, orderBy!, offset!, params);
    }
    else if (advancedSearch || advancedSearchPeriode) {
        const params = {
            advancedSearch: advancedSearch ? JSON.parse(advancedSearch) : null,
            advancedSearchPeriode: advancedSearchPeriode ? JSON.parse(advancedSearchPeriode) : null
        }

        dbRes = await db.getEventCodeGroups(page!, limit!, sortBy!, orderBy!, offset!, params);
    }
    else {
        dbRes = await db.getEventCodeGroups(page!, limit!, sortBy!, orderBy!, offset!);
    }

    const [data, [total]] = dbRes;

    replaceNullOrEmptyStringArray(data);

    const payload = {
        ...total,
        data: data
    }

    res.send(jsonSuccess(message, payload));
}

export async function getEventCodeGroupList(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const dbRes: TDbResponse = await db.getEventCodeGroupList();

    const [data] = dbRes;

    const payload = {
        ...data
    }

    res.send(jsonSuccess(message, payload));
}

export async function getEventCodeGroup(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    //const paramsData: TRequestParams = matchedData(req, { locations: ["params"] });

    const [data] = await db.getEventCodeGroup(req?.params?.id!);

    res.send(jsonSuccess(message, data));
}

export async function postEventCodeGroup(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    //const bodyData = matchedData(req, { locations: ["body"], includeOptionals: true });

    const message = {
        "english": `Successfully Insert An Event Code Group`,
        "indonesia": `Berhasil Memasukkan Sebuah Event Code Group`,
    }

    await db.postEventCodeGroup(req?.body, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

// export async function injectEventCodeGroup(req: IGetAllRequest, res: Response) {
//     addPayloadToRequestHeader(req);

//     const name = req.kauth.grant?.access_token.content.preferred_username;
//     //const bodyData = matchedData(req, { locations: ["body"], includeOptionals: true });

//     const message = {
//         "english": `Successfully Insert An Event Code Group`,
//         "indonesia": `Berhasil Memasukkan Sebuah Event Code Group`,
//     }

//     for (let index = 0; index < 207; index++) {
//         const dummy = {
//             group: "INJECT COY",
//             description: "INJECT DESC"
//         };
//         dummy.group += (index + 1);
//         dummy.description += (index + 1);
//         await db.postEventCodeGroup(dummy, name);
//     }

//     res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
// }

export async function changeOrdersEventCodeGroup(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    const bodyData = matchedData(req, { locations: ["body"] });

    const message = {
        "english": `Successfully Updated The Priority of The Event Code Group`,
        "indonesia": `Berhasil Mengubah Prioritas Event Code Group`,
    }

    await db.changeOrdersEventCodeGroup(req?.body, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function putEventCodeGroup(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    // const bodyData = matchedData(req, { locations: ["body"] });
    // const paramsData = matchedData(req, { locations: ["params"] });

    const message = {
        "english": `Successfully Updated An Event Code Group`,
        "indonesia": `Berhasil Mengubah Sebuah Event Code Group`,
    }

    await db.putEventCodeGroup(req?.body, req?.params?.id, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function deleteEventCodeGroup(req: IGetAllRequest, res: Response) {

    addPayloadToRequestHeader(req);
    const name = req.kauth.grant?.access_token.content.preferred_username;
    // const paramsData = matchedData(req, { locations: ["params"] });

    const message = {
        "english": `Successfully Delete An Event Code Group`,
        "indonesia": `Berhasil Menghapus Sebuah Event Code Group`,
    }

    await db.deleteEventCodeGroup(req?.params?.id, req?.body?.priority, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export { };

