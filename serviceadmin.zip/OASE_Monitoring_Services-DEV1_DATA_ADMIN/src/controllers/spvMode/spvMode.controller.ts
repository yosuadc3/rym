//Lost Comm Controller
import { Response } from "express";
import {
	IGetDetailSPVModeRequest,
	IGetSPVModeByFLMRequest,
	IGetSPVModeReportRequest,
	IGetSPVModeRequest,
} from "../../types/spvMode/spvMode.type";
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import * as dateTime from "../../utils/dateTime.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import printToConsole from "../../utils/printToConsole.util";
const spvModeRepo = require("../../repositories/spvMode.repository");

export const getSPVMode = async (req: IGetSPVModeRequest, res: Response) => {
	addPayloadToRequestHeader(req);

	const data = await spvModeRepo.get();
	let counterSPVMode = 0;

	data.rows.map((item: any) => {
		counterSPVMode = counterSPVMode + item.JUMLAH;
	});

	const response = {
		total: counterSPVMode,
		lastUpdate: dateTime.getCurrent(),
		data: data.rows,
	};
	const message = {
		english: `Successfully Retrieved SPV Mode Data`,
		indonesia: `Berhasil Mengambil Data SPV Mode`,
	};
	res.send(jsonMessage.jsonSuccess(message, response));
};

export const getSPVModeByFLM = async (req: any, res: Response) => {
	addPayloadToRequestHeader(req);

	const data = await spvModeRepo.getByFLM(req.param.id);
	const message = {
		english: `Successfully Retrieved SPV Mode Data`,
		indonesia: `Berhasil Mengambil Data SPV Mode`,
	};

	res.send(jsonMessage.jsonSuccess(message, data.rows));
};

export const getDetailSPVMode = async (
	req: IGetDetailSPVModeRequest,
	res: Response
) => {
	addPayloadToRequestHeader(req);

	const data = await spvModeRepo.getDetail();
	let total = 0;

	const responseArray = data.rows.map((value: any) => {
		total += value.JUMLAH;

		return {
			PENGELOLA: value.PENGELOLA,
			WSID: value.ID.split(","),
			JUMLAH: value.JUMLAH,
		};
	});

	const response = {
		total: total,
		data: responseArray,
	};
	const message = {
		english: `Successfully Retrieved SPV Mode Detail`,
		indonesia: `Berhasil Mengambil Detail SPV Mode`,
	};

	res.send(jsonMessage.jsonSuccess(message, response));
};

export const getSPVModeReport = async (
	req: IGetSPVModeReportRequest,
	res: Response
) => {
	addPayloadToRequestHeader(req);

	const data = await spvModeRepo.getReport();
	const message = {
		english: `Successfully Retrieved SPV Mode Report`,
		indonesia: `Berhasil Mengambil Report SPV Mode`,
	};

	res.send(jsonMessage.jsonSuccess(message, data.rows));
};

export { };

