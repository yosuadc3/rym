import * as welcomeApp from "../controllers/welcomeApp.controller";
import errorWrapper from "../utils/errorWrapper.util";
let router = require("express").Router();

router.get("/", errorWrapper(welcomeApp.getWelcomeApp));

export default router;
export { };

