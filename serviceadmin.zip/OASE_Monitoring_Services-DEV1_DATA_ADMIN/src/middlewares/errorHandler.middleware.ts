import { NextFunction, Response } from "express";
import GlobalError from "../errors/global.error";
import { IRequestAPI } from "../types/global.type";

export default (
   error: Error,
   _req: IRequestAPI,
   res: Response,
   _next: NextFunction
) => {
   if (error instanceof GlobalError) {
      return res.status(error.errorCode).send(error.serializeErrors());
   }
}
