import { Grid, Stack } from "@mui/material";
import React from "react";
import SkeletonText from "../components/skeleton/SkeletonText";

export default function IsLoading() {
	return (
		<Grid container spacing={3}>
			{Array(9)
				.fill(0)
				.map((_, i) => (
					<Grid item container xs={4} key={i}>
						<Stack justifyContent="start" alignItems="start">
							<SkeletonText width={100} />
							<SkeletonText width={150} />
						</Stack>
					</Grid>
				))}
		</Grid>
	);
}
