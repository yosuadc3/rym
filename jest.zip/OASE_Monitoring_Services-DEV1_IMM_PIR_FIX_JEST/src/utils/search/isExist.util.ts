function isExist(val: any) {
  return val ? true : false;
}

module.exports = isExist;

export {};
