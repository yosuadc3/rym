import React, { useState, useEffect, useRef, useLayoutEffect, useCallback } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import {STYLES} from '../../../../constants/IncidentManagement/Styles';
import DNDSort from './DNDSort';
import { LinearProgress } from '@mui/material';
const styles = {
	table: (useGrayTheme) => ({
		boxShadow: "0px 0px 3px rgb(0 0 0 / 7%)",
		textAlign: "center",
		border: "none",
		height: 576,
		".MuiTable-root": {
			width: "100%",
			border: "none",
			borderCollapse: "collapse",
			tableLayout: "fixed"
		},
		".MuiTableRow-root":{
			width:"100%",
		},
        '.MuiTableBody-root': {
            cursor: "pointer",
			overflow: "auto",
			borderTop: "10px solid #fff"
        },
        '.MuiTableBody-root .MuiTableRow-root': {
            "&:hover div": {
				fontWeight: "bold !important",
				backgroundColor: "#CDE8FF",
			}
        },
        '& .MuiTableBody-root .MuiTableRow-root:nth-child(odd)': {
            backgroundColor: "#E2E2EB",
        },

		".MuiTableCell-root": {
			fontSize: "14px",
			color: useGrayTheme ? "#65748B" : "black",
			whiteSpace: "normal",
			paddingX: 1,
			paddingY: 1,
			border: "none",
			outline:"none !important",
			height:"52px",
			wordWrap: "break-word",
		},

		".MuiTableCell-head": {
			fontSize: "14px",
			color: useGrayTheme ? "#333333" : "black",
			fontWeight: 600,
			overflow: "visible",
			lineHeight: "1.43rem",
			whiteSpace: "normal",
			height:"56px",
		},

		".MuiTableHead-root:focus": {
			outline: "none",
		},
		".MuiTableHead-root": {
			backgroundColor: useGrayTheme ? "#E0E0E0 !important" : "rgb(134, 199, 255) !important",
			opacity: useGrayTheme ? "0.7" : "none",
			fontSize: "14px",
			fontWeight: 900,
			border: "none",
			borderRadiusTopLeft: 2,
			borderRadiusTopRight: 2,
			outline:"none !important",
			position: "sticky",
			top: 0,
		},

        ".MuiTableCell-root:focus": {
			outline: "none",
		},
	   ...STYLES.scroll,
	}),
};

export default function TableV2({
	rows,
	setOffSet =()=>{},
	setChangeIndex = () => { },
	total,
	DATA_HEIGHT,
	headers,
}){
	const [dataTable,setDataTable] = useState(rows);
	const tableEl = useRef();
	const [tempOffSet,setTempOffSet] = useState(0);
	const [typeLoad,setTypeLoad] = useState(null);
	const [loading, setLoading] = useState(false);
	const OFFSET_LENGTH =  DATA_HEIGHT/2;

	const loadMore = useCallback(() => {
		const loadItems = async () => {
		await new Promise(resolve =>
			setTimeout(() => {
				setOffSet (tempOffSet+OFFSET_LENGTH);
				setTempOffSet(tempOffSet+OFFSET_LENGTH);
				resolve();
			}, 1000)
		)
		}
		setLoading(true)
		loadItems()
  	}, [rows])

	const loadTop = useCallback(() => {
		const loadItems = async () => {
		await new Promise(resolve =>
			setTimeout(() => {
				setOffSet (tempOffSet-OFFSET_LENGTH);
				setTempOffSet(tempOffSet-OFFSET_LENGTH);
				resolve();
			}, 1000)
		)
		}
		setLoading(true)
		loadItems()
  	}, [rows])

	  const scrollListener = useCallback(() => {
		let bottom = tableEl.current.scrollHeight - tableEl.current.clientHeight;

		if (tableEl.current.scrollTop == bottom && (rows.length%OFFSET_LENGTH == 0 && rows.length+OFFSET_LENGTH - total < OFFSET_LENGTH) && !loading) {
			setTypeLoad("loadBottom");
		  	loadMore()
		}
		if (tableEl.current.scrollTop == 0 && tempOffSet!=0 && !loading) {
			setTypeLoad("loadTop");
			loadTop()
		  }
	  }, [loadMore, loadTop, loading])

	  useLayoutEffect(() => {
		const tableRef = tableEl.current
		tableRef.addEventListener('scroll', scrollListener)
		return () => {
		  tableRef.removeEventListener('scroll', scrollListener)
		}
	  }, [scrollListener])

	const moveRow = (dragData,dragIndex, hoverIndex, sourceIndex) => {
        const newRow = () => {
            let dragRow;
            let newRows = [...dataTable];
			if(dragIndex>=tempOffSet&&dragIndex<tempOffSet+(OFFSET_LENGTH*2)){
				newRows.splice(dragIndex-tempOffSet, 1);
			}
			if(sourceIndex>=tempOffSet&&sourceIndex<tempOffSet+(OFFSET_LENGTH*2)){
				dragRow = dataTable[dragIndex-tempOffSet];
			}else{
				dragRow = dragData;
			}
            newRows.splice(hoverIndex-tempOffSet, 0, dragRow);
            newRows = newRows.map((obj, index) => {
                if(dragIndex<hoverIndex){
                    if(index>= dragIndex-tempOffSet &&index<= hoverIndex-tempOffSet){
                        const changeRow = {...obj,priority: index+1+tempOffSet};
                        return changeRow;
                    }else{
                        return obj;
                    }
                }else{
                    if(index<= dragIndex-tempOffSet &&index>= hoverIndex-tempOffSet){
                        const changeRow = {...obj,priority: index+1+tempOffSet};
                        return changeRow;
                    }else{
                        return obj;
                    }
                }
                
              });
            return newRows;
          };
        setDataTable(newRow);
      };

	useEffect(()=>{
        if(rows){
          setDataTable(rows);
		  setLoading(false);
        }
    },[rows]);

	useEffect(()=>{
        if(!loading){
			if(typeLoad == "loadTop"){
				tableEl.current.scrollTop = tableEl.current.scrollHeight * 0.496;
			}
		}
    },[loading]);
    return(
        <TableContainer component={"div"} sx={styles.table(false)}  ref={tableEl}>
            <Table component={"div"} aria-label="simple table" style={{position:"relative"}}>
                <TableHead component={"div"}>
					<TableRow component={"div"} >
						{
							headers.map((header)=>(
								<TableCell key={header.field} component={"div"} align={header.align} style={{width: `${header.width}`}}>{header.title}</TableCell>
							))
						}
					</TableRow>
					{loading && <LinearProgress  color="primary" sx={{width:"100%", position:"absolute", top: 51, zIndex:2}} />}
                </TableHead>
                <TableBody component={"div"}>
                {dataTable.map((row) => (
					<DNDSort key={row.id} data={row} moveRow={moveRow} changeIndex={setChangeIndex} headers={headers}/>
                ))}
                </TableBody>

            </Table>
        </TableContainer>
    );
}