import { FAULT_CATEGORY } from "../../constants/dbQuery.constant";
import { query as dbQuery, exec } from "../../databases/oase.database";
import { TQueryParams, TSearchParams } from "../../types/dataAdmin/dataAdmin.types";
import { handleAdvancedSearchParams, handleSearchParams } from "../../utils/dbQueryHelper.util";
import { getObjectEntries, getObjectValues, getObjectValuesOfArrayObject } from "../../utils/object/convertToArray.util";

export function getFaultCategories(page: number, limit: number, sortBy: string, orderBy: string, offset: number = page * limit, searchParams?: TSearchParams) {
    let searchData: TQueryParams = {
        query: "",
        params: []
    }

    if (searchParams?.search) {
        searchData = handleSearchParams(searchParams.search);
    }

    if (searchParams?.advancedSearch || searchParams?.advancedSearchPeriode) {
        searchData = handleAdvancedSearchParams(searchParams.advancedSearchPeriode!, searchParams.advancedSearch, "created_time");
    }

    const queryData = `select id, category, rules, priority, color, description
        from ${FAULT_CATEGORY.VIEW} ${searchData.query}
        order by \`${sortBy}\` ${orderBy} limit ${limit} offset ${offset}`;

    const queryTotal = `select count(id) as total from ${FAULT_CATEGORY.VIEW} ${searchData.query} `;

    const result = dbQuery(queryData, searchData.params);
    const total = dbQuery(queryTotal, searchData.params);

    return Promise.all([result, total]);
}

export function getFaultCategory(id: number | undefined) {
    const baseQuery = `select id, category, rules, color, description
        from ${FAULT_CATEGORY.VIEW} where id = ?`;

    return dbQuery(baseQuery, [id]);
}

export function getFaultCategoryList() {
    const baseQuery = `select json_arrayagg(json_object('id', id, 'value', category)) as list from ${FAULT_CATEGORY.VIEW}`;
    return dbQuery(baseQuery);
}

export function postFaultCategory(data: { [k: string]: unknown }, createdBy: string | undefined) {
    const baseQuery = `
        INSERT INTO ${FAULT_CATEGORY.TABLE} (\`category\`, color, description, is_delete, created_by, priority) 
        SELECT ?, ?, ?, 0, ?, subquery.priority
        FROM (SELECT (IFNULL(priority, 0) + 1) AS priority FROM ${FAULT_CATEGORY.TABLE} WHERE is_delete != 1 ORDER BY priority DESC LIMIT 1) AS subquery`;

    return dbQuery(baseQuery, [...getObjectValues(data), createdBy]);
}

export function putFaultCategory(body: { [k: string]: unknown }, id: number | undefined, modifiedBy: string | undefined) {
    const baseQuery = `UPDATE ${FAULT_CATEGORY.TABLE} t SET t.category = ?, t.color = ?, t.description = ?, t.modified_by = ? where t._id = ?`;

    return dbQuery(baseQuery, [...getObjectValues(body), modifiedBy, id]);
}

export function changeOrdersCategory(body: { [key: string]: unknown }, modifiedBy: string | undefined) {

    const operator = body.start_priority! < body.end_priority! ? '-' : '+'
    const data = {
        param1: operator === '-' ? '>' : '>=',
        param2: operator === '-' ? body.start_priority : body.end_priority,
        param3: operator === '-' ? '<=' : '<',
        param4: operator === '-' ? body.end_priority : body.start_priority
    }

    const query =
        `UPDATE ${FAULT_CATEGORY.TABLE} t
    SET t.priority = 
    CASE 
        WHEN t.priority ${data.param1} ? AND t.priority ${data.param3} ? AND t._id <> ? THEN (t.priority ${operator} 1)
        WHEN t._id = ? THEN ?
        ELSE t.priority
    END,
    t.modified_by = ?
    WHERE t.is_delete <> 1 AND t.priority >= ? AND t.priority <= ?`;

    return dbQuery(query, [data.param2, data.param4, body.id, body.id, body.end_priority, modifiedBy, data.param2, data.param4]);
}

export function deleteFaultCategory(id: number | undefined, priority: number | undefined, modifiedBy: string | undefined) {
    const baseQuery = `
    UPDATE ${FAULT_CATEGORY.TABLE} t 
        SET t.is_delete = CASE
            WHEN _id = ? THEN 1
            ELSE t.is_delete
        END,
        t.priority = CASE
            WHEN t.priority > ? THEN (t.priority - 1)
            ELSE t.priority
        END,
        t.modified_by = ?
    WHERE t.is_delete <> 1`;

    return dbQuery(baseQuery, [id, priority, modifiedBy]);
}

export { };

