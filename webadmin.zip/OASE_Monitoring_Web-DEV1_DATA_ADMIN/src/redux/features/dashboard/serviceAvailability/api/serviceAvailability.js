import { createApi } from "@reduxjs/toolkit/query/react";
import { BASE_URL_API_MONITORING } from "../../../../../constants/Api";
import axiosBaseQuery from "../../../../utils/axiosBaseQuery";

const path = "/service-availability";

export const serviceAvailabilityApi = createApi({
    reducerPath: "serviceAvailabilityApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getStatus: builder.query({
            query: (params = { page: 0, limit: 10, sortBy: "", orderBy: "", search: {}, advancedSearch: {}, advancedSearchPeriode: {} }) => ({
                url: `${path}`, method: "get", params: params
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total: data.total,
                    last_update: data.last_update
                }
            }
        }),
        getReport: builder.query({
            query: (params = { sortBy: "", orderBy: "", searchValue: {}, advancedSearch: {}, advancedSearchPeriode: {} }) => ({
                url: `${path}/report`, method: "get", params: params
            }),
            transformResponse: (res) => (res.data)
        }),
        getDsaStats: builder.query({
            query: () => ({ url: `${path}/dsa-stats`, method: "get" }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total_terminal: data.total_terminal,
                    last_update: data.last_update
                }
            }
        }),
        getSummary: builder.query({
            query: (params = { category: "", value: "" }) => ({
                url: `${path}/summary`, method: "get", params: params
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total_terminal: data.total_terminal,
                    last_update: data.last_update
                }
            }
        }),
        getSearchItems: builder.query({
            query: () => ({ url: `${path}/search-items`, method: "get" }),
            transformResponse: (res) => (res.data)
        }),
    })
});

export const {
    useGetStatusQuery,
    useGetReportQuery,
    useGetDsaStatsQuery,
    useGetSummaryQuery,
    useGetSearchItemsQuery
} = serviceAvailabilityApi;