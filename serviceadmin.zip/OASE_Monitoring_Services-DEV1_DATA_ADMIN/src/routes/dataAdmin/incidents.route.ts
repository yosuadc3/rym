import * as controller from "../../controllers/dataAdmin/incidents.controller";
import validation from "../../middlewares/validator.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
import * as validationRules from "../../validators/dataAdmin/incidents.validator";
const router = require("express").Router();

router.get("/", validationRules.getIncidents, validation(validationRules.getIncidents), errorWrapper(controller.getIncidents));

export default router;