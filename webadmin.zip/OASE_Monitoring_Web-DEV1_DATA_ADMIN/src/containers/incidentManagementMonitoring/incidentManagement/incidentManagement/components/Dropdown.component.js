import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Grid,
  Stack,
  Typography
} from "@mui/material";
import React, { useState } from "react";
import SkeletonText from "../../../../../components/skeleton/SkeletonText";
import ChevronDown from "../../../../../components/svgs/ChevronDown";
import { accordionStyle } from "../constants/IncidentManagement";

import DropdownTable from "./DropdownTable.component";

const Dropdown = ({
  idx,
  category,
  total,
  isLoading,
  handleRowClick,
  oldestIncident,
  recentIncident,
  averageIncident,
  searchQuery,
  borderBottomColor = "rgba(13, 124, 171, 0.25)",
}) => {
  const [expanded, setExpanded] = useState(false);
  const childGridProps = {
    direction: "row",
    justifyContent: "center",
    alignItems: "center",
  };

  const incidents = [averageIncident, recentIncident, oldestIncident];

  return (
    <Accordion
      sx={accordionStyle.accordion(idx, expanded, isLoading, borderBottomColor)}
      expanded={isLoading ? false : expanded}
      onChange={isLoading ? null : () => setExpanded((prev) => !prev)}
      disableGutters
    >
      <AccordionSummary
        sx={accordionStyle.accordionSummary(borderBottomColor, isLoading)}
        expandIcon={<ChevronDown sx={accordionStyle.accordionIcon} />}
        aria-controls={`${category}-content`}
        id={`${category}-header`}
      >
        <Grid container>
          <Grid item xs={3} container>
            <Stack
              display="flex"
              justifyContent="center"
              alignItems={isLoading ? "center" : "flex-start"}
              width={0.9}
              paddingLeft={5}
            >
              <Typography sx={accordionStyle.accordionCategory}>
                {isLoading ? <SkeletonText width={250} /> : category}
              </Typography>
            </Stack>
          </Grid>
          <Grid item container xs={1} {...childGridProps}>
            {isLoading ? (
              <Typography sx={accordionStyle.accordionCategoryCount}>
                <SkeletonText width={20} height={20} />
              </Typography>
            ) : total === 0 ? null : (
              <Typography sx={accordionStyle.accordionCategoryCount(category)}>
                {total}
              </Typography>
            )}
          </Grid>
          {incidents.map((val, i) => (
            <Grid
              item
              container
              xs={i === 2 ? 2 : 3}
              key={i}
              {...childGridProps}
            >
              {isLoading ? (
                <SkeletonText />
              ) : (
                <Typography sx={accordionStyle.accordionCategoryAge}>
                  {val}
                </Typography>
              )}
            </Grid>
          ))}
        </Grid>
      </AccordionSummary>
      <AccordionDetails sx={accordionStyle.accordionDetails}>
        {expanded ? (
          <DropdownTable
            handleRowClick={handleRowClick}
            category={category}
            total={total}
            searchQuery={searchQuery}
          />
        ) : null}
      </AccordionDetails>
    </Accordion>
  );
};

export default Dropdown;
