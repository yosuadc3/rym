module.exports = function () {
  require("./logger/dashboardLogger.scheduler");
};
