import { SvgIcon } from "@mui/material";
import React, { useState } from "react";

const ViewComponent = ({ color }) => {
	return (
		<svg viewBox="0 0 21 14" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M20.9002 6.6001C20.7002 6.4001 16.5002 0.600098 11.0002 0.600098C5.5002 0.600098 1.3002 6.3001 1.1002 6.6001C0.900195 6.8001 0.900195 7.1001 1.1002 7.4001C1.3002 7.6001 5.5002 13.4001 11.0002 13.4001C16.5002 13.4001 20.7002 7.7001 20.9002 7.4001C21.0002 7.2001 21.0002 6.8001 20.9002 6.6001ZM11.0002 12.1001C7.0002 12.1001 3.5002 8.3001 2.5002 7.0001C3.5002 5.8001 7.0002 1.9001 11.0002 1.9001C15.0002 1.9001 18.5002 5.7001 19.5002 7.0001C18.5002 8.2001 15.0002 12.1001 11.0002 12.1001Z" fill={color} />
			<path d="M11 3C8.8 3 7 4.8 7 7C7 9.2 8.8 11 11 11C13.2 11 15 9.2 15 7C15 4.8 13.2 3 11 3ZM11 9.6C9.5 9.6 8.4 8.4 8.4 7C8.4 5.6 9.6 4.4 11 4.4C12.4 4.4 13.6 5.6 13.6 7C13.6 8.4 12.5 9.6 11 9.6Z" fill={color} />
		</svg>
	)
}

const ViewUnclick = () => {
	return (
		<ViewComponent color="#65748B" />
	)
}

const ViewOnClick = () => {
	return (
		<ViewComponent color="#0D5CAB" />
	)
}

export default function View(props) {

	const [toggleHover, setToggleHover] = useState(false)

	const handleToggle = () => {
		setToggleHover((prev) => !prev);
	}

	return (
		<SvgIcon {...props}
			onMouseEnter={handleToggle}
			onMouseLeave={handleToggle}
		>
			{
				toggleHover ? <ViewOnClick /> : <ViewUnclick />
			}
		</SvgIcon>
	);
}
