import { Stack } from "@mui/material";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import View from "../../../../../components/svgs/View";
import { setCurrentDetailComment, setIsOpenDialogViewComments, setTicketId, setTicketIdComment } from "../../../../../redux/features/incident-management-monitoring/incident-management/imm";
import { CENTER_COLUMNS } from "../../../../../utilities/MaterialUI";
import { dayInMonthComparator } from "../../../../../utilities/Moment";
import LinkBox from "../components/LinkBox";
import LinkBoxTerminal from "../components/LinkBoxTerminal";

const DATE = "date";

const LABEL = {
  ALL: "All",
  INCIDENT_NUMBER: "Incident Number",
  START_TIME: "Start Time",
  END_TIME: "End Time",
  ACTION_CODE: "Action Code",
  ACTION_CODE_DESCRIPTION: "Action Code Description",
  STATUS_CODE: "Status Code",
  STATUS_DESCRIPTION: "Status Code Description",
  LAST_COMMENT: "Last Comment",
};

const VALUE = {
  ALL: "all",
  ID: "id",
  TICKET_ID: "ticket_id",
  LOKASI: "lokasi",
  START_TIME: "start_time",
  END_TIME: "end_time",
  STATUS_CODE: "status_code",
  ACTION_CODE: "action_code",
  DURATION: "duration",
  STATUS_CODE_DESCRIPTION: "status_code_description",
  ACTION_CODE_DESCRIPTION: "action_code_description",
  LAST_COMMENT: "last_comment",
};

const FIELD = {
  ID: "id",
  START_TIME: "start_time",
  END_TIME: "end_time",
  STATUS_CODE: "status_code",
  ACTION_CODE: "action_code",
  DURATION: "duration",
  STATUS_CODE_DESCRIPTION: "status_code_description",
  ACTION_CODE_DESCRIPTION: "action_code_description",
  LAST_COMMENT: "last_comment",
  ACTION: "action",
};

const HEADERNAME = {
  ALL: "All",
  INCIDENT_NUMBER: "Incident Number",
  WSID: "WSID",
  START_TIME: "Start Time",
  END_TIME: "End Time",
  STATUS_CODE: "Status Code",
  ACTION_CODE: "Action Code",
  DURATION: "Duration",
  STATUS_CODE_DESCRIPTION: "Status Code Description",
  ACTION_CODE_DESCRIPTION: "Action Code Description",
  LAST_COMMENT: "Last Comment",
  ACTION: "Action",
};

export const INCIDENT_MANAGEMENT_SEARCH = [
  { value: VALUE.ALL, label: LABEL.ALL },
  { value: VALUE.TICKET_ID, label: LABEL.INCIDENT_NUMBER },
  { value: VALUE.START_TIME, label: LABEL.START_TIME },
  { value: VALUE.END_TIME, label: LABEL.END_TIME },
  { value: VALUE.ACTION_CODE, label: LABEL.ACTION_CODE },
  { value: VALUE.ACTION_CODE_DESCRIPTION, label: LABEL.ACTION_CODE_DESCRIPTION },
  { value: VALUE.STATUS_CODE, label: LABEL.STATUS_CODE },
  { value: VALUE.STATUS_CODE_DESCRIPTION, label: LABEL.STATUS_DESCRIPTION },
  { value: VALUE.LAST_COMMENT, label: LABEL.LAST_COMMENT },
];

const styles = {
  view: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)"
  }
}

export const INCIDENT_MANAGEMENT_CURRENT_INCIDENT_COLUMNS = (
  handleCellClick
) => [
    {
      field: FIELD.ID,
      headerName: HEADERNAME.INCIDENT_NUMBER,
      ...CENTER_COLUMNS,
      renderCell: (data) => { return (<LinkBox data={data} value="id" />) },
    },
    {
      field: FIELD.START_TIME,
      headerName: HEADERNAME.START_TIME,
      type: DATE,
      valueGetter: (params) => params.row.start_time,
      sortComparator: dayInMonthComparator,
      renderCell: (data) => { return (<LinkBox data={data} value="start_time" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.END_TIME,
      headerName: HEADERNAME.END_TIME,
      type: DATE,
      valueGetter: (params) => params.row.end_time,
      sortComparator: dayInMonthComparator,
      renderCell: (data) => { return (<LinkBox data={data} value="end_time" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.ACTION_CODE,
      headerName: HEADERNAME.ACTION_CODE,
      renderCell: (data) => { return (<LinkBox data={data} value="action_code" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.ACTION_CODE_DESCRIPTION,
      headerName: HEADERNAME.ACTION_CODE_DESCRIPTION,
      renderCell: (data) => { return (<LinkBox data={data} value="action_code_description" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.STATUS_CODE,
      headerName: HEADERNAME.STATUS_CODE,
      renderCell: (data) => { return (<LinkBox data={data} value="status_code" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.STATUS_CODE_DESCRIPTION,
      headerName: HEADERNAME.STATUS_CODE_DESCRIPTION,
      renderCell: (data) => { return (<LinkBox data={data} value="status_code_description" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.LAST_COMMENT,
      headerName: HEADERNAME.LAST_COMMENT,
      renderCell: (data) => { return (<LinkBox data={data} value="last_comment" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.ACTION,
      sortable: false,
      headerName: HEADERNAME.ACTION,
      renderCell: (params) => {
        const dispatch = useDispatch();
        const { isOpenDialogViewComments } = useSelector(
          (state) => state.incidentManagement
        );
        const { id: ticketId, _id, start_time, end_time, action_code, action_code_description, status_code, status_code_description } = params.row;

        const handleView = (e) => {
          e.stopPropagation();

          // handleCellClick(ticketId);

          dispatch(setTicketIdComment({
            data: {
              ticketIdComment: _id
            }
          }))
          dispatch(setIsOpenDialogViewComments({
            data: {
              isOpenDialogViewComments: !isOpenDialogViewComments
            }
          }))
          dispatch(setCurrentDetailComment({
            data: {
              incident_number: ticketId,
              start_time,
              end_time,
              action_code,
              action_code_description,
              status_code,
              status_code_description
            }
          }))
        };

        return (
          <LinkBox data={params} value="null">
            <Stack direction="row" gap={2} sx={styles.view}>
              <View onClick={(e) => {
                e.stopPropagation();
                handleView(e);
              }}
                onMouseDown={(e) => e.stopPropagation()}
              />
            </Stack>
          </LinkBox>
        );
      },
      ...CENTER_COLUMNS,
    },
  ];

export const INCIDENT_MANAGEMENT_CURRENT_INCIDENT_COLUMNS_TERMINAL = (
  handleCellClick
) => [
    {
      field: FIELD.ID,
      headerName: HEADERNAME.INCIDENT_NUMBER,
      ...CENTER_COLUMNS,
      renderCell: (data) => { return (<LinkBoxTerminal data={data} value="id" />) },
    },
    {
      field: FIELD.START_TIME,
      headerName: HEADERNAME.START_TIME,
      type: DATE,
      valueGetter: (params) => params.row.start_time,
      sortComparator: dayInMonthComparator,
      renderCell: (data) => { return (<LinkBoxTerminal data={data} value="start_time" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.END_TIME,
      headerName: HEADERNAME.END_TIME,
      type: DATE,
      valueGetter: (params) => params.row.end_time,
      sortComparator: dayInMonthComparator,
      renderCell: (data) => { return (<LinkBoxTerminal data={data} value="end_time" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.ACTION_CODE,
      headerName: HEADERNAME.ACTION_CODE,
      renderCell: (data) => { return (<LinkBoxTerminal data={data} value="action_code" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.ACTION_CODE_DESCRIPTION,
      headerName: HEADERNAME.ACTION_CODE_DESCRIPTION,
      renderCell: (data) => { return (<LinkBoxTerminal data={data} value="action_code_description" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.STATUS_CODE,
      headerName: HEADERNAME.STATUS_CODE,
      renderCell: (data) => { return (<LinkBoxTerminal data={data} value="status_code" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.STATUS_CODE_DESCRIPTION,
      headerName: HEADERNAME.STATUS_CODE_DESCRIPTION,
      renderCell: (data) => { return (<LinkBoxTerminal data={data} value="status_code_description" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.LAST_COMMENT,
      headerName: HEADERNAME.LAST_COMMENT,
      renderCell: (data) => { return (<LinkBoxTerminal data={data} value="last_comment" />) },
      ...CENTER_COLUMNS,
    },
    {
      field: FIELD.ACTION,
      sortable: false,
      headerName: HEADERNAME.ACTION,
      renderCell: (params) => {
        const dispatch = useDispatch();
        const { isOpenDialogViewComments } = useSelector(
          (state) => state.incidentManagement
        );
        const { id: ticketId, _id, start_time, end_time, action_code, action_code_description, status_code, status_code_description } = params.row;

        const handleView = (e) => {
          e.stopPropagation();

          // handleCellClick(ticketId);

          dispatch(setTicketIdComment({
            data: {
              ticketIdComment: _id
            }
          }))
          dispatch(setIsOpenDialogViewComments({
            data: {
              isOpenDialogViewComments: !isOpenDialogViewComments
            }
          }))
          dispatch(setCurrentDetailComment({
            data: {
              incident_number: ticketId,
              start_time,
              end_time,
              action_code,
              action_code_description,
              status_code,
              status_code_description
            }
          }))
        };

        return (
          <LinkBoxTerminal data={params} value="null">
            <Stack direction="row" gap={2} sx={styles.view}>
              <View onClick={(e) => {
                e.stopPropagation();
                handleView(e);
              }}
                onMouseDown={(e) => e.stopPropagation()}
              />
            </Stack>
          </LinkBoxTerminal>
        );
      },
      ...CENTER_COLUMNS,
    },
  ];

export const INCIDENT_MANAGEMENT_DETAIL_BREADCRUMBS = (
  wsid = "-",
  lastUpdate = "-"
) => [
    {
      item: "Home",
      link: "/",
      current: false,
    },
    {
      item: "Incident Management",
      link: "/incident-management",
      current: false,
    },
    {
      item: `${wsid ? wsid : "-"} (${lastUpdate})`,
      link: null,
      current: true,
    },
  ];
