import React from 'react';
import { Box, Typography, Grid, LinearProgress, Link } from '@mui/material';
import { createTheme, ThemeProvider, StyledEngineProvider } from '@mui/material/styles';
import { hasRoles } from '../../../token/roles';
import { Link as LinkRouter} from 'react-router-dom'

const theme = createTheme(({
    palette: {
      primary: {
        main: '#29b6f6',
      },
      secondary: {
        main: '#f44336',
      },
    },
  }));


const useStyles = {

    boxRoot:{
        width: '100%',
        borderRadius: '8px',
        padding:'22px',
    },

    title: {
        fontSize: 20,
        fontWeight: 700,
        color:'#156db8',
        fontFamily: 'Montserrat',
    },

    gridRow:{
        marginBottom:'4px',
        justifyContent:"space-between",
    },


    task:{
        fontSize:'13px',
        fontFamily: 'Montserrat',
        color:'#455a64',
    },

    totalTask:{
        color:'black',
        fontWeight:'bold',
        display:'inline-block',
        fontFamily: 'Montserrat',
        '&:nth-child(even)':{
            fontWeight:'normal',
            color:'#9e9e9e',
        },
    },

    progressBar:{
        marginBottom:'27px',
        height:'12px',
        borderRadius:'8px',
        backgroundColor:'#eeeeee'
    },

    link:{
        '&:hover':{
            color:'inherit',
            cursor:'pointer',
            textDecoration:'underline'
        }
    }
};

const getLinearProgress = (x, y) => {
    return Math.floor((x/y)*100);
}

function ProgressTask({ dataProgressTask }){

    return (
        <Box sx={useStyles.boxRoot} boxShadow={6} >
            <Typography sx={useStyles.title}>Progress Task</Typography>
            <div style={{marginTop:'17px'}}>
                <Grid item container direction="column" xs={6} sm={12}>
                    {/* { */}
                    <Link
                        component={LinkRouter}
                        classes={hasRoles(['DASHBOARD_ADMIN_WH']) && {
                            root:useStyles.link
                        }}
                        underline="none" color="inherit" to={hasRoles(['DASHBOARD_ADMIN_WH']) && "/asset"}>
                    <div>
                        <Grid sx={useStyles.gridRow} container xs >
                            <Grid item>
                                <Typography sx={useStyles.task} variant="caption">Penempelan QR</Typography>
                            </Grid>
                            <Grid item>
                                <Typography sx={useStyles.totalTask}>{dataProgressTask.registrasiMesinComplete}</Typography>
                                <Typography sx={useStyles.totalTask}>/{dataProgressTask.registrasiMesinOutstanding}</Typography>
                            </Grid>
                        </Grid>
                        <StyledEngineProvider injectFirst>
                            <ThemeProvider theme={theme}>
                                <LinearProgress sx={useStyles.progressBar} color="primary" variant="determinate" value={getLinearProgress(dataProgressTask.registrasiMesinComplete, dataProgressTask.registrasiMesinOutstanding)} />
                            </ThemeProvider>
                        </StyledEngineProvider>
                    </div>
                    </Link>
                    {/* } */}
                    {hasRoles(['DASHBOARD_ASSET']) &&
                    <div>
                        <Grid sx={useStyles.gridRow} container xs>
                            <Grid item>
                                <Typography sx={useStyles.task} variant="caption">Registrasi WSID dan MK</Typography>
                            </Grid>
                            <Grid item>
                                <Typography sx={useStyles.totalTask}>{dataProgressTask.wsidRegistrationComplete}</Typography>
                                <Typography sx={useStyles.totalTask}>/{dataProgressTask.wsidRegistrationOutstanding}</Typography>
                            </Grid>
                        </Grid>

                        <StyledEngineProvider injectFirst>
                            <ThemeProvider theme={theme}>
                                <LinearProgress sx={useStyles.progressBar} color="primary" variant="determinate" value={getLinearProgress(dataProgressTask.wsidRegistrationComplete, dataProgressTask.wsidRegistrationOutstanding)}/>
                            </ThemeProvider>
                        </StyledEngineProvider>
                    </div>
                    }
                </Grid>
            </div>
        </Box>
    );
}

export default ProgressTask