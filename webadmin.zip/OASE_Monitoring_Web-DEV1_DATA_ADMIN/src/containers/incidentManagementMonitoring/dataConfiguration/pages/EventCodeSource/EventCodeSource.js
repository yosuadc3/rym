import React from "react";
import CustomBreadcrumbs from "../../../../../components/breadcrumb/CustomBreadcrumbs";
import StyledSearch from "../../../../../components/search/StyledSearch";
import {useCallback,useState,useEffect} from 'react';
import {useNavigate} from 'react-router-dom'
import StyledTable from "../../../../../components/table/StyledTable";
import {useGetEventCodeSourceQuery} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/api/eventCodeSource'
import { customFormat } from "../../../../../utilities/TimeConverter";
import { TABLE_ADDONS_SEARCH_ITEMS, BREADCRUMBS, SEARCH_ITEMS } from "../../../../../constants/IncidentManagement/EventCodeSource";
import SourceAction from "../../components/action/SourceAction";
import { Grid, Button,Box, Link, Typography} from "@mui/material";
import FormPopUp from "./FormPopUp";
import { handleInsertSource, handleRemoveSource, handleUpdateSource, setData } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/eventCodeSource";
import { useSelector, useDispatch } from "react-redux";


const tableColumnsCommonProps = {
    headerAlign: "center",
    align: "center",
    flex: 0.7
};

const styles = {
    table: {
        "& .MuiDataGrid-iconButtonContainer": {
            marginLeft: "0px !important"
        },
    }
}

function mapSearchItems() {
    return [
        ...TABLE_ADDONS_SEARCH_ITEMS,
        ...SEARCH_ITEMS
    ];
}

function EventCodeSource(){
    const [currRowsPerPage, setCurrRowsPerPage] = useState(5);
    const [page, setPage] = useState(0);
    const [total, setTotal] = useState(0);
    const [firstRender, setFirstRender] = useState(true);
    const [isUpdate, setIsUpdate]= useState(false);
    const [tableData, setTableData] = useState([]);
    const [sortBy, setSortBy] = useState("id");
    const [orderBy, setOrderBy] = useState("desc");
    const [isResetSearch, setIsResetSearch] = useState(false);
    const [searchFlag, setSearchFlag] = useState(false);
    const [advancedSearchFlag, setAdvancedSearchFlag] = useState(false);
    const [searchValue, setSearchValue] = useState(null);
    const [advancedSearchValue, setAdvancedSearchValue] = useState(null);
    const [advancedSearchPeriode, setAdvancedSearchPeriode] = useState({ startDate: null, endDate: null });
    const [updateData, setUpdateData] = useState({id:"",source:"",description:""});
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleCellClick = (id) =>{
        navigate('/data-configuration/event-code-catalog/'+id);
    }
    const [queryParams, setQueryParams] = useState({
        page: 0,
        limit: 10,
        sortBy: "id",
        orderBy: "desc",
        search: null,
        advancedSearch: null,
        advancedSearchPeriode: null
    });
    const { data: eventCodeSourceData, isLoading: eventCodeSourceIsLoading, refetch:eventCodeSourceRefetch } = useGetEventCodeSourceQuery(queryParams,{ refetchOnMountOrArgChange: isUpdate? true:60 });
    
const tableColumns = [
    {
        ...tableColumnsCommonProps,
        field: "source",
        headerName: "Source",
        flex: 3,
    },
    {
        ...tableColumnsCommonProps,
        field: "description",
        headerName: "Description",
        flex: 6,
    },
    {
        ...tableColumnsCommonProps,
        field: "-",
        headerName: "Action",
        renderCell: (data) =>  SourceAction(data.row),
        flex: 2,
        sortable: false 
    },
    
];

    useEffect(() => {
        if (!eventCodeSourceIsLoading) {
            const { data, total} = eventCodeSourceData;
            setTableData(data);
            setTotal(total);
        }
    }, [eventCodeSourceData, eventCodeSourceIsLoading]);

    useEffect(() => {
        if (firstRender) {
            setFirstRender(false);
        }else{
            setIsUpdate(true);
            eventCodeSourceRefetch();
        }
    }, [useSelector((state)=> state.eventCodeSource.refresh)]);

    useEffect(()=>{
        dispatch(setData(updateData));
    },[updateData]);

    useEffect(() => {
        const commonParams = {
            page: page,
            limit: currRowsPerPage,
            sortBy: sortBy,
            orderBy: orderBy
        }

        if (searchFlag) {
            setQueryParams({
                ...commonParams,
                search: searchValue
            });
        }
        else if (advancedSearchFlag) {
            setQueryParams({
                ...commonParams,
                advancedSearch: advancedSearchValue,
                advancedSearchPeriode: advancedSearchPeriode
            });
        }
        else {
            setQueryParams(commonParams);
        }
    }, [page, currRowsPerPage, sortBy, orderBy, searchValue, advancedSearchValue, advancedSearchPeriode]);


    const handleSortModelChange = useCallback((sortModel) => {
        if (sortModel.length) {
            setSortBy(() => sortModel[0]?.field);
            setOrderBy(() => sortModel[0]?.sort);
        } else {
            setSortBy(() => "id");
            setOrderBy(() => "desc");
        }
    }, []);

    
    const handleSearchClick = (searchInput) => {
        const { text, column } = searchInput;
        const data = {};

        if (column === "all") {
            SEARCH_ITEMS.forEach((item) => {
                data[item.value] = text;
            });
        }
        else {
            data[column] = text;
        }

        setSearchValue(data);
        setSearchFlag(true);
        setAdvancedSearchFlag(false);
    }

    const handleAdvancedSearchSubmit = (data) => {
        const { selectedDates, advancedData } = data;
        const temp = {};

        if (advancedData[0]?.category !== null) {
            advancedData.forEach((item) => {
                temp[item.category] = item.chips;
            });

            setAdvancedSearchValue(temp);
        }

        setAdvancedSearchPeriode({
            startDate: customFormat(selectedDates.startDate),
            endDate: customFormat(selectedDates.endDate)
        });
        setAdvancedSearchFlag(true);
        setSearchFlag(false);
    }

    const handleOpenInsertClick = () => {
        dispatch(handleInsertSource());
    }

    const handleOpenUpdateClick = () => {
        dispatch(handleUpdateSource());
    }

    const handleOpenRemoveClick = () => {
        dispatch(handleRemoveSource());
    }

    return (
        <>
            <Grid container alignItems={"center"} height={50} marginBottom={2}>
                <Grid item xs={12}>
                    <CustomBreadcrumbs breadcrumbs={BREADCRUMBS} />
                </Grid>
            </Grid>
            <Grid container direction={"row"} alignItems={"center"}>
                <Grid item xs={8} marginRight={"auto"}>
                    <StyledSearch
                        useAdvancedSearch
                        selectMenuItems={mapSearchItems()}
                        handleSearchClick={handleSearchClick}
                        handleAdvancedSearchSubmit={handleAdvancedSearchSubmit}
                        isResetSearch={isResetSearch}
                        setIsResetSearch={setIsResetSearch}
                    />
                </Grid>
            </Grid>
            <Grid container alignItems={"center"} marginTop={4}>
                <Grid item sx={styles.table} xs={12}>
                        <StyledTable
                            headers={tableColumns}
                            page={page}
                            rows={tableData}
                            pageSize={currRowsPerPage}
                            loading={eventCodeSourceIsLoading}
                            rowCount={total}
                            setPage={(e) => setPage(e)}
                            onCellClick={(e) => handleCellClick(e.id)}
                            useStripesWhiteGray
                            setPageSizeChange={(e) => setCurrRowsPerPage(e)}
                            onSortModelChange={handleSortModelChange}
                        />
                </Grid>
                <Grid item marginTop={3}>
                    <Button 
                        variant="contained"
                        disableElevation 
                        sx={{backgroundColor:"#0D5CAB", fontWeight:"700", fontSize:"16px",textTransform:"capitalize", padding:"10px",paddingX:"55px", borderRadius:"6px"}}
                        onClick={handleOpenInsertClick}
                        >
                        Tambah
                    </Button>
                </Grid>
            </Grid>
            <FormPopUp/>
        </>
    );
}

export default EventCodeSource;