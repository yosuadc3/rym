//DSA Router
import * as dsa from "../../controllers/dsa/dsa.controller";
const keycloak = require("../../middlewares/keycloakHandler.middleware").get();
let router = require("express").Router();

router.get("/", keycloak.protect("realm:GET_DSA"), dsa.getDSA);
router.get(
	"/report",
	keycloak.protect("realm:GET_DSA_REPORT"),
	dsa.getDSAReport
);

export default router;
export { };

