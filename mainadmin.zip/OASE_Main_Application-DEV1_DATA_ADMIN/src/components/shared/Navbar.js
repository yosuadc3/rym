import { CaretDownFilled } from '@ant-design/icons';
import { Button, Divider, Dropdown, Layout, Menu, Modal, Space, Typography } from 'antd';
import moment from 'moment';
import 'moment/locale/id';
import React, { useState } from 'react';
import { getRefreshToken } from "../../token/action";
import { getFullname } from "../../token/userInfo";
import { axiosPost } from '../../utilities/AxiosHelper';
import { vpnRedirect } from '../../utilities/Vpn';
import LogoutDialogIcon from "../svgs/LogoutDialogIcon";
import NotifIcon from "../svgs/NotifIcon";
import OASELogo from "../svgs/OASELogo";
import ProfileIcon from '../svgs/ProfileIcon';
import './styles/navbar.less';

const { Header } = Layout;
const { Text, Link } = Typography;

const API_URI = process.env.REACT_APP_API_OASE;

function Navbar() {
    const date = moment().format("dddd, DD MMMM YYYY");
    const fullname = getFullname();
    const [visible, setVisible] = useState(false);
    const [visibleDropdown, setVisibleDropdown] = useState(false);

    const menu = (
        <Menu
            className='menus-profile'
            // onClick={handleMenuClick}
            items={[
                {
                    label: 'Profile',
                    key: 'profile',
                    onClick: () => {
                        setVisibleDropdown(false)
                        window.location.assign(vpnRedirect("/profile"))
                    }
                },
                {
                    label: 'Keluar',
                    key: 'logout',
                    onClick: () => {
                        showModal()
                    }
                },
            ]}
        />
    );

    const showModal = () => {
        setVisibleDropdown(false)
        setVisible(true);
    };

    const handleCancel = () => {
        setVisible(false);
    };

    const toggleDropdown = () => {
        setVisibleDropdown(!visibleDropdown);
    };

    const handleConfirmLogout = async () => {
        const payload = {
            "refresh_token": getRefreshToken()
        };

        const res = await axiosPost(API_URI, "/usersession/logout-web", payload);

        if (res) {
            localStorage.clear();
            window.location.reload();
        }
    }

    const redirectToHome = () => {
        window.location.assign(vpnRedirect("/"))
    }

    return (
        <Layout className='layout-header'>
            <Header className="navbar-header">
                <div className='navbar-header-content'>
                    <div className='navbar-header-logo'>
                        <Button className='link-oase-logo' onClick={redirectToHome} icon={<OASELogo />} />
                    </div>
                    <div className='navbar-header-content-right'>
                        <Text className='date-text'>{date}</Text>
                        <div className='navbar-header-notification'>
                            <Button className='button-notification' icon={<NotifIcon />} />
                        </div>
                        <div className='navbar-header-profile' onMouseLeave={() => { setVisibleDropdown(false) }}>
                            <Dropdown destroyPopupOnHide={true} visible={visibleDropdown} overlay={menu} overlayStyle={{ minWidth: '163px' }} placement="bottom" trigger={['click']} >
                                <Button className='button-profile' onClick={toggleDropdown}>
                                    <Space align="center">
                                        <ProfileIcon />
                                        <Text className='text-hello'>Hello,&nbsp;</Text>
                                        <Text className='text-fullname'>{fullname}</Text>
                                        <CaretDownFilled />
                                    </Space>
                                </Button>
                            </Dropdown>
                        </div>
                    </div>
                </div>
            </Header>
            <div className='navbar-header-divider'>
                <Divider orientation="center" className="header-divider" />
            </div>
            <Modal
                visible={visible}
                centered
                footer={null}
                onCancel={handleCancel}
            >
                <div className='dialog-content-logout'>
                    <div className='logout-div'>
                        <LogoutDialogIcon className='logout-icon' />
                    </div>
                    <div className='logout-div'>
                        <Text className='logout-text'>Yakin ingin keluar?</Text>
                    </div>
                    <div className='logout-buttons'>
                        <Button onClick={handleCancel} className='button-logout-tidak'>Tidak</Button>
                        <Button onClick={handleConfirmLogout} className='button-logout-ya'>Ya</Button>
                    </div>
                </div>
            </Modal>
        </Layout>
    );
}

export default Navbar;