import React from "react";
import { Box } from "@mui/system";
import { Typography } from "@mui/material";

function Home() {
    return (
        <Box sx={{ flexGrow: 1 }}>
            <Typography paragraph>
                OASE Monitoring Micro-Frontend
            </Typography>
        </Box>
    );
}


export default Home;