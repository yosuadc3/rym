import { Request } from "express";
import {
	IActionCode,
	IActionCodeDescription,
	IAll,
	ICategory,
	ICommentText,
	IDuration,
	IEndDate,
	IIncidentID,
	IIncidentId,
	ILastComment,
	IPagination,
	IStartDate,
	IStartTime,
	IStatusCode,
	IStatusCodeDescription,
	ITicketID,
	ITicketId,
	IUser,
	IWSID,
	StringOrUndefined,
} from "../global.type";

export interface ITicketIDIncidentCurrent {
	ticketId: string;
}

export interface IWSIDIncidentCurrent {
	wsid: string;
}

export interface IWSIDIncidentHistory {
	wsid: string;
}

export interface IStartDateIncidentReport {
	startDate: string;
}

export interface IEndDateIncidentReport {
	endDate: string;
}

export interface ILokasi {
	lokasi: string;
}

export interface ILok {
	lok: string;
}

export interface ITipeMesin {
	tipe_mesin: string;
}

export interface IVendorMesin {
	vendor_mesin: string;
}

export interface IEndTime {
	end_time: StringOrUndefined;
}

interface IGetIncidentCategoryQuery
	extends IAll,
	ITicketId,
	IWSID,
	IStatusCode,
	ILokasi,
	IStartTime,
	IDuration,
	IStatusCodeDescription,
	ILastComment,
	IStartDate,
	IEndDate,
	ILok,
	ITipeMesin,
	IVendorMesin,
	IEndTime { }
export interface IGetIncidentCategoryRequest
	extends IUser, Request<any, any, any, IGetIncidentCategoryQuery, any> {
	query: IGetIncidentCategoryQuery;
}

interface IGetIncidentIDQuery
	extends ICategory,
	IPagination,
	IAll,
	ITicketId,
	IWSID,
	IStatusCode,
	IStartTime,
	IDuration,
	IStatusCodeDescription,
	ILastComment,
	IStartDate,
	IEndDate,
	ILokasi,
	ILok,
	ITipeMesin,
	IVendorMesin,
	IEndTime { }
export interface IGetIncidentIDRequest
	extends IUser, Request<any, any, any, IGetIncidentIDQuery, any> {
	query: IGetIncidentIDQuery;
}

interface IGetIncidentCurrentQuery extends ITicketIDIncidentCurrent, IWSIDIncidentCurrent { }
export interface IGetIncidentCurrentRequest
	extends IUser,
	Request<any, any, any, IGetIncidentCurrentQuery, any> {
	query: IGetIncidentCurrentQuery;
}

interface IGetTerminalDetailsQuery extends ITicketID, IWSID { }
export interface IGetTerminalDetailsRequest
	extends IUser,
	Request<any, any, any, IGetTerminalDetailsQuery, any> {
	query: IGetTerminalDetailsQuery;
}

interface IGetTerminalCurrentStatusQuery extends ITicketID { }
export interface IGetTerminalCurrentStatusRequest
	extends IUser,
	Request<any, any, any, IGetTerminalCurrentStatusQuery, any> {
	query: IGetTerminalCurrentStatusQuery;
}

interface IGetIncidentHistoryQuery extends
	IWSIDIncidentHistory,
	IPagination,
	IStatusCode,
	IAll,
	ITicketId,
	IStartTime,
	IStatusCodeDescription,
	IActionCode,
	IActionCodeDescription,
	ILastComment,
	IStartDateIncidentReport,
	IEndDateIncidentReport,
	IEndTime { }
export interface IGetIncidentHistoryRequest
	extends IUser,
	Request<any, any, any, any, any> {
	query: IGetIncidentHistoryQuery;
}

interface IPostIncidentCommentQuery extends IIncidentId, ICommentText { }
export interface IPostIncidentCommentRequest
	extends IUser,
	Request<any, any, any, any, any> {
	query: IPostIncidentCommentQuery;
}

interface IGetIncidentCommentsQuery extends IPagination, IIncidentID { }
export interface IGetIncidentCommentsRequest
	extends IUser,
	Request<any, any, any, any, any> {
	query: IGetIncidentCommentsQuery;
}

interface IGetIncidentReportQuery
	extends IAll,
	ITicketId,
	IWSID,
	IStatusCode,
	IStartTime,
	IDuration,
	IStatusCodeDescription,
	ILastComment,
	IStartDateIncidentReport,
	IEndDateIncidentReport,
	ILokasi,
	ILok,
	ITipeMesin,
	IVendorMesin,
	IEndTime { }
export interface IGetIncidentReportRequest
	extends IUser, Request<any, any, any, IGetIncidentReportQuery, any> {
	query: IGetIncidentReportQuery;
}

interface IGetIncidentReportInfoQuery
	extends IAll,
	ITicketId,
	IWSID,
	IStatusCode,
	IStartTime,
	IDuration,
	IStatusCodeDescription,
	ILastComment,
	IStartDateIncidentReport,
	IEndDateIncidentReport,
	ILokasi,
	ILok,
	ITipeMesin,
	IVendorMesin,
	IEndTime { }
export interface IGetIncidentReportInfoRequest
	extends IUser, Request<any, any, any, IGetIncidentReportInfoQuery, any> {
	query: IGetIncidentReportInfoQuery;
}
