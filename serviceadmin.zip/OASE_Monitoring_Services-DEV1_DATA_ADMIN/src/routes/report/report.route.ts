const router = require("express").Router();
import atlas from "./atlas.route";
import dataConfiguration from "./dataConfiguration.route";

router.use("/atlas", atlas);
router.use("/data-configuration", dataConfiguration);

export default router;
export { };

