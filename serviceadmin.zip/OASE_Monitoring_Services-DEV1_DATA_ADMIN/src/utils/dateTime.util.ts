import moment from "moment";
import "moment/locale/id";

const dateTimeFormat = "dddd, DD MMMM YYYY HH:mm";

export const getCurrent = () => {
	return moment().format(dateTimeFormat);
};

export const forLogging = () => {
	return moment().format(`${dateTimeFormat} Z`);
};

export const UTCTimeFormat = (date: string) => {
	const convertDate = moment(date, moment.ISO_8601).utcOffset(0).format("DD/MM/YYYY HH:mm");
	return convertDate === "Invalid date" ? "-" : convertDate;
};

export const secondsToReadableFormat = (
	secs: number,
	altZeroTimeDiffMsg = false
) => {
	if (typeof secs === "number") {
		if (secs < 60) return altZeroTimeDiffMsg ? "0 minute" : "Just now!";
		const days = Math.floor(secs / 86400);
		const hours = Math.floor((secs % 86400) / 3600);
		const minutes = Math.floor(((secs % 86400) % 3600) / 60);
		return readableTimeFormat(days, hours, minutes);
	}
	return "-";
};

export const readableTimeFormat = (DYS: number, HRS: number, MINS: number) => {
	let dateText = "";
	const TIME_FORMAT = [
		{
			value: DYS,
			type: "day",
		},
		{
			value: HRS,
			type: "hour",
		},
		{
			value: MINS,
			type: "minute",
		},
	];
	TIME_FORMAT.forEach(
		({ value, type }, i) =>
			(dateText += value ? `${value} ${type}${value === 1 ? "" : "s"} ` : "")
	);
	const formattedDateText = dateText.trim();
	return formattedDateText;
};

export const getCurrentDate = () => {
	return moment().format("DD/MM/YYYY HH:mm:ss");
};

export { };

