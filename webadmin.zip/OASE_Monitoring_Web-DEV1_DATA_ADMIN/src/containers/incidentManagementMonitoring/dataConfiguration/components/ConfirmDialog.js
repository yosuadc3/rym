import React from "react"
import { Dialog,Grid,Typography,Button } from "@mui/material";
import { STYLES } from "../../../../constants/IncidentManagement/Styles";


export default function ConfirmDialog({
    isOpen,
    handleClose,
    title,
    handleSave,
    paddingX = "70px",
    paddingTop = "30px",
}){
    return(
        <Dialog
        open = {isOpen}
        onClose={handleClose}
        PaperProps={{
            sx: {
                width: "640px",
                height: "212px",
                paddingX: paddingX,
                paddingTop: paddingTop,
                paddingBottom: "30px",
                ...STYLES.dialogConfirm
            },
        }}
        >
            <Grid container direction={"column"} justifyContent={"space-between"} width="100%" height="100%">
                <Grid item container justifyContent={"center"}>
                    <Typography variant="h5" textAlign={"center"} fontSize="24px" fontWeight="600">
                        {title}
                    </Typography>
                </Grid>
                <Grid item container gap={3} justifyContent={"center"}>
                    <Button onClick={handleClose} variant={"outlined"}sx={STYLES.outlinedButton}>Tidak</Button>
                    <Button onClick={handleSave} variant={"contained"} sx={STYLES.containedButton}>Ya</Button>
                </Grid>
            </Grid>

        </Dialog>
    );
}