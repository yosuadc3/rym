import { EMAIL } from "../../constants/dbQuery.constant";
import { query as dbQuery } from "../../databases/oase.database";

export function getFaultCategory(id: number | undefined) {
    const baseQuery = `select id, category, color, description
        from ${EMAIL.VIEW_TABLE_EMAIL_ACTION} where id = ?`;

    return dbQuery(baseQuery, [id]);
}

export function getEmailAction() {
    const baseQuery = `select json_arrayagg(json_object('id', id, 'action', action)) as list from ${EMAIL.VIEW_TABLE_EMAIL_ACTION}`;
    return dbQuery(baseQuery);
}