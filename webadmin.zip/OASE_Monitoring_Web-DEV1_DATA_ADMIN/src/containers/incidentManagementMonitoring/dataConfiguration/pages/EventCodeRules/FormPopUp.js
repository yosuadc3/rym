
import React from "react";
import FormInput from "../../components/FormInput";
import {useState,useEffect} from 'react';
import { Grid, Button, DialogContent, DialogActions,Typography, Dialog, DialogTitle, Box } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import {handleInsertRules,handleRefresh,handleRemoveRules,handleUpdateRules, setData } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeRules/eventCodeRules";
import {usePostEventCodeRulesMutation,usePutEventCodeRulesMutation,useDeleteEventCodeRulesMutation} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeRules/api/eventCodeRules';
import { useGetFaultCategoryListQuery } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/faultCategory/api/faultCategory";
import FormSelect from "../../components/FormSelect"
import ColorPicker from "../../components/colorPicker/ColorPicker";
import FormDialogV2 from "../../../../../components/form/FormDialogV2";
import ConfirmDialog from "../../components/ConfirmDialog";
import { STYLES, MENUPROPS } from "../../../../../constants/IncidentManagement/Styles";
import FormLabel from "../../../../../components/form/FormLabel";



export default function FormPopUp(){
    const [categoryData, setCategoryData] = useState([{}]);
    const [inputRule, setInputRule ] = useState("");
    const [inputTicketAction, setInputTicketAction ] = useState("");
    const [inputEmailAction, setInputEmailAction ] = useState("");
    const [inputCategory, setInputCategory ] = useState("");
    const [inputLimit, setInputLimit ] = useState("");
    const [openInsert2, setOpenInsert2 ] = useState(false);
    const [openUpdate2, setOpenUpdate2 ] = useState(false);
    const [isChange, setIsChange] = useState(false);
    const [insertIntoApi,{isLoading:insertLoading,error:insertError,isSuccess: insertSuccess}] = usePostEventCodeRulesMutation();
    const [updateApi,{isLoading:updateLoading,error:updateError,isSuccess: updateSuccess}] = usePutEventCodeRulesMutation();
    const [deleteApi, {isSuccess:deleteSuccess}] = useDeleteEventCodeRulesMutation();
    const { data: category, isLoading: categoryIsLoading} = useGetFaultCategoryListQuery();
   
    const [limitError,setLimitError] = useState([false,""]);
    const data = useSelector((state) => state.eventCodeRules.data);
    const dispatch = useDispatch();

    const ticketData = [
        {
            id:1,
            value: "Ignore",
        },
        {
            id:2,
            value: "Logging Only",
        },
        {
            id:3,
            value: "Open",
        },
        {
            id:4,
            value: "Close",
        },
    ];

    const emailData = [
        {
            id:1,
            value: "action 1",
        },
        {
            id:2,
            value: "action 2",
        },
        {
            id:3,
            value: "action 3",
        },
        {
            id:4,
            value: "action 4",
        },
    ];

    const insert = () =>{
        if(inputRule!=""&& inputTicketAction != "" && inputEmailAction != ""  ){
            let tempCategory = inputCategory;
            let tempLimit;
            if(inputCategory == ""){
                tempCategory = null;
            }
            if(inputLimit == ""){
                tempLimit = null;
            }else{
                tempLimit = parseInt(inputLimit);
            }

            const insertData = {
                rule: inputRule,
                action_id: inputTicketAction,
                email_action_id: inputEmailAction,
                fault_category_id: tempCategory,
                reopen_limit: tempLimit,
            }
            insertIntoApi(insertData);
        }
    }

    const update = () =>{
        if(data.id!= ""  && inputRule != "" && inputTicketAction != "" && inputEmailAction != "" ){
            let tempCategory = inputCategory;
            let tempLimit;
            if(inputCategory == ""){
                tempCategory = null;
            }
            if(inputLimit == "" ){
                tempLimit = null;
            }else{
                tempLimit = parseInt(inputLimit);
            }
            let data_update = {
                rule: inputRule,
                action_id: inputTicketAction,
                email_action_id: inputEmailAction,
                fault_category_id: tempCategory,
                reopen_limit: tempLimit,
            }
            updateApi({ id: data.id, data: data_update });
        }
        
    }

    const remove = () =>{
        if(data.id != "" && data.priority !=""){
            const data_priority = {
                priority: data.priority
            }
            deleteApi({id:data.id,data:data_priority});
            dispatch(handleRefresh());
        }
    }

    const handleCloseInsertClick = () => {
        dispatch(handleInsertRules());
        setIsChange(false);
    }

    const handleOpenInsert2Click = () => {
        dispatch(handleInsertRules());
        setOpenInsert2(true);
    }
    const handleCloseInsert2Click = () => {
        setIsChange(false);
        setOpenInsert2(false);
    }

    const handleCloseUpdateClick = () => {
        dispatch(handleUpdateRules());
        setIsChange(false);
    }

    const handleOpenUpdate2Click = () => {
        dispatch(handleUpdateRules());
        setOpenUpdate2(true);
    }

    const handleCloseUpdate2Click = () => {
        setIsChange(false);
        setOpenUpdate2(false);
    }

    const handleCloseRemoveClick = () => {
        dispatch(handleRemoveRules());
    }

    const handleInputLimit = (e)=>{
        setInputLimit(e.target.value);
        setLimitError([false,""]);
        setIsChange(true);
    }

    useEffect(() => {
        if(typeof insertError !== "undefined"){
            const len = insertError.data.error_message.message.body.length??0;
            for(let i=0; i<len ;i++){
                const key = Object.keys(insertError.data.error_message.message.body[i])[0];
                const data = insertError.data.error_message.message.body[i];
                if( key === "reopen_limit"){
                    setLimitError([true,data[key]]);
                }           
            }
        }     
        if(insertSuccess){
            dispatch(handleRefresh());
            handleCloseInsert2Click();
         }  
    }, [insertLoading]);

    useEffect(() => {  
        if(typeof updateError !== "undefined"){
            const len = updateError.data.error_message.message.body?updateError.data.error_message.message.body.length:0;
            for(let i=0; i<len ;i++){
                const key = Object.keys(updateError.data.error_message.message.body[i])[0];
                const data = updateError.data.error_message.message.body[i];
                if( key === "reopen_limit"){
                    setLimitError([true,data[key]]);
                }           
            }
        } 
        if(updateSuccess){
            dispatch(handleRefresh());
            handleCloseUpdate2Click();
         }  
    }, [updateLoading]);

    useEffect(() => {  
        if(deleteSuccess){
            dispatch(handleRemoveRules());
            dispatch(handleRefresh());
         }  
    }, [deleteSuccess]);

    useEffect(() => {
        if (!categoryIsLoading) {
            const {data} = category;
            const tempData = [...data.list??[{}],{id: null, value: 'NULL'}];
            setCategoryData(tempData);
        }
    }, [category, categoryIsLoading]);

    useEffect(() => {
        if(!isChange){
            setInputRule(data.rule);
            setInputLimit(data.reopen_limit);
            if(data.fault_category !== ""&&categoryData){
                const category = categoryData.find(c=>c.value === data.fault_category);
                setInputCategory(category?category.id:"");
            }
            if(data.action !== "" && ticketData){
                const ticket = ticketData.find(t=>t.value === data.action);
                setInputTicketAction(ticket?ticket.id:"");
            }
            if(data.email_action !== "" && emailData){
                const email = emailData.find(e=>e.value === data.email_action);
                setInputEmailAction(email?email.id:"");
            }
            setLimitError([false,""]);
        }
    }, [data,useSelector((state) => state.eventCodeRules.updateOpen)]);

    useEffect(()=>{
        if(!isChange){
            setInputRule("");
            setInputLimit("");
            setInputCategory("");
            setInputTicketAction("");
            setInputEmailAction("");
            setLimitError([false,""]);
        }
    },[useSelector((state) => state.eventCodeRules.insertOpen)]);
    

    return(
        <>
         <FormDialogV2
           isOpen={useSelector((state) => state.eventCodeRules.insertOpen)}
           handleToggle={handleCloseInsertClick}
           title = {"Tambah Event Code Rule"}
            >
                 <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={2}>
                             <FormInput
                                changed={inputRule != ""}
                                label={"Rule"}
                                autoFocus
                                onChange={(e) => {setInputRule(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Ticket Action"} items={ticketData??[{}]} onChange={(e)=> setInputTicketAction(e.target.value)}  value={inputTicketAction}  MenuProps={MENUPROPS}/>
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Email Action"} items={emailData??[{}]} onChange={(e)=> setInputEmailAction(e.target.value)}  value={inputEmailAction}  MenuProps={MENUPROPS}/>
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Fault Category (Opsional)"} items={categoryData??[{}]} onChange={(e)=> setInputCategory(e.target.value)}  value={inputCategory}  MenuProps={MENUPROPS}/>
                        </Grid>

                        <Grid item  marginBottom={2}>
                        <FormLabel  label={"Re-Open-Limit (Opsional)"}/>
                            <Grid container item gap={2} alignItems={"center"}>
                                <Grid item width={"50%"}>
                                    <FormInput
                                        changed={inputLimit != ""}
                                        error = {limitError[0]}
                                        helperText = {limitError[1]}
                                        onChange={handleInputLimit}
                                    />
                                </Grid>
                                <FormLabel label={"Minutes"}/>
                            </Grid>
                            
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={3}gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseInsertClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenInsert2Click}
                            disabled = {inputRule== "" ||inputTicketAction==""||inputEmailAction==""}
                            >
                            Simpan
                        </Button>
                       
                    </Grid>
                </DialogActions>
            </FormDialogV2>
       
            {/*                                  update                                                      */}
            <FormDialogV2
            isOpen={useSelector((state) => state.eventCodeRules.updateOpen)}
            handleToggle={handleCloseUpdateClick}
            title={"Detail Event Code Rule"}
            >
                 <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={2}>
                             <FormInput
                                changed={inputRule != ""}
                                label={"Rule"}
                                autoFocus
                                value={data.rule}
                                onChange={(e) => {setInputRule(e.target.value); setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Ticket Action"} items={ticketData??[{}]} onChange={(e)=> {setInputTicketAction(e.target.value); setIsChange(true);}}  value={inputTicketAction} MenuProps={MENUPROPS}/>
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Email Action"} items={emailData??[{}]} onChange={(e)=> {setInputEmailAction(e.target.value);setIsChange(true);}}  value={inputEmailAction} MenuProps={MENUPROPS}/>
                        </Grid>
                        <Grid item marginBottom={2}>
                            <FormSelect label={"Fault Category (Opsional)"} items={categoryData??[{}]} onChange={(e)=>{ setInputCategory(e.target.value);setIsChange(true);}}  value={inputCategory} MenuProps={MENUPROPS}/>
                        </Grid>

                        <Grid  item  marginBottom={2} rowGap={2}>
                            <FormLabel  label={"Re-Open-Limit (Opsional)"}/>
                            <Grid container item gap={2} alignItems={"center"}>
                                <Grid item width={"50%"}>
                                    <FormInput
                                        changed={inputLimit != ""}
                                        value={data.reopen_limit}
                                        error = {limitError[0]}
                                        helperText = {limitError[1]}
                                        onChange={handleInputLimit}
                                    />
                                </Grid>
                                <FormLabel label={"Minutes"}/>
                            </Grid>
                        </Grid>

                    </Grid>
                </DialogContent>
                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={3}gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseUpdateClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenUpdate2Click}
                            disabled = {inputRule== "" ||inputTicketAction==""||inputEmailAction==""||!isChange}
                            >
                            Simpan
                        </Button>
                       
                    </Grid>
                </DialogActions>
            </FormDialogV2>

            <ConfirmDialog
                isOpen={useSelector((state) => state.eventCodeRules.removeOpen)}
                handleClose={handleCloseRemoveClick}
                title={`Yakin akan menghapus Event Code Rule “${data.rule}” ?`}
                handleSave={remove}
                paddingX= "50px"
            />
            
             <ConfirmDialog
                isOpen={openInsert2}
                handleClose={handleCloseInsert2Click}
                title={`Yakin akan menambah Event Code Rule “${inputRule}” ?`}
                handleSave={insert}
                paddingX= "50px"
                paddingTop = "30px"
            />
            <ConfirmDialog
                isOpen={openUpdate2}
                handleClose = {handleCloseUpdate2Click}
                title = {"Yakin akan menyimpan perubahan Event Code Rule?"}
                handleSave = {update}
            />
            </>
    );
}