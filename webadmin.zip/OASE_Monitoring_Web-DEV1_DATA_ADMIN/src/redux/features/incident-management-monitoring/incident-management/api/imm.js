import { createApi } from "@reduxjs/toolkit/query/react";
import { BASE_URL_API_MONITORING } from "../../../../../constants/Api";
import axiosBaseQuery from "../../../../utils/axiosBaseQuery";

const PATH = "/incident";
const V1 = "v1"
const V2 = "v2"
const GET = "GET"

export const immApi = createApi({
   reducerPath: "immApi",
   baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
   endpoints: (builder) => ({
      getFaultCategory: builder.query({
         query: (params = "") => ({ url: `${PATH}/${V2}/category?${params}`, method: GET }),
         keepUnusedDataFor: 0,
         transformResponse: (res) => ({
            faultCategory: res?.data?.data?.faultCategory,
            lastUpdate: res?.data?.lastUpdate,
            totalActiveTerminal: res?.data?.totalActiveTerminal
         }),
      }),
      getTicketIds: builder.query({
         query: (params) => ({ url: `${PATH}/${V1}/tickets?${params}`, method: GET }),
         keepUnusedDataFor: 0,
         transformResponse: (res) => ({
            rows: res?.data?.tickets,
         })
      }),
      getIncidentDetail: builder.query({
         query: (ticketId) => ({ url: `${PATH}/${V1}/incident?ticketId=${ticketId}`, method: GET }),
         keepUnusedDataFor: 0,
         transformResponse: (res) => ({
            _wsid: res?.data?._wsid,
            wsid: res?.data?.wsid,
            currentDetails: res?.data?.currentDetails,
            incidentNumber: res?.data?.incidentNumber,
         })
      }),
      getTerminalDetails: builder.query({
         query: (wsid) => ({ url: `${PATH}/${V1}/terminal?wsid=${wsid}`, method: GET }),
         transformResponse: (res) => ({
            locationGroup: res?.data?.terminalDetails?.locationGroup,
            machineGroup: res?.data?.terminalDetails?.machineGroup,
            networkGroup: res?.data?.terminalDetails?.networkGroup,
            lastUpdate: res?.data?.terminalDetails?.lastUpdate,
         }),
      }),
      getTerminalStatus: builder.query({
         query: (ticketId) => ({ url: `${PATH}/${V1}/status?ticketId=${ticketId}`, method: GET }),
         transformResponse: (res) => ({
            status: res?.data?.status,
         }),
      }),
      getIMMReportInfo: builder.query({
         query: (query) => ({ url: `${PATH}/${V1}/info?${query}`, method: GET }),
         transformResponse: (res) => ({
            total: res?.data?.total,
            showTotal: res?.data?.showTotal
         }),
      }),
   }),
});

export const { useGetFaultCategoryQuery, useGetTicketIdsQuery, useGetIncidentDetailQuery, useGetTerminalDetailsQuery, useGetTerminalStatusQuery, useGetIMMReportInfoQuery } = immApi;