import { EVENT_CODE } from "../../../constants/dbQuery.constant";
import { query as dbQuery } from "../../../databases/oase.database";
import { TQueryParams, TSearchParams } from "../../../types/dataAdmin/dataAdmin.types";
import { handleAdvancedSearchParams, handleSearchParams } from "../../../utils/dbQueryHelper.util";
import { getObjectValues, getObjectValuesOfArrayObject } from "../../../utils/object/convertToArray.util";

export function getEventCodeRules(page: number, limit: number, sortBy: string, orderBy: string, offset: number = page * limit, searchParams?: TSearchParams) {
    let searchData: TQueryParams = {
        query: "",
        params: []
    }

    if (searchParams?.search) {
        searchData = handleSearchParams(searchParams.search);
    }

    if (searchParams?.advancedSearch || searchParams?.advancedSearchPeriode) {
        searchData = handleAdvancedSearchParams(searchParams.advancedSearchPeriode!, searchParams.advancedSearch, "created_time");
    }

    const queryData = `select id, rule, priority, action, email_action, fault_category, reopen_limit, color
        from ${EVENT_CODE.VIEW_RULE} ${searchData.query}
        order by \`${sortBy}\` ${orderBy} limit ${limit} offset ${offset}`;

    const queryTotal = `select count(id) as total from ${EVENT_CODE.VIEW_RULE} ${searchData.query} `;

    const result = dbQuery(queryData, searchData.params);
    const total = dbQuery(queryTotal, searchData.params);

    return Promise.all([result, total]);
}

export function cunGetEventCodeRules(page: number, limit: number, sortBy: string, orderBy: string, offset: number = page * limit, searchParams?: TSearchParams) {
    let searchData: TQueryParams = {
        query: "",
        params: []
    }

    if (searchParams?.search) {
        searchData = handleSearchParams(searchParams.search);
    }

    if (searchParams?.advancedSearch || searchParams?.advancedSearchPeriode) {
        searchData = handleAdvancedSearchParams(searchParams.advancedSearchPeriode!, searchParams.advancedSearch, "created_time");
    }

    const queryData = `select id, rule, priority, action, email_action, fault_category, reopen_limit, color
        from ${EVENT_CODE.VIEW_RULE_CUN} ${searchData.query}
        order by \`${sortBy}\` ${orderBy} limit ${limit} offset ${offset}`;

    const queryTotal = `select count(id) as total from ${EVENT_CODE.VIEW_RULE_CUN} ${searchData.query} `;

    const result = dbQuery(queryData, searchData.params);
    const total = dbQuery(queryTotal, searchData.params);

    return Promise.all([result, total]);
}

export function getEventCodeRule(id: number | undefined) {
    const baseQuery = `select id, rule, action, email_action, fault_category, reopen_limit
        from ${EVENT_CODE.VIEW_RULE} where id = ?`;

    return dbQuery(baseQuery, [id]);
}

export function getEventCodeRuleList() {
    const baseQuery = `select json_arrayagg(json_object('id', id, 'value', rule)) as list from ${EVENT_CODE.VIEW_RULE}`;

    return dbQuery(baseQuery);
}

export function postEventCodeRule(data: { [k: string]: unknown }, createdBy: string | undefined) {
    const baseQuery =
        `INSERT INTO ${EVENT_CODE.TABLE_RULE} (\`rule\`, action_id, email_action_id, fault_category_id, reopen_limit,  is_delete, created_by, priority) 
    SELECT ?, ?, ?, ?, ?, 0, ?, subquery.priority 
    FROM (SELECT (IFNULL(priority, 0) + 1) AS priority FROM ${EVENT_CODE.TABLE_RULE} WHERE is_delete != 1 ORDER BY priority DESC LIMIT 1) AS subquery`;

    return dbQuery(baseQuery, [...getObjectValues(data), createdBy]);
}

// export function injectEventCodeRule(data: { [k: string]: unknown }, createdBy: string | undefined) {
//     const baseQuery =
//         `INSERT INTO event_code_rule_cun (\`rule\`, action_id, email_action_id, fault_category_id, reopen_limit,  is_delete, created_by, priority)
//     SELECT ?, ?, ?, ?, ?, 0, ?, subquery.priority
//     FROM (SELECT (priority + 1) AS priority FROM event_code_rule_cun WHERE is_delete != 1 ORDER BY priority DESC LIMIT 1) AS subquery`;

//     return dbQuery(baseQuery, [...getObjectValues(data), createdBy]);
// }

// export function changeOrdersEventCodeRule(body: [{ [key: string]: unknown }], modifiedBy: string | undefined) {

//     const subquery = body.map(data => {
//         data.modified_by = modifiedBy ? modifiedBy : 'undefined';
//         return `SELECT ? as _id, ? as priority, ? as modified_by`;
//     }).join('\nUNION ALL\n');

//     const query = `UPDATE ${EVENT_CODE.TABLE_RULE} s
//         JOIN (
//         ${subquery}
//         ) vals ON s._id = vals._id
//         SET s.priority = vals.priority, s.modified_by = vals.modified_by;`;

//     return dbQuery(query, [...getObjectValuesOfArrayObject(body)]);
// }

// penyesuaian after lazyload
export function changeOrdersEventCodeRule(body: { [key: string]: unknown }, modifiedBy: string | undefined) {

    const operator = body.start_priority! < body.end_priority! ? '-' : '+'
    const data = {
        param1: operator === '-' ? '>' : '>=',
        param2: operator === '-' ? body.start_priority : body.end_priority,
        param3: operator === '-' ? '<=' : '<',
        param4: operator === '-' ? body.end_priority : body.start_priority
    }

    const query =
        `UPDATE ${EVENT_CODE.TABLE_RULE} t
    SET t.priority = 
    CASE 
        WHEN t.priority ${data.param1} ? AND t.priority ${data.param3} ? AND t._id <> ? THEN (t.priority ${operator} 1)
        WHEN t._id = ? THEN ?
        ELSE t.priority
    END,
    t.modified_by = ?
    WHERE t.is_delete <> 1 AND t.priority >= ? AND t.priority <= ?`;

    return dbQuery(query, [data.param2, data.param4, body.id, body.id, body.end_priority, modifiedBy, data.param2, data.param4]);
}

//sementara doang buat cun
export function cunChangeOrdersEventCodeRule(body: { [key: string]: unknown }, modifiedBy: string | undefined) {

    const operator = body.start_priority! < body.end_priority! ? '-' : '+'
    const data = {
        param1: operator === '-' ? '>' : '>=',
        param2: operator === '-' ? body.start_priority : body.end_priority,
        param3: operator === '-' ? '<=' : '<',
        param4: operator === '-' ? body.end_priority : body.start_priority
    }

    const query =
        `UPDATE ${EVENT_CODE.TABLE_RULE_CUN} t
    SET t.priority = 
    CASE 
        WHEN t.priority ${data.param1} ? AND t.priority ${data.param3} ? AND t._id <> ? THEN (t.priority ${operator} 1)
        WHEN t._id = ? THEN ?
        ELSE t.priority
    END,
    t.modified_by = ?
    WHERE t.is_delete <> 1 AND t.priority >= ? AND t.priority <= ?`;

    return dbQuery(query, [data.param2, data.param4, body.id, body.id, body.end_priority, modifiedBy, data.param2, data.param4]);
}

export function putEventCodeRule(body: { [k: string]: unknown }, id: number | undefined, modifiedBy: string | undefined) {
    const baseQuery = `UPDATE ${EVENT_CODE.TABLE_RULE} t SET t.rule = ?, t.action_id = ?, t.email_action_id = ?, t.fault_category_id = ?, t.reopen_limit = ?, t.modified_by = ? where t._id = ?`;
    let tempData;
    let updateData;
    if (!body.fault_category_id) {
        tempData = { rule: body.rule, fault_category_id: null, ...body }
        updateData = tempData;
    } else {
        updateData = body;
    }

    return dbQuery(baseQuery, [...getObjectValues(updateData), modifiedBy, id]);
}

export function deleteEventCodeRule(id: number | undefined, priority: number | undefined, modifiedBy: string | undefined) {
    const baseQuery = `
    UPDATE ${EVENT_CODE.TABLE_RULE} t 
        SET t.is_delete = CASE
            WHEN _id = ? THEN 1
            ELSE t.is_delete
        END,
        t.priority = CASE
            WHEN t.priority > ? THEN (t.priority - 1)
            ELSE t.priority
        END,
        t.modified_by = ?
    WHERE t.is_delete != 1`;

    return dbQuery(baseQuery, [id, priority, modifiedBy]);
}

export { };

