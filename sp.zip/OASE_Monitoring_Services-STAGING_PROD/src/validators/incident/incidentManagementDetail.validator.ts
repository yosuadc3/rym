import { body, param, query } from "express-validator";

export const getIncidentCurrent = [
    query("ticketId").isString()
];

export const getTerminalDetails = [
    query("wsid").optional().isString(),
    query("ticketId").optional().isString()
];

export const getTerminalCurrentStatus = [
    query("ticketId").optional().isString()
];

export const getIncidentHistory = [
    query("wsid").isString(),
    query("page").isNumeric(),
    query("limit").isNumeric(),
    query("sortBy").isString(),
    query("orderBy").isString(),
    query("status_code").optional().isString(),
    query("all").optional().isString(),
    query("ticket_id").optional().isString(),
    query("action_code").optional().isString(),
    query("action_code_description").optional().isString(),
    query("start_time").optional().isString(),
    query("end_time").optional().isString(),
    query("status_code_description").optional().isString(),
    query("last_comment").optional().isString(),
];

export const getIncidentComments = [
    query("incidentId").isString()
];

export const postIncidentComment = [
    query("incident_id").isString(),
    query("comment_text").isString()
];