import { jsonFailed } from "../utils/jsonMessage.util";

abstract class GlobalError extends Error {
   abstract errorCode: number;
   abstract errorType: string;

   constructor(message: string) {
      super(message);

      Object.setPrototypeOf(this, GlobalError.prototype);
   }

   abstract serializeErrors(): ReturnType<typeof jsonFailed>;
}

export default GlobalError;
