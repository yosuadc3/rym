import React from 'react';
import { Grid, Typography, List, ListItem, ListItemText } from '@mui/material';
import PropTypes from 'prop-types';
import { MapContainer , TileLayer, CircleMarker } from 'react-leaflet'
import 'leaflet/dist/leaflet.css';

const useStyles = {
  root: {
    flexGrow: 1,
  },
  listContainer: {
    display: 'flex',
    flexDirection: 'column',
    '& .MuiListItem-dense': {
      padding: 0,
      marginLeft: 10
    }
  },
  titleList: {
    fontSize: 18,
    fontFamily: 'Montserrat',
    fontWeight: 500,
    width:'9em'
  },
  titleMap: {
    fontSize: 12,
    fontFamily: 'Montserrat',
    fontWeight: 900,
    color: 'grey',
    textAlign: 'left'

  },
  itemListFont: {
    fontSize: 8,
    fontFamily: 'Montserrat',
    fontWeight: 400,
    color: '#65748B',
    textAlign: 'left'
  },
  mapStyle:{
    width:'100%',
    height:'70%'
  },
  demo:{
    marginTop:10
  }
};

function MapsContainer({ data }) {
  const center = [-2.548926, 118.0148634]

  return (
    <div style={useStyles.root}>
      <Grid container spacing={1}>
        <Grid item xs={2} sm={3} lg={3}>
          <Typography variant="subtitle" sx={useStyles.titleList}>Location</Typography>
          <div style={useStyles.demo}>
            <List dense={true} sx={useStyles.listContainer}>
              {data.map((x, index) => {
                return (
                  <ListItem key={index}>
                    <div style={{ width: 10, height: 10, background: x.color, marginRight: 5 }} />
                    <ListItemText
                      primary={x.name}
                      sx={useStyles.itemListFont}
                    />
                  </ListItem>
                )
              })}
            </List>
          </div>
        </Grid>
        <Grid item xs={9} sm={8}>
          <Typography variant="subtitle" sx={useStyles.titleMap}>ATM Location - Vendor Pengisian*</Typography>
          <MapContainer center={center} zoom={4} scrollWheelZoom={false} style={useStyles.mapStyle}>
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
            />
            {data.map((x, index) => {
              return <CircleMarker key={index} center={x.position} {...{ fill: true, fillColor: x.color, fillOpacity: 1, color: x.color }} radius={5} />
            })}
          </MapContainer>,
          <Typography variant="subtitle" sx={useStyles.titleMap}>*Currently showing a limited data set</Typography>
        </Grid>

      </Grid>
    </div>
  )
}


MapsContainer.defaultProps = {
  sx: '',
  data: [],
};

MapsContainer.propTypes = {
  sx: PropTypes.string,
  data: PropTypes.any,
};

export default MapsContainer