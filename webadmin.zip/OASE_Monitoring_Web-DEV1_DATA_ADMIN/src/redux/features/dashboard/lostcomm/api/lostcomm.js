import { createApi } from "@reduxjs/toolkit/query/react";
import { BASE_URL_API_MONITORING } from "../../../../../constants/Api";
import axiosBaseQuery from "../../../../utils/axiosBaseQuery";

const path = "/lost-comm";

export const lostcommApi = createApi({
    reducerPath: "lostcommApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getLostcomm: builder.query({
            query: () => ({ url: path, method: "get" }),
            transformResponse: (res) => {
                const { data } = res
                return {
                    data: data.data,
                    total: data.total,
                    lastUpdate: data.lastUpdate
                }
            }
        }),
        getLostcommReport: builder.query({
            query: () => ({ url: `${path}/report`, method: "get" }),
            transformResponse: (res) => (res.data)
        }),
    })
});

export const { useGetLostcommQuery, useGetLostcommReportQuery } = lostcommApi;
