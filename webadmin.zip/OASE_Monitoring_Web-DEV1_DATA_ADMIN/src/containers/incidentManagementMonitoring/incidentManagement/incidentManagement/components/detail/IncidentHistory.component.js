import { Grid } from "@mui/material";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import StyledSearchV2 from "../../../../../../components/search/StyledSearchV2";
import SkeletonTable from "../../../../../../components/skeleton/SkeletonTable";
import StyledTableV2 from "../../../../../../components/table/StyledTableV2";
import { setTicketId } from "../../../../../../redux/features/incident-management-monitoring/incident-management/imm";
import { INCIDENT_MANAGEMENT_CURRENT_INCIDENT_COLUMNS, INCIDENT_MANAGEMENT_SEARCH } from "../../constants/IncidentManagementDetail";

export default function IncidentHistory({ wsid }) {
  if (wsid === "") return <SkeletonTable amount={6} />;

  const dispatch = useDispatch();

  const { toggleFetchComments } = useSelector(
    (state) => state.incidentManagement
  );
  const [isResetSearch, setIsResetSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const search = (e) => {
    setSearchQuery(e);
  };

  const handleRowClick = (params) => {
    const ticketId = params.row._id;
    dispatch(
      setTicketId({
        data: {
          ticketId
        }
      })
    )
  };

  return (
    <Grid marginTop={1}>
      <Grid item container xs={7}>
        <StyledSearchV2
          selectMenuItems={INCIDENT_MANAGEMENT_SEARCH}
          handleSearchQuery={search}
          isResetSearch={isResetSearch}
          setIsResetSearch={setIsResetSearch}
          useMySQLTimeFormat={false}
        />
      </Grid>
      <Grid item marginTop={2}>
        <StyledTableV2
          headers={INCIDENT_MANAGEMENT_CURRENT_INCIDENT_COLUMNS(handleRowClick)}
          defaultSortBy="id"
          defaultOrderBy="desc"
          link="history"
          route="incident"
          refetchDependencies={[toggleFetchComments]}
          searchQuery={`&wsid=${wsid}` + searchQuery}
          onCellClick={handleRowClick} // scoll keatas
        />
      </Grid>
    </Grid>
  );
}
