import { Response } from "express";
import { matchedData } from "express-validator";
import * as db from "../../repositories/dataAdmin/incidents.repository";
import { IGetAllRequest, IRequestQueryParams, TDbResponse, TRequestParams } from "../../types/dataAdmin/dataAdmin.types";
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import * as dateTimeUtils from "../../utils/dateTime.util";
import { getInternalServerError, jsonSuccess } from "../../utils/jsonMessage.util";
import { replaceNullOrEmptyStringArray } from "../../utils/object/replaceNullOrEmptyStringArray.util";
import printToConsole from "../../utils/printToConsole.util";

const message = {
   "english": `Successfully Retrieved Incidents`,
   "indonesia": `Berhasil Mengambil Incidents`,
}
const errorMessage = "Internal Server Error!";
const errorTag = "getIncidents";


export async function getIncidents(req: IGetAllRequest, res: Response) {
   addPayloadToRequestHeader(req);

   let dbRes: TDbResponse = [[], []];
   // const queryData: IRequestQueryParams = matchedData(req, { locations: ["query"], includeOptionals: true });
   const page = req?.query?.page;
   const limit = req?.query?.limit;
   const sortBy = req?.query?.sortBy;
   const orderBy = req?.query?.orderBy;
   const search = req?.query?.search;
   const advancedSearch = req?.query?.advancedSearch;
   const advancedSearchPeriode = req?.query?.advancedSearchPeriode;

   if (search) {
      const params = {
         search: JSON.parse(search)
      }

      dbRes = await db.getIncidents(page!, limit!, sortBy!, orderBy!, params);
   }
   else if (advancedSearch || advancedSearchPeriode) {
      const params = {
         advancedSearch: advancedSearch ? JSON.parse(advancedSearch) : null,
         advancedSearchPeriode: advancedSearchPeriode ? JSON.parse(advancedSearchPeriode) : null
      }

      dbRes = await db.getIncidents(page!, limit!, sortBy!, orderBy!, params);
   }
   else {
      dbRes = await db.getIncidents(page!, limit!, sortBy!, orderBy!);
   }

   let [rows, [total]] = dbRes;

   const payload = {
      ...total,
      rows
   }

   res.send(jsonSuccess(message, payload));
}
