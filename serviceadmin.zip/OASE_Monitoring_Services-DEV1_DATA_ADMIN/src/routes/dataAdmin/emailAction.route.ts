import * as controller from "../../controllers/dataAdmin/emailAction.controller";
import errorWrapper from "../../utils/errorWrapper.util";
const router = require("express").Router();

router.get("/list", errorWrapper(controller.getEmailAction));

export default router;