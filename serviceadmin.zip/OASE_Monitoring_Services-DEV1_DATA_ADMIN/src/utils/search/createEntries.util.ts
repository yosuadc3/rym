export default (a: string[], b: string[]) => {
	return a.map((el, i) => [el, b[i]]);
};

export {};
