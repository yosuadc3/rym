import { body, param, query } from "express-validator";

export const getEventCodes = [
    query("catalog_id").isString(),
    query("page").isNumeric(),
    query("limit").isNumeric(),
    query("sortBy").isString(),
    query("orderBy").isAlpha(),
    query("search").optional().isJSON(),
    query("advancedSearch").optional().isJSON(),
    query("advancedSearchPeriode").optional().isJSON(),
];

export const getEventCode = [
    param("id").isUUID()
];

export const putEventCode = [
    param("id").isUUID(),
    body("event_code").optional().isString(),
    body("description").optional().isString(),
    body("group_id").optional({ nullable: true }).isUUID(),
    body("rule_id").optional().isUUID(),
    body("catalog_id").optional().isUUID(),
    body("knowledge_base").optional().isString(),
];

export const postEventCode = [
    body("event_code").isString(),
    body("description").isString(),
    body("group_id").optional({ nullable: true }).isUUID(),
    body("rule_id").optional().isUUID(),
    body("catalog_id").optional().isUUID(),
    body("knowledge_base").optional().isString(),
];

export const deleteEventCode = [
    param("id").isUUID()
];