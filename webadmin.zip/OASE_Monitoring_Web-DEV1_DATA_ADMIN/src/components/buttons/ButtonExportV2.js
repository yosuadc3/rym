import { Button } from "@mui/material";
import * as FileSaver from "file-saver";
import moment from "moment";
import React, { useEffect, useState } from "react";
import * as XLSX from "xlsx";
import useGet from "../../hooks/useGet";

const styles = {
  button: (disabled) => ({
    fontSize: "16px",
    fontWeight: "bold",
    px: 3,
    py: 1.5,
    textTransform: "none",
    "&.MuiButton-contained": {
      backgroundColor: disabled ? "#F0EBEB" : "#156db8",
    },
  }),
};

function exportToCSV(json, fileName, fileType, fileExtension, timestamp, bookType) {
  const ws = XLSX.utils.json_to_sheet(json);
  const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
  const excelBuffer = XLSX.write(wb, { bookType: bookType, type: "array" });
  const data = new Blob([excelBuffer], { type: fileType });

  const datetime =
    timestamp === true ? `_${moment().format("DDMMYYYY_HH-mm-ss")}` : "";

  FileSaver.saveAs(data, fileName + datetime + fileExtension);
}

function ButtonExportV2({ link, route, query, timestamp, filename, trigger, extension = "csv", disabled }) {
  //Flag for buttonclick
  const [rows, setRows] = useState([]);
  const [flag, setFlag] = useState(false);
  // const [isFirstRender, setIsFirstRender] = useState(true);
  const fileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  const fileExtension = `.${extension}`;
  const endpoint = `${link}?${query}`;

  // useEffect(() => {
  //   if (isFirstRender) {
  //     setIsFirstRender((prev) => false);
  //     return;
  //   }
  //   handleGetReport();
  // }, [...trigger]);

  useEffect(() => {
    if (flag) {
      exportToCSV(rows, filename, fileType, fileExtension, timestamp, extension);
      setFlag(false);
    }
  }, [flag, rows]);

  //Props for exporting to csv
  const handleGetReport = async () => {
    const data = await useGet(endpoint, route);
    setRows(data?.data?.rows);
    setFlag(true);
  };

  return (
    <>
      <Button
        onClick={handleGetReport}
        variant="contained"
        size="small"
        sx={styles.button(disabled)}
        disabled={disabled}
      >
        Download File
      </Button>
    </>
  );
}

export default ButtonExportV2;
