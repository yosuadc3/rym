import { Response } from "express";
import { matchedData, validationResult } from "express-validator";
import { HTTP_NO_CONTENT } from "../../constants/httpResponseCodes.constant";
import * as db from "../../repositories/dataAdmin/faultCategory.repository";
import { IGetAllRequest, IRequestQueryParams, TDbResponse, TRequestParams } from "../../types/dataAdmin/dataAdmin.types";
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import { getInternalServerError, jsonSuccess } from "../../utils/jsonMessage.util";
import { replaceNullOrEmptyStringArray } from "../../utils/object/replaceNullOrEmptyStringArray.util";
import printToConsole from "../../utils/printToConsole.util";

const message = {
    "english": `Successfully Retrieved Fault Category`,
    "indonesia": `Berhasil Mengambil Fault Category`,
}
const errorMessage = "Internal Server Error!";
const errorTag = "getFaultCategory";

export async function getFaultCategories(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    let dbRes: TDbResponse = [[], []];
    //const queryData: IRequestQueryParams = matchedData(req, { locations: ["query"], includeOptionals: true });
    const page = req?.query?.page;
    const limit = req?.query?.limit;
    const sortBy = req?.query?.sortBy;
    const orderBy = req?.query?.orderBy;
    const offset = req?.query?.offset;
    const search = req?.query?.search;
    const advancedSearch = req?.query?.advancedSearch;
    const advancedSearchPeriode = req?.query?.advancedSearchPeriode;

    if (search) {
        const params = {
            search: JSON.parse(search)
        }

        dbRes = await db.getFaultCategories(page!, limit!, sortBy!, orderBy!, offset!, params);
    }
    else if (advancedSearch || advancedSearchPeriode) {
        const params = {
            advancedSearch: advancedSearch ? JSON.parse(advancedSearch) : null,
            advancedSearchPeriode: advancedSearchPeriode ? JSON.parse(advancedSearchPeriode) : null
        }

        dbRes = await db.getFaultCategories(page!, limit!, sortBy!, orderBy!, offset!, params);
    }
    else {
        dbRes = await db.getFaultCategories(page!, limit!, sortBy!, orderBy!, offset!);
    }

    const [data, [total]] = dbRes;

    replaceNullOrEmptyStringArray(data);

    const payload = {
        ...total,
        data: data
    }

    res.send(jsonSuccess(message, payload));
}

export async function getFaultCategory(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    //const paramsData: TRequestParams = matchedData(req, { locations: ["params"] });

    const [data] = await db.getFaultCategory(req?.params?.id!);

    res.send(jsonSuccess(message, data));
}

export async function getFaultCategoryList(req: IGetAllRequest, res: Response) {
    const dbRes: TDbResponse = await db.getFaultCategoryList();

    const [data] = dbRes;

    const payload = {
        ...data
    }

    res.send(jsonSuccess(message, payload));
}

export async function postFaultCategory(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    // const bodyData = matchedData(req, { locations: ["body"], includeOptionals: true });

    const message = {
        "english": `Successfully Insert A Fault Category`,
        "indonesia": `Berhasil Memasukkan Sebuah Fault Category`,
    }

    await db.postFaultCategory(req?.body, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function putFaultCategory(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    const bodyData = matchedData(req, { locations: ["body"] });
    const paramsData = matchedData(req, { locations: ["params"] });

    const message = {
        "english": `Successfully Updated A Fault Category`,
        "indonesia": `Berhasil Mengubah Sebuah Fault Category`,
    }

    await db.putFaultCategory(req?.body, req?.params?.id, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function changeOrdersFaultCategory(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);

    const name = req.kauth.grant?.access_token.content.preferred_username;
    const bodyData = matchedData(req, { locations: ["body"] });

    const message = {
        "english": `Successfully Updated The Priority of The Fault Category`,
        "indonesia": `Berhasil Mengubah Prioritas Fault Category`,
    }

    await db.changeOrdersCategory(req?.body, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export async function deleteFaultCategory(req: IGetAllRequest, res: Response) {
    addPayloadToRequestHeader(req);
    const name = req.kauth.grant?.access_token.content.preferred_username;

    const paramsData = matchedData(req, { locations: ["params"] });

    const message = {
        "english": `Successfully Delete A Fault Category`,
        "indonesia": `Berhasil Menghapus Sebuah Fault Category`,
    }

    await db.deleteFaultCategory(req?.params?.id, req?.body?.priority, name);

    res.status(HTTP_NO_CONTENT).send(jsonSuccess(message));
}

export { };

