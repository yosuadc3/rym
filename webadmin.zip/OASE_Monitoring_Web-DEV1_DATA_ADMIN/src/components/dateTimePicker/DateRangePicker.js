import { Divider, Grid } from "@mui/material";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import React from "react";
import DatePicker from "./DatePicker";

export default function DateRangePicker({ date, setDate, handleDateError, disabled = false, showHint = true, minDate, maxDate }) {
	const handleStartDateChange = (newValue) => {
		setDate((prev) => ({ ...prev, start: newValue }));
	};

	const handleEndDateChange = (newValue) => {
		setDate((prev) => ({ ...prev, end: newValue }));
	};

	return (
		<LocalizationProvider dateAdapter={AdapterMoment}>
			<Grid container>
				<Grid item xs={5.5}>
					<DatePicker
						label="Start"
						startDate={date.start}
						endDate={date.end}
						placeholder={(!disabled && showHint) ? "Start" : ""}
						onError={(err) => handleDateError(err, "start")}
						isSmall
						isStartDate
						onChange={handleStartDateChange}
						disabled={disabled}
						minDate={minDate}
						maxDate={maxDate}
					/>
				</Grid>
				<Grid item xs={1} alignSelf={"center"}>
					<Divider
						color="black"
						sx={{ margin: "auto", textAlign: "center", width: "50%", border: "1px solid black" }}
					/>
				</Grid>
				<Grid item xs={5.5}>
					<DatePicker
						label="End"
						startDate={date.start}
						endDate={date.end}
						placeholder={(!disabled && showHint) ? "End" : ""}
						onError={(err) => handleDateError(err, "end")}
						isSmall
						onChange={handleEndDateChange}
						disabled={disabled}
						minDate={minDate}
						maxDate={maxDate}
					/>
				</Grid>
			</Grid>
		</LocalizationProvider>
	);
}
