import { Box, Grid, Stack, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import StyledPaper from "../../../../components/paper/StyledPaper";
import StyledSearchV2 from "../../../../components/search/StyledSearchV2";
import SkeletonText from "../../../../components/skeleton/SkeletonText";
import { setAll, setIsResetSearch, setTicketId, setTicketId_, setToggleRefresh } from "../../../../redux/features/incident-management-monitoring/incident-management/imm";
import {
  INCIDENT_MANAGEMENT_SEARCH,
  REFRESH_TIMEOUT_MS,
  styles
} from "./constants/IncidentManagement";

import { useGetFaultCategoryQuery } from "../../../../redux/features/incident-management-monitoring/incident-management/api/imm";
import Breadcrumbs from "./components/Breadcrumbs.component";
import Dropdown from "./components/Dropdown.component";
import FaultCategories from "./components/FaultCategories.component";
import Header from "./components/Header.component";
import Refresh from "./components/Refresh.component";

export default function IncidentManagement() {
  const { toggleRefresh, isResetSearch } = useSelector(state => state.incidentManagement);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [searchQuery, setSearchQuery] = useState("");

  const { data, isLoading, isFetching, error, refetch } = useGetFaultCategoryQuery(searchQuery, {
    refetchOnFocus: true,
    refetchOnMountOrArgChange: true,
    refetchOnReconnect: true
  });

  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
      dispatch(setToggleRefresh({ toggleRefresh: !toggleRefresh }));
    }, REFRESH_TIMEOUT_MS);

    return () => clearInterval(interval);
  }, [isFetching])

  useEffect(() => {
    dispatch(setAll({
      data: {
        wsid: "",
        ticketId: "",
      }
    }))
  }, []);

  const handleRowClick = (params) => {
    const id = params.row.id;
    if (typeof id === "number") {
      const _ticketId = params.row._id;

      dispatch(
        setTicketId({
          data: {
            ticketId: _ticketId
          }
        }));

      navigate(`/incident-management/${_ticketId}/-`);
      return;
    }

    // ini pasti wsid
    const _wsid = params.row._wsid;
    navigate(`/incident-management/-/${_wsid}`);
  };

  const handleRefreshData = () => {
    setSearchQuery((_) => "");
    dispatch(setIsResetSearch({ isResetSearch: !isResetSearch }))
    refetch();
  };

  const faultCategory = data?.faultCategory;
  const lastUpdate = data?.lastUpdate;
  const totalActiveTerminal = data?.totalActiveTerminal;

  return (
    <Box>
      <Grid container marginTop={4.3}>
        <Breadcrumbs />
        <Grid item container xs={5} justifyContent="end">
          <Stack
            display="flex"
            justifyContent="flex-end"
            alignItems="flex-end"
            width={1}
          >
            <Typography sx={styles.typography}>
              <Typography sx={styles.lastUpdate}>
                Last Update
                <span style={styles.lastUpdateSpan}>
                  {isLoading || error ? (
                    <SkeletonText height={20} />
                  ) : (
                    lastUpdate
                  )}
                </span>
              </Typography>
            </Typography>
            <Refresh
              disabled={isLoading ? true : false}
              handleRefreshData={handleRefreshData}
            />
          </Stack>
        </Grid>
      </Grid>
      <Grid container marginTop={1}>
        <Grid item container xs={7}>
          <StyledSearchV2
            selectMenuItems={INCIDENT_MANAGEMENT_SEARCH}
            handleSearchQuery={setSearchQuery}
            useAdvancedSearch
            isResetSearch={isResetSearch}
            setIsResetSearch={setIsResetSearch}
            useMySQLTimeFormat={false}
          />
        </Grid>
        <Grid item container xs={5} justifyContent="end">
          <Typography sx={{ ...styles.totalTerminal, ...styles.totalTerminalText }}>
            {
              isLoading || error ? (
                <SkeletonText height={33} />
              ) : (
                <>
                  <span style={{
                    fontWeight: 500,
                    color: "black",
                  }}>Total Terminal: &nbsp; </span>{totalActiveTerminal} {totalActiveTerminal > 1 ? "Terminals" : "Terminal"}
                </>
              )
            }
          </Typography>
        </Grid>
      </Grid>
      <Grid container sx={{ marginTop: 2 }} width="100%">
        <StyledPaper
          useTopBorder={false}
          customBoxShadow="2px 4px 8px rgba(0, 0, 0, 0.25)"
        >
          <Grid item xs={12}>
            <Grid container>
              <Grid item xs={12}>
                <Header />
              </Grid>
              {isLoading || error ? (
                <>
                  {Array(15)
                    .fill(0)
                    .map((_, i) => (
                      <Grid key={i} item xs={12}>
                        <Dropdown idx={i} isLoading />
                      </Grid>
                    ))}
                </>
              ) : (
                <>
                  <FaultCategories
                    data={faultCategory}
                    handleRowClick={handleRowClick}
                    searchQuery={searchQuery}
                  />
                </>
              )}
            </Grid>
          </Grid>
        </StyledPaper>
      </Grid>
    </Box>
  );
}
