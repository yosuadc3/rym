import { Grid, TextField } from "@mui/material";
import React, { useEffect, useRef } from "react";
import FormLabel from "./FormLabel";

const styles = {
	textInput: (notEmpty, disabled) => ({
		width: "100%",
		"& .MuiInputBase-root": {
			background: disabled ? "#E0E0E0" : notEmpty ? "#E4F2FF" : "#FFFFFF",
			fontWeight: 700,
		},
	}),
};

function FormTextInput({
	label,
	autoFocus = false,
	disabled = false,
	helperText,
	error,
	maxLength,
	onChange = () => { },
	value,
	useMultiline = false,
	inputRef,
}) {
	return (
		<Grid container direction={"column"} textAlign={"left"}>
			<Grid item>
				<FormLabel label={label} />
			</Grid>
			<Grid item>
				<TextField
					inputRef={inputRef}
					type={"text"}
					multiline={useMultiline}
					minRows={useMultiline ? 4 : 1}
					autoFocus={autoFocus}
					disabled={disabled}
					error={error}
					helperText={helperText}
					inputProps={{ maxLength: maxLength }}
					onChange={onChange}
					variant={"outlined"}
					defaultValue={value}
					sx={styles.textInput(value, disabled)}
				/>
			</Grid>
		</Grid>
	);
}

export default FormTextInput;
