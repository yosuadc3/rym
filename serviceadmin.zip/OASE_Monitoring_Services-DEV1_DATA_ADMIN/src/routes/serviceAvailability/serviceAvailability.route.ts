import * as controller from "../../controllers/serviceAvailability/serviceAvailability.controller";
import { protect } from "../../middlewares/keycloakHandler.middleware";
import errorWrapper from "../../utils/errorWrapper.util";
let router = require("express").Router();

router.get(
	"/",
	protect(["GET_SERVICE_AVAILABILITY"]),
	errorWrapper(controller.getStatus)
);
router.get(
	"/dsa-stats",
	protect(["GET_SERVICE_AVAILABILITY"]),
	errorWrapper(controller.getDsaStats)
);
router.get(
	"/summary",
	protect(["GET_SERVICE_AVAILABILITY"]),
	errorWrapper(controller.getSummary)
);
router.get(
	"/report",
	protect(["GET_SERVICE_AVAILABILITY_REPORT"]),
	errorWrapper(controller.getReport)
);
router.get(
	"/search-items",
	protect(["GET_SERVICE_AVAILABILITY"]),
	errorWrapper(controller.getSearchItems)
);

export default router;
export { };

