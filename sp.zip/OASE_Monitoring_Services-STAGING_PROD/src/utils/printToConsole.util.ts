const getTimestamp = require("./dateTime.util").forLogging;

export default function (
	tag: string | null | undefined = "common",
	error: string | unknown,
	timestamp = true
) {
	if (timestamp) {
		console.log(`[${tag} | ${getTimestamp()}]`, error);
	} else {
		console.log(`[${tag}]`, error);
	}
}
export { };

