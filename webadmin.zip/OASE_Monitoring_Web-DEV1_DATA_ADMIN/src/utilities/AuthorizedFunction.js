// import { useKeycloak } from '@react-keycloak/web';

export default function AuthorizedFunction(roles) {
    // const {keycloak} = useKeycloak()

    const userRoles = JSON.parse(localStorage.getItem('roles'))

    const isAutherized = () => {
        if (roles && roles.length > 0 && userRoles && userRoles.length > 0){
            return roles.some(role => userRoles.includes(role));
            // if (userRoles.includes(roles[0])) {
            //     return true
            // }
        }
        return false
    }

    return isAutherized();
}