import React, { useState } from "react";
import { Box, Button, Grid, Typography } from "@mui/material";
import Cards from "../../../components/cards/Cards";
import CustomStaticDateRangePicker from "../../../components/dateTimePicker/CustomStaticDateRangePicker";
import MonthYearPicker from "../../../components/dateTimePicker/MonthYearPicker";
import CustomBreadcrumbs from "../../../components/breadcrumb/CustomBreadcrumbs";

const breadcrumbs = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "Out of Cash",
        link: null,
        current: true
    },
];

const styles = {
    box: {
        height: "100%",
        borderRadius: "8px",
        padding: "2%",
        boxShadow: "6"
    },
    title: {
        fontSize: "2.5vw",
        fontWeight: 700,
        color: "#156db8"
    }
}


function OutOfCash() {
    const [dateRange, setDateRange] = useState([null, null]);
    const [month, setMonth] = useState(null);

    const totalOutOfCash = 46;
    const lastUpdate = "01-01-1001 01:01:01";
    const dataOutOfCash = {
        title: "Out of Cash",
        mainText: totalOutOfCash,
        subText: "Last Update : " + lastUpdate,
        warning: false
    };

    //Button onClick handle
    const downloadDailyReport = () => {
        console.log(dateRange);
    }

    const downloadMonthlyReport = () => {
        console.log(month);
    }

    return (
        <>
            <Grid container alignItems={"center"} height={60}>
                <Grid item xs>
                    <CustomBreadcrumbs breadcrumbs={breadcrumbs} />
                </Grid>
            </Grid>
            <Grid container>
                <Grid item paddingTop={2} paddingRight={1.5} xs>
                    <Cards type="big" data={dataOutOfCash} />
                </Grid>
            </Grid>
            <Grid container spacing={2} marginTop={1}>
                <Grid item xs={6}>
                    <Box sx={styles.box}>
                        <Typography sx={styles.title}>Laporan Harian</Typography>
                        <CustomStaticDateRangePicker setDateRange={setDateRange} />
                        <Box marginTop="2%" marginBottom={2}>
                            <Button onClick={downloadDailyReport} variant="contained" sx={{ fontWeight: "bold", fontSize: "0.8vw" }}>Download</Button>
                        </Box>
                    </Box>
                </Grid>
                <Grid item xs={6}>
                    <Box sx={styles.box}>
                        <Typography sx={styles.title}>Laporan Bulanan</Typography>
                        <MonthYearPicker setMonth={setMonth} />
                        <Box marginTop="2%" marginBottom={2}>
                            <Button onClick={downloadMonthlyReport} variant="contained" sx={{ fontWeight: "bold", fontSize: "0.8vw" }}>Download</Button>
                        </Box>
                    </Box>
                </Grid>
            </Grid>
        </>
    );
}


export default OutOfCash;