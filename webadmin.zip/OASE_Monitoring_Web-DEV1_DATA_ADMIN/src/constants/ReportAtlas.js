export const REPORT_CATEGORY_ITEMS = [
    {
        id: "vendor_service",
        label: "Pengelola",
    },
    {
        id: "city",
        label: "Kota",
    },
    {
        id: "location_category",
        label: "Daerah",
    },
    {
        id: "province",
        label: "Provinsi",
    },
    {
        id: "vendor_mesin",
        label: "Vendor Mesin",
    },
    {
        id: "group_ip",
        label: "Group IP",
    },
    {
        id: "tandem",
        label: "Tandem",
    },
    {
        id: "location_1st",
        label: "Lokasi",
    },
    {
        id: "kanwil",
        label: "Deskcw (Kanwil)",
    },
];