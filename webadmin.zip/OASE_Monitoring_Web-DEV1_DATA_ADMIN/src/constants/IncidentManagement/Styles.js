export const STYLES = { 
    outlinedButton:{
        color:"#0D5CAB",
        borderColor:"#0D5CAB",
        fontWeight:"700",
        fontSize:"16px",
        textTransform:"capitalize",
        padding:"10px",
        paddingX:"25px",
        borderRadius:"6px",
        width:"120px"
    },
    containedButton:{
        backgroundColor:"#0D5CAB",
        fontWeight:"700",
        fontSize:"16px",
        textTransform:"capitalize",
        padding:"10px",
        paddingX:"25px",
        borderRadius:"6px",
        width:"120px"
    },
    table: {
        "& .MuiDataGrid-iconButtonContainer": {
            marginLeft: "0px !important"
        },
        height: 586,
    },
    scroll:{
        "& ::-webkit-scrollbar": {
			width: "18px",
		},
		"& ::-webkit-scrollbar-track": {
			backgroundColor: "transparent",
			marginTop: "70px",
			marginBottom: "10px"
		  },
		"& ::-webkit-scrollbar-thumb": {
			borderRadius: "8px",
			borderLeft: "5px solid #fff",
			borderRight: "5px solid #fff",
			backgroundColor: "#D9D9D9",
			transition: "color .3s ease-in-out, .3s ease-in-out",
		  },
		  "& ::-webkit-scrollbar-thumb:hover": {
			borderRadius: "8px",
			borderLeft: "5px solid #fff",
			borderRight: "5px solid #fff",
			backgroundColor: "#BDBABA",
		  }
    },
    dialogForm:{
        position: 'absolute',
        top: "16%"
    },
    dialogContent:{
        width:"550px"
    }
};


export const MENUPROPS = {
    PaperProps: {
      style: {
        maxHeight: 190,
      },
    },
  };