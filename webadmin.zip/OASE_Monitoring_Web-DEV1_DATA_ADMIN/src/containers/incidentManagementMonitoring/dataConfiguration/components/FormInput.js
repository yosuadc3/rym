import { Grid, TextField } from "@mui/material";
import React, { useEffect, useRef } from "react";
import FormLabel from "../../../../components/form/FormLabel";

const styles = {
	textInput: (changed,disabled) => ({
		width: "100%",
		"& .MuiInputBase-root": {
			background: disabled ? "#E0E0E0" : changed? "#E4F2FF" : "#FFFFFF",
			fontWeight: 700,
		},
	}),
};

function FormInput({
    changed,
	label,
	autoFocus = false,
	disabled = false,
	helperText,
	error,
	maxLength,
	onChange = () => { },
	onClick = () => { },
	value,
	useMultiline = false,
	inputRef,
	minRow = 4,
	maxRow = 4,
}) {
	return (
		<Grid container direction={"column"} textAlign={"left"}>
			<Grid item>
				<FormLabel label={label} />
			</Grid>
			<Grid item>
				<TextField
					inputRef={inputRef}
					type={"text"}
					multiline={useMultiline}
					minRows={useMultiline ? minRow : 1}
					maxRows={useMultiline ? maxRow : 1}
					autoFocus={autoFocus}
					disabled={disabled}
					error={error}
					helperText={helperText}
					inputProps={{ maxLength: maxLength }}
					onChange={onChange}
					onClick={onClick}
					variant={"outlined"}
					defaultValue={value}
					sx={styles.textInput(changed,disabled)}
				/>
			</Grid>
		</Grid>
	);
}

export default FormInput;
