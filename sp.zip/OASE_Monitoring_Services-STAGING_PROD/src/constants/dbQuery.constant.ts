const oaseScheme = process.env.DB_SCHEMA_OASE;

export default Object.freeze({
	VIEW_SERVICE_AVAILABILITY: "vw_service_availability",
	VIEW_SERVICE_AVAILABILITY_REPORT: "vw_service_availability_report",
	TABLE_TERMINAL_TERPADUS: `${oaseScheme}.terminal_terpadus`,
	TABLE_TERMINALS: `${oaseScheme}.terminals`,
	TABLE_MASTER_DROPDOWNS: `${oaseScheme}.master_dropdowns`,
	VIEW_REPORT_ATLAS_FILTER_VALUES: "vw_report_atlas_filter_values",
	TABLE_DASHBOARD_SERVICE_AVAILABILITY: "dashboard_atlas_service_availability",
	TABLE_MAPPING_DSA_SUMMARY: "mapping_dsa_summary",
});
