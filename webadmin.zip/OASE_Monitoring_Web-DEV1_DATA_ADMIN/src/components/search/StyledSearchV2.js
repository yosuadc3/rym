import AddBoxIcon from "@mui/icons-material/AddBox";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  Box,
  Button,
  Divider,
  FormControl,
  IconButton,
  MenuItem,
  OutlinedInput,
  Popover,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import React, { createRef, useEffect, useRef, useState } from "react";
import Search from "../../components/svgs/Search";
import {
  MSSQLTimeFormat,
  mySQLTimeFormat,
} from "../../utilities/TimeConverter";
import ButtonCommon from "../buttons/ButtonCommon";
import StyledChips from "../chip/StyledChip";
import Date from "../svgs/Date";

const styles = {
  labelPeriode: {
    fontWeight: 600,
    fontSize: "1rem",
    color: "#65748B",
  },
  labelKategori: {
    fontWeight: 600,
    fontSize: "1rem",
    color: "#65748B",
    paddingTop: "28px",
  },
  hr: {
    width: "4%",
    margin: "1.2rem 1rem 0 1rem",
    height: 0,
    border: "1px solid black",
  },
  boxAS: {
    minWidth: 200,
    marginLeft: 5,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  searchWrapper: {
    minWidth: 200,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  select: {
    height: 48,
    textAlign: "left",
    borderRadius: 0,
    fontSize: 18,
    fontWeight: 500,
    width: "100%",
    "& .MuiSvgIcon-root": {
      color: "#156db8",
      fontSize: "2.5rem",
    },
  },
  paperSelect: {
    "& .MuiPaper-root > .MuiList-root > .MuiButtonBase-root-MuiMenuItem-root .Mui-selected ":
    {
      display: "none",
    },
    "& .MuiPaper-root > .MuiList-root > .MuiMenuItem-root.Mui-selected ": {
      display: "none",
    },
    ".MuiList-root > .MuiMenuItem-root.Mui-selected ": {
      display: "none",
    },
  },
  searchIcon: {
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
    borderTopRightRadius: 7,
    borderBottomRightRadius: 7,
    backgroundColor: "#0D5CAB",
    width: 50,
    height: 48,
    "&:hover": {
      backgroundColor: "#0D5CAB",
    },
  },
  parentBox: {
    width: "full",
    display: "flex",
    alignItems: "left",
    justifyContent: "left",
    flexDirection: "row",
  },
  buttonAS: {
    fontSize: "16px",
    fontWeight: 700,
    width: 208,
    height: 48,
    // paddingX: 7,
    textTransform: "none",
    borderRadius: 2,
    backgroundColor: "#0D5CAB",
    color: "white",
    transition: "transform .2s ease-in-out",
    "&:hover": {
      backgroundColor: "#125FA1",
    },
    "&:active": {
      backgroundColor: "#0D5CAB",
    },
  },
  popoverBox: {
    height: "340px",
    overflow: "auto",
    width: "100%",
    borderRadius: "8px",
    padding: "24px 30px 0 30px",
    backgroundColor: "white",
  },
  selectAS: {
    fontWeight: 500,
    minWidth: "230px",
    height: "100%",
    background: "#FFF",
    boxSizing: "border-box",
    "& .MuiSvgIcon-root": {
      color: "#156db8",
      fontSize: "2.5rem",
    },
    "&.Mui-selected": {
      display: "none",
    },
    "&.MuiMenuItem-root > .Mui-selected": {
      display: "none",
    },
    "&.MuiButtonBase-root-MuiMenuItem-root .Mui-selected ": {
      display: "none",
    },
    "& .MuiPaper-root > .MuiList-root > .MuiMenuItem-root.Mui-selected ": {
      display: "none",
    },
  },
  submitAS: {
    textTransform: "inherit",
    float: "right",
    fontWeight: "bold",
    marginTop: "40px",
    marginRight: "15px",
    marginBottom: "40px",
    width: 120,
    backgroundColor: "#0D5CAB",
    height: 48,
    color: "white",
    borderRadius: 1,
    fontSize: 16,
    fontFamily: "Montserrat",
    textTransform: "inherit",
    marginLeft: 2,
    "&:hover": {
      backgroundColor: "#125fa1",
    },
    "&:active": {
      backgroundColor: "#0D5CAB",
    },
  },
  category: {
    display: "flex",
    gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
    marginTop: "12px",
    width: "100%",
    gap: 10,
  },
  iconAS: (type) => ({
    "& :hover": {
      cursor: "pointer",
    },
    color: type === "add" ? "#156db8" : "#d63031",
    marginTop: "0.9%",
    marginLeft: type === "add" ? "10%" : "1.2%",
    fontSize: "35px",
  }),
};

export default function StyledSearchV2({
  selectMenuItems = [{ value: "all", label: "All" }],
  useAdvancedSearch = false,
  handleSearchQuery,
  isResetSearch,
  setIsResetSearch,
  useMySQLTimeFormat = true,
}) {
  const [value, setValue] = useState(selectMenuItems[0].value);
  const [anchorEl, setAnchorEl] = useState(null);
  const [searchInput, setSearchInput] = useState({
    text: "",
    column: "all",
  });

  // Advanced Search
  const [selectMenuItemsAS, setSelectMenuItemsAS] = useState(
    selectMenuItems.slice(1)
  );
  const [valueAS, setValueAS] = useState("");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const chipsRef = useRef([]);
  const [advancedData, setAdvancedData] = useState([
    {
      category: null,
      chips: [],
      label: null,
    },
  ]);
  const [selectPlaceholder, setSelectPlaceholder] = useState([]);

  const selectMenuItemsLen = selectMenuItems.length;

  useEffect(() => {
    if (isResetSearch) {
      setSearchInput((prev) => ({
        text: "",
        column: "all",
      }));
      setValue((prev) => selectMenuItems[0].value);
      setStartDate((prev) => null);
      setEndDate((prev) => null);
      setAdvancedData((prev) => [
        {
          category: null,
          chips: [],
          label: null,
        },
      ]);
      setIsResetSearch((prev) => false);
    }
  }, [isResetSearch]);

  if (selectPlaceholder.length !== selectMenuItemsLen) {
    const selectPlaceholderTemp = Array(selectMenuItemsLen).fill("blank");
    setSelectPlaceholder(selectPlaceholderTemp);
  }

  // Generate empty array(s), then fill each with a createRef value
  if (chipsRef.current.length !== selectMenuItemsLen) {
    chipsRef.current = Array(selectMenuItemsLen)
      .fill()
      .map((_, i) => chipsRef.current[i] || createRef());
  }

  const [selectMenuItemsFilter, setSelectMenuItemsFilter] = useState([]);

  function ArrowDownIcon() {
    return (
      <ArrowDropDownIcon
        sx={{
          color: "#0D5CAB",
        }}
        className="icon"
      />
    );
  }

  const handleSearchTextInput = (text) => {
    setSearchInput({
      ...searchInput,
      text,
    });
  };

  const handleSelectMenuSearch = (e, obj) => {
    const { value: column } = obj.props;
    setValue(e.target.value);

    setSearchInput({
      ...searchInput,
      column,
    });
  };

  const handleSearchClick = (searchInput) => {
    let { text, column } = searchInput;

    text = encodeURIComponent(text);

    let query = "&";

    if (column === "all") {
      if (text.length === 0) {
        handleSearchQuery("");
      } else {
        query += column;
      }
    } else {
      query += column;
    }

    query += `=${text}`;

    handleSearchQuery(query);
  };

  const isOpen = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;

  /** Advanced Search functionality */
  const handleShowPopover = (e) => {
    setAnchorEl(e.currentTarget);
  };

  const handleClosePopover = (e) => {
    setAnchorEl(null);
  };

  const handleSelectMenuAS = (idx, e) => {
    advancedData[idx].category = e.target.value.value;
    advancedData[idx].label = e.target.value.label;

    setAdvancedData([...new Set(advancedData)]);
  };

  const handleAddSelectMenuAS = (e) => {
    const advancedDataTemp = [...advancedData];
    advancedDataTemp.push({
      category: null,
      label: null,
      chips: [],
    });
    setAdvancedData([...new Set(advancedDataTemp)]);
  };

  const handleDeleteSelectMenuAS = (e, idx) => {
    const advancedDataTemp = [...advancedData];
    advancedDataTemp.splice(idx, 1);
    setAdvancedData(advancedDataTemp);

    const selectMenuItemsFilterTemp = [...selectMenuItemsFilter];
    selectMenuItemsFilterTemp.splice(idx, 1);
    setSelectMenuItemsFilter(selectMenuItemsFilterTemp);
  };

  /**
   * Handle add chip functionality to a specific element from advancedData
   * @param {Event} e Event
   * @param {Integer} idx Index pointing to a specific element from advancedData
   * @param {Hook} ref A useRef hook element which is pointing to a specific OutlinedInput
   */
  const handleAddChip = (e, idx, ref) => {
    e.preventDefault();

    // If user typed white spaces only
    if (ref.current.value.trim() === "") return;
    let advancedDataTemp = [...advancedData];

    // chipsRef.current.value -> Get text from outlined input
    const chipsTemp = [...advancedData[idx].chips, ref.current.value.trim()];

    // Update `chips`
    advancedDataTemp[idx].chips = [...new Set(chipsTemp)];

    // Push
    setAdvancedData(advancedDataTemp);

    // Reset the text on specific outlined input
    ref.current.value = "";
  };

  /**
   * Handle deletion for chips
   * @param {Integer} idx Index to point a specifc element from advancedData
   * @param {String} val Text description from a selected chip
   */
  const handleDeleteChip = (idx, val) => {
    const advancedDataTemp = [...advancedData];
    const chipsTemp = advancedDataTemp[idx].chips.filter(
      (chip) => chip !== val
    );
    advancedDataTemp[idx].chips = chipsTemp;
    setAdvancedData(advancedDataTemp);
  };

  const handleSubmitOnEnter = (e) => {
    if (e.key === "Enter") {
      handleSearchClick(searchInput)
    }
  }

  const handleASSubmit = (data) => {
    const { selectedDates, advancedData } = data;
    let query = "";
    if (Array.isArray(advancedData)) {
      advancedData.forEach((item) => {
        let { category } = item;
        let categoryQuery = `&${category}=`;

        item["chips"].forEach((chip) => {
          categoryQuery += chip + ",";
        });

        // Remove last comma
        query += categoryQuery.slice(0, -1);
      });
    }
    // TODO: What if it's not using MySQL?
    if (selectedDates?.startDate) {
      let formatStartDate = "";
      if (!useMySQLTimeFormat) {
        formatStartDate = MSSQLTimeFormat(selectedDates.startDate);
      } else {
        formatStartDate = mySQLTimeFormat(selectedDates.startDate);
      }
      query += `&startDate=${formatStartDate}`;
    }
    // TODO: What if it's not using MySQL?
    if (selectedDates?.endDate) {
      let formatEndDate = "";
      if (!useMySQLTimeFormat) {
        formatEndDate = MSSQLTimeFormat(selectedDates.endDate);
      } else {
        formatEndDate = mySQLTimeFormat(selectedDates.endDate);
      }
      query += `&endDate=${formatEndDate}`;
    }

    handleSearchQuery(query);
  };

  const handleValidateASSubmit = () => {
    const isInvalidDate = (date) => {
      if (date?._isValid === false) return "12/31/3000";
      else return date?._d;
    };

    const SELECTED_DATES = {
      startDate: isInvalidDate(startDate),
      endDate: isInvalidDate(endDate),
    };

    handleASSubmit({
      selectedDates: SELECTED_DATES,
      advancedData: [...advancedData],
    });

    handleClosePopover();
  };

  return (
    <Box sx={styles.parentBox}>
      <Box sx={styles.searchWrapper}>
        <FormControl sx={{ width: 241 }}>
          <OutlinedInput
            sx={{
              borderTopRightRadius: 0,
              borderBottomRightRadius: 0,
              height: 48,
              fontSize: 18,
              fontWeight: 500,
              "& input::placeholder": {
                color: "black",
                opacity: 1,
              },
            }}
            onChange={(e) => handleSearchTextInput(e.target.value)}
            value={searchInput.text}
            placeholder="Cari di sini"
            onKeyDown={handleSubmitOnEnter}
          />
        </FormControl>

        <FormControl sx={{ width: 210 }}>
          <Select
            sx={styles.select}
            value={value}
            onChange={(e, obj) => handleSelectMenuSearch(e, obj)}
            inputProps={{ "aria-label": "Without label" }}
          >
            {selectMenuItems.map(({ value, label }, idx) => (
              <MenuItem key={idx} value={value}>
                {label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <IconButton
          sx={styles.searchIcon}
          edge="end"
          onClick={() => handleSearchClick(searchInput)}
        >
          <Search />
        </IconButton>
      </Box>

      <Box sx={styles.boxAS}>
        {useAdvancedSearch && (
          <>
            <Button
              sx={styles.buttonAS}
              aria-describedby={id}
              onClick={handleShowPopover}
            >
              Advanced Search
            </Button>
            <Popover
              id={id}
              open={isOpen}
              anchorEl={anchorEl}
              onClose={handleClosePopover}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "left",
              }}
            >
              <Box sx={styles.popoverBox} boxShadow={2}>
                <div>
                  <Typography sx={styles.labelPeriode}>Periode</Typography>
                  <div style={{ display: "flex", marginTop: "12px" }}>
                    <LocalizationProvider dateAdapter={AdapterMoment}>
                      <DesktopDatePicker
                        minDate={"1950-01-01"}
                        maxDate={endDate ? endDate : undefined}
                        label="Start"
                        value={startDate}
                        inputFormat="DD/MM/YYYY"
                        components={{
                          OpenPickerIcon: () => (
                            <Date
                              sx={{
                                fontSize: 16,
                              }}
                            />
                          ),
                        }}
                        sx={{
                          backgroundColor: startDate ? "#C3E8FF" : "",
                          width: "37%",
                        }}
                        onChange={(newVal) => setStartDate(newVal)}
                        renderInput={({ inputRef, inputProps, InputProps, error, disabled }) => (
                          <TextField
                            ref={inputRef}
                            {...inputProps}
                            error={error}
                            disabled={disabled}
                            placeholder="Start"
                            InputProps={{
                              endAdornment: {
                                ...InputProps?.endAdornment,
                              },
                            }}
                            sx={{
                              color: "#333333",
                              fontWeight: 600,
                            }}
                            size="small"
                          />
                        )}
                      />
                      <Divider style={styles.hr} />
                      <DesktopDatePicker
                        minDate={startDate ? startDate : "1950-01-01"}
                        label="End"
                        inputFormat="DD/MM/YYYY"
                        value={endDate}
                        components={{
                          OpenPickerIcon: () => (
                            <Date
                              sx={{
                                fontSize: 16,
                              }}
                            />
                          ),
                        }}
                        sx={{
                          backgroundColor: startDate ? "#C3E8FF" : "",
                          width: "37%",
                          color: "#333333",
                          fontWeight: 600,
                        }}
                        onChange={(newVal) => setEndDate(newVal)}
                        renderInput={({ inputRef, inputProps, InputProps, error, disabled }) => (
                          <TextField
                            ref={inputRef}
                            {...inputProps}
                            error={error}
                            disabled={disabled}
                            placeholder="End"
                            InputProps={{
                              endAdornment: {
                                ...InputProps?.endAdornment,
                              },
                            }}
                            sx={{
                              color: "#333333",
                              fontWeight: 600,
                            }}
                            size="small"
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </div>
                </div>
                <div>
                  <Typography sx={styles.labelKategori}>Kategori</Typography>
                  {advancedData.map((data, i) => (
                    <div style={styles.category} key={i}>
                      <Select
                        sx={styles.selectAS}
                        name="select_category_as"
                        value={data.category}
                        onChange={(e) => handleSelectMenuAS(i, e)}
                        variant="outlined"
                        MenuProps={{
                          PaperProps: {
                            sx: styles.paperSelect,
                          },
                        }}
                      >
                        {selectMenuItemsAS.map((item, index) => {
                          return advancedData.filter(
                            (el) => el.category === item.value
                          ).length < 1 ? (
                            <MenuItem value={item} key={index}>
                              {item.label}
                            </MenuItem>
                          ) : (
                            <MenuItem value={data.category} key={index}>
                              {data.label}
                            </MenuItem>
                          );
                        })}
                      </Select>
                      <StyledChips
                        chipsRef={chipsRef.current[i]}
                        handleAddChip={handleAddChip}
                        handleDeleteChip={handleDeleteChip}
                        index={i}
                        chips={data.chips}
                      />
                      <div
                        style={{
                          width: "100%",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                      >
                        {i === advancedData.length - 1 &&
                          i < selectMenuItemsAS.length - 1 && (
                            <AddBoxIcon
                              onClick={handleAddSelectMenuAS}
                              sx={styles.iconAS("add")}
                            />
                          )}
                        {advancedData.length !== 1 && (
                          <DeleteIcon
                            onClick={(e) => handleDeleteSelectMenuAS(e, i)}
                            sx={styles.iconAS("delete")}
                          />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <ButtonCommon
                  sx={styles.submitAS}
                  label="Apply"
                  onClick={handleValidateASSubmit}
                />
              </Box>
            </Popover>
          </>
        )}
      </Box>
    </Box>
  );
}
