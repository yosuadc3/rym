export const days = [
    {
        id: 0,
        initial_english: 'S',
        initial_indonesia: 'M',
        initial_vision: 'N',
        label_indonesia: 'Minggu',
        label_english: 'Sunday',
        active: false
    },
    {
        id: 1,
        initial_english: 'M',
        initial_indonesia: 'S',
        initial_vision: 'M',
        label_indonesia: 'Senin',
        label_english: 'Monday',
        active: false
    },
    {
        id: 2,
        initial_english: 'T',
        initial_indonesia: 'S',
        initial_vision: 'T',
        label_indonesia: 'Selasa',
        label_english: 'Tuesday',
        active: false
    },
    {
        id: 3,
        initial_english: 'W',
        initial_indonesia: 'R',
        initial_vision: 'W',
        label_indonesia: 'Rabu',
        label_english: 'Wednesday',
        active: false
    },
    {
        id: 4,
        initial_english: 'T',
        initial_indonesia: 'K',
        initial_vision: 'R',
        label_indonesia: 'Kamis',
        label_english: 'Thursday',
        active: false
    },
    {
        id: 5,
        initial_english: 'F',
        initial_indonesia: 'J',
        initial_vision: 'F',
        label_indonesia: 'Jumat',
        label_english: 'Friday',
        active: false
    },
    {
        id: 6,
        initial_english: 'S',
        initial_indonesia: 'S',
        initial_vision: 'S',
        label_indonesia: 'Sabtu',
        label_english: 'Saturday',
        active: false
    },
]