import { Button } from "@mui/material";
import React from "react";

const styles = {
  primaryButton: {
    fontWeight: "bold",
    fontSize: 16,
    height: 48,
    // paddingX: 7,
    px: 4,
    textTransform: "none",
    borderRadius: 2,
    backgroundColor: "#0D5CAB",
    color: "white",
    transition: "transform .2s ease-in-out",
    "&:hover": {
      backgroundColor: "#125FA1",
    },
    "&:active": {
      backgroundColor: "#0D5CAB",
    },
  },
};

export default function AddButton({ toggleDialog }) {
  return (
    <Button sx={styles.primaryButton} onClick={toggleDialog}>
      Add
    </Button>
  );
}
