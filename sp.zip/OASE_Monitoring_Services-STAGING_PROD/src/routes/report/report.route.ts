const router = require("express").Router();
import atlas from "./atlas.route";

router.use("/atlas", atlas);

export default router;
export {};
