import { Request, Response } from "express";

export const getStatusApplication = async (req: Request, res: Response) => {
	try {
		res.send("Success to health check OASE Monitoring API Services");
	} catch (error: any) {
		const errMessage =
			error.message || "Some error occurred while health check";
		res.status(500).send(errMessage);
	}
};

export {};
