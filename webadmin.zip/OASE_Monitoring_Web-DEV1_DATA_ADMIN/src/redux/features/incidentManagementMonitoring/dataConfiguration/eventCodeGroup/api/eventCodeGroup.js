import { createApi } from "@reduxjs/toolkit/query/react";
import axiosBaseQuery from "../../../../../utils/axiosBaseQuery";
import { BASE_URL_API_MONITORING } from "../../../../../../constants/Api";

const path = "/data-admin/event-code/group/";

export const eventCodeGroupApi = createApi({
    reducerPath: "eventCodeGroupApi",
    baseQuery: axiosBaseQuery({ baseUrl: BASE_URL_API_MONITORING }),
    endpoints: (builder) => ({
        getEventCodeGroup: builder.query({
            query: (params = { page: 0, limit: 10, sortBy: "", orderBy: "", search: {}, advancedSearch: {}, advancedSearchPeriode: {} }) => ({
                url: `${path}`, method: "get", params: params
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data.data,
                    total: data.total,
                }
            }
        }),
        getEventCodeGroupById: builder.query({
            query: (id) => ({
                url: `${path}${id}/`, method: "get"
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data,
                }
            }
          }),
          getEventCodeGroupList: builder.query({
            query: () => ({
                url: `${path}list/`, method: "get"
            }),
            transformResponse: (res) => {
                const { data } = res;
                return {
                    data: data,
                }
            }
        }),
        postEventCodeGroup: builder.mutation({
            query: (data) => ({
                url: `${path}`,
                method: "POST",
                data: data
            })
        }),
        putEventCodeGroup: builder.mutation({
            query: ({id,data}) => ({
                url: `${path}${id}`,
                method: "PUT",
                data: data
            })
        }),
        deleteEventCodeGroup: builder.mutation({
            query: ({id,data}) => ({
                url: `${path}${id}`,
                method: 'DELETE',
                data: data,
                credentials: 'include',
              }),
        }),
        changePriorityEventCodeGroup: builder.mutation({
            query: (data) => ({
                url: `${path}change-orders/`,
                method: "PUT",
                data: data
            })
        }),
    })
});

export const {
    useGetEventCodeGroupQuery,
    useGetEventCodeGroupByIdQuery,
    useGetEventCodeGroupListQuery,
    usePostEventCodeGroupMutation,
    usePutEventCodeGroupMutation,
    useDeleteEventCodeGroupMutation,
    useChangePriorityEventCodeGroupMutation
} = eventCodeGroupApi;