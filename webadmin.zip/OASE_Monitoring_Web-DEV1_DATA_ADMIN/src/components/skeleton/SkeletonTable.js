import { Stack } from "@mui/material";
import Skeleton from "@mui/material/Skeleton";
import React from "react";

export default function SkeletonTable({ amount = 5 }) {
  return (
    <Stack spacing={1} width={1}>
      {Array.from({ length: amount }, (x, i) => i).map((d, i) => (
        <Skeleton
          key={i}
          variant="rounded"
          animation="wave"
          width="100%"
          height={40}
        />
      ))}
    </Stack>
  );
}
