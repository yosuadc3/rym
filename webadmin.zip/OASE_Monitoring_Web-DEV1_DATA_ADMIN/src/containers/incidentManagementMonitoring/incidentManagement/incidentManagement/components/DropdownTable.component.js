import React, { useCallback, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import SkeletonTable from "../../../../../components/skeleton/SkeletonTable";
import StyledTable from "../../../../../components/table/StyledTable";
import { useGetTicketIdsQuery } from "../../../../../redux/features/incident-management-monitoring/incident-management/api/imm";
import { INCIDENT_MANAGEMENT_TABLE_COLUMNS } from "../constants/IncidentManagement";

const DropdownTable = ({
  category,
  total,
  handleRowClick,
  searchQuery = "",
}) => {
  if (category === undefined || category === null) return <div></div>;

  const { isResetSearch, toggleRefresh } = useSelector(state => state.incidentManagement);
  const [page, setPage] = useState(0);

  const [currRowsPerPage, setCurrRowsPerPage] = useState(5);

  const [sortBy, setSortBy] = useState("id");
  const [orderBy, setOrderBy] = useState("desc");

  const { data, isLoading, isFetching, refetch } = useGetTicketIdsQuery(
    `category=${encodeURIComponent(category)}&page=${page}&limit=${currRowsPerPage}&sortBy=${sortBy}&orderBy=${orderBy}&` +
    searchQuery, {
    refetchOnFocus: true,
    refetchOnMountOrArgChange: true,
    refetchOnReconnect: true
  });

  useEffect(() => {
    refetch();
  }, [isResetSearch, toggleRefresh])

  useEffect(() => {
    refetch();
  }, [isResetSearch])

  const handleSortModelChange = useCallback((sortModel) => {
    if (sortModel.length) {
      setSortBy((_) => sortModel[0]?.field);
      setOrderBy((_) => sortModel[0]?.sort);
    } else {
      setSortBy((_) => "id");
      setOrderBy((_) => "desc");
    }
  }, []);

  if (isLoading) {
    return <SkeletonTable amount={6} />;
  }

  const rows = data?.rows;

  return (
    <StyledTable
      headers={INCIDENT_MANAGEMENT_TABLE_COLUMNS}
      page={page}
      rows={rows ?? []}
      pageSize={currRowsPerPage}
      loading={isFetching}
      rowCount={total ?? 0}
      setPage={(e) => setPage(e)}
      useStripesWhiteGray
      setPageSizeChange={(e) => setCurrRowsPerPage(e)}
      onSortModelChange={handleSortModelChange}
      onCellClick={(id) => handleRowClick(id, category)}
    />
  );
};

export default DropdownTable;
