import { Request, Response } from "express";
import { JwtPayload } from "jwt-decode";

export type NumberOrUndefined = number | undefined;
export type StringOrNull = string | null;
export type StringOrUndefined = string | undefined;
export type Nullable<T> = { [K in keyof T]: T[K] | null };
export type TPeriode = {
	startDate: string;
	endDate: string;
};
export type TFilter = {
	[k: string]: string[];
};
export type TSearchData = {
	query: string;
	params: string[];
};

export interface IPagination {
	page: number;
	limit: number;
	sortBy: string;
	orderBy: string;
}

export type TPagination = [
	IPagination["page"],
	IPagination["limit"],
	IPagination["sortBy"],
	IPagination["orderBy"]
];

export interface IMorgan {
	name: string;
	error: string;
}

export interface IAccessToken extends Partial<Nullable<JwtPayload>> {
	sub: string;
	typ: string;
	azp: string;
	session_state: string;
	acr: string;
	realm_access: {
		roles: string[];
	};
	resource_access: {
		"realm-management": {
			roles: string[];
		};
	};
	scope: string;
	user_group: string[];
	name: string;
	preferred_username: string;
	given_name: string;
	family_name: string;
	vendor_site_id: StringOrUndefined;
	koordinator: StringOrUndefined;
}

export interface IKeycloakAuth {
	kauth: {
		grant: {
			access_token: {
				content: IAccessToken;
			};
		};
	};
}

export interface IUser extends Nullable<IMorgan>, IKeycloakAuth { }

export interface IMorganLoggingRequest extends Request, Partial<IMorgan> { }

export interface IParam {
	id: string;
}

export interface IIncidentID {
	incidentId: string;
}

export interface IIncidentId {
	incident_id: string;
}

export interface ICommentText {
	comment_text: string;
}

export interface ICategory {
	category: string;
}

export interface ITicketID {
	ticketId: StringOrUndefined;
}

export interface ITicketId {
	ticket_id: StringOrUndefined;
}

export interface IWSID {
	wsid: StringOrUndefined;
}

export interface IStartTime {
	start_time: StringOrUndefined;
}

export interface IDuration {
	duration: NumberOrUndefined;
}

export interface IStatusCodeDescription {
	status_code_description: StringOrUndefined;
}

export interface IActionCodeDescription {
	action_code_description: StringOrUndefined;
}

export interface ILastComment {
	last_comment: StringOrUndefined;
}

export interface IStatusCodeDefined {
	status_code_defined: NumberOrUndefined;
}

export interface ITableName {
	table_name: StringOrUndefined;
}

export interface ICodeType {
	code_type: StringOrUndefined;
}

export interface ICodeLength {
	code_length: NumberOrUndefined;
}

export interface IComponentId {
	component_id: NumberOrUndefined;
}

export interface IStatusCodeId {
	status_code_id: NumberOrUndefined;
}

export interface ICurrStatusCode {
	curr_status_code: StringOrUndefined;
}

export interface INewStatusCode {
	new_status_code: StringOrUndefined;
}

export interface IStatusCodeTable {
	status_code_table: StringOrUndefined;
}

export interface IStatusCodeTableId {
	status_code_table_id: NumberOrUndefined;
}

export interface IStatusCode {
	status_code: StringOrUndefined;
}

export interface IComponent {
	component: StringOrUndefined;
}

export interface IId {
	id: NumberOrUndefined;
}

export interface INumber {
	number: NumberOrUndefined;
}

export interface IActionCode {
	action_code: StringOrUndefined;
}

export interface IDescription {
	description: StringOrUndefined;
}

export interface IReopenLimit {
	reopen_limit: NumberOrUndefined;
}

export interface ICurrActionCode {
	curr_action_code: StringOrUndefined;
}

export interface INewActionCode {
	new_action_code: StringOrUndefined;
}

export interface IActionCodeCategoryId {
	action_code_category_id: NumberOrUndefined;
}

export interface IActionCodeCategory {
	action_code_category: StringOrUndefined;
}

export interface IActionCodeDefined {
	action_code_defined: StringOrUndefined;
}

export interface IPriority {
	priority: NumberOrUndefined;
}

export interface IThreshold {
	threshold: StringOrUndefined;
}

export interface IThresholdColor {
	threshold_color: StringOrUndefined;
}

export interface IDescription {
	description: StringOrUndefined;
}

export interface IActionCodeId {
	action_code_id: StringOrUndefined;
}

export interface IActionCode {
	action_code: StringOrUndefined;
}

export interface IStartDate {
	startDate: StringOrUndefined;
}

export interface IEndDate {
	endDate: StringOrUndefined;
}

export interface IAll {
	all: StringOrUndefined;
}

export interface IResponseAPI extends Response { }

export interface IRequestAPI extends IUser, Request<any, any, any, any, any> { }
