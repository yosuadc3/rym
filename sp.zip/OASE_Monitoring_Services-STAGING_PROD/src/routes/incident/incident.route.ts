//Incident Router
import * as incident from "../../controllers/incident/incident.controller";
// import * as incidentV1 from "../../controllers/incident/incident.v1.controller";
const keycloak = require("../../middlewares/keycloakHandler.middleware").get();
let router = require("express").Router();

// VALIDATION
import validation from "../../middlewares/validator.middleware";
import * as validationRules from "../../validators/incident/incidentManagement.validator";
import * as validationRulesDetail from "../../validators/incident/incidentManagementDetail.validator";
import * as validationRulesReport from "../../validators/incident/incidentManagementReport.validator";

/** Incident Management */
// router.get(
// 	"/v1/category",
// 	keycloak.protect("realm:LIST_INCIDENT_MANAGEMENT"),
// 	incidentV1.getIncidentCategoryV1
// );
router.get(
	"/v2/category",
	keycloak.protect("realm:LIST_INCIDENT_MANAGEMENT"),
	validationRules.getIncidentCategory,
	validation,
	incident.getIncidentCategory
);
router.get(
	"/v1/tickets",
	keycloak.protect("realm:LIST_INCIDENT_MANAGEMENT"),
	validationRules.getIncidentID,
	validation,
	incident.getIncidentID
);

/** Incident Management Detail */
router.get(
	"/v1/incident",
	keycloak.protect("realm:GET_INCIDENT_DETAIL"),
	validationRulesDetail.getIncidentCurrent,
	validation,
	incident.getIncidentCurrent
);
router.get(
	"/v1/terminal",
	keycloak.protect("realm:GET_INCIDENT_DETAIL"),
	validationRulesDetail.getTerminalDetails,
	validation,
	incident.getTerminalDetails
);
router.get(
	"/v1/status",
	keycloak.protect("realm:GET_INCIDENT_DETAIL"),
	validationRulesDetail.getTerminalCurrentStatus,
	validation,
	incident.getTerminalCurrentStatus
);
router.get(
	"/v1/history",
	keycloak.protect("realm:GET_INCIDENT_DETAIL"),
	validationRulesDetail.getIncidentHistory,
	validation,
	incident.getIncidentHistory
);
router.get(
	"/v1/comment",
	keycloak.protect("realm:LIST_INCIDENT_MANAGEMENT"),
	validationRulesDetail.getIncidentComments,
	validation,
	incident.getIncidentComments
);
router.post(
	"/v1/comment",
	keycloak.protect("realm:LIST_INCIDENT_MANAGEMENT"),
	validationRulesDetail.postIncidentComment,
	validation,
	incident.postIncidentComment
);

/** Report */
router.get(
	"/v1/report",
	keycloak.protect("realm:LIST_INCIDENT_MANAGEMENT"),
	validationRulesReport.getIncidentReport,
	validation,
	incident.getIncidentReport
);
router.get(
	"/v1/report-preview",
	keycloak.protect("realm:LIST_INCIDENT_MANAGEMENT"),
	validationRulesReport.getIncidentReport,
	validation,
	incident.getIncidentReportPreview
);
router.get(
	"/v1/info",
	keycloak.protect("realm:LIST_INCIDENT_MANAGEMENT"),
	validationRulesReport.getIncidentReport,
	validation,
	incident.getIncidentReportInfo
);

export default router;
export { };

