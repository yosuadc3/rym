import env from "../env/server.env";
const oaseScheme = env.DB_SCHEMA_OASE;

export default Object.freeze({
	VIEW_SERVICE_AVAILABILITY: "vw_service_availability",
	VIEW_SERVICE_AVAILABILITY_REPORT: "vw_service_availability_report",
	TABLE_TERMINAL_TERPADUS: `${oaseScheme}.terminal_terpadus`,
	TABLE_TERMINALS: `${oaseScheme}.terminals`,
	TABLE_MASTER_DROPDOWNS: `${oaseScheme}.master_dropdowns`,
	VIEW_REPORT_ATLAS_FILTER_VALUES: "vw_report_atlas_filter_values",
	TABLE_DASHBOARD_SERVICE_AVAILABILITY: "dashboard_atlas_service_availability",
	TABLE_MAPPING_DSA_SUMMARY: "mapping_dsa_summary",
});

export const EVENT_CODE = Object.freeze({
	TABLE: "event_code",
	TABLE_GROUP: "event_code_group",
	TABLE_RULE: "event_code_rule",
	//sementara doang buat cun
	TABLE_RULE_CUN: "event_code_rule_cun",
	TABLE_SOURCE: "event_code_catalog",
	VIEW: "vw_event_code",
	VIEW_RULE: "vw_event_code_rule",
	//sementara doang buat cun
	VIEW_RULE_CUN: "vw_event_code_rule_cun",
	VIEW_TABLE_GROUP: "vw_event_code_group",
	VIEW_SOURCE: "vw_event_code_catalog"
});

export const FAULT_CATEGORY = Object.freeze({
	TABLE: "fault_category",
	VIEW: "vw_fault_category"
});

export const TICKET_ACTION = Object.freeze({
	VIEW_TABLE_TICKET_ACTION: "vw_event_code_action",
});

export const EMAIL = Object.freeze({
	VIEW_TABLE_EMAIL_ACTION: "vw_email_action",
});

export const INCIDENT = "vw_incidents";