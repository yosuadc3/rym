import * as controller from "../../controllers/dataAdmin/ticketAction.controller";
import errorWrapper from "../../utils/errorWrapper.util";
const router = require("express").Router();

router.get("/list", errorWrapper(controller.getTicketAction));

export default router;