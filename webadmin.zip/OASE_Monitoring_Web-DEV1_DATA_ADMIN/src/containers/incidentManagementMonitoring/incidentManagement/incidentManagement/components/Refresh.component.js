import RefreshIcon from "@mui/icons-material/Refresh";
import { Button } from "@mui/material";
import React from "react";
import { styles } from "../constants/IncidentManagement";

const Refresh = ({ disabled, handleRefreshData }) => {
  return (
    <Button
      disabled={disabled}
      startIcon={<RefreshIcon />}
      onClick={handleRefreshData}
      sx={styles.refreshButton}
    >
      Refresh Data
    </Button>
  );
};

export default Refresh;
