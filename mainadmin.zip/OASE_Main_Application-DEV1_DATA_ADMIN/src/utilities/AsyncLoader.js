import React from "react";
import { Suspense } from "react";
import BaseDialog from "../components/dialog/BaseDialog";
import ErrorBoundary from "./ErrorBoundary";

function AsyncLoader({ children }) {
    return (
        <Suspense fallback={<BaseDialog open={true} title="Permintaan Anda sedang diproses" type="progress" />}>
            <ErrorBoundary>
                {children}
            </ErrorBoundary>
        </Suspense>
    );
}

export default AsyncLoader;