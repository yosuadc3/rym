import React from "react";
import { Dialog, Button, DialogTitle, CircularProgress, DialogContent, DialogActions, Box } from "@mui/material";

const styles = {
    dialogTitle: {
        textTransform: "inherit",
        fontWeight: "bold",
        fontSize: "24px",
        color: "black",
        textAlign: "center",
    },
    dialogProgress: {
        textTransform: "inherit",
        fontWeight: "bold",
        fontSize: "24px",
        color: "black",
        textAlign: "left",
    },
    btnContained: {
        textTransform: "inherit",
        width: "80%",
        borderRadius: "8px",
        height: 44,
        fontSize: 16,
        fontWeight: "bold",
        backgroundColor: "#156db8",
        color: "white",
        "&:hover": {
            backgroundColor: "#125fa1",
        },
        "&:active": {
            backgroundColor: "#156db8",
        }
    },
    dialogContainer: {
        justifyContent: "center",
        display: "flex",
        flexDirection: "column",
        padding: 6,
    },
};

function BaseDialog({ type, title, buttonText, open, handleClose }) {
    return (
        <Dialog open={open} onClose={handleClose}>
            <Box sx={styles.dialogContainer}>
                <DialogTitle sx={styles.dialogTitle}>{title}</DialogTitle>
                <DialogContent>
                    {
                        type === "progress" &&
                        <Box display="flex" justifyContent="center" alignItems="center">
                            <CircularProgress />
                        </Box>
                    }
                </DialogContent>
                <DialogActions sx={{ justifyContent: "center" }}>
                    {
                        type === "info" && <Button sx={styles.btnContained} onClick={handleClose}>{buttonText}</Button>
                    }
                </DialogActions>
            </Box>
        </Dialog>
    )
}

export default BaseDialog