import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import BasicSelect from "../../../../components/form/BasicSelect";
import { setReportType } from "../../../../redux/features/report/dataConfiguration/dataConfiguration";

const reportMenuItems = [
   {
      id: "Report Data Configuration",
      label: "Report Data Configuration"
   },
   {
      id: "Report Log Perubahan",
      label: "Report Log Perubahan"
   },
]

export default function ReportType() {
   const dispatch = useDispatch();
   const { reportType } = useSelector((state) => state.reportDataConfigurationSlice)

   const onChange = (e) => {
      const selectedValue = e.target.value;
      dispatch(setReportType(selectedValue))
   }

   return (
      <BasicSelect items={reportMenuItems} onChange={onChange} value={reportType} />
   )
}