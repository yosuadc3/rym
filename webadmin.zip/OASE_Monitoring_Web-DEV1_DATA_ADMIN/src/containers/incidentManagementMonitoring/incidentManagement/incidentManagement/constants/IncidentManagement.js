import React from "react";
import { CENTER_COLUMNS } from "../../../../../utilities/MaterialUI";
import { dayInMonthComparator } from "../../../../../utilities/Moment";
import LinkBox from "../components/LinkBox";

const TRUE = true;
const FALSE = false;
const DATE = "date";
export const REFRESH_TIMEOUT_MS = 60000;
const FAULT_CATEGORY = "Fault Category";
const JUMLAH_INCIDENT = "Total Terminal";
const AVERAGE_INCIDENT = "Average Age";
const MOST_RECENT_INCIDENT = "Most Recent Incident";
const OLDEST_INCIDENT = "Oldest Incident";
const LABEL = {
  ALL: "All",
  INCIDENT_NUMBER: "Incident Number",
  WSID: "WSID",
  LOKASI: "Lokasi",
  START_TIME: "Start Time",
  STATUS_CODE: "Status Code",
  DURATION: "Duration",
  STATUS_DESCRIPTION: "Status Description",
  LAST_COMMENT: "Last Comment",
};
const VALUE = {
  ALL: "all",
  ID: "id",
  WSID: "wsid",
  TICKET_ID: "ticket_id",
  LOKASI: "lokasi",
  START_TIME: "start_time",
  END_TIME: "end_time",
  STATUS_CODE: "status_code",
  ACTION_CODE: "action_code",
  DURATION: "duration",
  STATUS_CODE_DESCRIPTION: "status_code_description",
  ACTION_CODE_DESCRIPTION: "action_code_description",
  LAST_COMMENT: "last_comment",
};
const HEADERNAME = {
  ALL: "All",
  INCIDENT_NUMBER: "Incident Number",
  WSID: "WSID",
  LOKASI: "Lokasi",
  START_TIME: "Start Time",
  STATUS_CODE: "Status Code",
  DURATION: "Duration",
  STATUS_DESCRIPTION: "Status Description",
  LAST_COMMENT: "Last Comment",
};
const FIELD = {
  ID: "id",
  WSID: "wsid",
  START_TIME: "start_time",
  LOKASI: "lokasi",
  END_TIME: "end_time",
  STATUS_CODE: "status_code",
  ACTION_CODE: "action_code",
  DURATION: "duration",
  STATUS_CODE_DESCRIPTION: "status_code_description",
  ACTION_CODE_DESCRIPTION: "action_code_description",
  LAST_COMMENT: "last_comment",
};
const BREADCRUMB = {
  ITEM: {
    HOME: "Home",
    INCIDENT_MANAGEMENT: "Incident Management",
  },
  LINK: {
    HOME: "/",
    INCIDENT_MANAGEMENT: null,
  },
  CURRENT: {
    HOME: FALSE,
    INCIDENT_MANAGEMENT: TRUE,
  },
};
export const INCIDENT_MANAGEMENT_BREADCRUMBS = [
  {
    item: BREADCRUMB.ITEM.HOME,
    link: BREADCRUMB.LINK.HOME,
    current: BREADCRUMB.CURRENT.HOME,
  },
  {
    item: BREADCRUMB.ITEM.INCIDENT_MANAGEMENT,
    link: BREADCRUMB.LINK.INCIDENT_MANAGEMENT,
    current: BREADCRUMB.CURRENT.INCIDENT_MANAGEMENT,
  },
];
export const INCIDENT_MANAGEMENT_SEARCH = [
  { value: VALUE.ALL, label: LABEL.ALL },
  { value: VALUE.TICKET_ID, label: LABEL.INCIDENT_NUMBER },
  { value: VALUE.WSID, label: LABEL.WSID },
  { value: VALUE.LOKASI, label: LABEL.LOKASI },
  { value: VALUE.START_TIME, label: LABEL.START_TIME },
  { value: VALUE.STATUS_CODE, label: LABEL.STATUS_CODE },
  { value: VALUE.DURATION, label: LABEL.DURATION },
  { value: VALUE.STATUS_CODE_DESCRIPTION, label: LABEL.STATUS_DESCRIPTION },
  { value: VALUE.LAST_COMMENT, label: LABEL.LAST_COMMENT },
];
export const INCIDENT_MANAGEMENT_FILTER_COLUMNS = [
  { id: VALUE.ALL, label: LABEL.ALL },
  { id: VALUE.TICKET_ID, label: LABEL.INCIDENT_NUMBER },
  { id: VALUE.WSID, label: LABEL.WSID },
  { id: VALUE.LOKASI, label: LABEL.LOKASI },
  { id: VALUE.START_TIME, label: LABEL.START_TIME },
  { id: VALUE.STATUS_CODE, label: LABEL.STATUS_CODE },
  { id: VALUE.DURATION, label: LABEL.DURATION },
  { id: VALUE.STATUS_CODE_DESCRIPTION, label: LABEL.STATUS_DESCRIPTION },
  { id: VALUE.LAST_COMMENT, label: LABEL.LAST_COMMENT },
];
export const INCIDENT_MANAGEMENT_TABLE_COLUMNS = [
  {
    field: "incident_number",
    headerName: HEADERNAME.INCIDENT_NUMBER,
    renderCell: (data) => { return (<LinkBox data={data} value="incident_number" />) },
    ...CENTER_COLUMNS,
  },
  {
    field: FIELD.WSID,
    headerName: HEADERNAME.WSID,
    renderCell: (data) => { return (<LinkBox data={data} value="wsid" />) },
    ...CENTER_COLUMNS,
  },
  {
    field: FIELD.LOKASI,
    headerName: HEADERNAME.LOKASI,
    renderCell: (data) => { return (<LinkBox data={data} value="lokasi" />) },
    ...CENTER_COLUMNS,
  },
  {
    field: FIELD.START_TIME,
    headerName: HEADERNAME.START_TIME,
    type: DATE,
    valueGetter: (params) => params.row.start_time,
    sortComparator: dayInMonthComparator,
    renderCell: (data) => { return (<LinkBox data={data} value="start_time" />) },
    ...CENTER_COLUMNS,
  },
  {
    field: FIELD.DURATION,
    headerName: HEADERNAME.DURATION,
    renderCell: (data) => { return (<LinkBox data={data} value="duration" />) },
    ...CENTER_COLUMNS,
  },
  {
    field: FIELD.STATUS_CODE,
    headerName: HEADERNAME.STATUS_CODE,
    renderCell: (data) => { return (<LinkBox data={data} value="status_code" />) },
    ...CENTER_COLUMNS,
  },
  {
    field: FIELD.STATUS_CODE_DESCRIPTION,
    headerName: HEADERNAME.STATUS_DESCRIPTION,
    renderCell: (data) => { return (<LinkBox data={data} value="status_code_description" />) },
    ...CENTER_COLUMNS,
  },
  {
    field: FIELD.LAST_COMMENT,
    headerName: HEADERNAME.LAST_COMMENT,
    renderCell: (data) => { return (<LinkBox data={data} value="last_comment" />) },
    ...CENTER_COLUMNS,
  },
];
export const INCIDENT_MANAGEMENT_HEADER = [
  FAULT_CATEGORY,
  JUMLAH_INCIDENT,
  AVERAGE_INCIDENT,
  MOST_RECENT_INCIDENT,
  OLDEST_INCIDENT,
];
export const styles = {
  lastUpdate: {
    fontWeight: "bold",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    whiteSpace: "nowrap",
    fontSize: "15px",
  },
  refreshButton: {
    textTransform: "none",
    fontWeight: "bold",
    ".MuiButton-text": {
      textTransform: "none",
    },
  },
  tableTitle: { fontWeight: "bold", fontSize: 30, color: "#0D5CAB" },
  tableRowCount: {
    fontSize: 40,
    fontWeight: "bold",
    color: "red",
  },
  tableHr: {
    border: "1px solid #F2F2F7",
    width: "100%",
    marginTop: ".5rem",
    marginBottom: "1rem",
  },
  hr: {
    border: "1px solid #F1F1F7",
    width: "100%",
    marginTop: ".8rem",
    marginLeft: "1rem",
    marginRight: "1rem",
  },
  accordion: {
    borderBottom: "none",
    borderTop: "none",
  },
  accordionIcon: {
    color: "#0D5CAB",
    fontSize: 50,
  },
  accordionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#0D5CAB",
    whiteSpace: "nowrap",
  },
  typography: {
    fontWeight: "bold",
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "flex-end",
  },
  totalTerminal: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "flex-end",
    padding: "12px 24px",
    backgroundColor: "#fff",
    boxShadow: "2px 4px 8px rgba(0, 0, 0, 0.2)",
    borderRadius: "8px",
  },
  totalTerminalText: {
    color: "#156db8",
    fontSize: "22px",
    fontWeight: "bolder",
  },

  lastUpdateSpan: { marginLeft: "4px", display: "inline-block" },
};
export const accordionStyle = {
  accordion: (idx, isExpand, isLoading, borderBottomColor) => ({
    marginTop: 0,
    boxShadow: "none",
    borderTop: idx === 0 ? "1px solid #005CAA" : "",
    borderBottom: isExpand || isLoading
      ? `1px solid rgba(0, 0, 0, .125)`
      : `8px solid ${borderBottomColor}`,
    "&.MuiAccordion-root": {
      borderBottomLeftRadius: 0,
      borderBottomRightRadius: 0,
      borderTopLeftRadius: 0,
      borderTopRightRadius: 0,
    },
    "&.Mui-expanded": {
      borderTop: "1px solid #005CAA",
    },
  }),
  accordionIcon: {
    color: "#0D5CAB",
    fontSize: 20,
  },
  accordionCategory: {
    fontSize: "24px",
    color: "#0D5CAB",
    fontWeight: "bold",
    textAlign: "left",
  },
  accordionCategoryCount: (category) => ({
    backgroundColor: category === "In Service" ? "#25A722" : "#FF6058",
    padding: "6px 16px",
    borderRadius: "20px",
    color: "white",
    fontSize: "18px",
    fontWeight: 600,
  }),
  accordionCategoryAge: { color: "#333333", fontWeight: 600, fontSize: "16px", textAlign: "center" },
  accordionSummary: (borderBottomColor, isLoading) => ({
    boxShadow: "none",
    borderRadius: "none",
    "&.Mui-expanded": {
      bgcolor: "#E9F5FF",
      borderBottom: isLoading
        ? `1px solid rgba(0, 0, 0, .125)`
        : `8px solid ${borderBottomColor}`,
    },
  }),
  accordionDetails: {
    width: "100%",
    height: "100%",
    "&.MuiAccordionDetails-root": {
      padding: 0,
    },
  },
};
export const headerStyle = {
  accordion: {
    boxShadow: "none",
  },
  accordionSummary: {
    ".MuiButtonBase-root": {
      cursor: "default",
    },
    ".MuiAccordionSummary-root": {
      cursor: "default",
    },
    cursor: "default",
    ".MuiAccordionSummary-content, .MuiAccordionSummary-expandIconWrapper": {
      cursor: "default",
    },
  },
  accordionIcon: { ...accordionStyle.accordionIcon, visibility: "hidden" },
  item: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#65748B",
  },
  title: {
    fontSize: "20px",
    fontWeight: "bold",
    color: "#65748B",
    textAlign: "center"
  },
};
