import { days } from '../constants/day.constant';
import { NumberOrUndefined, StringOrUndefined } from '../types/global.type';

export const getOperationalDaysByBinary = (decimalOperationalDays: NumberOrUndefined | null) => {
    let operationalDays = "-";
    let binaryOperationalDays = "-";

    if (!decimalOperationalDays || decimalOperationalDays > 128) {
        operationalDays = "-";
    } else {
        binaryOperationalDays = decimalOperationalDays.toString(2).padStart(7, "0").split("").reverse().join("");
    }
    if (binaryOperationalDays.length > 7 || decimalOperationalDays === 0) {
        operationalDays = "-";
    } else {
        operationalDays = "";
        let startDay: string = "", endDay: string = "";

        days.forEach((item, index) => {
            if (Number(binaryOperationalDays[index]) === 1) {
                if (!startDay) {
                    startDay = item.label_english
                    endDay = item.label_english
                } else {
                    endDay = item.label_english
                }
            } else {
                if (!!startDay) {
                    if (!!operationalDays) {
                        operationalDays = operationalDays.concat(", ");
                    }

                    if (startDay === endDay) {
                        operationalDays = operationalDays.concat(startDay.substring(0, 3));
                    } else {
                        operationalDays = operationalDays.concat(`${startDay.substring(0, 3)} - ${endDay.substring(0, 3)}`)
                    }
                    startDay = ""
                    endDay = ""
                }
            }
        })
        if (!!startDay) {
            if (!!operationalDays) {
                operationalDays = operationalDays.concat(", ");
            }

            if (startDay === endDay) {
                operationalDays = operationalDays.concat(startDay.substring(0, 3));
            } else {
                operationalDays = operationalDays.concat(`${startDay.substring(0, 3)} - ${endDay.substring(0, 3)}`)
            }
            startDay = ""
            endDay = ""
        }
    }

    return operationalDays;
}

export const getOperationalDaysByInitial = (initialOperationalDays: StringOrUndefined) => {
    let decimalOperationalDays = null;
    if (!initialOperationalDays) {
        decimalOperationalDays = null;
    } else {
        const arrInitialOperationalDays: string[] = initialOperationalDays?.split(',');
        decimalOperationalDays = [0, 0, 0, 0, 0, 0, 0];
        arrInitialOperationalDays?.forEach((initialDay) => {
            if (initialDay.indexOf('-') !== -1) {
                let startIndex = days.findIndex(item => item.initial_vision === initialDay.substring(0, initialDay.indexOf('-')));
                let endIndex = days.findIndex(item => item.initial_vision === initialDay.substring(initialDay.indexOf('-') + 1));
                for (let i = startIndex; i <= endIndex; i++) {
                    decimalOperationalDays[i] = 1;
                }
            } else {
                let indexFoundAt = days.findIndex(item => item.initial_vision === initialDay);
                decimalOperationalDays[indexFoundAt] = 1
            }
        })
        decimalOperationalDays = parseInt(decimalOperationalDays.join(''), 2)
    }
    return getOperationalDaysByBinary(decimalOperationalDays);
}