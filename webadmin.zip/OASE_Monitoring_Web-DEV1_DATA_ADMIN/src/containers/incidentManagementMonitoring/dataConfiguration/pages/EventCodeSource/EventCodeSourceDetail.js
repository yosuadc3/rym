import { Typography,Grid,Button } from "@mui/material";
import CustomBreadcrumbs from "../../../../../components/breadcrumb/CustomBreadcrumbs";
import React from "react";
import {useParams} from "react-router-dom"
import {useGetEventCodeSourceByIdQuery} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/api/eventCodeSource'
import { useState,useEffect } from "react";
import EventCodes from "../EventCodes/EventCodes";
import StyledAccordion from "../../../../../components/accordion/StyledAccordion";
import EmptyCard from "../../../../../components/cards/EmptyCard";
import Information from "../../components/Information";
import { handleUpdateSource, setData } from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/eventCodeSource/eventCodeSource";
import { useSelector, useDispatch } from "react-redux";
import FormPopUp from "../EventCodeSource/FormPopUp";
export default function EventCodeSourceDetail(){
    const {id} = useParams();
    const [data, setData2] = useState({});
    const { data: sourceData, isLoading: sourceIsLoading, refetch:eventCodeSourceRefetch } = useGetEventCodeSourceByIdQuery(id,{refetchOnReconnect: true});
    const dispatch = useDispatch();
    const handleOpenUpdateClick = () => {
        dispatch(handleUpdateSource());
    }
    const BREADCRUMBS = [
        {
            item: "Home",
            link: "/",
            current: false
        },
        {
            item: "Incident Management & Monitoring",
            link: null,
            current: false
        },
        {
            item: "Data Configuration",
            link: null,
            current: false
        },
        {
            item: "Event Code Catalog",
            link: "/data-configuration/event-code-catalog/",
            current: false
        },
        {
            item: data.source,
            link: null,
            current: true
        },
    ];
    
    useEffect(() => {
        if (!sourceIsLoading) {
            const { data} = sourceData;
            setData2(data);
            dispatch(setData(data));
        }
    }, [sourceData, sourceIsLoading]);

    useEffect(() => {
        eventCodeSourceRefetch();
    }, [useSelector((state)=> state.eventCodeSource.refresh)]);

    return(
        <>
            <Grid container alignItems={"center"} height={50}>
                    <Grid item xs={12}>
                        <CustomBreadcrumbs breadcrumbs={BREADCRUMBS} />
                    </Grid>
            </Grid>
            <Grid container>
                <EmptyCard sx={{ padding: 3 }} >
                    <StyledAccordion
                        title={"Event Code Catalog"}
                        defaultExpanded = {true}
                    >
                        <Information name={data.source} description={data.description} defined={data.total} last_modified={data.modified_time} color={"#E37448"} onClick={handleOpenUpdateClick}/>
                    </StyledAccordion>

                    <StyledAccordion
                        title={"List Event Code"}  
                        defaultExpanded = {true}  
                    >
                        <EventCodes id={id}/>
                    </StyledAccordion>
                </EmptyCard>
            </Grid>
            <FormPopUp/>
        </>
        
    );
}
