import React from 'react';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import { Link } from 'react-router-dom';

const styles = {
    text: {
        color: "white",
        height: "auto",
        "&:hover": {
            color: "#c5b7b7",
            fontWeight: "bold",
        }
    },
}

function GenerateItems(props) {
    const items = props.items;
    const level = props.level;

    return items.map(value => {
        return (
            <ListItemButton key={value.key} component={Link} to={value.link}>
                <ListItemText inset primary={<Typography marginLeft={level + 1} sx={styles.text}>{value.text}</Typography>} />
            </ListItemButton>
        );
    });
}

export default GenerateItems;