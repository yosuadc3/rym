import mysql from "mysql2";
import * as dbConfig from "../configs/database.config";

const oasemon = dbConfig.oasemon;

const environment = `[${process.env.NODE_ENV?.toUpperCase()}]`;

let pool: any;
let poolPromise: any;

export const connect = async () => {
	process.stdout.write(`${environment}: Connecting to OASE...`);
	try {
		pool = mysql.createPool(oasemon);
		poolPromise = pool.promise();
		process.stdout.write(`\r${environment}: Connected to OASE     \n`);
	} catch (err) {
		process.stdout.write(`\r${environment}: Failed to connect to OASE\n`);
		console.log(err);
	}
};

export const disconnect = (): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		try {
			pool.end();
			resolve();
		} catch (err) {
			console.log(err);
			reject();
		}
	});
};

export const exec = async (query: string, binds: (string | number)[] = []) => {
	const sql = poolPromise.format(query, binds);
	// console.log(sql.replace(/\s+/g, " ").trim());
	const [rows, _] = await poolPromise.execute(sql);
	return rows;
};

export const query = async (
	query: string,
	binds: any[] = [],
	rowsAsArray = false
) => {
	const sql = poolPromise.format(query, binds);
	// console.log("[EXECUTING]: ", sql.replace(/\s+/g, " ").trim());
	const [rows, fields] = await poolPromise.query({
		sql: sql,
		rowsAsArray: rowsAsArray,
	});

	return rows;
};

// export const getConnection = async (conn: any) => {
// 	return conn.getConnection()
// };

export { pool, poolPromise };

