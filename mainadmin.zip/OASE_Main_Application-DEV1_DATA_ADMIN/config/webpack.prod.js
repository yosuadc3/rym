const { merge } = require("webpack-merge");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const Dotenv = require("dotenv-webpack");
const CopyPlugin = require("copy-webpack-plugin");
const path = require("path");
const commonConfig = require("./webpack.common");

const PUBLIC_PATH = process.env.PUBLIC_PATH || "auto";
const REMOTE_OASE_MONITORING =
	process.env.REMOTE_OASE_MONITORING || "/monitoring";
const REMOTE_OASE_ASSET = process.env.REMOTE_OASE_ASSET || "/asset";

module.exports = (env) => {
	const prodConfig = {
		mode: "production",

		devtool: "source-map",

		output: {
			filename: '[name].[contenthash].js',
			path: path.resolve("nginx", "html"),
			publicPath: PUBLIC_PATH,
			library: "oase_main",
			clean: true,
		},

		plugins: [
			new ModuleFederationPlugin({
				remotes: {
					OASE_MONITORING: `oase_monitoring@${REMOTE_OASE_MONITORING}/remoteEntry.js`,
					OASE_ASSET: `oase_asset@${REMOTE_OASE_ASSET}/remoteEntry.js`,
				},
			}),
			new Dotenv({
				systemvars: true,
			}),
			new CopyPlugin({
				patterns: [
					{ from: path.resolve("public", "oase_icon.ico") },
					{ from: path.resolve("public", "index.css") },
					{ from: path.resolve("public", "font"), to: "font" },
				],
			}),
		],
	};

	return merge(commonConfig, prodConfig);
};