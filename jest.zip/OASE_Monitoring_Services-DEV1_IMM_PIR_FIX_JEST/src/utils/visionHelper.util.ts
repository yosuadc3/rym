import * as axiosHelper from "./axiosHelper.util";

const URL = process.env.VISION_API_URL;

const config = {
	auth: {
		username: process.env.VISION_API_CLIENT_ID,
		password: process.env.VISION_API_CLIENT_AUTH,
	},
};

export const getToken = async (user: string | null) => {
	const route = "/incident-service/external/login";
	const res = await axiosHelper.post(URL + route, config, {}, config, user);
	return res;
};

export const postComment = async (
	token: string,
	commentText: string,
	ticketId: string,
	user: string | null
) => {
	const route = `/incident-service/incidentManagement/ticket/${ticketId}/comments`;
	const header = {
		Authorization: `AccessToken ${token}`,
	};
	const jsonContentTemplate = {
		commentsList: [
			{
				commentType: "Shared",
				details: commentText,
			},
		],
	};
	const res = await axiosHelper.post(URL + route, header, jsonContentTemplate, {}, user);
	return res;
};

export const getFaultCategory = async (token: string, user: string | null) => {
	const route = `/incident-service/filters/faultCategories`;
	const header = {
		Authorization: `AccessToken ${token}`,
	};
	const faultCategoryPayload = {
		criteria: [{
			key: "deldate",
			operation: "eq",
			value: "false",
		}],
		sorting: {
			key: "terminalID",
			value: "asc",
		}
	}
	const res = await axiosHelper.post(URL + route, header, faultCategoryPayload, {}, user);
	return res;
};


export { };

