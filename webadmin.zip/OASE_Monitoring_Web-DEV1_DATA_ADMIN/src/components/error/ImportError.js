import React from "react";

function ImportError() {
    return (
        <h1>Something went wrong :(</h1>
    );
}

export default ImportError;