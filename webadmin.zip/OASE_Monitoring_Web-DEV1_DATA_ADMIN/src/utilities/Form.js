export const NUMBER_ONLY_REGEX = /^[0-9]*$/g;

export const createEmptyFormTargets = (formTargets) => {
	return formTargets.reduce((newObj, curr) => {
		newObj[curr] = "";
		return newObj;
	}, {});
};

export const createFalseFormTargets = (formTargets) => {
	return formTargets.reduce((newObj, curr) => {
		newObj[curr] = false;
		return newObj;
	}, {});
};

export const handleDisabledSubmit = (form, errorTarget, errorMessage) => {
	return (
		(!Object.keys(errorTarget).every((key) => errorTarget[key] === false) &&
			!Object.keys(errorMessage).every((key) => errorMessage[key] === "")) ||
		!Object.keys(form).every((key) => form[key] !== "")
	);
};

export const handleFormError = (
	errorMessage,
	targetError,
	setErrorMessage,
	setErrorTarget,
	bool
) => {
	setErrorTarget((prevErrorTarget) => ({
		...prevErrorTarget,
		[targetError]: bool,
	}));
	setErrorMessage((prevErrorMessage) => ({
		...prevErrorMessage,
		[targetError]: errorMessage,
	}));
};
