
import React from "react";
import FormDialogV2 from "../../../../../components/form/FormDialogV2";
import FormInput from "../../components/FormInput";
import {useState, useEffect} from 'react';
import { Grid, Button, DialogContent, DialogActions,Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { handleInsertFaultCategory, handleRefresh, handleRemoveFaultCategory, handleUpdateFaultCategory, setData} from "../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/faultCategory/faultCategory";
import {usePostFaultCategoryMutation,usePutFaultCategoryMutation,useDeleteFaultCategoryMutation} from '../../../../../redux/features/incidentManagementMonitoring/dataConfiguration/faultCategory/api/faultCategory'
import ConfirmDialog from "../../components/ConfirmDialog";
import FormSelect from "../../components/FormSelect";
import FormLabel from "../../../../../components/form/FormLabel";
import ColorPicker from "../../components/colorPicker/ColorPicker";
import { STYLES } from "../../../../../constants/IncidentManagement/Styles";
export default function FormPopUp(){
    const [inputCategory, setInputCategory ] = useState("");
    const [inputPriority, setInputPriority ] = useState("");
    const [inputColor, setInputColor ] = useState("");
    const [inputDesc, setInputDesc ] = useState("");
    const [isChange, setIsChange] = useState(false);
    const [openInsert2, setOpenInsert2 ] = useState(false);
    const [openUpdate2, setOpenUpdate2 ] = useState(false);
    const [insertIntoApi,{isLoading:insertLoading,error:insertError,isSuccess: insertSuccess}] = usePostFaultCategoryMutation();
    const [updateApi,{isLoading:updateLoading,error:updateError,isSuccess: updateSuccess}] = usePutFaultCategoryMutation();
    const [deleteApi,{isSuccess:deleteSuccess}] = useDeleteFaultCategoryMutation();
    const [priorityError,setPriorityError] = useState([false,""]);

    const data = useSelector((state) => state.faultCategory.data);
    const dispatch = useDispatch();

    const insert = () =>{
        if(inputCategory !=""){
            const insertData = {
                category: inputCategory,
                color: inputColor,
                description: inputDesc,
            }
            insertIntoApi(insertData);
        }
    }

    const update = () =>{
        if(data.id!= "" && inputCategory != ""){ 
            const data_update = {
                category: inputCategory,
                color: inputColor,
                description: inputDesc,
            }
            updateApi({ id: data.id, data: data_update });
        }
    }

    const remove = () =>{
        if(data.id != "" && data.priority !=""){
            const data_priority = {
                priority: data.priority
            }
            deleteApi({id:data.id,data:data_priority});
            dispatch(handleRefresh());
        }
    }

    const handleCloseInsertClick = () => {
        dispatch(handleInsertFaultCategory());
        setIsChange(false);
    }

    const handleOpenInsert2Click = () => {
        dispatch(handleInsertFaultCategory());
        setOpenInsert2(true);
    }
    const handleCloseInsert2Click = () => {
        setIsChange(false);
        setOpenInsert2(false);
    }

    const handleCloseUpdateClick = () => {
        dispatch(handleUpdateFaultCategory());
        setIsChange(false);
    }

    const handleOpenUpdate2Click = () => {
        dispatch(handleUpdateFaultCategory());
        setOpenUpdate2(true);
    }

    const handleCloseUpdate2Click = () => {
        setIsChange(false);
        setOpenUpdate2(false);
    }
 
    const handleCloseRemoveClick = () => {
        dispatch(handleRemoveFaultCategory());
    }

    const handleInputCategory = (e)=>{
        setInputCategory(e.target.value);
        setIsChange(true);
    }
    const handleInputPriority = (e)=>{
        setInputPriority(e.target.value);
        setPriorityError([false,""]);
        setIsChange(true);
    }
    const handleInputColor = (e)=>{
        setInputColor(e);
        setIsChange(true);
    }
    
    useEffect(() => {
        if(typeof insertError !== "undefined"){
            const len = insertError.data.error_message.message.body.length;
            for(let i=0; i<len ;i++){
                const key = Object.keys(insertError.data.error_message.message.body[i])[0];
                const data = insertError.data.error_message.message.body[i];
                if( key === "priority"){
                    setPriorityError([true,data[key]]);
                }
            }
        }     
        if(insertSuccess){
            dispatch(handleRefresh());
            handleCloseInsert2Click();
        }  
    }, [insertLoading]);

    useEffect(() => {
        if(typeof updateError !== "undefined"){
            const len = updateError.data.error_message.message.body.length;
            for(let i=0; i<len ;i++){
                const key = Object.keys(updateError.data.error_message.message.body[i])[0];
                const data = updateError.data.error_message.message.body[i];
                if( key === "priority"){
                    setPriorityError([true,data[key]]);
                }             
            }
        }     
        if(updateSuccess){
            dispatch(handleRefresh());
            handleCloseUpdate2Click();
        }  
    }, [updateLoading]);

    useEffect(() => {  
        if(deleteSuccess){
            dispatch(handleRefresh());
            dispatch(handleRemoveFaultCategory());
         }  
    }, [deleteSuccess]);

    useEffect(() => {
        if(!isChange){
            setInputCategory(data.category);
            setInputPriority(data.priority);
            setInputColor(data.color);
            setInputDesc(data.description);
            setPriorityError([false,""]);
        }
    }, [data,useSelector((state) =>  state.faultCategory.updateOpen)]);

    useEffect(()=>{
        if(!isChange){
            setInputCategory("");
            setInputPriority("");
            setInputColor("");
            setInputDesc("");
            setPriorityError([false,""]);
        }
    },[useSelector((state) => state.faultCategory.insertOpen)]);

    return(
        <>
        <FormDialogV2
                isOpen={useSelector((state) => state.faultCategory.insertOpen)}
                handleToggle={handleCloseInsertClick}
                title = {"Tambah Fault Category"}
            >
                <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={3}>
                            <FormInput
                                changed={inputCategory != ""}
                                autoFocus
                                label={"Category"}
                                onChange={handleInputCategory}
                            />
                        </Grid>
                        <Grid item marginBottom={3}>
                            <FormLabel label={"Rules"}/>
                            <Typography>-</Typography>
                        </Grid>
                        <Grid item marginBottom={3}>
                            <FormInput
                            changed={inputDesc !=""}
                            label={"Description"}
                            useMultiline
                            onChange={(e)=>{setInputDesc(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item>
                            <FormLabel label={"Color (Opsional)"} />
                            <ColorPicker handleInputColor={setInputColor}/>
                        </Grid>
                    </Grid>
                </DialogContent>

                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={4} marginTop={2} gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseInsertClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenInsert2Click} 
                            disabled = {inputCategory == ""}
                            >
                            Simpan
                        </Button>
                    </Grid>
                </DialogActions>

            </FormDialogV2>    

            <FormDialogV2
                isOpen={useSelector((state) => state.faultCategory.updateOpen)}
                handleToggle={handleCloseUpdateClick}
                title = {"Update Fault Category"}
            >
                <DialogContent sx={STYLES.dialogContent}>
                    <Grid>
                        <Grid item marginBottom={3}>
                            <FormInput
                                changed={inputCategory != ""}
                                label={"Category"}
                                onChange={handleInputCategory}
                                value = {data.category}
                            />
                        </Grid>
                        <Grid item marginBottom={3}>
                            <FormLabel label={"Rules"}/>
                            <Typography>-</Typography>
                        </Grid>
                        <Grid item marginBottom={3}>
                            <FormInput
                            changed={inputDesc !=""}
                            label={"Description"}
                            value = {data.description}
                            useMultiline
                            onChange={(e)=>{setInputDesc(e.target.value);setIsChange(true);}}
                            />
                        </Grid>
                        <Grid item>
                            <FormLabel label={"Color (Opsional)"} />
                            <ColorPicker handleInputColor={handleInputColor} hex={data.color} />
                        </Grid>
                    </Grid>
                </DialogContent>

                <DialogActions>
                    <Grid container justifyContent={"center"} marginBottom={4} marginTop={2} gap={3}>
                        <Button 
                            variant="outlined"
                            disableElevation 
                            sx={STYLES.outlinedButton}
                            onClick={handleCloseUpdateClick}
                            >
                            Batal
                        </Button>
                        <Button 
                            variant="contained"
                            disableElevation 
                            sx={STYLES.containedButton}
                            onClick={handleOpenUpdate2Click} 
                            disabled = {inputCategory == "" || !isChange}
                            >
                            Simpan
                        </Button>
                    </Grid>
                </DialogActions>

            </FormDialogV2>   

            <ConfirmDialog
                isOpen={useSelector((state) => state.faultCategory.removeOpen)}
                handleClose={handleCloseRemoveClick}
                title={`Yakin akan menghapus Fault Category “${data.category}” ?`}
                handleSave={remove}
                paddingX= "50px"
            />
             <ConfirmDialog
                isOpen={openUpdate2}
                handleClose = {handleCloseUpdate2Click}
                title = {"Yakin akan menyimpan perubahan Fault Category?"}
                handleSave = {update}
            />
            
             <ConfirmDialog
                isOpen={openInsert2}
                handleClose={handleCloseInsert2Click}
                title={`Yakin akan menambah Fault Category “${inputCategory}” ?`}
                handleSave={insert}
                paddingX= "20px"
                paddingTop = "30px"
            />
            </>
    );
}