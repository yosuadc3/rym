import React from "react";

function ProfileIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="32"
      height="32"
      fill="none"
      viewBox="0 0 32 32"
      {...props}
    >
      <circle cx="16" cy="16" r="16" fill="#0F549F"></circle>
      <path
        stroke="#fff"
        d="M16 6a5 5 0 100 10 5 5 0 000-10zM10.125 18C8.952 18 8 18.95 8 20.124v.376c0 1.878.97 3.284 2.46 4.19C11.924 25.582 13.893 26 16 26s4.076-.418 5.54-1.31c1.49-.907 2.46-2.312 2.46-4.19v-.376A2.124 2.124 0 0021.875 18h-11.75z"
      ></path>
    </svg>
  );
}

export default ProfileIcon;
