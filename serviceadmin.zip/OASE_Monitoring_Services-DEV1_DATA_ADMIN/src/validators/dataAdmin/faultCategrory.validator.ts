import { body, param, query } from "express-validator";

export const getFaultCategories = [
    query("page").isNumeric(),
    query("limit").isNumeric(),
    query("sortBy").isString(),
    query("orderBy").isAlpha(),
    query("offset").optional().isNumeric(),
    query("search").optional().isJSON(),
    query("advancedSearch").optional().isJSON(),
    query("advancedSearchPeriode").optional().isJSON()
];

export const getFaultCategory = [
    param("id").isUUID()
];

export const postFaultCategory = [
    body("category").isString(),
    body("color").isString(),
    body("description").isString(),
];

export const putFaultCategory = [
    body("category").isString(),
    body("color").isString(),
    body("description").isString(),
    param("id").isUUID(),
];

export const changeOrdersFaultCategory = [
    body("id").isUUID(),
    body("start_priority").isNumeric(),
    body("end_priority").isNumeric()
];

export const deleteFaultCategory = [
    param("id").isUUID(),
    body("priority").isNumeric()
];