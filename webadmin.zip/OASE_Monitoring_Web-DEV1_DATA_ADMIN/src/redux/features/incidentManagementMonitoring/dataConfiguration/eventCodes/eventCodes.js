import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   insertOpen: false,
   updateOpen: false,
   removeOpen: false,
   refresh : false,
   data : {id:"",event_code:"",description:"",group:"",rule:"",source:""}
}

const eventCodesSlice = createSlice({
   name: "eventCodes",
   initialState: initialState,
   reducers: {
      handleInsertCodes: (state) => {
         state.insertOpen = !state.insertOpen;
      },
      handleUpdateCodes: (state) => {
        state.updateOpen = !state.updateOpen;
     },
     handleRemoveCodes: (state) => {
        state.removeOpen = !state.removeOpen;
     },
     handleRefresh: (state) => {
        state.refresh = !state.refresh;
     },
     setData: (state,action)=>{
        const { payload } = action;
        state.data =  payload;
     }
     
   }
});

export const { handleInsertCodes,handleRefresh, handleRemoveCodes, handleUpdateCodes,setData } = eventCodesSlice.actions;

export default eventCodesSlice;
