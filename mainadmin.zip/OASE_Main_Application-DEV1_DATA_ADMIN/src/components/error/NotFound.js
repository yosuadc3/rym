import React from "react";

function NotFound() {
    return (
        <h1 style={{ textAlign: "center" }}>404 Not Found</h1>
    );
}

export default NotFound;