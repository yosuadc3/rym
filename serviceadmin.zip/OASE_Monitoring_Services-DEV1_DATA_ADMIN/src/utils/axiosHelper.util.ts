// EXTERNAL API PURPOSES

import { AxiosError, AxiosResponse } from "axios";
import 'express-async-errors';
import moment, { Moment } from "moment";
import { HTTP_BAD_GATEWAY } from "../constants/httpResponseCodes.constant";
import env from "../env/server.env";
import { BadGatewayError } from "../errors/server.error";
import { formatBytes, formatMilliseconds } from "../middlewares/logging.middleware";
const axios = require("axios");

type TStatuses = "POST" | "GET" | "DELETE" | "PATCH" | "PUT"

const POST = "POST";
const GET = "GET";
const PUT = "PUT";

const SERVER_SITE = env.SERVER_SITE;

const spitLogToKibana = (startTime: Moment, method: TStatuses, status: string | number | "-" = "-", url: string = "-", duration: number | "-" = "-", size: number = 0, user: string | null | undefined, body: object, header: object) => {
	const log = {
		timestamp: startTime.format("DD/MM/YYYY HH:mm:ss"),
		method,
		status,
		url,
		duration: formatMilliseconds(Number(Number(duration).toFixed(0))) || 0,
		size: formatBytes(size),
		user,
		os: "-",
		browser: "-",
		browser_version: "-",
		ip: "-",
		site: SERVER_SITE,
		type: "EXTERNAL",
		body: JSON.stringify(body),
		header: JSON.stringify(header),
	};

	// baris dibawah JANGAN dihapus!
	// eslint-disable-next-line
	console.log(JSON.stringify(log));
}

// @ts-ignore
export const get = async (url: string, headers: object, params: string, body: object, user?: string | null, oaseUser: string | null): Promise<void> => {
	const startTime = moment();
	const config = {
		headers: headers,
		params: params,
	};

	try {
		const response = await axios.get(url, config)
		const data = response.data;
		const status = response.status;
		const endTime = moment();
		const duration = endTime.diff(startTime);
		const size = JSON.stringify(data).length;
		spitLogToKibana(startTime, GET, status, url, duration, size, oaseUser, body, config);

		return data;
	} catch (err) {
		const endTime = moment();
		const duration = endTime.diff(startTime);
		spitLogToKibana(startTime, GET, HTTP_BAD_GATEWAY, url, duration, 0, oaseUser, body, config);

		throw new BadGatewayError("Unable to get response from stream server", "AXIOS_GET_ERROR")
	}
};

export const post = async (url: string, headers: object, body: object, config: object, oaseUser?: string | null) => {
	const startTime = moment();

	let setConfig = config;
	if (Object.keys(setConfig).length === 0) {
		setConfig = { headers };
	}

	try {
		const response = await axios.post(url, body, setConfig)
		const data = response.data;
		const status = response.status;
		const endTime = moment();
		const duration = endTime.diff(startTime);
		const size = JSON.stringify(data).length;
		spitLogToKibana(startTime, POST, status, url, duration, size, oaseUser, body, setConfig);

		return data;
	} catch (err) {
		const endTime = moment();
		const duration = endTime.diff(startTime);
		spitLogToKibana(startTime, POST, HTTP_BAD_GATEWAY, url, duration, 0, oaseUser, body, setConfig);

		throw new BadGatewayError("Unable to get response from stream server", "AXIOS_POST_ERROR")
	}
};

// @ts-ignore
export const put = async (url: string, headers: object, body: object, user?: string | null): Promise<void> => {
	const startTime = moment();
	const config = {
		headers: headers,
	};

	return new Promise((resolve, reject) => {
		axios
			.put(url, body, config)
			.then((res: AxiosResponse) => {
				const data = res.data;
				const status = res.status;
				const endTime = moment();
				const duration = endTime.diff(startTime);
				const size = JSON.stringify(data).length;

				spitLogToKibana(startTime, PUT, status, url, duration, size, user, body, config);
				resolve(data);
			})
			.catch((error: AxiosError) => {
				const endTime = moment();
				const duration = endTime.diff(startTime);

				spitLogToKibana(startTime, PUT, HTTP_BAD_GATEWAY, url, duration, 0, user, body, config);

				throw new BadGatewayError("Bad gateway", "AXIOS_GET_ERROR")
			});
	});
};

// @ts-ignore
export const retry = (prevConfig, token: string, user?: string | null): Promise<void> => {
	const config = prevConfig;
	config.headers.Authorization = `Bearer ${token}`;

	return new Promise((resolve, reject) => {
		axios
			.request(config)
			.then((res: AxiosResponse) => {
				resolve(res.data);
			})
			.catch((error: AxiosError) => {
				reject(error);
			});
	});
};

export { };

