export default (...args: any[]) => {
   console.log(...args);
}