const scheduler = require("node-schedule");
const controller = require("../../controllers/logger/dashboardLogger.controller");

const main = scheduler.scheduleJob("* * * * *", function () {
  controller.main();
});

const housekeeping = scheduler.scheduleJob("0 0 * * *", function () {
  controller.housekeeping();
});
