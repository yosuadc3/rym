import React from "react";
import ReactDOM from "react-dom";
import { ReactKeycloakProvider } from '@react-keycloak/web';
import keycloak from './keycloak';
import App from "./App";

const onKeycloakEvent = (event, error) => {
    console.log("KeycloakEvent", event, error);
}

const onKeycloakToken = (token) => {
    localStorage.setItem("token", token.token);
    localStorage.setItem("refreshToken", token.refreshToken);
}

ReactDOM.render(
    <React.StrictMode>
        <ReactKeycloakProvider
            authClient={keycloak}
            initOptions={{
                onLoad: "login-required",
                checkLoginIframe: false
            }}
            onEvent={onKeycloakEvent}
            onTokens={onKeycloakToken}
        >
            <App />
        </ReactKeycloakProvider>
    </React.StrictMode>,
    document.getElementById('app')
);