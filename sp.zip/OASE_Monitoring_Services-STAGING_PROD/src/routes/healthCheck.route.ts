import * as healthCheck from "../controllers/healthCheck.controller";
var router = require("express").Router();

// This function for check the healthy of the application
// const getHealthCheck = (app) => {
//     router.get('/', healthCheck.getStatusApplication);
//     app.use("/api/health-check", router);
// }

// module.exports = (app) => {
//     getHealthCheck(app)
// };

router.get("/", healthCheck.getStatusApplication);

export default router;
export {};
