import { Grid } from "@mui/material";
import React, { useState } from "react";

import Dropdown from "./Dropdown.component";

const FaultCategories = ({
  isNullCategories,
  hasNonNullCategories,
  data,
  handleRowClick,
  searchQuery,
  isLoading,
}) => {
  const categoryKeys = Object.keys(data);
  const [categories, setCategories] = useState(categoryKeys);

  return (
    <Grid container>
      {categories.map((category, i) => (
        <Grid
          item
          xs={12}
          key={i}
        >
          <Dropdown
            idx={isNullCategories && hasNonNullCategories ? i + 1 : i}
            isLoading={isLoading}
            category={category}
            borderBottomColor={data[category]["color"]}
            handleRowClick={handleRowClick}
            total={data[category]["total"] ?? 0}
            oldestIncident={data[category]["Oldest Incident"]}
            recentIncident={data[category]["Recent Incident"]}
            averageIncident={data[category]["Average Incident"]}
            searchQuery={searchQuery}
          />
        </Grid>
      ))}
    </Grid>
  )
}

export default FaultCategories;
