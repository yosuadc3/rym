import { TPeriode } from "../types/global.type";
type THandleAdvancedSearchParamsAdvancedSearch = {
	[k: string]: string[];
};

type THandleSearchParamsData = {
	[k: string]: string;
};

type TFilter = {
	[k: string]: string[];
};

const dateFormat = {
	start: "%Y-%m-%d 00:00:00",
	end: "%Y-%m-%d 23:59:59",
};

export const handleSearchParams = (data: THandleSearchParamsData | null) => {
	const params: string[] = [];
	let searchQuery = "";

	if (data !== null) {
		const length = Object.keys(data).length;
		Object.keys(data).forEach((value, index) => {
			if (data[value] && data[value] !== "") {
				if (index === 0) {
					searchQuery = "where (?? like ?";
				} else {
					searchQuery += " or ?? like ?";
				}
				if (index + 1 === length) {
					searchQuery += ")";
				}
				params.push(value, `%${data[value]}%`);
			}
		});
	}

	return {
		query: searchQuery,
		params,
	};
};

export const handleAdvancedSearchParams = (
	advancedSearchPeriode: TPeriode,
	advancedSearch?: THandleAdvancedSearchParamsAdvancedSearch | null,
	timestampColumnName: string = "timestamp"
) => {
	let searchQuery = "";
	const params = [];

	searchQuery += `where (?? between date_format(?, '${dateFormat.start}') and date_format(?, '${dateFormat.end}'))`;
	params.push(
		timestampColumnName,
		advancedSearchPeriode.startDate,
		advancedSearchPeriode.endDate
	);

	if (advancedSearch) {
		for (const key in advancedSearch) {
			let regexpValue = ".";
			searchQuery += " and (?? regexp ?)";

			// @ts-ignore
			advancedSearch[key].forEach((value, index) => {
				if (index === 0) {
					regexpValue = value;
				} else {
					regexpValue += `|${value}`;
				}
			});

			params.push(key, regexpValue);
		}
	}

	return {
		query: searchQuery,
		params: params,
	};
};

export const handleFiltering = (periode: TPeriode, filter: TFilter | null, timestampColumnName: string = "timestamp") => {
	let searchQuery = "";
	const params = [];

	searchQuery = `where (?? between date_format(?, '${dateFormat.start}') and date_format(?, '${dateFormat.end}'))`;
	params.push(timestampColumnName, periode?.startDate, periode?.endDate);

	if (filter) {
		for (const key in filter) {
			// @ts-ignore
			const arrayLength = filter[key].length;

			if (arrayLength > 0) {
				searchQuery += " and (??";
				params.push(key);

				if (arrayLength === 1) {
					searchQuery += " in (?))";

					// @ts-ignore
					params.push(filter[key][0]);
				} else {
					// @ts-ignore
					filter[key].forEach((value, index) => {
						if (index === 0) {
							searchQuery += " in (?";
						} else if (index === arrayLength - 1) {
							searchQuery += ",?))";
						} else {
							searchQuery += ",?";
						}

						params.push(value);
					});
				}
			}
		}
	}

	return {
		query: searchQuery,
		params: params,
	};
};

export const handleUpdate = (data: { [k: string]: string | number | unknown }) => {
	let searchQuery = "";
	const params: (string | number | unknown)[] = [];

	const objectKeys = Object.keys(data);

	objectKeys.forEach((value, index) => {
		if (index === 0) { searchQuery += "set " }

		if (index === objectKeys.length - 1) {
			searchQuery += "?? = ?";
			params.push(value, data[value]);
		}
		else {
			searchQuery += "?? = ?, ";
			params.push(value, data[value]);
		}
	});
	return {
		query: searchQuery,
		params: params
	}
}

export { };

