import { Accordion, AccordionSummary, Grid, Typography } from "@mui/material";
import React from "react";
import ChevronDown from "../../../../../components/svgs/ChevronDown";
import {
  INCIDENT_MANAGEMENT_HEADER,
  headerStyle,
} from "../constants/IncidentManagement";

const Header = () => {
  return (
    <Accordion disableGutters expanded={false} sx={headerStyle.accordion}>
      <AccordionSummary
        sx={headerStyle.accordionSummary}
        expandIcon={<ChevronDown sx={headerStyle.accordionIcon} />}
      >
        <Grid container>
          {INCIDENT_MANAGEMENT_HEADER.map((title, i) => (
            <Grid
              key={i}
              item
              xs={
                i === 0
                  ? 3
                  : i === 1
                    ? 1
                    : i === INCIDENT_MANAGEMENT_HEADER.length - 1
                      ? 2
                      : 3
              }
              container
              // spacing={6}
              // justifyContent={i === 0 ? "start" : "center"}
              justifyContent="center"
              alignItems="center"
            >
              <Typography sx={{ ...headerStyle.title }}>{title}</Typography>
            </Grid>
          ))}
        </Grid>
      </AccordionSummary>
    </Accordion>
  );
};

export default Header;
