import FilterListIcon from "@mui/icons-material/FilterList";
import { Box, Button, Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import BaseBreadcrumbs from "../../../components/breadcrumb/BaseBreadcrumbs";
import ButtonExportV2 from "../../../components/buttons/ButtonExportV2";
import EmptyCard from "../../../components/cards/EmptyCard";
import SkeletonText from "../../../components/skeleton/SkeletonText";
import StyledTableV2 from "../../../components/table/StyledTableV2";
import useFetch from "../../../hooks/useFetch";
import { useGetLogPerubahanTablePreviewQuery } from "../../../redux/features/report/dataConfiguration/api/dataConfiguration";
import { customFormat } from "../../../utilities/TimeConverter";
import FilterBox from "./components/FilterBox";
import {
   FILTER_OBJ,
   REPORT_CATEGORY_DATA_CONFIGURATION,
   REPORT_DATA_CONFIGURATION_BREADCRUMBS,
   REPORT_HEADER_LOG_PERUBAHAN,
   REPORT_TYPE_MENU_LOG_PERUBAHAN,
   styles,
} from "./constants/ReportDataConfiguration";

const ReportInfo = ({ query, isRefetch, setHasRows, setDisabledSearch, jenisMenuDataConfiguration }) => {
   const endpoint = `info?${query}`;
   const [isFirstRender, setIsFirstRender] = useState(true);
   const { data, isLoading, fetch } = useFetch(endpoint, "incident");

   useEffect(() => {
      if (isFirstRender) {
         setIsFirstRender((_) => false);
         return;
      }
      fetch(endpoint, "incident");
   }, [isRefetch]);

   useEffect(() => {
      if (data && data.data) {
         setDisabledSearch(prev => false);
         setHasRows(data?.data?.total !== 0)
      }
   }, [data])

   if (isLoading) {
      return (
         <div style={{ marginLeft: "12px" }}>
            <Typography sx={styles.reportTitle}>
               <SkeletonText height={30} width={300} />
            </Typography>
            <Typography sx={styles.reportDescription}>
               <SkeletonText height={20} width={400} />
            </Typography>
         </div>
      );
   }

   const showTotal = data?.data?.showTotal;
   const total = data?.data?.total || 0;

   return (
      <div style={{ marginLeft: "12px" }}>
         {total !== 0 ? (
            <>
               <Typography sx={styles.reportTitle}>
                  Report Data Configuration - {jenisMenuDataConfiguration}
               </Typography>
               <Typography sx={styles.reportDescription}>
                  Data yang ditampilkan {showTotal} dari {total} record, untuk melihat
                  lebih lengkap dapat klik 'Download File'
               </Typography>
            </>
         ) : null}
      </div>
   );
};

const PreviewTable = ({ searchQuery, hasSearch }) => {
   const { reportType } = useSelector((state) => state.reportDataConfigurationSlice);

   const isLogPerubahan = reportType === REPORT_TYPE_MENU_LOG_PERUBAHAN;
   const header = isLogPerubahan ? REPORT_HEADER_LOG_PERUBAHAN : REPORT_CATEGORY_DATA_CONFIGURATION;

   const link = isLogPerubahan ? "/data-configuration/log" : "";

   return (
      <StyledTableV2
         headers={header}
         defaultSortBy="id"
         link={link}
         route="report"
         useReportTheme
         searchQuery={searchQuery}
         refetchDependencies={[hasSearch]}
      />
   )
}

export default function ReportDataConfiguration() {
   const dispatch = useDispatch();
   const { reportType, logPerubahanQuery } = useSelector((state) => state.reportDataConfigurationSlice);

   // log perubahan
   const [query, setQuery] = useState(null);
   const [skip, setSkip] = useState(true);
   const { data = [], isLoading } = useGetLogPerubahanTablePreviewQuery(query, { skip })

   const [hasSearch, setHasSearch] = useState(false);
   const [searchQuery, setSearchQuery] = useState("");
   const [isFirstRender, setIsFirstRender] = useState(true);
   const [trigger, setTrigger] = useState(false);
   const [hasRows, setHasRows] = useState(false);
   const [disabledSearch, setDisabledSearch] = useState(false);

   const [filter, setFilter] = useState([FILTER_OBJ]);

   const [isOpen, setIsOpen] = useState(true);

   useEffect(() => {
      if (isFirstRender) {
         setIsFirstRender((_) => false);
         return;
      }
      setTrigger((_) => true);
   }, [hasSearch]);

   const handleHasSearch = () => {
      setHasSearch((prev) => !prev);
      setIsOpen((prev) => !prev);
   };

   const handleTogglePopup = () => {
      setIsOpen((prev) => !prev);
   };

   const getFilter = () => {
      setDisabledSearch((_) => true);

      if (reportType === REPORT_TYPE_MENU_LOG_PERUBAHAN) {
         const { period, types } = logPerubahanQuery;
         const typeValues = types.map((v) => v.value);

         const { start, end } = period;
         const startPeriod = customFormat(start, "DD/MM/YYYY");
         const endPeriod = customFormat(end, "DD/MM/YYYY");

         const newQuery = {
            start_period: startPeriod,
            end_period: endPeriod,
            types: typeValues
         }

         setQuery((_) => newQuery);

         if (skip) {
            setSkip((_) => false);
            return;
         }

         setSearchQuery(() => newQuery);
      }

      // setSearchQuery(() => params);
   };

   return (
      <Box>
         <BaseBreadcrumbs breadcrumbs={REPORT_DATA_CONFIGURATION_BREADCRUMBS} />
         <Grid>
            <Grid item container xs={4}>
               <div style={styles.filterBtnDiv}>
                  <Button
                     startIcon={<FilterListIcon sx={styles.filterIcon} />}
                     sx={styles.filterBtn}
                     onClick={handleTogglePopup}
                  >
                     Filter
                  </Button>
                  {(hasSearch || trigger) && (
                     <ReportInfo query={searchQuery} isRefetch={hasSearch} setHasRows={setHasRows} setDisabledSearch={setDisabledSearch} />
                  )}
               </div>
            </Grid>
         </Grid>
         <Grid container spacing={2}>
            {isOpen && (
               <Grid item xs={3}>
                  <FilterBox
                     categories={REPORT_CATEGORY_DATA_CONFIGURATION}
                     freeSolo
                     getter={getFilter}
                     handleHasSearch={handleHasSearch}
                     filter={filter}
                     setFilter={setFilter}
                     disabled={disabledSearch}
                  />
               </Grid>
            )}
            {(hasSearch || trigger) && (
               <Grid item xs={isOpen ? 9 : 12}>
                  <EmptyCard sx={styles.tableDiv(isOpen)}>
                     <PreviewTable searchQuery={searchQuery} hasSearch={hasSearch} />
                  </EmptyCard>
                  {hasRows && (
                     <div style={styles.downloadDiv}>
                        <ButtonExportV2
                           link="report"
                           route="incident"
                           query={searchQuery}
                           timestamp={true}
                           filename="Report Data Configuration"
                           trigger={[hasSearch]}
                           disabled={disabledSearch}
                           extension="xlsx"
                        />
                     </div>
                  )
                  }
               </Grid>
            )}
         </Grid>
      </Box>
   );
}
