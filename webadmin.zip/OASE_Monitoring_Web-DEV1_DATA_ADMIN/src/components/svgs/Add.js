import { SvgIcon } from "@mui/material";
import React from "react";

export default function Add(props) {
  return (
    <SvgIcon {...props}>
      <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M15.5 9.07143H9.07143V15.5H6.92857V9.07143H0.5V6.92857H6.92857V0.5H9.07143V6.92857H15.5V9.07143Z"
          fill="white"
        />
      </svg>
    </SvgIcon>
  );
}
