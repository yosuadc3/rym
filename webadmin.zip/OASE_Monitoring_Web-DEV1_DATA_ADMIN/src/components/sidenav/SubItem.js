import React from "react";
import { Collapse, List } from "@mui/material";


const styles = {
    level_0: {
        backgroundColor: "inherit"
    },
    level_1: {
        backgroundColor: "#0C599A"
    },
    level_2: {
        backgroundColor: "#0B4C83"
    },
    level_3: {
        backgroundColor: "#094476"
    },
}


function SubItem(props) {
    const children = props.children;
    const level = props.level;
    const state = props.state;

    let style;

    switch (level) {
        case 1:
            style = styles.level_1;
            break;
        case 2:
            style = styles.level_2;
            break;
        case 3:
            style = styles.level_3;
            break;
        default:
            style = styles.level_0;
    }


    return (
        <Collapse in={state} timeout="auto" unmountOnExit>
            <List sx={style} component="div" disablePadding>
                {children}
            </List>
        </Collapse>
    );
}

export default SubItem;