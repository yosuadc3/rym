import { Grid, Stack, Typography } from "@mui/material";
import React from "react";

export default function CustomGrid({ useContainer = false, xs, title, description }) {
	return (
		<Grid item container={useContainer} xs={xs}>
			<Stack justifyContent="start" alignItems="start">
				<Typography sx={{ fontWeight: "bold", color: "#65748B" }}>
					{title}
				</Typography>
				<Typography sx={{ textAlign: "left", fontWeight: 600 }}>
					{description}
				</Typography>
			</Stack>
		</Grid>
	);
}
