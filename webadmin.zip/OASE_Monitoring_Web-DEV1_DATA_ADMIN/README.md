<img src="http://bcagitlab/cts-e/atm_touchpoint/oase_monitoring/OASE_Monitoring_Web/-/raw/DEV1_INCIDENT_MANAGEMENT/src/assets/image/OASE.png" width="auto">

# OASE - Monitoring Web
OASE Monitoring Web is to visualize and monitors current statuses of BCA's ATM all over Indonesia.

## Installation

**npm:**
```bash
npm install
```

**npm (*optional*):**
```bash
npm install --legacy-peer-deps
```

## Project Structure
Below, is the tree for OASE Monitoring Web

```bash
├───config
├───nginx
├───openshift
│   ├───dev
│   ├───prod
│   └───uat
├───public
│   └───font
└───src
    ├───actions
    ├───assets
    ├───components
    ├───constant
    ├───containers
    │   ├───dashboard
    │   ├───home
    │   ├───incident
    │   ├───kibana
    │   └───onlineBaru
    │   └───report
    ├───hooks
    ├───reducers
    ├───router
    ├───singleSPA
    ├───token
    └───utilities
```
| Folder | Description  |
| ------- | --- |
| `config` | This folder consists of a configuration file where we store webpack config file, We will use this file to set up webpack in your application.|
| `nginx` | This folder consists of a configuration file where we store `nginx.confg.`|
| `openshift` | This folder contains openshift yaml file for `dev`, `uat`, and production environtment. |
| `public` |  The public folder contains static files such as `index.html`, Javascript library files, images, and other assets, etc. which you don’t want to be processed by webpack. |
| `src` | This folder is the heart of React application as it contains JavaScript which needs to be processed by webpack. In this folder, there is a main component `App.js`, its related styles (`App.css`), test suite (`App.test.js`). `index.js`, and its style (`index.css`); which provide an entry point into the App. |
| `src/assets` | This folder contains assets of our project. It consists of images, and icons files. |
| `src/components` | Components are the building blocks of any react project. This folder consists of a collection of UI components like buttons, modals, inputs, loader, etc., that can be used across various files in the project. In this project you can custom with HTML elements or Material UI component to create a custom component. |
| `src/constants` |   This folder contains hardcoded value where we stored in constant file, so we can make it more readable and change the hardcoded value in constant file. |
| `src/containers` | This folder is the parent elements of other components in a React app. They serve as a bridge between the normal components that render the UI and the logic that makes the UI components interactive and dynamic. A container can contain its subfolder. It usually consists of various components grouped. |
| `src/hooks` |   This folder contains custom React Hooks. |
| `src/reducers` |   This folder contains slices and global state configurations for Redux. |
| `src/router` | This folder consists of all routes of the application. It consists of private, protected, and all types of routes. Here we can even call our sub-route. |
| `src/singleSPA` | This folder consists of single spa file, single spa react is a helper library that helps implement single-spa registered application lifecycle functions (bootstrap, mount and unmount) for use with React to help you build a microfrontend application. |
| `src/token` | This folder consist of all file about extract token, store token, get token, and etc. |
| `src/utilities` | Utils folder consists of some repeatedly used functions that are commonly used in the project. It should contain only common js functions & objects like dropdown options, regex condition, data formatting, etc. |

## Documentation
Visit the [documentation](http://bcagitlab/cts-e/atm_touchpoint/oase_monitoring/OASE_Monitoring_Web/-/tree/DEV1_INCIDENT_MANAGEMENT/src/components) for our useable OASE's components.

## Some things to notice
- **Material UI v5**
  - Visit https://mui.com/material-ui/getting-started/overview/