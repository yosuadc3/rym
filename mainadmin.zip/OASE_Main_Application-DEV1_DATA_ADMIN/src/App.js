// import axios from "axios";
import React, { useState } from "react";
import BaseDialog from "./components/dialog/BaseDialog";
import AppRouter from "./router/AppRouter";
// import { getToken, renewToken } from "./token/action";
// import { getVPNUrl } from './utilities/Vpn';
import { initInterceptors as initAxiosInterceptors } from "./utilities/AxiosInstance";

function App() {
  const [openDialog, setOpenDialog] = useState(false);
  const [openProgress, setOpenProgress] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  initAxiosInterceptors(setOpenDialog, setOpenProgress, setErrorMessage);

  // axios.defaults.baseURL = getVPNUrl();
  // axios.interceptors.request.use(
  //   function (config) {
  //     if (config.url.match("api/dashboard/count") === null && config.url.match("api/usersession/refresh-token") === null) {
  //       setOpenProgress(true)
  //     }
  //     const token = getToken();
  //     config.url = getVPNUrl() + config.url
  //     config.headers.authorization = `Bearer ${token}`;

  //     return config;
  //   },
  //   function (error) {
  //     return Promise.reject(error);
  //   }
  // );

  // axios.interceptors.response.use(
  //   function (response) {
  //     setTimeout(async () => {
  //       setOpenProgress(false)
  //     }, 2000)

  //     return response;
  //   },
  //   function (error) {
  //     const errorMessage = error.response?.data?.error_message;
  //     const responseStatusCode = error.response?.status;

  //     setTimeout(async () => {
  //       setOpenProgress(false)
  //     }, 2000);

  //     if (error && error.message === 'Network Error' && error.response === undefined) {
  //       setErrorMessage("Mohon maaf, koneksi Anda terputus. Silahkan coba beberapa saat lagi.");
  //       setOpenDialog(true);
  //     }

  //     if (responseStatusCode === 401) {
  //       return renewToken()
  //         .then(res => {
  //           const token = res.data.access_token;

  //           const config = error.config;
  //           config.headers.authorization = `Bearer ${token}`;

  //           return new Promise((resolve, reject) => {
  //             axios.request(config)
  //               .then(res => resolve(res))
  //               .catch(error => reject(error));
  //           });
  //         })
  //         .catch(() => {
  //           localStorage.clear();
  //           window.location.reload();
  //         });
  //     }

  //     if (errorMessage) {
  //       if (errorMessage?.message) {
  //         setErrorMessage(errorMessage.message);
  //       }

  //       if (errorMessage?.indonesia) {
  //         setErrorMessage(errorMessage.indonesia);
  //       }
  //     }
  //     else {
  //       setErrorMessage("Server Error!");
  //     }

  //     if (responseStatusCode === 500 && !error.response.config.url.match("api/usersession/refresh-token")) {
  //       //setErrorMessage(error?.data?.error_message?.indonesia || error?.data?.error_message?.message || errorMessage);
  //       setOpenDialog(true);
  //     }

  //     return Promise.reject(error);
  //   }
  // );

  const handleClose = () => {
    setOpenDialog(false);
  }

  return (
    <>
      <BaseDialog open={openDialog} title={errorMessage} handleClose={handleClose} type="info" buttonText="OK" />
      <BaseDialog open={openProgress} type="progress" />
      <AppRouter />
    </>
  );
}

export default App;