import { Dialog, DialogTitle } from "@mui/material";
import React from "react";
import Close from "../svgs/Close";

export default function FormDialog({
	isOpen,
	handleToggle,
	title,
	children,
	width = "50%",
}) {
	return (
		<Dialog
			open={isOpen}
			onClose={handleToggle}
			PaperProps={{
				sx: {
					maxWidth: width ? width : "50%",
					height: "full",
				},
			}}
		>
			<DialogTitle
				sx={{
					display: "flex",
					alignItems: "center",
					justifyContent: "space-between",
					fontSize: 18,
					fontWeight: 600,
					color: "#0D5CAB",
				}}
			>
				{title}
				<Close
					aria-label="close"
					onClick={handleToggle}
					sx={{ ml: "auto", cursor: "pointer", fontSize: 16 }}
				/>
			</DialogTitle>
			{children}
		</Dialog>
	);
}
