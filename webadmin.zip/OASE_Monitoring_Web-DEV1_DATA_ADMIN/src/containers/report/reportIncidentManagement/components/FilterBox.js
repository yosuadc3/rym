import Delete from "@mui/icons-material/Delete";
import { Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import AutocompleteFreeSolo from "../../../../components/autocomplete/AutocompleteFreeSolo";
import ButtonCommon from "../../../../components/buttons/ButtonCommon";
import EmptyCard from "../../../../components/cards/EmptyCard";
import DateRangePicker from "../../../../components/dateTimePicker/DateRangePicker";
import BasicSelect from "../../../../components/form/BasicSelect";
import { dateAdd, dateSubtract } from "../../../../utilities/DateManipulator";
import {
	DATE_OBJ,
	FILTER_OBJ,
	filterBoxStyles,
} from "../constants/ReportIncidentManagement";

function FilterCategoryComponent({
	id,
	categories,
	options,
	handleSelectCategory,
	handleSelectValues,
	handleDelete,
	selectedCategory,
	selectedValues,
	freeSolo,
	isDisabled = false,
}) {
	return (
		<Grid key={id} container marginBottom={1} paddingRight={1}>
			<Grid item xs={id === 0 ? 6 : 5.5}>
				<BasicSelect
					items={categories}
					onChange={(e) => handleSelectCategory(e, id)}
					value={selectedCategory}
					useSmallSize
					disabled={isDisabled}
				/>
			</Grid>
			<Grid item xs={id === 0 ? 6 : 5.5} paddingLeft={1}>
				<AutocompleteFreeSolo
					onChange={(_, values) => handleSelectValues(values, id)}
					options={options}
					value={selectedValues}
					freeSolo={freeSolo}
					useSmallSize
					disabled={isDisabled}
				/>
			</Grid>
			{id === 0 ? null : (
				<Grid item alignSelf={"center"} textAlign={"center"} xs={1}>
					<ButtonCommon
						handleClick={() => handleDelete(id)}
						label={<Delete sx={{ color: "#8D8D8D" }} />}
						variant={"text"}
						sx={filterBoxStyles.btnDeleteSelect}
						disabled={isDisabled}
					/>
				</Grid>
			)}
		</Grid>
	);
}

export default function ReportFilter({
	categories,
	values,
	freeSolo,
	handleHasSearch,
	getter,
	date,
	filter,
	disabled,
	setDate,
	setFilter,
}) {
	const [hasErrorDate, sethasErrorDate] = useState(DATE_OBJ);
	const [SelectCategoryComponents, setSelectCategoryComponents] = useState([]);

	const isErrorDate = hasErrorDate.start !== null || hasErrorDate.end !== null;
	const isDisabledByFilter = date.start === null || date.end === null || isErrorDate;

	const handleSelectCategory = (event, index) => {
		const { value } = event.target;
		const selected = {
			...FILTER_OBJ,
			category: value,
		};

		setFilter((prev) => Object.assign([...prev], { [index]: selected }));
	};

	const handleSelectValues = (values, index) => {
		const selected = {
			...filter[index],
			values: values,
		};

		setFilter((prev) => Object.assign([...prev], { [index]: selected }));
	};

	const handleDelete = (index) => {
		const temp = [...filter];
		temp.splice(index, 1);
		setFilter(temp);
	};

	const handleAddSearchCategory = () => {
		setFilter((prev) => [...prev, FILTER_OBJ]);
	};

	const handleButtonSearch = () => {
		getter();
		handleHasSearch();
	};

	const handleResetFilter = () => {
		setDate(DATE_OBJ);
		setFilter([FILTER_OBJ]);
	};

	const handleDateError = (error, target) => {
		if (target === "start") {
			sethasErrorDate((prev) => ({ ...prev, start: error }));
		}

		if (target === "end") {
			sethasErrorDate((prev) => ({ ...prev, end: error }));
		}
	};

	useEffect(() => {
		const selectedCategories = filter.map((item) => item.category);
		const components = filter.map((item, index) => {
			const toBeRemoved = selectedCategories.filter(
				(category) => category !== item.category
			);
			const categoryList = categories.filter(
				(x) => !toBeRemoved.includes(x.id)
			);
			const selectedCategory = item?.category;
			const selectedValues = item?.values;

			return FilterCategoryComponent({
				id: index,
				categories: categoryList,
				handleSelectCategory,
				handleSelectValues,
				handleDelete,
				selectedCategory,
				selectedValues,
				freeSolo,
				isDisabled: isDisabledByFilter || disabled,
			});
		});

		setSelectCategoryComponents(components);
	}, [filter, values, isDisabledByFilter, isErrorDate, disabled]);

	return (
		<EmptyCard sx={{ padding: 2, marginTop: 2 }}>
			<Grid container direction="column" textAlign="left" spacing={3}>
				<Grid item>
					<Grid container direction="column" spacing={1}>
						<Grid item>
							<Typography sx={filterBoxStyles.label}>Periode</Typography>
						</Grid>
						<Grid item>
							<DateRangePicker
								date={date}
								setDate={setDate}
								disabled={disabled}
								handleDateError={handleDateError}
								minDate={date.end ? dateSubtract(29, "days", date.end) : null}
								maxDate={dateAdd(29, "days", date.start)}
							/>
						</Grid>
					</Grid>
				</Grid>
				<Grid item>
					<Grid container direction="column" spacing={1}>
						<Grid item>
							<Typography sx={filterBoxStyles.label}>
								Kategori (optional)
							</Typography>
						</Grid>
						<Grid item>{SelectCategoryComponents}</Grid>
					</Grid>
				</Grid>
				{filter.length < categories.length ? (
					<Grid item marginTop={-3}>
						<button
							disabled={isDisabledByFilter || disabled}
							onClick={handleAddSearchCategory}
							style={filterBoxStyles.btnAddSearchCategory}
						>
							Tambah kategori pencarian
						</button>
					</Grid>
				) : null}
				<Grid item>
					<Grid container justifyContent="right">
						<Grid item alignSelf="center">
							<ButtonCommon
								label="Reset Filter"
								disabled={disabled}
								handleClick={handleResetFilter}
								variant="text"
								sx={filterBoxStyles.btnResetFilter}
							/>
						</Grid>
						<Grid item>
							<ButtonCommon
								label="Search"
								disabled={isDisabledByFilter || disabled}
								handleClick={handleButtonSearch}
								sx={filterBoxStyles.btnSearch}
							/>
						</Grid>
					</Grid>
				</Grid>
			</Grid>
		</EmptyCard>
	);
}
