const lostCommConstant = require("../constants/lostComm.constant");
const dbExec = require("../databases/gasper.database").exec;

function get() {
  const query = `Select alias3 as PENGELOLA, Count(gasper_object_id) as JUMLAH 
        from vw_open_ticket_details where action_code_key in (${lostCommConstant.LOST_COMMUNICATION_ACTION_CODE_KEY})
        group by alias3
        order by alias3`;

  return dbExec(query);
}

function getReport() {
  const query = `select g.id as WSID, g.address as Lokasi, g.address2 as Lokasi2, ins.description as Pengelola, g.city as KOTA,
        g.state as PROVINSI, z.description as  Jabo_NonJabo,ot.description as Tipe_Mesin,
        substr(dl.description,1,4) as Data_Line,
        g.alias3 as Provider,
        LTRIM(to_char(FLOOR(OPERATION_HOUR_start1/60),'00'))||':'||LTRIM(to_char(MOD
        (OPERATION_HOUR_start1,60),'00'))||' - '||LTRIM(to_char(FLOOR
        (OPERATION_HOUR_end1/60),'00'))||':'||LTRIM(to_char(MOD(OPERATION_HOUR_end1,60),'00')) as jam_operasi,
        C.DESCRIPTION AS status_opr,action_code_key, status_code_desc,
        to_CHAR(Start_date,'mm/dd/yyyy') as tanggal_mulai, 
        to_CHAR(Start_date,'HH24:MI:SS') as jam_mulai
        from vw_open_ticket_details OP 
        join gasper_object g on op.gasper_object_id=g.id
        join institution ins on ins.link = g.institution_link 
        join zone z on g.zone_link=z.link 
        join object_type ot on g.object_type_link=ot.link 
        join data_line dl on g.data_line_link=dl.link 
        join class c on g.class_link=c.link 
        where action_code_key in (${lostCommConstant.LOST_COMMUNICATION_ACTION_CODE_KEY})`;

  return dbExec(query);
}

function getDetail() {
  const query = `select ticket.gasper_object_id as wsid, g.address2 as lokasi, g.city as kota, g.state as provinsi,
    z.description as jabo_nonjabo, ot.description as tipe_mesin, dl.description as data_line, g.alias3 as provider
    from vw_open_ticket_details ticket
    join gasper_object g on ticket.gasper_object_id = g.id
    join zone z on ticket.zone_link = z.link
    join object_type ot on ticket.object_type_link = ot.link
    join data_line dl on ticket.data_line_link = dl.link
    where ticket.action_code_key = ${lostCommConstant.LOST_COMMUNICATION_ACTION_CODE_KEY}`;

  return dbExec(query);
}

function getTotal() {
  const query = `select count(gasper_object_id) as JUMLAH from vw_open_ticket_details
    where action_code_key = ${lostCommConstant.LOST_COMMUNICATION_ACTION_CODE_KEY}`;

  return dbExec(query);
}

module.exports = {
  get,
  getReport,
  getDetail,
  getTotal,
};

export { };

