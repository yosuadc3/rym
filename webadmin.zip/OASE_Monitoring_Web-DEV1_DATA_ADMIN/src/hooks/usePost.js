import { get as getAxios } from "../utilities/AxiosInstance";

const axios = getAxios();
const BASE_URL = process.env.REACT_APP_API_OASE_MONITORING;
const API_VERSION = process.env.REACT_APP_API_VERSION_OASE_MONITORING;
const USE_POST_MSG = {
	ERROR: "Tidak dapat mengirim data!",
};


const usePost = async (url, container) => {
	const endpoint = `${BASE_URL}/${container}/${API_VERSION}/${url}`;

	try {
		const response = await axios.post(endpoint);
		if (response.status === 200) {
			return "Berhasil!";
		}
	} catch (err) {
		err.message = USE_POST_MSG.ERROR;
		return err;
	}
};

export default usePost;
