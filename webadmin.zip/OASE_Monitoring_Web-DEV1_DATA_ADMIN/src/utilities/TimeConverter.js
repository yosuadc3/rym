import moment from "moment";

export const MSSQLTimeFormat = (date) => {
	return moment(date).format("MM/DD/YYYY");
};

export const customFormat = (date, format = "YYYY-MM-DD") => {
	return moment(date).format(format);
};

export const mySQLTimeFormat = (date) => {
	return moment(date).format("YYYY-MM-DD");
};

export const UTCTimeFormat = (date) => {
	const convertDate = moment(date).utc().local().format("DD/MM/YYYY HH:mm");
	return convertDate === "Invalid date" ? "-" : convertDate;
};

export const readableTimeFormat = (YRS, MNTS, DYS, HRS, MINS, SECS) => {
	let dateText = "";
	const TIME_FORMAT = [
		{
			value: YRS,
			type: "year",
		},
		{
			value: MNTS,
			type: "month",
		},
		{
			value: DYS,
			type: "day",
		},
		{
			value: HRS,
			type: "hour",
		},
		{
			value: MINS,
			type: "minute",
		},
		// {
		//   type: SECS,
		//   value: "seconds",
		// },
	];
	TIME_FORMAT.forEach(
		({ value, type }, i) =>
			(dateText += value ? `${value} ${type}${value === 1 ? "" : "s"} ` : "")
	);
	const formattedDateText = dateText.trim();
	return formattedDateText === "" ? "Just now!" : formattedDateText;
};
