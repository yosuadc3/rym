import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   insertOpen: false,
   updateOpen: false,
   removeOpen: false,
   refresh : false,
   data : {id:"",rule:"",priority: -1,action: "",email_action: "",fault_category:"",reopen_limit: -1}
}

const eventCodeRulesSlice = createSlice({
   name: "eventCodeRules",
   initialState: initialState,
   reducers: {
      handleInsertRules: (state) => {
         state.insertOpen = !state.insertOpen;
      },
      handleUpdateRules: (state) => {
        state.updateOpen = !state.updateOpen;
     },
     handleRemoveRules: (state) => {
        state.removeOpen = !state.removeOpen;
     },
     handleRefresh: (state) => {
        state.refresh = !state.refresh;
     },
     setData: (state,action)=>{
        const { payload } = action;
        state.data =  payload;
     }
     
   }
});

export const { handleInsertRules,handleRefresh, handleRemoveRules, handleUpdateRules,setData } = eventCodeRulesSlice.actions;

export default eventCodeRulesSlice;
