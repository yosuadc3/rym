import { createSlice } from "@reduxjs/toolkit";

const initialState = {
   insertOpen: false,
   updateOpen: false,
   removeOpen: false,
   refresh : false,
   data : {id:"",category:"",priority:-1,color:""}
}

const faultCategorySlice = createSlice({
   name: "faultCategory",
   initialState: initialState,
   reducers: {
      handleInsertFaultCategory: (state) => {
         state.insertOpen = !state.insertOpen;
      },
      handleUpdateFaultCategory: (state) => {
        state.updateOpen = !state.updateOpen;
     },
     handleRemoveFaultCategory: (state) => {
        state.removeOpen = !state.removeOpen;
     },
     handleRefresh: (state) => {
        state.refresh = !state.refresh;
     },
     setData: (state,action)=>{
        const { payload } = action;
        state.data =  payload;
     }
     
   }
});

export const { handleInsertFaultCategory,handleRefresh, handleRemoveFaultCategory, handleUpdateFaultCategory,setData } = faultCategorySlice.actions;

export default faultCategorySlice;
