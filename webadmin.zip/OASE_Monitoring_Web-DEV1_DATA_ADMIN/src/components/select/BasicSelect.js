import { FormControl, MenuItem, Select } from "@mui/material";
import React from "react";

const styles = {
    selectMenu: {
        PaperProps: {
            style: {
                maxHeight: 300,
                // width: 200
            }
        }
    },
    menuItem: {
        "&.Mui-selected": {
            display: "none"
        }
    }
}

export default function BasicSelect({ items, onChange, value = "", disabled = false }) {
    return (
        <FormControl fullWidth>
            <Select
                disabled={disabled}
                onChange={onChange}
                value={value}
                MenuProps={styles.selectMenu}
                sx={{
                    backgroundColor: disabled ? "#C4C4C4" : "#FFFFFF"
                }}
            >
                {
                    items.map((item, index) => {
                        return (
                            <MenuItem key={index} value={item.id} sx={styles.menuItem}>{item.label}</MenuItem>
                        );
                    })
                }
            </Select>
        </FormControl>
    );
}
