import { Response } from "express";
import * as incidentRepo from "../../repositories/incident.repository";
import {
	IGetIncidentCategoryRequest,
	IGetIncidentCommentsRequest,
	IGetIncidentCurrentRequest,
	IGetIncidentHistoryRequest,
	IGetIncidentIDRequest,
	IGetIncidentReportInfoRequest,
	IGetIncidentReportRequest,
	IGetTerminalCurrentStatusRequest,
	IGetTerminalDetailsRequest,
	IPostIncidentCommentRequest
} from "../../types/incident/incident.type";
import addPayloadToRequestHeader from "../../utils/addPayloadToRequestHeader.util";
import * as timeFormatter from "../../utils/dateTime.util";
import * as jsonMessage from "../../utils/jsonMessage.util";
import { getOperationalDaysByInitial } from "../../utils/operationalDays.util";
import * as visionHelper from "../../utils/visionHelper.util";
import { handleAdvancedSearch, handleHistoryAdvancedSearch, handleProcessIncidentCurrent, handleProcessTerminalDetails, paginate } from "./helper.incident";

interface IData {
	[key: string | number]: (string | number)
}

interface IFaultCategory {
	[key: string]: string
}

/**
 * Get all fault category oldest, average and recent durations
 */
export const getIncidentCategory = async (
	req: IGetIncidentCategoryRequest,
	res: Response
) => {
	const all = req.query?.all;
	const ticket_id = req.query?.ticket_id;
	const wsid = req.query?.wsid;
	const status_code = req.query?.status_code;
	const start_time = req.query?.start_time;
	const end_time = req.query?.end_time;
	const lok = req.query?.lok;
	const lokasi = req.query?.lokasi;
	const tipe_mesin = req.query?.tipe_mesin;
	const vendor_mesin = req.query?.vendor_mesin;
	const duration = req.query?.duration;
	const status_code_description = req.query?.status_code_description;
	const last_comment = req.query?.last_comment;
	const startDate = req.query?.startDate;
	const endDate = req.query?.endDate;

	const { terminal_assignment_criteria: terminalAssignmentCriteria, terminal_assignment: terminalAssigment } = req.kauth?.grant?.access_token?.content || "";

	addPayloadToRequestHeader(req);


	let allFaultCategory: IFaultCategory[] = await incidentRepo.getAllFaultCategory();
	let data: IData[] = await incidentRepo.getIncidentCategory(
		startDate,
		endDate,
		terminalAssignmentCriteria,
		terminalAssigment
	);

	let totalActiveTerminal = 0;
	let [{ total_wsid_in_service: totalInService }] = await incidentRepo.getCountTerminalInService(terminalAssignmentCriteria, terminalAssigment, { ...req.query });

	if (data) {
		data.forEach((item) => {
			item["start_time"] = timeFormatter.UTCTimeFormat(String(item["start_time"]));
			item["duration"] = timeFormatter.secondsToReadableFormat(
				Number(item["age_seconds"])
			);
			Object.keys(item).forEach(
				(key) => (item[key] = item[key] === null ? "-" : item[key])
			);
		});

		const store = handleAdvancedSearch(
			data,
			all,
			ticket_id,
			wsid,
			lok,
			lokasi,
			tipe_mesin,
			vendor_mesin,
			status_code,
			start_time,
			end_time,
			duration,
			status_code_description,
			last_comment
		);

		if (
			ticket_id ||
			wsid ||
			lokasi ||
			status_code ||
			duration ||
			status_code_description ||
			all ||
			start_time ||
			last_comment
		) {
			data = store;
		}
	}

	// Mengambil seluruh kategori
	const allCategory = [...new Set(data.map((item) => item.category))];
	let categorizeTickets: { [key: string]: IData[] } = {};

	// Memuat setiap category sebagai key pada categorizeTickets
	allCategory.forEach((category) => (categorizeTickets[category] = []));
	// Menambahkan setiap ticket kedalam categorynya masing-masing
	data.forEach((item) => categorizeTickets[item.category].push(item));

	// Preprocessing setiap data tiket
	Object.keys(categorizeTickets).forEach((item) =>
		categorizeTickets[item].forEach((ticket) => {
			delete ticket.category;
		})
	);

	const faultCategories: { [key: (string)]: { [key: (string)]: (string | number) } } = {}

	// calculate each category to seconds
	Object.keys(categorizeTickets).forEach((category) => {
		let totalSeconds = 0,
			oldestIncident = Number.MIN_SAFE_INTEGER,
			recentIncident = Number.MAX_SAFE_INTEGER;
		categorizeTickets[category].forEach((ticket) => {
			const { age_seconds } = ticket;
			totalSeconds += +age_seconds;
			oldestIncident = Math.max(+age_seconds, oldestIncident);
			recentIncident = Math.min(+age_seconds, recentIncident);
		});
		const averageIncident = Math.floor(
			totalSeconds / categorizeTickets[category].length
		);
		faultCategories[category] = {
			"Oldest Incident":
				timeFormatter.secondsToReadableFormat(oldestIncident),
			"Recent Incident":
				timeFormatter.secondsToReadableFormat(recentIncident),
			"Average Incident":
				timeFormatter.secondsToReadableFormat(averageIncident),
			total: categorizeTickets[category].length,
		};
	});

	const hasWSID = Object.keys(req.query).includes('wsid');
	const hasAll = Object.keys(req.query).includes('all');
	const hasLokasi = Object.keys(req.query).includes('lokasi');
	const hasParams = Object.keys(req.query).length > 0;

	const includeInService = (hasWSID || hasAll || hasLokasi) || !hasParams;

	const listFaultCategory = allFaultCategory.reduce(
		(item: { [key: string | number]: IData }, curr) => {
			let obj: IData = {
				"Oldest Incident": "-",
				"Recent Incident": "-",
				"Average Incident": "-",
				total: 0,
				color: curr.faultCategoryColor,
			};

			if (faultCategories[curr.category]) {
				obj = {
					...faultCategories[curr.category],
					color: curr.faultCategoryColor,
				};
			} else if (curr.category.toLowerCase() === "In Service".toLowerCase()) {
				if (includeInService) {
					obj = {
						...obj,
						total: totalInService,
					};
				} else {
					obj = {
						...obj,
						total: 0,
					};
				}
			}
			totalActiveTerminal = totalActiveTerminal + Number(obj.total);
			item[curr.category] = obj;
			return item;
		},
		{}
	);

	const payload = {
		lastUpdate: timeFormatter.getCurrent(),
		totalActiveTerminal: totalActiveTerminal,
		data: {
			faultCategory: listFaultCategory,
		},
	};

	const message = {
		english: `Successfully Retrieved Fault Category Data`,
		indonesia: `Berhasil Mengambil Data Fault Category`,
	};

	res.send(jsonMessage.jsonSuccess(message, payload));
};

/**
 * Get tickets for each category
 */
export const getIncidentID = async (
	req: IGetIncidentIDRequest,
	res: Response
) => {
	const category = req.query?.category;
	const page = req.query?.page;
	const limit = req.query?.limit;
	const sortBy = req.query?.sortBy;
	const orderBy = req.query?.orderBy;
	const all = req.query?.all;
	const ticket_id = req.query?.ticket_id;
	const wsid = req.query?.wsid;
	const lok = req.query?.lok;
	const lokasi = req.query?.lokasi;
	const tipe_mesin = req.query?.tipe_mesin;
	const vendor_mesin = req.query?.vendor_mesin;
	const status_code = req.query?.status_code;
	const start_time = req.query?.start_time;
	const end_time = req.query?.end_time;
	const duration = req.query?.duration;
	const status_code_description = req.query?.status_code_description;
	const last_comment = req.query?.last_comment;
	const startDate = req.query?.startDate;
	const endDate = req.query?.endDate;

	const { terminal_assignment_criteria: terminalAssignmentCriteria, terminal_assignment: terminalAssigment } = req.kauth?.grant?.access_token?.content || "";

	addPayloadToRequestHeader(req);

	if (page && limit && sortBy && orderBy && category) {
		let data: IData[] = await incidentRepo.getIncidentID(
			category,
			page,
			limit,
			sortBy,
			orderBy,
			startDate,
			endDate,
			terminalAssignmentCriteria,
			terminalAssigment
		);
		let isUsingAdvSearch = false;

		if (data) {
			data.forEach((item) => {
				Object.keys(item).forEach(
					(key) => (item[key] = item[key] === null ? "-" : item[key])
				);
				item["start_time"] = timeFormatter.UTCTimeFormat(String(item["start_time"]));
				item["duration"] = timeFormatter.secondsToReadableFormat(
					Number(item["age_seconds"])
				);
				delete item["age_seconds"];
				delete item["rn"];
			});

			const store = handleAdvancedSearch(
				data,
				all,
				ticket_id,
				wsid,
				lok,
				lokasi,
				tipe_mesin,
				vendor_mesin,
				status_code,
				start_time,
				end_time,
				duration,
				status_code_description,
				last_comment
			);

			if (
				ticket_id ||
				wsid ||
				lokasi ||
				status_code ||
				duration ||
				status_code_description ||
				all ||
				start_time ||
				last_comment
			) {
				data = paginate(store, +page, +limit);
				isUsingAdvSearch = true;
			}
		}

		if (!isUsingAdvSearch) {
			data = paginate(data, +page, +limit);
		}

		const hasWSID = Object.keys(req.query).includes('wsid');
		const hasAll = Object.keys(req.query).includes('all');
		const hasLokasi = Object.keys(req.query).includes('lokasi');
		const hasParams = Object.keys(req.query).length > 5;

		const includeInService = (hasWSID || hasAll || hasLokasi) || !hasParams;

		const isInService = category === "In Service";

		let result = {};

		if ((isInService && includeInService) || !isInService) {
			result = {
				lastUpdate: timeFormatter.getCurrent(),
				tickets: data
			};
		}
		else {
			result = {
				lastUpdate: timeFormatter.getCurrent(),
				tickets: []
			};
		}

		const message = {
			english: `Successfully Retrieved Fault Category Data`,
			indonesia: `Berhasil Mengambil Data Fault Category`,
		};

		res.send(jsonMessage.jsonSuccess(message, result));
	}
};

/**
 * Get Current Incident details for Incident Detail page
 */
export const getIncidentCurrent = async (
	req: IGetIncidentCurrentRequest,
	res: Response
) => {
	const { terminal_assignment_criteria: terminalAssignmentCriteria, terminal_assignment: terminalAssigment } = req.kauth?.grant?.access_token?.content || "";

	addPayloadToRequestHeader(req);

	const ticketId = req.query?.ticketId;
	const wsid = req.query?.wsid;

	if (ticketId === "-") {
		const message = {
			english: `Successfully Retrieved Incident Current Data`,
			indonesia: `Berhasil Mengambil Data Incident Current`,
		};

		const data = await incidentRepo.getTerminalDetails(wsid, terminalAssignmentCriteria, terminalAssigment);

		// klo misalnya tidak ada gimana?

		const response = {
			wsid: data[0]['WSID'],
			_wsid: data[0]['_wsid'],
			currentDetails: {
				"Status Code": "-",
				Component: "-",
				Detail: "-",
				"Start Time": "-",
				"End Time": "-",
				"Created By": "-",
			},
		};

		res.send(jsonMessage.jsonSuccess(message, response));
		return;
	}

	let ticketIdData = await incidentRepo.getIncidentCurrent(
		ticketId,
		terminalAssignmentCriteria,
		terminalAssigment
	);

	const data = handleProcessIncidentCurrent(ticketIdData);

	const message = {
		english: `Successfully Retrieved Incident Current Data`,
		indonesia: `Berhasil Mengambil Data Incident Current`,
	};

	res.send(jsonMessage.jsonSuccess(message, data));
};

/**
 * Get Terminal Details for Incident Management Detail
 */
export const getTerminalDetails = async (
	req: IGetTerminalDetailsRequest,
	res: Response
) => {
	const wsid = req.query?.wsid;
	// if (wsid) wsid = decrypt(wsid);
	const ticketId = req.query?.ticketId;
	// if (ticketId) ticketId = decrypt(ticketId);

	addPayloadToRequestHeader(req);

	if (wsid) {
		const { terminal_assignment_criteria: terminalAssignmentCriteria, terminal_assignment: terminalAssigment } = req.kauth?.grant?.access_token?.content || "";

		let data = await incidentRepo.getTerminalDetails(wsid, terminalAssignmentCriteria, terminalAssigment);

		if (!data.length) {
			const message = {
				english: `WSID ${wsid} does not exist!`,
				indonesia: `Tidak ditemukan WSID ${wsid}`,
			};

			const response = {
				"terminalDetails": {
					"locationGroup": {
						"WSID": "-",
						"Location 1": "-",
						"Location 2": "-",
						"State/Country": "-",
						"City": "-",
						"ZIP": "-",
						"Operational Hour": "-",
						"Area": "-",
						"Branch": "-",
						"District": "-",
						"Institution": "-",
						"Latitude": "-",
						"Longitude": "-",
						"Region": "-"
					},
					"machineGroup": {
						"Manufacturer": "-",
						"Tipe Mesin": "-",
						"Serial Number": "-",
						"Vendor Mesin": "-",
						"Cassette Out Table": "-",
						"Jumlah Kaset": "-"
					},
					"networkGroup": {
						"IP Address": "-",
						"INIDIU": "-"
					},
					"status": "-",
					"lastUpdate": "-"
				}
			}

			res.send(jsonMessage.jsonSuccess(message, response));
			return;
		}

		data = handleProcessTerminalDetails(data);
		let { terminalDetails } = data;
		const operationalHour = `${getOperationalDaysByInitial(terminalDetails["Operational Days"])} ${terminalDetails["Operational Hour"]}`
		const locationGroup = {
			WSID: terminalDetails["WSID"],
			"Location 1": terminalDetails["Location 1"],
			"Location 2": terminalDetails["Location 2"],
			"State/Country": terminalDetails["State/Country"],
			City: terminalDetails["City"],
			ZIP: terminalDetails["ZIP"],
			"Operational Hour": operationalHour === "- -" ? "-" : operationalHour,
			Area: terminalDetails["Area"],
			Branch: terminalDetails["Branch"],
			District: terminalDetails["District"],
			Institution: terminalDetails["Institution"],
			Latitude: terminalDetails["Latitude"],
			Longitude: terminalDetails["Longitude"],
			Region: terminalDetails["Region"],
		};

		// Machine Group
		const machineGroup = {
			Manufacturer: terminalDetails["Manufacturer"],
			"Tipe Mesin": terminalDetails["Tipe Mesin"],
			"Serial Number": terminalDetails["Serial Number"],
			"Vendor Mesin": terminalDetails["Vendor Mesin"],
			"Cassette Out Table": terminalDetails["Cassette Out Table"],
			"Jumlah Kaset": terminalDetails["Jumlah Kaset"],
		};

		// Network Group
		const networkGroup = {
			"IP Address": terminalDetails["IP Address"],
			INIDIU: terminalDetails["INIDIU"],
		};

		let isExist = "-";

		if (ticketId) {
			let getStatus = await incidentRepo.getTerminalStatus(ticketId);
			if (getStatus && getStatus[0] && getStatus[0].category)
				isExist = getStatus[0].category;
		}

		data.terminalDetails = {
			locationGroup,
			machineGroup,
			networkGroup,
			status: isExist,
			lastUpdate: timeFormatter.getCurrent(),
		};

		const message = {
			english: `Successfully Retrieved Terminal Detail's Data`,
			indonesia: `Berhasil Mengambil Data Terminal`,
		};

		res.send(jsonMessage.jsonSuccess(message, data));
	}
};

export const getTerminalCurrentStatus = async (
	req: IGetTerminalCurrentStatusRequest,
	res: Response
) => {
	const ticketId = req.query.ticketId;
	// if (ticketId) ticketId = decrypt(ticketId);

	addPayloadToRequestHeader(req);

	if (ticketId) {
		const data = await incidentRepo.getTerminalCurrentStatus(ticketId);
		const message = {
			indonesia: "Berhasil mengambil status terminal",
			english: "Successfully retrived terminal status",
		};

		try {
			const status = data[0].FAULT_CATEGORY;

			const response = {
				status,
			};

			// console.log(jsonMessage.jsonSuccess(message, response));

			res.send(jsonMessage.jsonSuccess(message, response));
			return;
		} catch (e) {
			// check if wsid exists from database
			const hasWSID = await incidentRepo.getHasWSID(ticketId);
			const [wsid] = hasWSID;
			if (wsid.count === 0) {
				const response = {
					status: "-",
				};
				res.send(jsonMessage.jsonSuccess(message, response));
				return;
			}

			const response = {
				status: "In Service",
			};
			res.send(jsonMessage.jsonSuccess(message, response));
			return;
		}
	}
};

/**
 * Get Incident History details for Incident Detail page
 */
export const getIncidentHistory = async (
	req: IGetIncidentHistoryRequest,
	res: Response
) => {
	const wsid = req.query?.wsid;
	const page = req.query?.page;
	const limit = req.query?.limit;
	const sortBy = req.query?.sortBy;
	const orderBy = req.query?.orderBy;
	const status_code = req.query?.status_code;
	const all = req.query?.all;
	const ticket_id = req.query?.ticket_id;
	const action_code = req.query?.action_code;
	const action_code_description = req.query?.action_code_description;
	const start_time = req.query?.start_time;
	const end_time = req.query?.end_time;
	const status_code_description = req.query?.status_code_description;
	const last_comment = req.query?.last_comment;
	const startDate = req.query?.startDate;
	const endDate = req.query?.endDate;

	const obj = { message: "Page or limit is not defined" };

	const { terminal_assignment_criteria: terminalAssignmentCriteria, terminal_assignment: terminalAssigment } =
		req.kauth?.grant?.access_token?.content || "";

	addPayloadToRequestHeader(req);

	if (page && limit && sortBy && orderBy) {
		let terminalIncidentHistory;
		const getTotal = await incidentRepo.getTotalIncidentHistory(
			wsid,
			terminalAssignmentCriteria,
			terminalAssigment
		);
		let { total } = getTotal[0];

		if (
			all ||
			ticket_id ||
			start_time ||
			end_time ||
			action_code ||
			action_code_description ||
			status_code ||
			status_code_description ||
			startDate ||
			endDate ||
			last_comment
		) {
			terminalIncidentHistory = await incidentRepo.getIncidentHistory(
				wsid,
				0,
				total,
				sortBy,
				orderBy,
				terminalAssignmentCriteria,
				terminalAssigment
			);
			// Set start_time and end time to UTC time format
			terminalIncidentHistory.forEach((item: any) => {
				item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
				item["end_time"] = timeFormatter.UTCTimeFormat(item["end_time"]);
				delete item["rn"];
				Object.keys(item).forEach(
					(key) => (item[key] = item[key] === null ? "-" : item[key])
				);
			});

			const data = handleHistoryAdvancedSearch(
				terminalIncidentHistory,
				all,
				ticket_id,
				start_time,
				end_time,
				action_code,
				action_code_description,
				status_code,
				status_code_description,
				last_comment
			);
			total = data.length;
			terminalIncidentHistory = paginate(data, +page, +limit);
		} else {
			terminalIncidentHistory = await incidentRepo.getIncidentHistory(
				wsid,
				page,
				limit,
				sortBy,
				orderBy,
				terminalAssignmentCriteria,
				terminalAssigment
			);
			// Set start_time and end time to UTC time format
			terminalIncidentHistory.forEach((item: any) => {
				item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
				item["end_time"] = timeFormatter.UTCTimeFormat(item["end_time"]);
				delete item["rn"];
				Object.keys(item).forEach(
					(key) => (item[key] = item[key] === null ? "-" : item[key])
				);
			});

		}

		if (!terminalIncidentHistory && !terminalIncidentHistory.length) {
			const message = {
				english: `Data history does not exist!`,
				indonesia: `Tidak ditemukan riwayat!`,
			};

			res.send(jsonMessage.jsonSuccess(message, {}));
			return;
		}


		const data = {
			total,
			rows: terminalIncidentHistory,
		};

		const message = {
			english: `Successfully Retrieved Incident History Data`,
			indonesia: `Berhasil Mengambil Data Incident History`,
		};

		res.send(jsonMessage.jsonSuccess(message, data));
	}
};

export const postIncidentComment = async (
	req: IPostIncidentCommentRequest,
	res: Response
) => {
	const incidentId = req.query?.incident_id;
	let commentText = req.query?.comment_text;

	const name =
		req.kauth.grant.access_token.content.preferred_username || null;
	req.name = name;
	commentText = name + " ~ " + commentText;

	// Get token
	let visionToken = await visionHelper.getToken(name);

	const getIncidentNumber = await incidentRepo.getIncidentNumber(incidentId);
	const incidentNumber = getIncidentNumber[0].ticket_key;

	// Post comment
	// await visionHelper.//devtriton01.dti.co.id/incident-service/incidentManagement/incidents/66782/locks
	await visionHelper.postComment(
		visionToken,
		commentText,
		incidentNumber,
		name
	);

	const message = {
		english: `Successfully inserted a new comment!`,
		indonesia: `Berhasil menambahkan komentar baru!`,
	};

	res.send(jsonMessage.jsonSuccess(message));
};

export const getIncidentComments = async (
	req: IGetIncidentCommentsRequest,
	res: Response
) => {
	const incidentId = req.query?.incidentId;

	const name =
		req.kauth.grant.access_token.content.preferred_username || null;
	req.name = name;

	if (incidentId) {
		const incidentComments = await incidentRepo.getIncidentComments(
			incidentId
		);
		incidentComments.forEach((comment: any, idx: number) => {
			comment["id"] = idx;
			comment["created_date"] = timeFormatter.UTCTimeFormat(
				comment["created_date"]
			);
			comment["created_by"] = comment.created_by_oase
				? comment.created_by_oase
				: comment.created_by;
		});

		const message = {
			english: `Successfully Retrieved Incident History Data`,
			indonesia: `Berhasil Mengambil Data Incident History`,
		};

		const data = {
			rows: incidentComments,
		};

		res.send(jsonMessage.jsonSuccess(message, data));
	}
};

/** Report */
export const getIncidentReport = async (
	req: IGetIncidentReportRequest,
	res: Response
) => {
	const all = req.query?.all;
	const ticket_id = req.query?.ticket_id;
	const wsid = req.query?.wsid;
	const lok = req.query?.lok;
	const lokasi = req.query?.lokasi;
	const tipe_mesin = req.query?.tipe_mesin;
	const vendor_mesin = req.query?.vendor_mesin;
	const status_code = req.query?.status_code;
	const start_time = req.query?.start_time;
	const end_time = req.query?.end_time;
	const duration = req.query?.duration;
	const status_code_description = req.query?.status_code_description;
	const last_comment = req.query?.last_comment;

	const startDate = req.query?.startDate;
	const endDate = req.query?.endDate;

	addPayloadToRequestHeader(req);

	const { terminal_assignment_criteria: terminalAssignmentCriteria, terminal_assignment: terminalAssigment } =
		req.kauth?.grant?.access_token?.content || "";

	let data: IData[] = await incidentRepo.getIncidentReport(
		startDate,
		endDate,
		terminalAssignmentCriteria,
		terminalAssigment
	);

	data.forEach((item) => {
		Object.keys(item).forEach((key) => {
			item[key] = item[key] === null ? "-" : item[key];
		});
		item["start_time"] = timeFormatter.UTCTimeFormat(String(item["start_time"]));
		item["end_time"] = timeFormatter.UTCTimeFormat(String(item["end_time"]));
		item["duration"] = timeFormatter.secondsToReadableFormat(
			Number(item["age_seconds"]),
			true
		);
	});

	const store = handleAdvancedSearch(
		data,
		all,
		ticket_id,
		wsid,
		lok,
		lokasi,
		tipe_mesin,
		vendor_mesin,
		status_code,
		start_time,
		end_time,
		duration,
		status_code_description,
		last_comment
	);

	if (
		ticket_id ||
		wsid ||
		lok ||
		lokasi ||
		tipe_mesin ||
		vendor_mesin ||
		status_code ||
		duration ||
		status_code_description ||
		all ||
		start_time ||
		last_comment
	) {
		data = store;
	}

	const rows = data.reduce((acc: object[], item) => {
		acc.push({
			'Incident Number': item['id'],
			'WSID': item['wsid'],
			'Lok': item['lok'],
			'Lokasi': item['lokasi'],
			'Tipe Mesin': item['tipe_mesin'],
			'Vendor Mesin': item['vendor_mesin'],
			'Start Time': item['start_time'],
			'End Time': item['end_time'],
			'Duration': item['duration'],
			'Status Code - Description': item['status_code_description'],
			'Last Comment': item['last_comment']
		})
		return acc
	}, []);

	const message = {
		indonesia: "Berhasil mengambil report incidents",
		english: "Successfully generated an incident report",
	};

	const response = { rows };

	res.send(jsonMessage.jsonSuccess(message, response));
};

export const getIncidentReportPreview = async (
	req: IGetIncidentReportRequest,
	res: Response
) => {
	const all = req.query?.all;
	const ticket_id = req.query?.ticket_id;
	const wsid = req.query?.wsid;
	const lok = req.query?.lok;
	const lokasi = req.query?.lokasi;
	const tipe_mesin = req.query?.tipe_mesin;
	const vendor_mesin = req.query?.vendor_mesin;
	const status_code = req.query?.status_code;
	const start_time = req.query?.start_time;
	const end_time = req.query?.end_time;
	const duration = req.query?.duration;
	const status_code_description = req.query?.status_code_description;
	const last_comment = req.query?.last_comment;

	const startDate = req.query?.startDate;
	const endDate = req.query?.endDate;

	addPayloadToRequestHeader(req);

	const { terminal_assignment_criteria: terminalAssignmentCriteria, terminal_assignment: terminalAssigment } = req.kauth?.grant?.access_token?.content || "";

	let data = await incidentRepo.getIncidentReport(
		startDate,
		endDate,
		terminalAssignmentCriteria,
		terminalAssigment
	);

	data.forEach((item: any) => {
		Object.keys(item).forEach(
			(key) => (item[key] = item[key] === null ? "-" : item[key])
		);
		item["start_time"] = timeFormatter.UTCTimeFormat(item["start_time"]);
		item["end_time"] = timeFormatter.UTCTimeFormat(item["end_time"]);
		item["duration"] = timeFormatter.secondsToReadableFormat(
			item["age_seconds"],
			true
		);
		delete item["age_seconds"];
		delete item["rn"];
	});

	const store = handleAdvancedSearch(
		data,
		all,
		ticket_id,
		wsid,
		lok,
		lokasi,
		tipe_mesin,
		vendor_mesin,
		status_code,
		start_time,
		end_time,
		duration,
		status_code_description,
		last_comment
	);

	if (
		ticket_id ||
		wsid ||
		lok ||
		lokasi ||
		tipe_mesin ||
		vendor_mesin ||
		status_code ||
		duration ||
		status_code_description ||
		all ||
		start_time ||
		last_comment
	) {
		data = store;
	}

	const message = {
		indonesia: "Berhasil mengambil report incidents",
		english: "Successfully generated an incident report",
	};

	// slice data to maximum of 10
	const maxRows = data.slice(0, 10);

	const response = {
		rows: maxRows,
		total: maxRows.length,
	};

	res.send(jsonMessage.jsonSuccess(message, response));
};

export const getIncidentReportInfo = async (
	req: IGetIncidentReportInfoRequest,
	res: Response
) => {
	const all = req.query?.all;
	const ticket_id = req.query?.ticket_id;
	const wsid = req.query?.wsid;
	const lok = req.query?.lok;
	const lokasi = req.query?.lokasi;
	const tipe_mesin = req.query?.tipe_mesin;
	const vendor_mesin = req.query?.vendor_mesin;
	const status_code = req.query?.status_code;
	const start_time = req.query?.start_time;
	const end_time = req.query?.end_time;
	const duration = req.query?.duration;
	const status_code_description = req.query?.status_code_description;
	const last_comment = req.query?.last_comment;

	const startDate = req.query?.startDate;
	const endDate = req.query?.endDate;

	addPayloadToRequestHeader(req);

	const { terminal_assignment_criteria: terminalAssignmentCriteria, terminal_assignment: terminalAssigment } = req.kauth?.grant?.access_token?.content || "";

	let data: IData[] = await incidentRepo.getIncidentReport(
		startDate,
		endDate,
		terminalAssignmentCriteria,
		terminalAssigment
	);

	data.forEach((item) => {
		Object.keys(item).forEach(
			(key) => (item[key] = item[key] === null ? "-" : item[key])
		);
		item["start_time"] = timeFormatter.UTCTimeFormat(String(item["start_time"]));
		item["end_time"] = timeFormatter.UTCTimeFormat(String(item["end_time"]));
		item["duration"] = timeFormatter.secondsToReadableFormat(
			Number(item["age_seconds"]),
			true
		);
		delete item["age_seconds"];
		delete item["rn"];
	});

	const store = handleAdvancedSearch(
		data,
		all,
		ticket_id,
		wsid,
		lok,
		lokasi,
		tipe_mesin,
		vendor_mesin,
		status_code,
		start_time,
		end_time,
		duration,
		status_code_description,
		last_comment
	);

	if (
		ticket_id ||
		wsid ||
		lokasi ||
		lok ||
		tipe_mesin ||
		vendor_mesin ||
		status_code ||
		duration ||
		status_code_description ||
		all ||
		start_time ||
		last_comment
	) {
		data = store;
	}

	const message = {
		indonesia: "Berhasil mengambil data report incident",
		english: "Successfully retrieved incident report info",
	};

	let total = data.length;
	let showTotal = 0;

	if (total >= 10) {
		showTotal = 10;
	} else {
		showTotal = total;
	}

	const response = {
		showTotal,
		total,
	};

	res.send(jsonMessage.jsonSuccess(message, response));
};

export { };

