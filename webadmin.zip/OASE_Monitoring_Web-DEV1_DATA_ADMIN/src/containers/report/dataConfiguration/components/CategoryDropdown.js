import CheckBoxIcon from "@mui/icons-material/CheckBox";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import {
   Autocomplete,
   Box,
   Checkbox,
   ClickAwayListener,
   TextField
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useGetListDataConfigurationQuery } from "../../../../redux/features/report/dataConfiguration/api/dataConfiguration";

const selectAllOption = { id: "select-all", value: "Select all" };
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const styles = {
   autocomplete: {
      background: "#FFFFFF",
      ".MuiAutocomplete-tag": {
         backgroundColor: "#E4F2FF",
         textOverflow: "ellipsis",
         maxWidth: "100px",
         color: "#65748B",
         fontWeight: 500,
      },
      ".MuiAutocomplete-endAdornment, .MuiSvgIcon-root": {
         color: "#65748B",
      }
   },
   arrowDropDown: {
      color: "#156db8",
      fontSize: "2.5rem",
   }
};

export default function CategoryDropdown({ type, onChange }) {
   const params = { type };
   const [skip, setSkip] = useState(true);
   const [prevType, setPrevType] = useState(type);
   const { data = [], isUninitialized, refetch } = useGetListDataConfigurationQuery(params, { skip });

   const [value, setValue] = useState([]);
   const [checkAll, setCheckAll] = useState(false);
   const [open, setOpen] = useState(false);
   const [options, setOptions] = useState([]);

   useEffect(() => {
      if (type) setSkip((_) => false);
      if (type !== prevType) {
         setPrevType((_) => type);

         if (!isUninitialized) refetch();
      }
   }, [type])

   useEffect(() => {
      if (!isUninitialized) {
         setOptions((_) => [selectAllOption, ...data]);
      }
   }, [isUninitialized, data, setOptions])

   const checkAllChange = (event) => {
      const { checked } = event.target;

      setCheckAll((_) => checked);

      if (!checked) {
         setValue((_) => []);
         return;
      }

      setValue((_) => data);
   };

   const handleOnChange = (_, newValue, reason) => {
      const excludeSelectAll = newValue.filter((v) => v.id !== "select-all");

      const reasonObj = {
         "selectOption": () => {
            setValue((_) => excludeSelectAll);
         },
         "removeOption": () => {
            setCheckAll((_) => false);
            setValue((_) => excludeSelectAll);
         },
         "clear": () => {
            setValue((_) => []);
            setCheckAll((_) => false);
         }
      }

      reasonObj[reason]();
   }

   const handleClickAway = (e) => {
      setOpen((_) => false);
   };

   const toggleOpen = () => {
      setOpen((prev) => !prev)
   }

   const getOptionLabel = (option) => option.value;

   const rendererInput = (params) => <TextField {...params} />;

   const getOptionEqualToValue = (option, anotherOption) => option.value === anotherOption.value;

   const rendererOptions = (props, option, { selected }) => {
      const { value } = option;
      const isSelectAll = option.id === "select-all";

      return (
         <li {...props}>
            <Checkbox
               icon={icon}
               checkedIcon={checkedIcon}
               checked={!isSelectAll ? (selected || checkAll) : checkAll}
               onChange={!isSelectAll ? null : checkAllChange}
               sx={{ marginRight: "8px" }}
            />
            {value}
         </li>
      )
   }

   return (
      <ClickAwayListener onClickAway={handleClickAway}>
         <Box>
            <Autocomplete
               multiple
               size="small"
               disableCloseOnSelect
               options={options}
               value={value}
               open={open}
               onOpen={toggleOpen}
               onClose={toggleOpen}
               onChange={handleOnChange}
               getOptionLabel={getOptionLabel}
               isOptionEqualToValue={getOptionEqualToValue}
               renderOption={rendererOptions}
               renderInput={rendererInput}
               sx={styles.autocomplete}
            />
         </Box>
      </ClickAwayListener>
   );
}
