import React, { useState, useEffect, useRef } from "react";
import { Menu, Layout, Button, Divider, Typography, Affix, Badge } from "antd";
import OASELogo from "../svgs/OASELogo";
import { HomeFilled, RightOutlined, DownOutlined } from "@ant-design/icons";
import { getSidenavMenu } from "../../constant/menu";
import { hasRoles } from "../../token/roles";
import "./styles/sidenav.less";
import { vpnRedirect } from "../../utilities/Vpn";
import { axiosGet } from "../../utilities/AxiosHelper";

const { Sider } = Layout;
const { Text, Link } = Typography;

const API_URI = process.env.REACT_APP_API_OASE;

const getCountOutstanding = async () => {
    let temp;
    try {
        temp = await axiosGet(API_URI, "/dashboard/count");
    } catch (e) {
        throw e;
    }
    return temp;
};

function getItem(key, label, icon, link, roles, children, handleCollapsed, count, onTitleClick, isPrimary, handleOpenKeys) {
    label = <div className='sidenav-text-badge'>
        <Text className="menu-label-text">{label}</Text>
        <Badge overflowCount={999} style={{ boxShadow: 'none' }} count={count} />
    </div>

    const menuItems = {
        key,
        icon,
        children,
        label,
    }

    if (onTitleClick) {
        menuItems.onTitleClick = onTitleClick
    }

    if (isPrimary) {
        menuItems.onTitleClick = () => {
            handleCollapsed(false)
            handleOpenKeys([key])
        }
    }

    if (link) {
        menuItems.onClick = () => {
            window.location.assign(vpnRedirect(link));
            handleCollapsed(true);
        }
    }

    if (roles) {
        if (hasRoles(roles)) {
            return menuItems
        }
    }
    else if (roles === null) {
        return menuItems
    }
}

let rootSubMenu = []

function generateMenu(menus, handleCollapsed, index, handleOpenKeys) {
    const mappingMenu = menus.map(menu => {

        if (rootSubMenu[index]) {
            rootSubMenu[index].push(menu.key)
        } else {
            rootSubMenu.push([menu.key])
        }

        return getItem(
            menu.key,
            menu.label,
            menu.icon ? <menu.icon className="icon" /> : null,
            menu.link,
            menu.roles,
            menu.children ? generateMenu(menu.children, handleCollapsed, index + 1) : null,
            handleCollapsed,
            menu.count,
            menu?.onTitleClick,
            menu?.isPrimary,
            handleOpenKeys
        )
    })
    return mappingMenu
}

function Sidenav() {
    const wrapperRef = useRef(null);
    const [collapsed, setCollapsed] = useState(true);
    const [openKeys, setOpenKeys] = useState([]);
    const [countSidenav, setCountSidenav] = useState({})

    const handleCollapsed = (isCollapse) => {
        setCollapsed(isCollapse)
    }

    const handleMenuClick = ({ onClick }) => {
        if (onClick) {
            onClick()
        } else {
            return false
        }
    };

    const handleOpenKeys = (openKeys) => {
        setOpenKeys(openKeys)
    }

    const items = generateMenu(getSidenavMenu(countSidenav?.data), handleCollapsed, 0, handleOpenKeys)

    const toggleCollpased = () => {
        setCollapsed(!collapsed)
    }

    useEffect(() => {
        function handleClickOutside(event) {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
                setCollapsed(true)
            }
        }

        // Bind the event listener
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            // Unbind the event listener on clean up
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [wrapperRef]);


    useEffect(() => {
        const getSidenavApi = async () => {
            const temp = await getCountOutstanding();
            setCountSidenav(temp)
        }
        if (!!collapsed && hasRoles(['DASHBOARD', 'DASHBOARD_ADMIN_WH'])) {
            getSidenavApi()
        }
    }, [collapsed])

    const redirectToHome = () => {
        window.location.assign(vpnRedirect("/#"))
    }

    const onOpenChange = (keys) => {

        const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
        let arr = [];
        let tempArrIndex;

        for (let [index, item] of rootSubMenu.entries()) {
            if (item.indexOf(latestOpenKey) !== -1) {
                tempArrIndex = index;
                arr = item
                break;
            }
        }

        let boolOpenKeys = false
        let element;

        for (let item of arr) {
            if (openKeys.includes(item)) {
                boolOpenKeys = true
                element = item
                break;
            }
        }

        if (arr.indexOf(latestOpenKey) === -1) {
            setOpenKeys(keys);
        } else {
            if (openKeys.indexOf(latestOpenKey) === -1 && !boolOpenKeys) {
                setOpenKeys([...openKeys, latestOpenKey]);
            } else {
                let tempOpenKeys = openKeys;
                if (openKeys.length > tempArrIndex) {
                    tempOpenKeys = openKeys.slice(0, tempArrIndex)
                } else {
                    tempOpenKeys = openKeys.filter(item => item.toLowerCase() !== element.toLowerCase())
                }
                setOpenKeys(latestOpenKey ? [...tempOpenKeys, latestOpenKey] : []);
            }
        }
    };

    return (
        <div ref={wrapperRef}>
            <Sider width={400} breakpoint="lg" trigger={null} collapsible collapsed={collapsed} className="layout-container">
                <div className="logo">
                    {collapsed ?
                        <Button onClick={toggleCollpased} icon={<HomeFilled className="icon" />} size="large" className="button-home-icon" />
                        :
                        <Link onClick={redirectToHome}><OASELogo white={true} props={{ height: '90px', width: "100%" }} /></Link>

                    }
                </div>
                <Divider orientation="center" className="logo-divider" />
                <Menu
                    openKeys={openKeys}
                    triggerSubMenuAction={['click']}
                    theme="light"
                    mode="inline"
                    items={items}
                    onClick={handleMenuClick}
                    className="sidenav-menu"
                    onOpenChange={onOpenChange}
                    expandIcon={
                        (props) => {
                            return !props.isOpen ? <RightOutlined /> : <DownOutlined />
                        }
                    }
                />
            </Sider>
        </div>
    );
}

export default Sidenav;
