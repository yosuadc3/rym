import Button from "@mui/material/Button";
import React from "react";

const styles = {
	btn: function (isOutlined, primary, danger) {
		const color = primary && isOutlined ? "#0d5cab" : danger && isOutlined ? "#b91c1c" : (!primary && !danger) ? "black" : "white"; 
		const backgroundColor = isOutlined ? "white" : primary ? "#0D5CAB" : danger ? "#B91C1C" : "white";
		const borderColor = primary && isOutlined ? "#0d5cab" : danger && isOutlined ? "#b91c1c" : (!primary && !danger) ? "black" : "white"; 
		const hoverBackgroundColor = isOutlined ? "white" : primary ? "#125FA1" : danger ? "#B91C1C" : "white";
		const activeBackgroundColor = isOutlined ? hoverBackgroundColor : primary ? "#125FA1" : danger ? "#B91C1C" : hoverBackgroundColor;

		return {
			textTransform: "inherit",
			width: "100%",
			border: `1px solid ${backgroundColor}`,
			borderRadius: 1,
			borderColor,
			backgroundColor,
			color,
			"&:hover": {
				backgroundColor: hoverBackgroundColor,
			},
			"&:active": {
				backgroundColor: activeBackgroundColor,
			},
         "&:disabled": {
				border: "none",
            backgroundColor: "#EFEFEF"
         }
		};
	},
};

export default function FormButton({
   primary = false,
   danger = false,
	isOutlined = false,
	disabled = false,
	onClick,
	label,
}) {
	return (
		<Button sx={styles.btn(isOutlined, primary, danger)} onClick={onClick} disabled={disabled}>
			{label}
		</Button>
	);
}
