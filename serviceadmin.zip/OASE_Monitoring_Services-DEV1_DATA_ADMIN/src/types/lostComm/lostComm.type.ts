import { Request } from "express";
import { IUser } from "../global.type";

export interface IGetLostCommRequest
	extends IUser,
	Request<any, any, any, any, any> { }

export interface IGetLostCommReportRequest
	extends IUser,
	Request<any, any, any, any, any> { }
