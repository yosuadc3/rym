import FilterListIcon from '@mui/icons-material/FilterList';
import { Box, Grid, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useSelector } from 'react-redux';
import CustomBreadcrumbs from "../../../components/breadcrumb/CustomBreadcrumbs";
import ButtonCommon from "../../../components/buttons/ButtonCommon";
// import { useGetReportFiltersQuery, useGetReportTypeQuery } from "../../../redux/features/report/atlas/api/reportAtlas";
import ReportFilter from "./components/filter/ReportFilter";
import ReportTable from "./components/table/ReportTable";

const breadcrumbs = [
    {
        item: "Home",
        link: "/",
        current: false
    },
    {
        item: "Report Atlas",
        link: null,
        current: true
    }
];

const styles = {
    buttonFilter: {
        fontWeight: "bold"
    },
    textTitle: {
        fontSize: "20px",
        fontWeight: "bold"
    },
    textDescription: {
        fontSize: "12px"
    },
    gridFilter: (show) => ({
        display: {
            xs: show ? "block" : "none",
        }
    })
}

function ReportAtlas() {
    const [length, setLength] = useState({ data: null, total: null });
    const filter = useSelector((state) => state.reportAtlas.filter);
    const [flagShowFilter, setFlagShowFilter] = useState(true);
    const { data: reportTypeData, isLoading: typeIsLoading } = useGetReportTypeQuery();
    const { data: filterData, isLoading: filterIsLoading } = useGetReportFiltersQuery(selectedType, { skip: skipUseQuery });

    useEffect(() => {
        if (filter) {
            setFlagShowFilter(false);
        }
    }, [filter]);

    const handleShowFilter = () => {
        setFlagShowFilter(flag => !flag);
    }

    return (
        <>
            <Grid container alignItems={"center"} height={60}>
                <Grid item xs>
                    <CustomBreadcrumbs breadcrumbs={breadcrumbs} />
                </Grid>
            </Grid>
            <Grid container marginBottom={2} >
                <ButtonCommon
                    handleClick={handleShowFilter}
                    label={"Filter"}
                    variant={"outlined"}
                    startIcon={<FilterListIcon sx={{ transform: "scale(1.5)" }} />}
                    sx={styles.buttonFilter}
                />
                {filter && length.data > 0 && length.total > 0 && (
                    <Box marginLeft={2} textAlign={"left"}>
                        <Typography sx={styles.textTitle}>
                            Report DSA Monitoring
                        </Typography>
                        <Typography sx={styles.textDescription}>
                            Data yang ditampilkan {length.data < 10 ? length.data : 10} dari {length.total} record, untuk melihat lebih lengkap dapat klik ‘Download File’
                        </Typography>
                    </Box>
                )}
            </Grid>
            <Grid container>
                <Grid item xs={3} paddingRight={2} sx={styles.gridFilter(flagShowFilter)}>
                    <ReportFilter />
                </Grid>
                <Grid item xs={flagShowFilter ? 9 : 12}>
                    {filter && (
                        <ReportTable
                            getLength={(length) => setLength(length)}
                        />
                    )}
                </Grid>
            </Grid>
        </>
    );
}

export default ReportAtlas;
